// Arcade Rogue

// This is designed for the Math Day presentation in April 2015, along side the "Arena" game developed.

// This is a rogue-like game, and was originally named "Scoundrel".  You must descend down 5 levels, get the Amulet of Yendor,
// then re-ascend back the surface to win.

// Things are not perfect in this game, and the code is very spagetti like (especially with the arrows!!!) but it functions solidly none-the-less.

// Some particulars:
//	- Arrows can be shot at any time
//	- Weapons and Armor are pickups and cannot be placed in inventory
//	- Scrolls always teleport, potions always heal
//	- Gold is only for scoring purposes
//	- This game is very hard

// Some things I found out already:
//	- A goblin at Depth 1 can kill a player that is completely unequipped
//	- Food seems well enough but if used to 'heal', it can run out very quickly
//	- Stocking up on scrolls and potions before hitting Depth 5 is VERY important
//	- Nymphs can supply a great deal of scrolls and potions
//	- Vampires are a great way to get equipment on Depth 4 (after Amoebas and Nymphs take everything else)
//	- Leather armor is actually fairly important and useful because it will not rust
//	- Trolls are very strong, especially in numbers
//	- You can block faster creatures using slower creatures in their path
//	- Mummys when grabbing you will not let you teleport
//	- Depth 5 is basically just running around without dying, attempts at killing all creatures is futile unless you have proper equipment
//	- The re-ascent is easier than Depth 5, but still has a great deal of creatures, any remaining scrolls come in handy
//	- On Depth 5 you must get the Amulet of Yendor first before re-ascending.  Memory location of the upstairs helps though.

// As of 12/27/2014 at 10:28am (in Kansas!), I have not beat this game.

// This could be considered a 7DRL (from RogueBasin.com).  Basically it was made in 5 days: Tuesday Dec 23rd 2014 to Saturday Dec 27th 2014. 

// On Monday Dec 29th 2014, I am changing the controls to fit to my detachable Numpad.  And changed the 'explain' a little.  That is it :)

// It will be altered a bit for here and there purposes, to make it more fun.  Then it will be transferred over to OpenGL graphics to make it scalable and bigger to view.
// Also a lot of the messages will be synced better and stay longer, perhaps even a previous log system.  The USB Numpad will definitely be used as a controller.
// Eventually even sprites could be used instead of letters, and the graphic display can be switched by a button.  Perhaps even some 'animations' and sound effects? :)


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>


const int MAP_X = 78;
const int MAP_Y = 21;

int map_tile[MAP_X][MAP_Y];
int map_fog[MAP_X][MAP_Y];
int map_memory[MAP_X][MAP_Y];

int monster_class[MAP_X][MAP_Y];
int monster_behavior[MAP_X][MAP_Y];
int monster_health[MAP_X][MAP_Y];
int monster_moved[MAP_X][MAP_Y];

int item_description[MAP_X][MAP_Y];

int pos_x, pos_y;
int player_health, player_max_health;
int player_weapon, player_armor;
int player_level, player_experience;
int player_arrows, player_gold;
int player_depth, player_direction;
int player_turns, player_food;
int player_potions, player_scrolls;
bool player_cannot_move;
bool player_has_amulet_of_yendor = false;

bool key_pressed = false;
bool action_done = false;


const int TILE_CLOSED = 0;
const int TILE_OPEN = 1;
const int TILE_DOOR = 2;
const int TILE_UPSTAIRS = 3;
const int TILE_DOWNSTAIRS = 4;
const int TILE_SECRET = 5;

const int CLASS_NONE = 0;
const int CLASS_AMOEBA = 1;
const int CLASS_BAT = 2;
const int CLASS_FUNGUS = 3;
const int CLASS_GOBLIN = 4;
const int CLASS_JAGUAR = 5;
const int CLASS_MUMMY = 6;
const int CLASS_NYMPH = 7;
const int CLASS_ORC = 8;
const int CLASS_SNAKE = 9;
const int CLASS_TROLL = 10;
const int CLASS_VAMPIRE = 11;
const int CLASS_ZOMBIE = 12;

const int EXPERIENCE_NONE = 0;
const int EXPERIENCE_AMOEBA = 4;
const int EXPERIENCE_BAT = 2;
const int EXPERIENCE_FUNGUS = 1;
const int EXPERIENCE_GOBLIN = 4;
const int EXPERIENCE_JAGUAR = 8;
const int EXPERIENCE_MUMMY = 6;
const int EXPERIENCE_NYMPH = 5;
const int EXPERIENCE_ORC = 6;
const int EXPERIENCE_SNAKE = 7;
const int EXPERIENCE_TROLL = 15;
const int EXPERIENCE_VAMPIRE = 10;
const int EXPERIENCE_ZOMBIE = 4;

const int BEHAVIOR_PASSIVE = 0;
const int BEHAVIOR_MOVING = 1;
const int BEHAVIOR_CHASING = 2;
const int BEHAVIOR_RANDOM_SLOW = 3;
const int BEHAVIOR_FAST = 4;
const int BEHAVIOR_FLEE = 5;

const int DESCRIPTION_NONE = 0;
const int DESCRIPTION_DAGGER = 1;
const int DESCRIPTION_MACE = 2;
const int DESCRIPTION_AXE = 3;
const int DESCRIPTION_SWORD = 4;
const int DESCRIPTION_LEATHER = 5;
const int DESCRIPTION_CHAINMAIL = 6;
const int DESCRIPTION_PLATE = 7;
const int DESCRIPTION_QUIVER = 8;
const int DESCRIPTION_GOLD = 9;
const int DESCRIPTION_FOOD = 10;
const int DESCRIPTION_POTION = 11;
const int DESCRIPTION_SCROLL = 12;
const int DESCRIPTION_AMULET_OF_YENDOR = 13;

// x2 - x1 <= 2
void CreateHorizontalPath(int x1, int y1, int x2, int y2)
{
	int dist;

	if (x2 - x1 >= 2) 
	{
		dist = rand() % (x2 - x1 - 1) + 1;

		for (int i=x1; i<=x1+dist; i++)
		{
			map_tile[i][y1] = TILE_OPEN;
		}

		if (y1 <= y2)
		{
			for (int j=y1; j<=y2; j++)
			{
				map_tile[x1+dist][j] = TILE_OPEN;
			}
		}
		else
		{
			for (int j=y2; j<=y1; j++)
			{
				map_tile[x1+dist][j] = TILE_OPEN;
			}
		}

		for (int i=x1+dist+1; i<=x2; i++)
		{
			map_tile[i][y2] = TILE_OPEN;
		}
	}

	return;	
};

// y2 - y1 <= 2
void CreateVerticalPath(int x1, int y1, int x2, int y2)
{	
	int dist;

	if (y2 - y1 >= 2) 
	{
		dist = rand() % (y2 - y1 - 1) + 1;

		for (int j=y1; j<=y1+dist; j++)
		{
			map_tile[x1][j] = TILE_OPEN;
		}
		
		if (x1 <= x2)
		{
			for (int i=x1; i<=x2; i++)
			{
				map_tile[i][y1+dist] = TILE_OPEN;
			}
		}
		else
		{
			for (int i=x2; i<=x1; i++)
			{
				map_tile[i][y1+dist] = TILE_OPEN;
			}
		}

		for (int j=y1+dist; j<=y2; j++)
		{
			map_tile[x2][j] = TILE_OPEN;
		}
	}

	return;
};

// creates 3x3 grid of rooms, somewhat connected
void CreateGridRooms()
{	
	int x1[3][3], y1[3][3], x2[3][3], y2[3][3];
	bool tiny[3][3];
	int temp, temp2;

	// make all connected/disconnected pathways
	int disconnected_outside_hv = rand() % 2;
	int disconnected_outside_t = rand() % 2;
	int disconnected_outside_xy = rand() % 3;

	int connected_inside[4];

	for (int i=0; i<4; i++) connected_inside[i] = 0;

	connected_inside[rand() % 4] = 1;

	for (int i=0; i<4; i++) if (rand() % 100 < 25) connected_inside[i] = 1;

	// initialize tiles
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			map_tile[i][j] = TILE_CLOSED;

			map_fog[i][j] = -1; // won't stay like this

			map_memory[i][j] = false;
		}
	}

	// create the rooms
	for (int x=0; x<3; x++)
	{
		for (int y=0; y<3; y++)
		{
			tiny[x][y] = false;

			// give each a second chance at big-ness
			x1[x][y] = rand() % (MAP_X/3 - 2) + (MAP_X/3)*x + 1;
			temp = rand() % (MAP_X/3 - 2) + (MAP_X/3)*x + 1;
			if (temp < x1[x][y]) x1[x][y] = temp;			

			y1[x][y] = rand() % (MAP_Y/3 - 2) + (MAP_Y/3)*y + 1;
			temp = rand() % (MAP_Y/3 - 2) + (MAP_Y/3)*y + 1;
			if (temp < y1[x][y]) y1[x][y] = temp;

			x2[x][y] = rand() % (MAP_X/3 - 2) + (MAP_X/3)*x + 1;
			temp = rand() % (MAP_X/3 - 2) + (MAP_X/3)*x + 1;
			if (temp > x2[x][y]) x2[x][y] = temp;

			y2[x][y] = rand() % (MAP_Y/3 - 2) + (MAP_Y/3)*y + 1;
			temp = rand() % (MAP_Y/3 - 2) + (MAP_Y/3)*y + 1;
			if (temp > y2[x][y]) y2[x][y] = temp;

			if (x1[x][y] > x2[x][y]) { temp = x1[x][y]; x1[x][y] = x2[x][y]; x2[x][y] = temp; }
			if (y1[x][y] > y2[x][y]) { temp = y1[x][y]; y1[x][y] = y2[x][y]; y2[x][y] = temp; }
		}
	}

	// spacing the rooms
	for (int x=0; x<3; x++)
	{
		for (int y=0; y<3; y++)
		{
			if (x > 0) 
			{
				while (x1[x][y] - x2[x-1][y] <= 3)
				{
					if (rand() % 100 < 50) 
					{
						if (x1[x][y] == x2[x][y]) { x1[x][y] += 1; x2[x][y] += 1; }
						else x1[x][y] += 1;
					}
					else 
					{
						if (x1[x-1][y] == x2[x-1][y]) { x1[x-1][y] -= 1; x2[x-1][y] -= 1; }
						else x2[x-1][y] -= 1;
					}
				}
			}
			if (y > 0) 
			{
				while (y1[x][y] - y2[x][y-1] <= 3)
				{
					if (rand() % 100 < 50)
					{
						if (y1[x][y] == y2[x][y]) { y1[x][y] += 1; y2[x][y] += 1; }
						else y1[x][y] += 1;
					}
					else
					{
						if (y1[x][y-1] == y2[x][y-1]) { y1[x][y-1] -= 1; y2[x][y-1] -= 1; }
						else y2[x][y-1] -= 1;
					}
				}
			}
		}
	}

	// rooms vs hallways
	for (int x=0; x<3; x++)
	{
		for (int y=0; y<3; y++)
		{
			if (x1[x][y] == x2[x][y]) { y1[x][y] = y2[x][y]; tiny[x][y] = true; }
			if (y1[x][y] == y2[x][y]) { x1[x][y] = x2[x][y]; tiny[x][y] = true; }
		}
	}

	// opening up rooms
	for (int x=0; x<3; x++)
	{
		for (int y=0; y<3; y++)
		{
			if (rand() % 100 < 75) temp = 0;
			else temp = rand() % 10 + 1;

			for (int i=x1[x][y]; i<=x2[x][y]; i++)
			{
				for (int j=y1[x][y]; j<=y2[x][y]; j++)
				{
					map_tile[i][j] = TILE_OPEN;

					map_fog[i][j] = temp;
				}
			}
		}
	}

	if (player_direction == -1)
	{
		// up stairs
		temp = rand() % MAP_X;
		temp2 = rand() % MAP_Y;

		while (map_tile[temp][temp2] != TILE_OPEN) { temp = rand() % MAP_X; temp2 = rand() % MAP_Y; }
		map_tile[temp][temp2] = TILE_UPSTAIRS;
	}	
	else if (player_direction == 1)
	{
		// down stairs
		temp = rand() % MAP_X;
		temp2 = rand() % MAP_Y;

		while (map_tile[temp][temp2] != TILE_OPEN) { temp = rand() % MAP_X; temp2 = rand() % MAP_Y; }
		map_tile[temp][temp2] = TILE_DOWNSTAIRS;
	}

	// horizontal lines
	for (int t=0; t<2; t++)
	{
		for (int y=0; y<3; y++)
		{
			if (y != 1 && disconnected_outside_hv == 0 && 
				disconnected_outside_t == t && 
				disconnected_outside_xy == y)
			{
				// do nothing
			}
			else if (y == 1 && connected_inside[t] == 0)
			{
				// do nothing
			}
			else
			{
				temp = rand() % (y2[t][y] - y1[t][y] + 1) + y1[t][y];
		
				temp2 = rand() % (y2[t+1][y] - y1[t+1][y] + 1) + y1[t+1][y];

				CreateHorizontalPath(x2[t][y]+1, temp, x1[t+1][y]-1, temp2);

				if (tiny[t][y] == false) map_tile[x2[t][y]+1][temp] = TILE_DOOR;
				if (tiny[t+1][y] == false) map_tile[x1[t+1][y]-1][temp2] = TILE_DOOR;
			}
		}
	}

	// vertical lines
	for (int x=0; x<3; x++)
	{
		for (int t=0; t<2; t++)
		{
			if (x != 1 && disconnected_outside_hv == 1 &&
				disconnected_outside_t == t &&
				disconnected_outside_xy == x)
			{
				// do nothing
			}
			else if (x == 1 && connected_inside[t+2] == 0)
			{
				// do nothing
			}
			else
			{
				temp = rand() % (x2[x][t] - x1[x][t] + 1) + x1[x][t];
			
				temp2 = rand() % (x2[x][t+1] - x1[x][t+1] + 1) + x1[x][t+1];
		
				CreateVerticalPath(temp, y2[x][t]+1, temp2, y1[x][t+1]-1);

				if (tiny[x][t] == false) map_tile[temp][y2[x][t]+1] = TILE_DOOR;
				if (tiny[x][t+1] == false) map_tile[temp2][y1[x][t+1]-1] = TILE_DOOR;
			}
		}
	}

	// create fog for everything outside of the rooms
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_CLOSED) map_fog[i][j] = 100;
			else if (map_tile[i][j] == TILE_OPEN && map_fog[i][j] == -1) map_fog[i][j] = 10; // only pathways here
			else if (map_tile[i][j] == TILE_DOOR) map_fog[i][j] = 100;
			else if (map_tile[i][j] == TILE_UPSTAIRS) map_fog[i][j] = 1;
			else if (map_tile[i][j] == TILE_DOWNSTAIRS) map_fog[i][j] = 1;
		}
	}

	// spread out secret walls
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN && player_depth > 1)
			{
				if (i-1 >= 0 && i+1 < MAP_X && j-1 >= 0 && j+1 < MAP_Y)
				{
					if (map_tile[i-1][j] == TILE_OPEN && map_tile[i+1][j] == TILE_OPEN &&
						map_tile[i][j-1] == TILE_CLOSED && map_tile[i][j+1] == TILE_CLOSED)
					{
						if (rand() % 100 < 3)
						{
							map_tile[i][j] = TILE_SECRET;
						}
					}
					else if (map_tile[i-1][j] == TILE_CLOSED && map_tile[i+1][j] == TILE_CLOSED &&
						map_tile[i][j-1] == TILE_OPEN && map_tile[i][j+1] == TILE_OPEN)
					{
						if (rand() % 100 < 3)
						{
							map_tile[i][j] = TILE_SECRET;
						}
					}
				}
			}
			else if (map_tile[i][j] == TILE_DOOR && player_depth > 1)
			{
				if (rand() % 100 < 10)
				{
					map_tile[i][j] = TILE_SECRET;
				}
			}
		}
	}
/*
	// initialize the character position
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_UPSTAIRS)
			{
				pos_x = i;
				pos_y = j;
			}
		}
	}
*/
	// initialize the character position
	temp = 0;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN)
			{
				temp += 1;
			}
		}
	}

	temp2 = rand() % temp;

	temp = 0;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN)
			{
				if (temp2 == temp)
				{
					pos_x = i;
					pos_y = j;

					i = MAP_X + 1;
					j = MAP_Y + 1;
				}

				temp += 1;
			}
		}
	}

	return;
};

// very open, pillars and nooks everywhere
void CreateLargeCavern()
{
	int count, value;

	int temp, temp2;

	// initialize tiles
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			map_tile[i][j] = TILE_OPEN;

			map_memory[i][j] = false;
		}
	}

	// place a few pillars out there
	for (int loop=0; loop<20; loop++)
	{
		map_tile[rand()%MAP_X][rand()%MAP_Y] = TILE_CLOSED;
	}

	// random chance to fill in next to pillars
	for (int loop=0; loop<100; loop++)
	{
		count = 0;

		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_CLOSED) count++;
			}
		}

		value = rand() % count;

		count = 0;

		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_CLOSED)
				{
					if (value == count)
					{
						for (int x=-1; x<=1; x++)
						{
							for (int y=-1; y<=1; y++)
							{
								if (i+x >= 0 && i+x < MAP_X &&
									j+y >= 0 && j+y < MAP_Y)
								{
									if (rand() % 100 < 75) map_tile[i+x][j+y] = TILE_CLOSED;
								}
							}
						}

						i = MAP_X + 1;
						j = MAP_Y + 1;
					}

					count++;
				}
			}
		}
	}
					
	// sides are closed off
	for (int i=0; i<MAP_X; i++)
	{
		map_tile[i][0] = TILE_CLOSED;
		map_tile[i][MAP_Y-1] = TILE_CLOSED;
	}

	for (int j=0; j<MAP_Y; j++)
	{
		map_tile[0][j] = TILE_CLOSED;
		map_tile[MAP_X-1][j] = TILE_CLOSED;
	}

	// repeat again for sides and pillars now
	for (int loop=0; loop<100; loop++)
	{
		count = 0;

		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_CLOSED) count++;
			}
		}

		value = rand() % count;

		count = 0;

		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_CLOSED)
				{
					if (value == count)
					{
						for (int x=-1; x<=1; x++)
						{
							for (int y=-1; y<=1; y++)
							{
								if (i+x >= 0 && i+x < MAP_X &&
									j+y >= 0 && j+y < MAP_Y)
								{
									if (rand() % 100 < 50) map_tile[i+x][j+y] = TILE_CLOSED;
								}
							}
						}

						i = MAP_X + 1;
						j = MAP_Y + 1;
					}

					count++;
				}
			}
		}
	}

	// pick a nice spot to flood fill cavern
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN)
			{
				if (i-2 >= 0 && i+2 < MAP_X && j-2 >= 0 && j+2 < MAP_Y)
				{
					if (map_tile[i-1][j] == TILE_OPEN &&
						map_tile[i-2][j] == TILE_OPEN &&
						map_tile[i+1][j] == TILE_OPEN &&
						map_tile[i+2][j] == TILE_OPEN &&
						map_tile[i][j-1] == TILE_OPEN &&
						map_tile[i][j-2] == TILE_OPEN &&
						map_tile[i][j+1] == TILE_OPEN &&
						map_tile[i][j+2] == TILE_OPEN)
					{
						map_tile[i][j] = TILE_DOOR; // temporary
					}
				}
			}
		}
	}

	// flood fill cavern
	for (int loop=0; loop<(MAP_X*MAP_Y); loop++)
	{
		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_DOOR)
				{
					if (i-1 >= 0) if (map_tile[i-1][j] == TILE_OPEN) map_tile[i-1][j] = TILE_DOOR;
					if (i+1 < MAP_X) if (map_tile[i+1][j] == TILE_OPEN) map_tile[i+1][j] = TILE_DOOR;
					if (j-1 >= 0) if (map_tile[i][j-1] == TILE_OPEN) map_tile[i][j-1] = TILE_DOOR;
					if (j+1 < MAP_Y) if (map_tile[i][j+1] == TILE_OPEN) map_tile[i][j+1] = TILE_DOOR;
					if (i-1 >= 0 && j-1 >= 0) if (map_tile[i-1][j-1] == TILE_OPEN) map_tile[i-1][j-1] = TILE_DOOR;
					if (i+1 < MAP_X && j-1 >= 0) if (map_tile[i+1][j-1] == TILE_OPEN) map_tile[i+1][j-1] = TILE_DOOR;
					if (i-1 >= 0 && j+1 < MAP_Y) if (map_tile[i-1][j+1] == TILE_OPEN) map_tile[i-1][j+1] = TILE_DOOR;
					if (i+1 < MAP_X && j+1 < MAP_Y) if (map_tile[i+1][j+1] == TILE_OPEN) map_tile[i+1][j+1] = TILE_DOOR;
				}
			}
		}
	}

	// switch it all up
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN) map_tile[i][j] = TILE_CLOSED;
			else if (map_tile[i][j] == TILE_DOOR) map_tile[i][j] = TILE_OPEN;
		}
	}

	if (player_direction == -1)
	{
		// up stairs
		temp = rand() % MAP_X;
		temp2 = rand() % MAP_Y;

		while (map_tile[temp][temp2] != TILE_OPEN) { temp = rand() % MAP_X; temp2 = rand() % MAP_Y; }
		map_tile[temp][temp2] = TILE_UPSTAIRS;
	}	
	else if (player_direction == 1)
	{
		// down stairs
		temp = rand() % MAP_X;
		temp2 = rand() % MAP_Y;

		while (map_tile[temp][temp2] != TILE_OPEN) { temp = rand() % MAP_X; temp2 = rand() % MAP_Y; }
		map_tile[temp][temp2] = TILE_DOWNSTAIRS;
	}

	// create fog for everything outside of the rooms
	//value = rand() % 11;
	value = 2;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_CLOSED) map_fog[i][j] = 100;
			else if (map_tile[i][j] == TILE_OPEN) map_fog[i][j] = value;
			else if (map_tile[i][j] == TILE_UPSTAIRS) map_fog[i][j] = 1;
			else if (map_tile[i][j] == TILE_DOWNSTAIRS) map_fog[i][j] = 1;
			else if (map_tile[i][j] == TILE_SECRET) map_fog[i][j] = 100;
		}
	}
/*
	// initialize the character position
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_UPSTAIRS)
			{
				pos_x = i;
				pos_y = j;
			}
		}
	}
*/
	// initialize the character position
	temp = 0;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN)
			{
				temp += 1;
			}
		}
	}

	temp2 = rand() % temp;

	temp = 0;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN)
			{
				if (temp2 == temp)
				{
					pos_x = i;
					pos_y = j;

					i = MAP_X + 1;
					j = MAP_Y + 1;
				}

				temp += 1;
			}
		}
	}

	return;
};

// put monsters throughout space
void SpreadMonsters()
{
	int number, type, temp_depth;
	
	// initialize
	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			monster_class[i][j] = CLASS_NONE;
			monster_behavior[i][j] = BEHAVIOR_PASSIVE;
			monster_health[i][j] = 0;
		}
	}

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			// more creatures on the return path
			if (map_tile[i][j] == TILE_OPEN && rand() % 100 < 3 + 
				(player_direction==-1&&player_depth<5?1:0) + (player_depth==5?-1:0))
			{
				type = CLASS_NONE;

				number = rand() % 1000;

				// put in all kinds of creatures when returning
				if (player_direction == -1 && player_depth < 5)
				{
					temp_depth = player_depth;

					player_depth = rand() % 5 + 1;
				}

				// pick a monster for it's level
				if (player_depth == 1)
				{
					if (number < 400) type = CLASS_BAT;
					else if (number < 700) type = CLASS_FUNGUS;
					else if (number < 1000) type = CLASS_GOBLIN;
				}
				else if (player_depth == 2)
				{
					if (number < 300) type = CLASS_BAT;
					else if (number < 500) type = CLASS_GOBLIN;
					else if (number < 700) type = CLASS_ORC;
					else if (number < 1000) type = CLASS_ZOMBIE;
				}
				else if (player_depth == 3)
				{
					if (number < 200) type = CLASS_AMOEBA;
					else if (number < 400) type = CLASS_MUMMY;
					else if (number < 500) type = CLASS_ORC;
					else if (number < 700) type = CLASS_NYMPH;
					else if (number < 800) type = CLASS_SNAKE;
					else if (number < 1000) type = CLASS_ZOMBIE;
				}
				else if (player_depth == 4)
				{
					if (number < 200) type = CLASS_AMOEBA;
					else if (number < 300) type = CLASS_JAGUAR;
					else if (number < 500) type = CLASS_MUMMY;
					else if (number < 700) type = CLASS_NYMPH;
					else if (number < 900) type = CLASS_SNAKE;
					else if (number < 1000) type = CLASS_VAMPIRE;
				}
				else if (player_depth == 5)
				{
					if (number < 400) type = CLASS_JAGUAR;
					else if (number < 800) type = CLASS_TROLL;
					else if (number < 1000) type = CLASS_VAMPIRE;
				}

				// make sure the value is returned
				if (player_direction == -1 && player_depth < 5)
				{
					player_depth = temp_depth;
				}

				// health and behavior of each monster
				if (type == CLASS_AMOEBA)
				{
					monster_class[i][j] = CLASS_AMOEBA;
					monster_behavior[i][j] = BEHAVIOR_RANDOM_SLOW;
					monster_health[i][j] = 0;
					for (int k=0; k<2; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_BAT)
				{
					monster_class[i][j] = CLASS_BAT;
					monster_behavior[i][j] = BEHAVIOR_MOVING;
					monster_health[i][j] = 0;
					for (int k=0; k<1; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_FUNGUS)
				{
					monster_class[i][j] = CLASS_FUNGUS;
					monster_behavior[i][j] = BEHAVIOR_PASSIVE;
					monster_health[i][j] = 0;
					for (int k=0; k<2; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_GOBLIN) 
				{
					monster_class[i][j] = CLASS_GOBLIN;
					monster_behavior[i][j] = BEHAVIOR_MOVING;
					monster_health[i][j] = 0;
					for (int k=0; k<3; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_JAGUAR)
				{
					monster_class[i][j] = CLASS_JAGUAR;
					monster_behavior[i][j] = BEHAVIOR_FAST;
					monster_health[i][j] = 0;
					for (int k=0; k<4; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_MUMMY)
				{
					monster_class[i][j] = CLASS_MUMMY;
					monster_behavior[i][j] = BEHAVIOR_RANDOM_SLOW;
					monster_health[i][j] = 0;
					for (int k=0; k<6; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_NYMPH)
				{
					monster_class[i][j] = CLASS_NYMPH;
					monster_behavior[i][j] = BEHAVIOR_MOVING;
					monster_health[i][j] = 0;
					for (int k=0; k<2; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_ORC)
				{
					monster_class[i][j] = CLASS_ORC;
					monster_behavior[i][j] = BEHAVIOR_CHASING;
					monster_health[i][j] = 0;
					for (int k=0; k<4; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_SNAKE)
				{
					monster_class[i][j] = CLASS_SNAKE;
					monster_behavior[i][j] = BEHAVIOR_FAST;
					monster_health[i][j] = 0;
					for (int k=0; k<2; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_TROLL)
				{
					monster_class[i][j] = CLASS_TROLL;
					monster_behavior[i][j] = BEHAVIOR_CHASING;
					monster_health[i][j] = 0;
					for (int k=0; k<6; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_VAMPIRE)
				{
					monster_class[i][j] = CLASS_VAMPIRE;
					monster_behavior[i][j] = BEHAVIOR_PASSIVE;
					monster_health[i][j] = 0;
					for (int k=0; k<5; k++) monster_health[i][j] += rand() % 8 + 1;
				}
				else if (type == CLASS_ZOMBIE)
				{
					monster_class[i][j] = CLASS_ZOMBIE;
					monster_behavior[i][j] = BEHAVIOR_RANDOM_SLOW;
					monster_health[i][j] = 0;
					for (int k=0; k<3; k++) monster_health[i][j] += rand() % 8 + 1;
				}

				monster_moved[i][j] = false;
			}
			else monster_class[i][j] = CLASS_NONE;
		}
	}

	return;
};

// put one monster out there
void PlaceCreature()
{
	int number, type, temp_depth;
	
	int x = 1, y = 1;

	// find a place away from player
	number = 0;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN && monster_class[i][j] == CLASS_NONE && abs(pos_x - i) + abs(pos_y - j) > 20)
			{
				number += 1;
			}
		}
	}

	type = rand() % number;

	number = 0;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN && monster_class[i][j] == CLASS_NONE && abs(pos_x - i) + abs(pos_y - j) > 20)
			{
				if (type == number)
				{
					x = i;
					y = j;
				}

				number += 1;
			}
		}
	}
	
	type = CLASS_NONE;

	number = rand() % 1000;

	// all kinds of creatures on the return
	if (player_direction == -1 && player_depth < 5)
	{
		temp_depth = player_depth;

		player_depth = rand() % 5 + 1;
	}

	// pick a monster for it's level
	if (player_depth == 1)
	{
		if (number < 400) type = CLASS_BAT;
		else if (number < 700) type = CLASS_FUNGUS;
		else if (number < 1000) type = CLASS_GOBLIN;
	}
	else if (player_depth == 2)
	{
		if (number < 300) type = CLASS_BAT;
		else if (number < 500) type = CLASS_GOBLIN;
		else if (number < 700) type = CLASS_ORC;
		else if (number < 1000) type = CLASS_ZOMBIE;
	}
	else if (player_depth == 3)
	{
		if (number < 200) type = CLASS_AMOEBA;
		else if (number < 400) type = CLASS_MUMMY;
		else if (number < 500) type = CLASS_ORC;
		else if (number < 700) type = CLASS_NYMPH;
		else if (number < 800) type = CLASS_SNAKE;
		else if (number < 1000) type = CLASS_ZOMBIE;
	}
	else if (player_depth == 4)
	{
		if (number < 200) type = CLASS_AMOEBA;
		else if (number < 300) type = CLASS_JAGUAR;
		else if (number < 500) type = CLASS_MUMMY;
		else if (number < 700) type = CLASS_NYMPH;
		else if (number < 900) type = CLASS_SNAKE;
		else if (number < 1000) type = CLASS_VAMPIRE;
	}
	else if (player_depth == 5)
	{
		if (number < 200) type = CLASS_JAGUAR;
		else if (number < 400) type = CLASS_SNAKE;
		else if (number < 800) type = CLASS_TROLL;
		else if (number < 1000) type = CLASS_VAMPIRE;
	}

	// make sure the value is put back
	if (player_direction == -1 && player_depth < 5)
	{
		player_depth = temp_depth;
	}

	// monster health and behavior
	if (type == CLASS_AMOEBA)
	{
		monster_class[x][y] = CLASS_AMOEBA;
		monster_behavior[x][y] = BEHAVIOR_RANDOM_SLOW;
		monster_health[x][y] = 0;
		for (int k=0; k<2; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_BAT)
	{
		monster_class[x][y] = CLASS_BAT;
		monster_behavior[x][y] = BEHAVIOR_MOVING;
		monster_health[x][y] = 0;
		for (int k=0; k<1; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_FUNGUS)
	{
		monster_class[x][y] = CLASS_FUNGUS;
		monster_behavior[x][y] = BEHAVIOR_PASSIVE;
		monster_health[x][y] = 0;
		for (int k=0; k<2; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_GOBLIN) 
	{
		monster_class[x][y] = CLASS_GOBLIN;
		monster_behavior[x][y] = BEHAVIOR_MOVING;
		monster_health[x][y] = 0;
		for (int k=0; k<3; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_JAGUAR)
	{
		monster_class[x][y] = CLASS_JAGUAR;
		monster_behavior[x][y] = BEHAVIOR_FAST;
		monster_health[x][y] = 0;
		for (int k=0; k<4; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_MUMMY)
	{
		monster_class[x][y] = CLASS_MUMMY;
		monster_behavior[x][y] = BEHAVIOR_RANDOM_SLOW;
		monster_health[x][y] = 0;
		for (int k=0; k<6; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_NYMPH)
	{
		monster_class[x][y] = CLASS_NYMPH;
		monster_behavior[x][y] = BEHAVIOR_MOVING;
		monster_health[x][y] = 0;
		for (int k=0; k<2; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_ORC)
	{
		monster_class[x][y] = CLASS_ORC;
		monster_behavior[x][y] = BEHAVIOR_CHASING;
		monster_health[x][y] = 0;
		for (int k=0; k<4; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_SNAKE)
	{
		monster_class[x][y] = CLASS_SNAKE;
		monster_behavior[x][y] = BEHAVIOR_FAST;
		monster_health[x][y] = 0;
		for (int k=0; k<2; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_TROLL)
	{
		monster_class[x][y] = CLASS_TROLL;
		monster_behavior[x][y] = BEHAVIOR_CHASING;
		monster_health[x][y] = 0;
		for (int k=0; k<6; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_VAMPIRE)
	{
		monster_class[x][y] = CLASS_VAMPIRE;
		monster_behavior[x][y] = BEHAVIOR_PASSIVE;
		monster_health[x][y] = 0;
		for (int k=0; k<5; k++) monster_health[x][y] += rand() % 8 + 1;
	}
	else if (type == CLASS_ZOMBIE)
	{
		monster_class[x][y] = CLASS_ZOMBIE;
		monster_behavior[x][y] = BEHAVIOR_RANDOM_SLOW;
		monster_health[x][y] = 0;
		for (int k=0; k<3; k++) monster_health[x][y] += rand() % 8 + 1;
	}

	monster_moved[x][y] = false;

	return;
};

// move those monsters around however they are trained
void BehaviorAI()
{
	int x1, y1, x2, y2;

	bool attacked[MAP_X][MAP_Y];

	int number;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			attacked[i][j] = false;
		}
	}

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (monster_moved[i][j] == false)
			{
				monster_moved[i][j] = true;

				if (monster_behavior[i][j] == BEHAVIOR_PASSIVE) // standing still
				{
					// nothing
				}
				else if (monster_behavior[i][j] == BEHAVIOR_MOVING) // randomly moving around
				{
					x1 = rand() % 3 - 1 + i;
					y1 = rand() % 3 - 1 + j;
					
					if ((map_tile[x1][y1] == TILE_OPEN || map_tile[x1][y1] == TILE_DOOR ||
						map_tile[x1][y1] == TILE_UPSTAIRS || map_tile[x1][y1] == TILE_DOWNSTAIRS) && 
						monster_class[x1][y1] == CLASS_NONE)
					{
						if (pos_x == x1 && pos_y == y1)
						{
							attacked[i][j] = true;
						}
						else
						{
							// movement
							monster_class[x1][y1] = monster_class[i][j];
							monster_behavior[x1][y1] = monster_behavior[i][j];
							monster_health[x1][y1] = monster_health[i][j];
							monster_moved[x1][y1] = monster_moved[i][j];
	
							monster_class[i][j] = CLASS_NONE;
							monster_behavior[i][j] = BEHAVIOR_PASSIVE;
							monster_health[i][j] = 0;
							monster_moved[i][j] = false;
						}
					}
				}
				else if (monster_behavior[i][j] == BEHAVIOR_CHASING) // chase player down
				{
					if (abs(pos_x - i) + abs(pos_y - j) <= 20)
					{
						x1 = i;
						y1 = j;
	
						if (pos_x < i)
						{
							if (pos_y < j) { x1 = i-1; y1 = j-1; }
							else if (pos_y > j) { x1 = i-1; y1 = j+1; }
							else if (pos_y == j) { x1 = i-1; }
						}
						else if (pos_x > i)
						{
							if (pos_y < j) { x1 = i+1; y1 = j-1; }
							else if (pos_y > j) { x1 = i+1; y1 = j+1; }
							else if (pos_y == j) { x1 = i+1; }
						}
						else if (pos_x == i)
						{
							if (pos_y < j) { y1 = j-1; }
							else if (pos_y > j) { y1 = j+1; }
							else if (pos_y == j) { }
						}
						
						// fixing stupid behavior
						if (map_tile[x1][y1] == TILE_CLOSED || map_tile[x1][y1] == TILE_SECRET)
						{
							x1 = i;
							y1 = j;

							for (int x=-1; x<=1; x++)
							{
								for (int y=-1; y<=1; y++)
								{
									if (i+x >= 0 && i+x < MAP_X &&
										j+y >= 0 && j+y < MAP_Y)
									{
										if (map_tile[i+x][j+y] != TILE_CLOSED &&
											map_tile[i+x][j+y] != TILE_SECRET)
										{
											if (pow(pos_x - (i+x), 2.0f) + pow(pos_y - (j+y), 2.0f) <
												pow(pos_x - x1, 2.0f) + pow(pos_y - y1, 2.0f))
											{
												x1 = i+x;
												y1 = j+y;
											}
										}
									}
								}
							}
						}

						if ((map_tile[x1][y1] == TILE_OPEN || map_tile[x1][y1] == TILE_DOOR ||
							map_tile[x1][y1] == TILE_UPSTAIRS || map_tile[x1][y1] == TILE_DOWNSTAIRS) && 
							monster_class[x1][y1] == CLASS_NONE)
						{
							if (pos_x == x1 && pos_y == y1)
							{
								attacked[i][j] = true;
							}
							else
							{
								// movement
								monster_class[x1][y1] = monster_class[i][j];
								monster_behavior[x1][y1] = monster_behavior[i][j];
								monster_health[x1][y1] = monster_health[i][j];
								monster_moved[x1][y1] = monster_moved[i][j];
		
								monster_class[i][j] = CLASS_NONE;
								monster_behavior[i][j] = BEHAVIOR_PASSIVE;
								monster_health[i][j] = 0;
								monster_moved[i][j] = false;
							}
						}
					}
				}
				else if (monster_behavior[i][j] == BEHAVIOR_RANDOM_SLOW) // randomly slow
				{
					if (abs(pos_x - i) + abs(pos_y - j) <= 20 && rand() % 100 < 50)
					{
						x1 = i;
						y1 = j;
	
						if (pos_x < i)
						{
							if (pos_y < j) { x1 = i-1; y1 = j-1; }
							else if (pos_y > j) { x1 = i-1; y1 = j+1; }
							else if (pos_y == j) { x1 = i-1; }
						}
						else if (pos_x > i)
						{
							if (pos_y < j) { x1 = i+1; y1 = j-1; }
							else if (pos_y > j) { x1 = i+1; y1 = j+1; }
							else if (pos_y == j) { x1 = i+1; }
						}
						else if (pos_x == i)
						{
							if (pos_y < j) { y1 = j-1; }
							else if (pos_y > j) { y1 = j+1; }
							else if (pos_y == j) { }
						}
						
						// fixing stupid behavior
						if (map_tile[x1][y1] == TILE_CLOSED || map_tile[x1][y1] == TILE_SECRET)
						{
							x1 = i;
							y1 = j;

							for (int x=-1; x<=1; x++)
							{
								for (int y=-1; y<=1; y++)
								{
									if (i+x >= 0 && i+x < MAP_X &&
										j+y >= 0 && j+y < MAP_Y)
									{
										if (map_tile[i+x][j+y] != TILE_CLOSED &&
											map_tile[i+x][j+y] != TILE_SECRET)
										{
											if (pow(pos_x - (i+x), 2.0f) + pow(pos_y - (j+y), 2.0f) <
												pow(pos_x - x1, 2.0f) + pow(pos_y - y1, 2.0f))
											{
												x1 = i+x;
												y1 = j+y;
											}
										}
									}
								}
							}
						}

						if ((map_tile[x1][y1] == TILE_OPEN || map_tile[x1][y1] == TILE_DOOR ||
							map_tile[x1][y1] == TILE_UPSTAIRS || map_tile[x1][y1] == TILE_DOWNSTAIRS) && 
							monster_class[x1][y1] == CLASS_NONE)
						{
							if (pos_x == x1 && pos_y == y1)
							{
								attacked[i][j] = true;
							}
							else
							{
								// movement
								monster_class[x1][y1] = monster_class[i][j];
								monster_behavior[x1][y1] = monster_behavior[i][j];
								monster_health[x1][y1] = monster_health[i][j];
								monster_moved[x1][y1] = monster_moved[i][j];
		
								monster_class[i][j] = CLASS_NONE;
								monster_behavior[i][j] = BEHAVIOR_PASSIVE;
								monster_health[i][j] = 0;
								monster_moved[i][j] = false;
							}
						}
					}
				}
				else if (monster_behavior[i][j] == BEHAVIOR_FAST) // double movement
				{
					x1 = i;
					y1 = j;

					for (int loop=0; loop<2; loop++)
					{
						x2 = x1;
						y2 = y1;

						if (abs(pos_x - x2) + abs(pos_y - y2) <= 20)
						{
							if (pos_x < x2)
							{
								if (pos_y < y2) { x1 = x2-1; y1 = y2-1; }
								else if (pos_y > y2) { x1 = x2-1; y1 = y2+1; }
								else if (pos_y == y2) { x1 = x2-1; }
							}
							else if (pos_x > x2)
							{
								if (pos_y < y2) { x1 = x2+1; y1 = y2-1; }
								else if (pos_y > y2) { x1 = x2+1; y1 = y2+1; }
								else if (pos_y == y2) { x1 = x2+1; }
							}
							else if (pos_x == x2)
							{
								if (pos_y < y2) { y1 = y2-1; }
								else if (pos_y > y2) { y1 = y2+1; }
								else if (pos_y == y2) { }
							}
							
							// fixing stupid behavior
							if (map_tile[x1][y1] == TILE_CLOSED || map_tile[x1][y1] == TILE_SECRET)
							{
								x1 = x2;
								y1 = y2;
	
								for (int x=-1; x<=1; x++)
								{
									for (int y=-1; y<=1; y++)
									{
										if (x2+x >= 0 && x2+x < MAP_X &&
											y2+y >= 0 && y2+y < MAP_Y)
										{
											if (map_tile[x2+x][y2+y] != TILE_CLOSED &&
												map_tile[x2+x][y2+y] != TILE_SECRET)
											{
												if (pow(pos_x - (x2+x), 2.0f) + pow(pos_y - (y2+y), 2.0f) <
													pow(pos_x - x1, 2.0f) + pow(pos_y - y1, 2.0f))
												{
													x1 = x2+x;
													y1 = y2+y;
												}
											}
										}
									}
								}
							}
	
							if ((map_tile[x1][y1] == TILE_OPEN || map_tile[x1][y1] == TILE_DOOR ||
								map_tile[x1][y1] == TILE_UPSTAIRS || map_tile[x1][y1] == TILE_DOWNSTAIRS) && 
								monster_class[x1][y1] == CLASS_NONE)
							{
								if (pos_x == x1 && pos_y == y1)
								{
									attacked[x2][y2] = true;

									loop = 3;
								}
								else
								{
									// movement
									monster_class[x1][y1] = monster_class[x2][y2];
									monster_behavior[x1][y1] = monster_behavior[x2][y2];
									monster_health[x1][y1] = monster_health[x2][y2];
									monster_moved[x1][y1] = monster_moved[x2][y2];
			
									monster_class[x2][y2] = CLASS_NONE;
									monster_behavior[x2][y2] = BEHAVIOR_PASSIVE;
									monster_health[x2][y2] = 0;
									monster_moved[x2][y2] = false;
								}
							}
						}
					}
				}
				else if (monster_behavior[i][j] == BEHAVIOR_FLEE) // run away quickly
				{
					x1 = i;
					y1 = j;

					for (int loop=0; loop<2; loop++)
					{
						x2 = x1;
						y2 = y1;

						if (abs(pos_x - x2) + abs(pos_y - y2) <= 20)
						{
							if (pos_x < x2)
							{
								if (pos_y < y2) { x1 = x2+1; y1 = y2+1; }
								else if (pos_y > y2) { x1 = x2+1; y1 = y2-1; }
								else if (pos_y == y2) { x1 = x2+1; }
							}
							else if (pos_x > x2)
							{
								if (pos_y < y2) { x1 = x2-1; y1 = y2+1; }
								else if (pos_y > y2) { x1 = x2-1; y1 = y2-1; }
								else if (pos_y == y2) { x1 = x2-1; }
							}
							else if (pos_x == x2)
							{
								if (pos_y < y2) { y1 = y2+1; }
								else if (pos_y > y2) { y1 = y2-1; }
								else if (pos_y == y2) { }
							}
							
							// fixing stupid behavior
							if (map_tile[x1][y1] == TILE_CLOSED || map_tile[x1][y1] == TILE_SECRET)
							{
								x1 = x2;
								y1 = y2;
	
								for (int x=-1; x<=1; x++)
								{
									for (int y=-1; y<=1; y++)
									{
										if (x2+x >= 0 && x2+x < MAP_X &&
											y2+y >= 0 && y2+y < MAP_Y)
										{
											if (map_tile[x2+x][y2+y] != TILE_CLOSED &&
												map_tile[x2+x][y2+y] != TILE_SECRET)
											{
												if (pow(pos_x - (x2+x), 2.0f) + pow(pos_y - (y2+y), 2.0f) >
													pow(pos_x - x1, 2.0f) + pow(pos_y - y1, 2.0f))
												{
													x1 = x2+x;
													y1 = y2+y;
												}
											}
										}
									}
								}
							}
	
							if ((map_tile[x1][y1] == TILE_OPEN || map_tile[x1][y1] == TILE_DOOR ||
								map_tile[x1][y1] == TILE_UPSTAIRS || map_tile[x1][y1] == TILE_DOWNSTAIRS) && 
								monster_class[x1][y1] == CLASS_NONE)
							{
								if (pos_x == x1 && pos_y == y1)
								{
									attacked[x2][y2] = true; // probably not going to happen

									loop = 3;
								}
								else
								{
									// movement
									monster_class[x1][y1] = monster_class[x2][y2];
									monster_behavior[x1][y1] = monster_behavior[x2][y2];
									monster_health[x1][y1] = monster_health[x2][y2];
									monster_moved[x1][y1] = monster_moved[x2][y2];
			
									monster_class[x2][y2] = CLASS_NONE;
									monster_behavior[x2][y2] = BEHAVIOR_PASSIVE;
									monster_health[x2][y2] = 0;
									monster_moved[x2][y2] = false;
								}
							}
						}
					}
				}
			}
		}
	}

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (monster_class[i][j] != CLASS_NONE)
			{
				// regeneration
				if (monster_class[i][j] == CLASS_TROLL && monster_health[i][j] < 48)
				{
					monster_health[i][j] += 1;
				}

				// attacking
				if (attacked[i][j] == true)
				{
					number = rand() % 100;

					if (monster_class[i][j] == CLASS_AMOEBA)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 0) ||
							(player_armor == DESCRIPTION_LEATHER && number < 0) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 25) ||
							(player_armor == DESCRIPTION_PLATE && number < 25))
						{
							printf("\x1b[1;40f");
					
							printf("Amoeba rusts your armor!          \n");
		
							player_armor = DESCRIPTION_NONE;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Amoeba misses!         \n");
						}
					}
					else if (monster_class[i][j] == CLASS_BAT)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 95) ||
							(player_armor == DESCRIPTION_LEATHER && number < 55) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 35) ||
							(player_armor == DESCRIPTION_PLATE && number < 15))
						{
							printf("\x1b[1;40f");
					
							printf("Bat attacks!          \n");
		
							player_health -= rand() % 4 + 1;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Bat misses!          \n");
						}
					}	
					else if (monster_class[i][j] == CLASS_FUNGUS) // should never happen
					{
						if ((player_armor == DESCRIPTION_NONE && number < 5) ||
							(player_armor == DESCRIPTION_LEATHER && number < 0) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 0) ||
							(player_armor == DESCRIPTION_PLATE && number < 0))
						{
							printf("\x1b[1;40f");
					
							printf("Fungus attacks?          \n");
		
							player_health -= rand() % 2 + 1;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Fungus misses?          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_GOBLIN)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 50) ||
							(player_armor == DESCRIPTION_LEATHER && number < 35) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 20) ||
							(player_armor == DESCRIPTION_PLATE && number < 10))
						{
							printf("\x1b[1;40f");
					
							printf("Goblin attacks!          \n");
		
							player_health -= rand() % 6 + 1;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Goblin misses!          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_JAGUAR)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 95) ||
							(player_armor == DESCRIPTION_LEATHER && number < 75) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 50) ||
							(player_armor == DESCRIPTION_PLATE && number < 25))
						{
							printf("\x1b[1;40f");
					
							printf("Jaguar attacks!          \n");
		
							player_health -= rand() % 8 + 2;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Jaguar misses!          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_MUMMY)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 80) ||
							(player_armor == DESCRIPTION_LEATHER && number < 60) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 40) ||
							(player_armor == DESCRIPTION_PLATE && number < 20))
						{
							printf("\x1b[1;40f");
					
							printf("Mummy grabs!          \n");
		
							player_health -= rand() % 10 + 1;

							player_cannot_move = true;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Mummy misses!          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_NYMPH)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 50) ||
							(player_armor == DESCRIPTION_LEATHER && number < 50) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 50) ||
							(player_armor == DESCRIPTION_PLATE && number < 50))
						{
							printf("\x1b[1;40f");
					
							printf("Nymph steals your weapon!          \n");
		
							player_weapon = DESCRIPTION_NONE;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Nymph misses!          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_ORC)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 75) ||
							(player_armor == DESCRIPTION_LEATHER && number < 50) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 25) ||
							(player_armor == DESCRIPTION_PLATE && number < 10))
						{
							printf("\x1b[1;40f");
					
							printf("Orc attacks!          \n");
		
							player_health -= rand() % 6 + 3;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Orc misses!          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_SNAKE)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 95) ||
							(player_armor == DESCRIPTION_LEATHER && number < 85) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 50) ||
							(player_armor == DESCRIPTION_PLATE && number < 25))
						{
							printf("\x1b[1;40f");
					
							printf("Snake attacks!          \n");
		
							player_health -= rand() % 10 + 1;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Snake misses!          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_TROLL)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 50) ||
							(player_armor == DESCRIPTION_LEATHER && number < 40) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 30) ||
							(player_armor == DESCRIPTION_PLATE && number < 20))
						{
							printf("\x1b[1;40f");
					
							printf("Troll attacks!          \n");
		
							player_health -= rand() % 8 + 4;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Troll misses!          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_VAMPIRE)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 50) ||
							(player_armor == DESCRIPTION_LEATHER && number < 50) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 50) ||
							(player_armor == DESCRIPTION_PLATE && number < 50))
						{
							printf("\x1b[1;40f");
					
							printf("Vampire sucks!          \n");
		
							player_health -= rand() % 6 + 3;

							monster_health[i][j] += 3;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Vampire misses!          \n");
						}
					}
					else if (monster_class[i][j] == CLASS_ZOMBIE)
					{
						if ((player_armor == DESCRIPTION_NONE && number < 65) ||
							(player_armor == DESCRIPTION_LEATHER && number < 35) ||
							(player_armor == DESCRIPTION_CHAINMAIL && number < 15) ||
							(player_armor == DESCRIPTION_PLATE && number < 5))
						{
							printf("\x1b[1;40f");
					
							printf("Zombie attacks!          \n");
		
							player_health -= rand() % 8 + 1;
						}
						else
						{
							printf("\x1b[1;40f");
	
							printf("Zombie misses!          \n");
						}
					}
				}
			}
		}	
	}

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			monster_moved[i][j] = false;
		}
	}

	return;
};	

// throw items all over the place
void AddItems()
{
	int number, value;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			item_description[i][j] = DESCRIPTION_NONE;
		}
	}

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			if (map_tile[i][j] == TILE_OPEN && rand() % 100 < 4)
			{
				number = rand() % 5000;

				if (number < 300) item_description[i][j] = DESCRIPTION_DAGGER;
				else if (number < 500) item_description[i][j] = DESCRIPTION_MACE;
				else if (number < 575) item_description[i][j] = DESCRIPTION_AXE;
				else if (number < 600) item_description[i][j] = DESCRIPTION_SWORD;
				else if (number < 900) item_description[i][j] = DESCRIPTION_LEATHER;
				else if (number < 975) item_description[i][j] = DESCRIPTION_CHAINMAIL;
				else if (number < 1000) item_description[i][j] = DESCRIPTION_PLATE;
				else if (number < 1500) item_description[i][j] = DESCRIPTION_QUIVER;
				else if (number < 4500) item_description[i][j] = DESCRIPTION_GOLD;
				//else if (number < 4500) item_description[i][j] = DESCRIPTION_FOOD; // food is guaranteed
				else if (number < 4750) item_description[i][j] = DESCRIPTION_POTION;
				else if (number < 5000) item_description[i][j] = DESCRIPTION_SCROLL;
			}
			else
			{
				item_description[i][j] = DESCRIPTION_NONE;
			}
		}
	}
	
	// 2 foods per level 
	for (int loop=0; loop<2; loop++)
	{
		number = 0;

		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_OPEN && item_description[i][j] == DESCRIPTION_NONE) number += 1;
			}
		}
		
		value = rand() % number;
	
		number = 0;

		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_OPEN && item_description[i][j] == DESCRIPTION_NONE)
				{
					if (value == number)
					{
						item_description[i][j] = DESCRIPTION_FOOD;
					}
				
					number += 1;
				}
			}
		}
	}

	// placing the Amulet of Yendor
	if (player_depth == 5)
	{
		number = 0;

		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_OPEN && item_description[i][j] == DESCRIPTION_NONE) number += 1;
			}
		}
		
		value = rand() % number;
	
		number = 0;

		for (int i=0; i<MAP_X; i++)
		{
			for (int j=0; j<MAP_Y; j++)
			{
				if (map_tile[i][j] == TILE_OPEN && item_description[i][j] == DESCRIPTION_NONE)
				{
					if (value == number)
					{
						item_description[i][j] = DESCRIPTION_AMULET_OF_YENDOR;
					}
				
					number += 1;
				}
			}
		}
	}	

	return;
};

// keyboard controls for player
void PlayerControls()
{	
	int number, temp;

	// kbhit()
	struct termios oldt, newt;
	int ch;
	int oldf;

	int old_x, old_y;
 
	tcgetattr(STDIN_FILENO, &oldt);
	newt = oldt;
	newt.c_lflag &= ~(ICANON | ECHO);
	tcsetattr(STDIN_FILENO, TCSANOW, &newt);
	oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
	fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
	 
	ch = getchar();
	
//	tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
//	fcntl(STDIN_FILENO, F_SETFL, oldf);

	if (ch != EOF)
	{
		ungetc(ch, stdin);

		ch = getchar();

		if (key_pressed == false)
		{
			key_pressed = true;

			printf("\x1b[1;1f");

			for (int i=0; i<MAP_X; i++) printf(" ");
	
			old_x = pos_x;
			old_y = pos_y;

			// movement
			if (ch == '4') 
			{
				pos_x -= 1;

				action_done = true;
			}
			else if (ch == '6')
			{
				pos_x += 1;

				action_done = true;
			}
			else if (ch == '2')
			{
				pos_y += 1;

				action_done = true;
			}
			else if (ch == '8')
			{
				pos_y -= 1;

				action_done = true;
			}
			else if (ch == '7')
			{
				pos_x -= 1;
				pos_y -= 1;

				action_done = true;
			}
			else if (ch == '1')
			{
				pos_x -= 1;
				pos_y += 1;

				action_done = true;
			}
			else if (ch == '9')
			{
				pos_x += 1;
				pos_y -= 1;

				action_done = true;
			}
			else if (ch == '3')
			{
				pos_x += 1;
				pos_y += 1;

				action_done = true;
			}
			// searching
			else if (ch == '-')
			{
				printf("\x1b[1;1f");

				printf("Searching...          \n");

				for (int x=-1; x<=1; x++)
				{
					for (int y=-1; y<=1; y++)
					{
						if (pos_x+x >= 0 && pos_x+x < MAP_X && pos_y+y >= 0 && pos_y+y < MAP_Y)
						{
							if (map_tile[pos_x+x][pos_y+y] == TILE_SECRET)
							{
								if (rand() % 100 < 25) 
								{
									printf("\x1b[1;1f");
		
									printf("Found Secret!          \n");

									map_tile[pos_x+x][pos_y+y] = TILE_OPEN;
									map_fog[pos_x+x][pos_y+y] = 10;
								}
							}
						}
					}
				}

				action_done = true;
			}
			// arrows
			else if (ch == '/' && player_arrows <= 0)
			{
				printf("\x1b[1;1f");

				printf("No arrows!          \n");

				action_done = true;
			}
			else if (ch == '/' && player_arrows > 0)
			{
				player_arrows -= 1;

				ungetc(ch, stdin);

				printf("\x1b[1;1f");
	
				printf("Which direction? [ Press Enter to cancel ]");

				ch = 0;

				while (!(ch == '4' || ch == '6' || ch == '2' || ch == '8' ||
					ch == '7' || ch == '1' || ch == '9' || ch == '3' || ch == 10))
				{
					ch = getchar();
				}

				if (ch == 10) 
				{
					printf("\x1b[1;1f");

					printf("Nevermind.          \n");
				}	
				// each arrow direction
				else if (ch == '4')
				{
					for (int i=pos_x-1; i>=0; i--)
					{
						if (monster_class[i][pos_y] != CLASS_NONE)
						{
							if (rand() % 100 < 50+5*player_level)
							{
								printf("\x1b[1;1f");
		
								printf("Hit with arrow!          \n");
	
								monster_health[i][pos_y] -= rand() % 4 + 1;

								if (monster_class[i][pos_y] == CLASS_VAMPIRE ||
									monster_class[i][pos_y] == CLASS_NYMPH ||
									monster_class[i][pos_y] == CLASS_GOBLIN)
								{
									monster_behavior[i][pos_y] = BEHAVIOR_CHASING;
								}

								if (monster_class[i][pos_y] == CLASS_JAGUAR)
								{
									if (monster_health[i][pos_y] < 8) 
										monster_behavior[i][pos_y] = BEHAVIOR_FLEE;
								}

								if (monster_health[i][pos_y] <= 0)
								{
									printf("\x1b[1;1f");

									printf("Slayed!          \n");
	
									if (monster_class[i][pos_y] == CLASS_AMOEBA)	
									{
										player_experience += EXPERIENCE_AMOEBA;
									}
									else if (monster_class[i][pos_y] == CLASS_BAT)
									{
										player_experience += EXPERIENCE_BAT;
									}
									else if (monster_class[i][pos_y] == CLASS_FUNGUS)
									{
										player_experience += EXPERIENCE_FUNGUS;
									}
									else if (monster_class[i][pos_y] == CLASS_GOBLIN)
									{
										player_experience += EXPERIENCE_GOBLIN;

										if (item_description[i][pos_y] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[i][pos_y] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[i][pos_y] == CLASS_JAGUAR)
									{
										player_experience += EXPERIENCE_JAGUAR;
									}
									else if (monster_class[i][pos_y] == CLASS_MUMMY)
									{
										player_experience += EXPERIENCE_MUMMY;

										player_cannot_move = false;
									}
									else if (monster_class[i][pos_y] == CLASS_NYMPH)
									{
										player_experience += EXPERIENCE_NYMPH;

										if (item_description[i][pos_y] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 50) 
											{
												if (rand() % 100 < 50)
												{
													item_description[i][pos_y] =
														DESCRIPTION_POTION;
												}
												else
												{
													item_description[i][pos_y] =
														DESCRIPTION_SCROLL;
												}
											}
										}
									}
									else if (monster_class[i][pos_y] == CLASS_ORC)
									{
										player_experience += EXPERIENCE_ORC;

										if (item_description[i][pos_y] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[i][pos_y] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[i][pos_y] == CLASS_SNAKE)
									{
										player_experience += EXPERIENCE_SNAKE;
									}
									else if (monster_class[i][pos_y] == CLASS_TROLL)
									{
										player_experience += EXPERIENCE_TROLL;
									}
									else if (monster_class[i][pos_y] == CLASS_VAMPIRE)
									{
										player_experience += EXPERIENCE_VAMPIRE;

										// random item drop
										if (item_description[i][pos_y] == DESCRIPTION_NONE)
										{
											item_description[i][pos_y] = rand() % DESCRIPTION_AMULET_OF_YENDOR;
										}
									}
									else if (monster_class[i][pos_y] == CLASS_ZOMBIE)
									{
										player_experience += EXPERIENCE_ZOMBIE;
									}

									monster_class[i][pos_y] = CLASS_NONE;
									monster_behavior[i][pos_y] = BEHAVIOR_PASSIVE;
								}
							}
							else
							{
								printf("\x1b[1;1f");
		
								printf("Just missed!          \n");
							}

							i = -1;
						}
						else if (map_tile[i][pos_y] == TILE_CLOSED || map_tile[i][pos_y] == TILE_SECRET)
						{
							printf("\x1b[1;1f");
		
							printf("Wall hit!          \n");

							i = -1;
						}
					}
				}
				else if (ch == '2')
				{
					for (int j=pos_y+1; j<MAP_Y; j++)
					{
						if (monster_class[pos_x][j] != CLASS_NONE)
						{
							if (rand() % 100 < 50+5*player_level)
							{
								printf("\x1b[1;1f");
		
								printf("Hit with arrow!          \n");
	
								monster_health[pos_x][j] -= rand() % 4 + 1;

								if (monster_class[pos_x][j] == CLASS_VAMPIRE ||
									monster_class[pos_x][j] == CLASS_NYMPH ||
									monster_class[pos_x][j] == CLASS_GOBLIN)
								{
									monster_behavior[pos_x][j] = BEHAVIOR_CHASING;
								}

								if (monster_class[pos_x][j] == CLASS_JAGUAR)
								{
									if (monster_health[pos_x][j] < 8) 
										monster_behavior[pos_x][j] = BEHAVIOR_FLEE;
								}

								if (monster_health[pos_x][j] <= 0)
								{
									printf("\x1b[1;1f");

									printf("Slayed!          \n");
	
									if (monster_class[pos_x][j] == CLASS_AMOEBA)	
									{
										player_experience += EXPERIENCE_AMOEBA;
									}
									else if (monster_class[pos_x][j] == CLASS_BAT)
									{
										player_experience += EXPERIENCE_BAT;
									}
									else if (monster_class[pos_x][j] == CLASS_FUNGUS)
									{
										player_experience += EXPERIENCE_FUNGUS;
									}
									else if (monster_class[pos_x][j] == CLASS_GOBLIN)
									{
										player_experience += EXPERIENCE_GOBLIN;

										if (item_description[pos_x][j] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x][j] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x][j] == CLASS_JAGUAR)
									{
										player_experience += EXPERIENCE_JAGUAR;
									}
									else if (monster_class[pos_x][j] == CLASS_MUMMY)
									{
										player_experience += EXPERIENCE_MUMMY;

										player_cannot_move = false;
									}
									else if (monster_class[pos_x][j] == CLASS_NYMPH)
									{
										player_experience += EXPERIENCE_NYMPH;

										if (item_description[pos_x][j] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 50) 
											{
												if (rand() % 100 < 50)
												{
													item_description[pos_x][j] =
														DESCRIPTION_POTION;
												}
												else
												{
													item_description[pos_x][j] =
														DESCRIPTION_SCROLL;
												}
											}
										}
									}
									else if (monster_class[pos_x][j] == CLASS_ORC)
									{
										player_experience += EXPERIENCE_ORC;

										if (item_description[pos_x][j] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x][j] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x][j] == CLASS_SNAKE)
									{
										player_experience += EXPERIENCE_SNAKE;
									}
									else if (monster_class[pos_x][j] == CLASS_TROLL)
									{
										player_experience += EXPERIENCE_TROLL;
									}
									else if (monster_class[pos_x][j] == CLASS_VAMPIRE)
									{
										player_experience += EXPERIENCE_VAMPIRE;
	
										// random item drop
										if (item_description[pos_x][j] == DESCRIPTION_NONE)
										{
											item_description[pos_x][j] = rand() % DESCRIPTION_AMULET_OF_YENDOR;
										}
									}
									else if (monster_class[pos_x][j] == CLASS_ZOMBIE)
									{
										player_experience += EXPERIENCE_ZOMBIE;
									}

									monster_class[pos_x][j] = CLASS_NONE;
									monster_behavior[pos_x][j] = BEHAVIOR_PASSIVE;
								}
							}
							else
							{
								printf("\x1b[1;1f");
		
								printf("Just missed!          \n");
							}

							j = MAP_Y;
						}
						else if (map_tile[pos_x][j] == TILE_CLOSED || map_tile[pos_x][j] == TILE_SECRET)
						{
							printf("\x1b[1;1f");
		
							printf("Wall hit!          \n");

							j = MAP_Y;
						}
					}
				}
				else if (ch == '8')
				{
					for (int j=pos_y-1; j>=0; j--)
					{
						if (monster_class[pos_x][j] != CLASS_NONE)
						{
							if (rand() % 100 < 50+5*player_level)
							{
								printf("\x1b[1;1f");
		
								printf("Hit with arrow!          \n");
	
								monster_health[pos_x][j] -= rand() % 4 + 1;

								if (monster_class[pos_x][j] == CLASS_VAMPIRE ||
									monster_class[pos_x][j] == CLASS_NYMPH ||
									monster_class[pos_x][j] == CLASS_GOBLIN)
								{
									monster_behavior[pos_x][j] = BEHAVIOR_CHASING;
								}

								if (monster_class[pos_x][j] == CLASS_JAGUAR)
								{
									if (monster_health[pos_x][j] < 8) 
										monster_behavior[pos_x][j] = BEHAVIOR_FLEE;
								}

								if (monster_health[pos_x][j] <= 0)
								{
									printf("\x1b[1;1f");

									printf("Slayed!          \n");
	
									if (monster_class[pos_x][j] == CLASS_AMOEBA)	
									{
										player_experience += EXPERIENCE_AMOEBA;
									}
									else if (monster_class[pos_x][j] == CLASS_BAT)
									{
										player_experience += EXPERIENCE_BAT;
									}
									else if (monster_class[pos_x][j] == CLASS_FUNGUS)
									{
										player_experience += EXPERIENCE_FUNGUS;
									}
									else if (monster_class[pos_x][j] == CLASS_GOBLIN)
									{
										player_experience += EXPERIENCE_GOBLIN;

										if (item_description[pos_x][j] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x][j] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x][j] == CLASS_JAGUAR)
									{
										player_experience += EXPERIENCE_JAGUAR;
									}
									else if (monster_class[pos_x][j] == CLASS_MUMMY)
									{
										player_experience += EXPERIENCE_MUMMY;

										player_cannot_move = false;
									}
									else if (monster_class[pos_x][j] == CLASS_NYMPH)
									{
										player_experience += EXPERIENCE_NYMPH;

										if (item_description[pos_x][j] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 50) 
											{
												if (rand() % 100 < 50)
												{
													item_description[pos_x][j] =
														DESCRIPTION_POTION;
												}
												else
												{
													item_description[pos_x][j] =
														DESCRIPTION_SCROLL;
												}
											}
										}
									}
									else if (monster_class[pos_x][j] == CLASS_ORC)
									{
										player_experience += EXPERIENCE_ORC;

										if (item_description[pos_x][j] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x][j] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x][j] == CLASS_SNAKE)
									{
										player_experience += EXPERIENCE_SNAKE;
									}
									else if (monster_class[pos_x][j] == CLASS_TROLL)
									{
										player_experience += EXPERIENCE_TROLL;
									}
									else if (monster_class[pos_x][j] == CLASS_VAMPIRE)
									{
										player_experience += EXPERIENCE_VAMPIRE;

										// random item drop
										if (item_description[pos_x][j] == DESCRIPTION_NONE)
										{
											item_description[pos_x][j] = rand() % DESCRIPTION_AMULET_OF_YENDOR;
										}
									}
									else if (monster_class[pos_x][j] == CLASS_ZOMBIE)
									{
										player_experience += EXPERIENCE_ZOMBIE;
									}

									monster_class[pos_x][j] = CLASS_NONE;
									monster_behavior[pos_x][j] = BEHAVIOR_PASSIVE;
								}
							}
							else
							{
								printf("\x1b[1;1f");
		
								printf("Just missed!          \n");
							}

							j = -1;
						}
						else if (map_tile[pos_x][j] == TILE_CLOSED || map_tile[pos_x][j] == TILE_SECRET)
						{
							printf("\x1b[1;1f");
		
							printf("Wall hit!          \n");

							j = -1;
						}
					}
				}
				else if (ch == '6')
				{
					for (int i=pos_x+1; i<MAP_X; i++)
					{
						if (monster_class[i][pos_y] != CLASS_NONE)
						{
							if (rand() % 100 < 50+5*player_level)
							{
								printf("\x1b[1;1f");
		
								printf("Hit with arrow!          \n");
	
								monster_health[i][pos_y] -= rand() % 4 + 1;

								if (monster_class[i][pos_y] == CLASS_VAMPIRE ||
									monster_class[i][pos_y] == CLASS_NYMPH ||
									monster_class[i][pos_y] == CLASS_GOBLIN)
								{
									monster_behavior[i][pos_y] = BEHAVIOR_CHASING;
								}

								if (monster_class[i][pos_y] == CLASS_JAGUAR)
								{
									if (monster_health[i][pos_y] < 8) 
										monster_behavior[i][pos_y] = BEHAVIOR_FLEE;
								}

								if (monster_health[i][pos_y] <= 0)
								{
									printf("\x1b[1;1f");

									printf("Slayed!          \n");
	
									if (monster_class[i][pos_y] == CLASS_AMOEBA)	
									{
										player_experience += EXPERIENCE_AMOEBA;
									}
									else if (monster_class[i][pos_y] == CLASS_BAT)
									{
										player_experience += EXPERIENCE_BAT;
									}
									else if (monster_class[i][pos_y] == CLASS_FUNGUS)
									{
										player_experience += EXPERIENCE_FUNGUS;
									}
									else if (monster_class[i][pos_y] == CLASS_GOBLIN)
									{
										player_experience += EXPERIENCE_GOBLIN;

										if (item_description[i][pos_y] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[i][pos_y] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[i][pos_y] == CLASS_JAGUAR)
									{
										player_experience += EXPERIENCE_JAGUAR;
									}
									else if (monster_class[i][pos_y] == CLASS_MUMMY)
									{
										player_experience += EXPERIENCE_MUMMY;

										player_cannot_move = false;
									}
									else if (monster_class[i][pos_y] == CLASS_NYMPH)
									{
										player_experience += EXPERIENCE_NYMPH;

										if (item_description[i][pos_y] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 50) 
											{
												if (rand() % 100 < 50)
												{
													item_description[i][pos_y] =
														DESCRIPTION_POTION;
												}
												else
												{
													item_description[i][pos_y] =
														DESCRIPTION_SCROLL;
												}
											}
										}
									}
									else if (monster_class[i][pos_y] == CLASS_ORC)
									{
										player_experience += EXPERIENCE_ORC;

										if (item_description[i][pos_y] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[i][pos_y] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[i][pos_y] == CLASS_SNAKE)
									{
										player_experience += EXPERIENCE_SNAKE;
									}
									else if (monster_class[i][pos_y] == CLASS_TROLL)
									{
										player_experience += EXPERIENCE_TROLL;
									}
									else if (monster_class[i][pos_y] == CLASS_VAMPIRE)
									{
										player_experience += EXPERIENCE_VAMPIRE;

										// random item drop
										if (item_description[i][pos_y] == DESCRIPTION_NONE)
										{
											item_description[i][pos_y] = rand() % DESCRIPTION_AMULET_OF_YENDOR;
										}
									}
									else if (monster_class[i][pos_y] == CLASS_ZOMBIE)
									{
										player_experience += EXPERIENCE_ZOMBIE;
									}

									monster_class[i][pos_y] = CLASS_NONE;
									monster_behavior[i][pos_y] = BEHAVIOR_PASSIVE;
								}
							}
							else
							{
								printf("\x1b[1;1f");
		
								printf("Just missed!          \n");
							}

							i = MAP_X;
						}
						else if (map_tile[i][pos_y] == TILE_CLOSED || map_tile[i][pos_y] == TILE_SECRET)
						{
							printf("\x1b[1;1f");
		
							printf("Wall hit!          \n");

							i = MAP_X;
						}
					}
				}
				else if (ch == '7')
				{
					for (int k=1; k<(MAP_X+MAP_Y); k++)
					{
						if (monster_class[pos_x-k][pos_y-k] != CLASS_NONE)
						{
							if (rand() % 100 < 50+5*player_level)
							{
								printf("\x1b[1;1f");
		
								printf("Hit with arrow!          \n");
	
								monster_health[pos_x-k][pos_y-k] -= rand() % 4 + 1;

								if (monster_class[pos_x-k][pos_y-k] == CLASS_VAMPIRE ||
									monster_class[pos_x-k][pos_y-k] == CLASS_NYMPH ||
									monster_class[pos_x-k][pos_y-k] == CLASS_GOBLIN)
								{
									monster_behavior[pos_x-k][pos_y-k] = BEHAVIOR_CHASING;
								}

								if (monster_class[pos_x-k][pos_y-k] == CLASS_JAGUAR)
								{
									if (monster_health[pos_x-k][pos_y-k] < 8) 
										monster_behavior[pos_x-k][pos_y-k] = BEHAVIOR_FLEE;
								}

								if (monster_health[pos_x-k][pos_y-k] <= 0)
								{
									printf("\x1b[1;1f");

									printf("Slayed!          \n");
	
									if (monster_class[pos_x-k][pos_y-k] == CLASS_AMOEBA)	
									{
										player_experience += EXPERIENCE_AMOEBA;
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_BAT)
									{
										player_experience += EXPERIENCE_BAT;
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_FUNGUS)
									{
										player_experience += EXPERIENCE_FUNGUS;
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_GOBLIN)
									{
										player_experience += EXPERIENCE_GOBLIN;

										if (item_description[pos_x-k][pos_y-k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x-k][pos_y-k] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_JAGUAR)
									{
										player_experience += EXPERIENCE_JAGUAR;
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_MUMMY)
									{
										player_experience += EXPERIENCE_MUMMY;

										player_cannot_move = false;
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_NYMPH)
									{
										player_experience += EXPERIENCE_NYMPH;

										if (item_description[pos_x-k][pos_y-k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 50) 
											{
												if (rand() % 100 < 50)
												{
													item_description[pos_x-k][pos_y-k] =
														DESCRIPTION_POTION;
												}
												else
												{
													item_description[pos_x-k][pos_y-k] =
														DESCRIPTION_SCROLL;
												}
											}
										}
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_ORC)
									{
										player_experience += EXPERIENCE_ORC;

										if (item_description[pos_x-k][pos_y-k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x-k][pos_y-k] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_SNAKE)
									{
										player_experience += EXPERIENCE_SNAKE;
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_TROLL)
									{
										player_experience += EXPERIENCE_TROLL;
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_VAMPIRE)
									{
										player_experience += EXPERIENCE_VAMPIRE;

										// random item drop
										if (item_description[pos_x-k][pos_y-k] == DESCRIPTION_NONE)
										{
											item_description[pos_x-k][pos_y-k] = 
												rand() % DESCRIPTION_AMULET_OF_YENDOR;
										}
									}
									else if (monster_class[pos_x-k][pos_y-k] == CLASS_ZOMBIE)
									{
										player_experience += EXPERIENCE_ZOMBIE;
									}

									monster_class[pos_x-k][pos_y-k] = CLASS_NONE;
									monster_behavior[pos_x-k][pos_y-k] = BEHAVIOR_PASSIVE;
								}
							}
							else
							{
								printf("\x1b[1;1f");
		
								printf("Just missed!          \n");
							}

							k = (MAP_X + MAP_Y) + 1;
						}
						else if (map_tile[pos_x-k][pos_y-k] == TILE_CLOSED || map_tile[pos_x-k][pos_y-k] == TILE_SECRET)
						{
							printf("\x1b[1;1f");
		
							printf("Wall hit!          \n");

							k = (MAP_X + MAP_Y) + 1;
						}
					}
				}
				else if (ch == '9')
				{
					for (int k=1; k<(MAP_X+MAP_Y); k++)
					{
						if (monster_class[pos_x+k][pos_y-k] != CLASS_NONE)
						{
							if (rand() % 100 < 50+5*player_level)
							{
								printf("\x1b[1;1f");
		
								printf("Hit with arrow!          \n");
	
								monster_health[pos_x+k][pos_y-k] -= rand() % 4 + 1;

								if (monster_class[pos_x+k][pos_y-k] == CLASS_VAMPIRE ||
									monster_class[pos_x+k][pos_y-k] == CLASS_NYMPH ||
									monster_class[pos_x+k][pos_y-k] == CLASS_GOBLIN)
								{
									monster_behavior[pos_x+k][pos_y-k] = BEHAVIOR_CHASING;
								}

								if (monster_class[pos_x+k][pos_y-k] == CLASS_JAGUAR)
								{
									if (monster_health[pos_x+k][pos_y-k] < 8) 
										monster_behavior[pos_x+k][pos_y-k] = BEHAVIOR_FLEE;
								}

								if (monster_health[pos_x+k][pos_y-k] <= 0)
								{
									printf("\x1b[1;1f");

									printf("Slayed!          \n");
	
									if (monster_class[pos_x+k][pos_y-k] == CLASS_AMOEBA)	
									{
										player_experience += EXPERIENCE_AMOEBA;
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_BAT)
									{
										player_experience += EXPERIENCE_BAT;
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_FUNGUS)
									{
										player_experience += EXPERIENCE_FUNGUS;
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_GOBLIN)
									{
										player_experience += EXPERIENCE_GOBLIN;

										if (item_description[pos_x+k][pos_y-k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x+k][pos_y-k] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_JAGUAR)
									{
										player_experience += EXPERIENCE_JAGUAR;
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_MUMMY)
									{
										player_experience += EXPERIENCE_MUMMY;

										player_cannot_move = false;
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_NYMPH)
									{
										player_experience += EXPERIENCE_NYMPH;

										if (item_description[pos_x+k][pos_y-k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 50) 
											{
												if (rand() % 100 < 50)
												{
													item_description[pos_x+k][pos_y-k] =
														DESCRIPTION_POTION;
												}
												else
												{
													item_description[pos_x+k][pos_y-k] =
														DESCRIPTION_SCROLL;
												}
											}
										}
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_ORC)
									{
										player_experience += EXPERIENCE_ORC;

										if (item_description[pos_x+k][pos_y-k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x+k][pos_y-k] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_SNAKE)
									{
										player_experience += EXPERIENCE_SNAKE;
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_TROLL)
									{
										player_experience += EXPERIENCE_TROLL;
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_VAMPIRE)
									{
										player_experience += EXPERIENCE_VAMPIRE;

										// random item drop
										if (item_description[pos_x+k][pos_y-k] == DESCRIPTION_NONE)
										{
											item_description[pos_x+k][pos_y-k] = 
												rand() % DESCRIPTION_AMULET_OF_YENDOR;
										}
									}
									else if (monster_class[pos_x+k][pos_y-k] == CLASS_ZOMBIE)
									{
										player_experience += EXPERIENCE_ZOMBIE;
									}

									monster_class[pos_x+k][pos_y-k] = CLASS_NONE;
									monster_behavior[pos_x+k][pos_y-k] = BEHAVIOR_PASSIVE;
								}
							}
							else
							{
								printf("\x1b[1;1f");
		
								printf("Just missed!          \n");
							}

							k = (MAP_X + MAP_Y) + 1;
						}
						else if (map_tile[pos_x+k][pos_y-k] == TILE_CLOSED || map_tile[pos_x+k][pos_y-k] == TILE_SECRET)
						{
							printf("\x1b[1;1f");
		
							printf("Wall hit!          \n");

							k = (MAP_X + MAP_Y) + 1;
						}
					}
				}
				else if (ch == '1')
				{
					for (int k=1; k<(MAP_X+MAP_Y); k++)
					{
						if (monster_class[pos_x-k][pos_y+k] != CLASS_NONE)
						{
							if (rand() % 100 < 50+5*player_level)
							{
								printf("\x1b[1;1f");
		
								printf("Hit with arrow!          \n");
	
								monster_health[pos_x-k][pos_y+k] -= rand() % 4 + 1;

								if (monster_class[pos_x-k][pos_y+k] == CLASS_VAMPIRE ||
									monster_class[pos_x-k][pos_y+k] == CLASS_NYMPH ||
									monster_class[pos_x-k][pos_y+k] == CLASS_GOBLIN)
								{
									monster_behavior[pos_x-k][pos_y+k] = BEHAVIOR_CHASING;
								}

								if (monster_class[pos_x-k][pos_y+k] == CLASS_JAGUAR)
								{
									if (monster_health[pos_x-k][pos_y+k] < 8) 
										monster_behavior[pos_x-k][pos_y+k] = BEHAVIOR_FLEE;
								}

								if (monster_health[pos_x-k][pos_y+k] <= 0)
								{
									printf("\x1b[1;1f");

									printf("Slayed!          \n");
	
									if (monster_class[pos_x-k][pos_y+k] == CLASS_AMOEBA)	
									{
										player_experience += EXPERIENCE_AMOEBA;
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_BAT)
									{
										player_experience += EXPERIENCE_BAT;
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_FUNGUS)
									{
										player_experience += EXPERIENCE_FUNGUS;
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_GOBLIN)
									{
										player_experience += EXPERIENCE_GOBLIN;

										if (item_description[pos_x-k][pos_y+k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x-k][pos_y+k] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_JAGUAR)
									{
										player_experience += EXPERIENCE_JAGUAR;
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_MUMMY)
									{
										player_experience += EXPERIENCE_MUMMY;

										player_cannot_move = false;
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_NYMPH)
									{
										player_experience += EXPERIENCE_NYMPH;

										if (item_description[pos_x-k][pos_y+k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 50) 
											{
												if (rand() % 100 < 50)
												{
													item_description[pos_x-k][pos_y+k] =
														DESCRIPTION_POTION;
												}
												else
												{
													item_description[pos_x-k][pos_y+k] =
														DESCRIPTION_SCROLL;
												}
											}
										}
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_ORC)
									{
										player_experience += EXPERIENCE_ORC;

										if (item_description[pos_x-k][pos_y+k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x-k][pos_y+k] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_SNAKE)
									{
										player_experience += EXPERIENCE_SNAKE;
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_TROLL)
									{
										player_experience += EXPERIENCE_TROLL;
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_VAMPIRE)
									{
										player_experience += EXPERIENCE_VAMPIRE;

										// random item drop
										if (item_description[pos_x-k][pos_y+k] == DESCRIPTION_NONE)
										{
											item_description[pos_x-k][pos_y+k] = 
												rand() % DESCRIPTION_AMULET_OF_YENDOR;
										}
									}
									else if (monster_class[pos_x-k][pos_y+k] == CLASS_ZOMBIE)
									{
										player_experience += EXPERIENCE_ZOMBIE;
									}

									monster_class[pos_x-k][pos_y+k] = CLASS_NONE;
									monster_behavior[pos_x-k][pos_y+k] = BEHAVIOR_PASSIVE;
								}
							}
							else
							{
								printf("\x1b[1;1f");
		
								printf("Just missed!          \n");
							}

							k = (MAP_X + MAP_Y) + 1;
						}
						else if (map_tile[pos_x-k][pos_y+k] == TILE_CLOSED || map_tile[pos_x-k][pos_y+k] == TILE_SECRET)
						{
							printf("\x1b[1;1f");
		
							printf("Wall hit!          \n");

							k = (MAP_X + MAP_Y) + 1;
						}
					}
				}
				else if (ch == '3')
				{
					for (int k=1; k<(MAP_X+MAP_Y); k++)
					{
						if (monster_class[pos_x+k][pos_y+k] != CLASS_NONE)
						{
							if (rand() % 100 < 50+5*player_level)
							{
								printf("\x1b[1;1f");
		
								printf("Hit with arrow!          \n");
	
								monster_health[pos_x+k][pos_y+k] -= rand() % 4 + 1;

								if (monster_class[pos_x+k][pos_y+k] == CLASS_VAMPIRE ||
									monster_class[pos_x+k][pos_y+k] == CLASS_NYMPH ||
									monster_class[pos_x+k][pos_y+k] == CLASS_GOBLIN)
								{
									monster_behavior[pos_x+k][pos_y+k] = BEHAVIOR_CHASING;
								}

								if (monster_class[pos_x+k][pos_y+k] == CLASS_JAGUAR)
								{
									if (monster_health[pos_x+k][pos_y+k] < 8) 
										monster_behavior[pos_x+k][pos_y+k] = BEHAVIOR_FLEE;
								}

								if (monster_health[pos_x+k][pos_y+k] <= 0)
								{
									printf("\x1b[1;1f");

									printf("Slayed!          \n");
	
									if (monster_class[pos_x+k][pos_y+k] == CLASS_AMOEBA)	
									{
										player_experience += EXPERIENCE_AMOEBA;
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_BAT)
									{
										player_experience += EXPERIENCE_BAT;
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_FUNGUS)
									{
										player_experience += EXPERIENCE_FUNGUS;
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_GOBLIN)
									{
										player_experience += EXPERIENCE_GOBLIN;

										if (item_description[pos_x+k][pos_y+k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x+k][pos_y+k] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_JAGUAR)
									{
										player_experience += EXPERIENCE_JAGUAR;
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_MUMMY)
									{
										player_experience += EXPERIENCE_MUMMY;

										player_cannot_move = false;
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_NYMPH)
									{
										player_experience += EXPERIENCE_NYMPH;

										if (item_description[pos_x+k][pos_y+k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 50) 
											{
												if (rand() % 100 < 50)
												{
													item_description[pos_x+k][pos_y+k] =
														DESCRIPTION_POTION;
												}
												else
												{
													item_description[pos_x+k][pos_y+k] =
														DESCRIPTION_SCROLL;
												}
											}
										}
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_ORC)
									{
										player_experience += EXPERIENCE_ORC;

										if (item_description[pos_x+k][pos_y+k] == DESCRIPTION_NONE)
										{
											if (rand() % 100 < 25) 
											{
												item_description[pos_x+k][pos_y+k] = DESCRIPTION_GOLD;
											}
										}
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_SNAKE)
									{
										player_experience += EXPERIENCE_SNAKE;
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_TROLL)
									{
										player_experience += EXPERIENCE_TROLL;
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_VAMPIRE)
									{
										player_experience += EXPERIENCE_VAMPIRE;

										// random item drop
										if (item_description[pos_x+k][pos_y+k] == DESCRIPTION_NONE)
										{
											item_description[pos_x+k][pos_y+k] = 
												rand() % DESCRIPTION_AMULET_OF_YENDOR;
										}
									}
									else if (monster_class[pos_x+k][pos_y+k] == CLASS_ZOMBIE)
									{
										player_experience += EXPERIENCE_ZOMBIE;
									}

									monster_class[pos_x+k][pos_y+k] = CLASS_NONE;
									monster_behavior[pos_x+k][pos_y+k] = BEHAVIOR_PASSIVE;
								}
							}
							else
							{
								printf("\x1b[1;1f");
		
								printf("Just missed!          \n");
							}

							k = (MAP_X + MAP_Y) + 1;
						}
						else if (map_tile[pos_x+k][pos_y+k] == TILE_CLOSED || map_tile[pos_x+k][pos_y+k] == TILE_SECRET)
						{
							printf("\x1b[1;1f");
		
							printf("Wall hit!          \n");

							k = (MAP_X + MAP_Y) + 1;
						}
					}
				}

				if (ch != 10) action_done = true;
			}
			// direction up and down
			else if (ch == '+') // as in, "direction"
			{
				if (map_tile[pos_x][pos_y] == TILE_DOWNSTAIRS)
				{
					player_depth += 1;

					if (player_depth == 5) player_direction = -1;

					if (player_depth != 5) CreateGridRooms();
					else CreateLargeCavern();

					SpreadMonsters();
	
					AddItems();
				}
				else if (map_tile[pos_x][pos_y] == TILE_UPSTAIRS && player_has_amulet_of_yendor == true)
				{
					player_depth -= 1;

					if (player_depth != 5) CreateGridRooms();
					else CreateLargeCavern();

					SpreadMonsters();
	
					AddItems();
				}
				else if (map_tile[pos_x][pos_y] == TILE_UPSTAIRS && player_has_amulet_of_yendor == false)
				{
					printf("\x1b[1;1f");

					printf("Can't ascend yet, you need the Amulet of Yendor!          \n");
				}
			
				action_done = true;
			}
			// quaffing potions
			else if (ch == '*' && player_potions <= 0)
			{
				printf("\x1b[1;1f");

				printf("No potions!          \n");

				action_done = true;
			}
			else if (ch == '*' && player_potions > 0)
			{
				printf("\x1b[1;1f");

				printf("Quaffing potion!          \n");

				player_potions -= 1;

				player_health = player_max_health;

				action_done = true;
			}
			// reading scrolls
			else if (ch == 127 && player_scrolls <= 0)
			{
				printf("\x1b[1;1f");

				printf("No scrolls!          \n");

				action_done = true;
			}
			else if (ch == 127 && player_scrolls > 0)
			{
				printf("\x1b[1;1f");

				printf("Reading scroll!          \n");

				player_scrolls -= 1;

				number = 0;

				for (int i=0; i<MAP_X; i++)
				{
					for (int j=0; j<MAP_Y; j++)
					{
						if (map_tile[i][j] == TILE_OPEN && monster_class[i][j] == CLASS_NONE)
						{
							number += 1;
						}
					}
				}

				temp = rand() % number;

				number = 0;

				for (int i=0; i<MAP_X; i++)
				{
					for (int j=0; j<MAP_Y; j++)
					{
						if (map_tile[i][j] == TILE_OPEN && monster_class[i][j] == CLASS_NONE)
						{
							if (temp == number)
							{
								pos_x = i;
								pos_y = j;

								i = MAP_X + 1;
								j = MAP_Y + 1;
							}

							number += 1;
						}
					}
				}

				action_done = true;
			}
			// showing what characters represent what
			else if (ch == '0') // as in "explanation"
			{
				printf("\x1b[1;1f");

				printf("Legend:                                                   Tips:                 \n");
				printf("                                                                                \n");
				printf("@ your character                                          - It is good to be    \n"); 
				printf("# wall               . floor                                slow and careful    \n");
				printf("+ door               # hidden secret passage                while exploring.    \n");
				printf("< upstairs           > downstairs                                               \n");
				printf(") weapon             ] armor                              - To attack an enemy, \n");
				printf("/ arrows             $ gold (for final score)               you need to press   \n");
				printf("%% food               ! health potion                        the move button in  \n");
				printf("? teleport scroll    * Amulet of Yendor                     direction of enemy. \n");
				printf("                                                                                \n");
				printf("A amoeba             B bat                                - You cannot stay     \n");
				printf("F fungus             G goblin                               too long on one     \n");
				printf("J jaguar             M mummy                                level, or you will  \n");
				printf("N nymph              O orc                                  run out of food.    \n");
				printf("S snake              T troll                                                    \n");
				printf("V vampire            Z zombie                             - If you are stuck,   \n");
				printf("                                                            try searching the   \n");
				printf("Go down to depth of 5, grab the Amulet of Yendor,           walls next to       \n");
				printf("then re-ascend back to the surface to win!                  large empty spaces. \n");
				printf("[ Press Enter to continue ]                                                     \n");
				printf("                                                                                \n");
			
				ch = 0;

				while (ch != 10) { ch = getchar(); }
			
				action_done = false; // no action done!
			}
				
			// melee attack on creatures
			if (map_tile[pos_x][pos_y] == TILE_OPEN || map_tile[pos_x][pos_y] == TILE_DOOR ||
				map_tile[pos_x][pos_y] == TILE_UPSTAIRS || map_tile[pos_x][pos_y] == TILE_DOWNSTAIRS)
			{
				map_memory[pos_x][pos_y] = true;

				if (monster_class[pos_x][pos_y] != CLASS_NONE)
				{
					number = rand() % 100;

					if (monster_class[pos_x][pos_y] == CLASS_AMOEBA && number < 75+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Amoeba!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_AMOEBA;

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Amoeba!          \n");
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_BAT && number < 35+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Bat!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_BAT;

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Bat!          \n");
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_FUNGUS && number < 85+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Fungus!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_FUNGUS;

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Fungus!          \n");
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_GOBLIN && number < 65+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Goblin!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_GOBLIN;

							if (item_description[pos_x][pos_y] == DESCRIPTION_NONE)
							{
								if (rand() % 100 < 25) 
								{
									item_description[pos_x][pos_y] = DESCRIPTION_GOLD;
								}
							}

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Goblin!          \n");

							monster_behavior[pos_x][pos_y] = BEHAVIOR_CHASING;
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_JAGUAR && number < 35+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Jaguar!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_JAGUAR;

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Jaguar!          \n");

							if (monster_health[pos_x][pos_y] < 8) monster_behavior[pos_x][pos_y] = BEHAVIOR_FLEE;
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_MUMMY && number < 55+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Mummy!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_MUMMY;

							player_cannot_move = false;

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Mummy!          \n");
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_NYMPH && number < 55+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Nymph!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_NYMPH;

							if (item_description[pos_x][pos_y] == DESCRIPTION_NONE)
							{
								if (rand() % 100 < 50) 
								{
									if (rand() % 100 < 50)
									{
										item_description[pos_x][pos_y] =
											DESCRIPTION_POTION;
									}
									else
									{
										item_description[pos_x][pos_y] =
											DESCRIPTION_SCROLL;
									}
								}
							}
		
							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Nymph!          \n");

							monster_behavior[pos_x][pos_y] = BEHAVIOR_CHASING;
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_ORC && number < 65+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Orc!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_ORC;

							if (item_description[pos_x][pos_y] == DESCRIPTION_NONE)
							{
								if (rand() % 100 < 25) 
								{
									item_description[pos_x][pos_y] = DESCRIPTION_GOLD;
								}
							}

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Orc!          \n");
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_SNAKE && number < 45+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Snake!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_SNAKE;

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Snake!          \n");
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_TROLL && number < 35+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Troll!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_TROLL;

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Troll!          \n");
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_VAMPIRE && number < 75+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Vampire!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_VAMPIRE;

							// random item drop
							if (item_description[pos_x][pos_y] == DESCRIPTION_NONE)
							{
								item_description[pos_x][pos_y] = 
									rand() % DESCRIPTION_AMULET_OF_YENDOR;
							}

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Vampire!          \n");

							monster_behavior[pos_x][pos_y] = BEHAVIOR_CHASING;
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else if (monster_class[pos_x][pos_y] == CLASS_ZOMBIE && number < 85+10*player_level)
					{
						if (player_weapon == DESCRIPTION_NONE) monster_health[pos_x][pos_y] -= 1;
						else if (player_weapon == DESCRIPTION_DAGGER) monster_health[pos_x][pos_y] -= rand() % 3 + 1;
						else if (player_weapon == DESCRIPTION_MACE) monster_health[pos_x][pos_y] -= rand() % 4 + 2;
						else if (player_weapon == DESCRIPTION_AXE) monster_health[pos_x][pos_y] -= rand() % 6 + 1;
						else if (player_weapon == DESCRIPTION_SWORD) monster_health[pos_x][pos_y] -= rand() % 8 + 1;

						if (monster_health[pos_x][pos_y] <= 0)
						{
							printf("\x1b[1;1f");
	
							printf("Slayed Zombie!          \n");
		
							monster_class[pos_x][pos_y] = CLASS_NONE;
							monster_behavior[pos_x][pos_y] = BEHAVIOR_PASSIVE;

							player_experience += EXPERIENCE_ZOMBIE;

							pos_x = old_x;
							pos_y = old_y;
						}
						else
						{
							printf("\x1b[1;1f");
	
							printf("Attacking Zombie!          \n");
		
							pos_x = old_x;
							pos_y = old_y;
						}
					}
					else
					{
						printf("\x1b[1;1f");
	
						printf("Missed!          \n");
		
						pos_x = old_x;
						pos_y = old_y;
					}
				}

				if (item_description[pos_x][pos_y] != DESCRIPTION_NONE)
				{
					if (item_description[pos_x][pos_y] == DESCRIPTION_DAGGER)
					{
						if (player_weapon == DESCRIPTION_DAGGER || 
							player_weapon == DESCRIPTION_MACE ||
							player_weapon == DESCRIPTION_AXE ||
							player_weapon == DESCRIPTION_SWORD) 
						{
							printf("\x1b[1;1f");

							printf("A dagger, already using something better.          \n");
						}
						else
						{
							printf("\x1b[1;1f");

							printf("Brandishing a dagger!          \n");

							number = player_weapon;

							player_weapon = DESCRIPTION_DAGGER;

							item_description[pos_x][pos_y] = number;
						}
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_MACE)
					{
						if (player_weapon == DESCRIPTION_MACE ||
							player_weapon == DESCRIPTION_AXE ||
							player_weapon == DESCRIPTION_SWORD) 
						{
							printf("\x1b[1;1f");

							printf("A mace, already using something better.          \n");
						}
						else
						{
							printf("\x1b[1;1f");

							printf("Brandishing a mace!          \n");

							number = player_weapon;

							player_weapon = DESCRIPTION_MACE;

							item_description[pos_x][pos_y] = number;
						}
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_AXE)
					{
						if (player_weapon == DESCRIPTION_AXE ||
							player_weapon == DESCRIPTION_SWORD) 
						{
							printf("\x1b[1;1f");

							printf("An axe, already using something better.          \n");
						}
						else
						{
							printf("\x1b[1;1f");

							printf("Brandishing an axe!          \n");

							number = player_weapon;

							player_weapon = DESCRIPTION_AXE;

							item_description[pos_x][pos_y] = number;
						}
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_SWORD)
					{
						if (player_weapon == DESCRIPTION_SWORD) 
						{
							printf("\x1b[1;1f");

							printf("A sword, already using something better.          \n");
						}
						else
						{
							printf("\x1b[1;1f");

							printf("Brandishing a sword!          \n");

							number = player_weapon;

							player_weapon = DESCRIPTION_SWORD;

							item_description[pos_x][pos_y] = number;
						}
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_LEATHER)
					{
						if (player_armor == DESCRIPTION_LEATHER || 
							player_armor == DESCRIPTION_CHAINMAIL || 
							player_armor == DESCRIPTION_PLATE) 
						{
							printf("\x1b[1;1f");

							printf("Leather armor, already using something better.          \n");
						}
						else
						{
							printf("\x1b[1;1f");

							printf("Wearing leather!          \n");

							number = player_armor;

							player_armor = DESCRIPTION_LEATHER;

							item_description[pos_x][pos_y] = number;
						}
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_CHAINMAIL)
					{
						if (player_armor == DESCRIPTION_CHAINMAIL ||
							player_armor == DESCRIPTION_PLATE) 
						{
							printf("\x1b[1;1f");

							printf("Chainmail armor, already using something better.          \n");
						}
						else
						{
							printf("\x1b[1;1f");

							printf("Wearing chainmail!          \n");

							number = player_armor;

							player_armor = DESCRIPTION_CHAINMAIL;

							item_description[pos_x][pos_y] = number;
						}
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_PLATE)
					{
						if (player_armor == DESCRIPTION_PLATE) 
						{
							printf("\x1b[1;1f");

							printf("Plate armor, already using something better.          \n");
						}
						else
						{
							printf("\x1b[1;1f");

							printf("Wearing plate!          \n");

							number = player_armor;

							player_armor = DESCRIPTION_PLATE;

							item_description[pos_x][pos_y] = number;
						}
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_QUIVER)
					{
						printf("\x1b[1;1f");

						printf("Found arrows!          \n");

						player_arrows += 5;

						item_description[pos_x][pos_y] = DESCRIPTION_NONE;
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_GOLD)
					{
						printf("\x1b[1;1f");

						printf("Found gold!          \n");

						player_gold += 1;

						item_description[pos_x][pos_y] = DESCRIPTION_NONE;
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_FOOD)
					{
						printf("\x1b[1;1f");

						printf("Found food!          \n");
		
						player_food += 100;

						item_description[pos_x][pos_y] = DESCRIPTION_NONE;
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_POTION)
					{
						printf("\x1b[1;1f");
						
						printf("Found potion!          \n");
				
						player_potions += 1;

						item_description[pos_x][pos_y] = DESCRIPTION_NONE;
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_SCROLL)
					{
						printf("\x1b[1;1f");
		
						printf("Found scroll!          \n");

						player_scrolls += 1;

						item_description[pos_x][pos_y] = DESCRIPTION_NONE;
					}
					else if (item_description[pos_x][pos_y] == DESCRIPTION_AMULET_OF_YENDOR)
					{
						printf("\x1b[1;1f");
	
						printf("Found the Amulet of Yendor!          \n");

						player_has_amulet_of_yendor = true;
					
						item_description[pos_x][pos_y] = DESCRIPTION_NONE;
					}
				}
			}

			// bumping into walls
			if (map_tile[pos_x][pos_y] == TILE_CLOSED || map_tile[pos_x][pos_y] == TILE_SECRET)
			{
				pos_x = old_x;
				pos_y = old_y;
			}

			// being grabbed
			if (player_cannot_move == true && (pos_x != old_x || pos_y != old_y))
			{
				if (rand() % 100 < 20)
				{
					printf("\x1b[1;1f");

					printf("Free to move!          \n");

					player_cannot_move = false;
				}
				else
				{
					printf("\x1b[1;1f");

					printf("Cannot move!          \n");

					pos_x = old_x;
					pos_y = old_y;
				}
			}	
		}
	}
	else
	{
		key_pressed = false;

		action_done = false;
	}

	return;
};

// regenerate health and gaining levels
void CharacterEvents()
{
	player_turns += 1;

	// regenerate
	if (player_health < player_max_health && player_turns % 4 == 0) 
	{
		player_health += 1;
	}

	// level ups
	if (player_experience >= 5*player_level)
	{
		player_experience -= 5*player_level;

		player_level += 1;

		player_max_health += 10;

		printf("\x1b[1;40f");

		printf("Level up!          \n");
	}

	// creature placement
	if (player_turns % 50 == 0) PlaceCreature();

	// eating food
	if (player_turns % 4 == 0) player_food -= 1;
			
	if (player_food < 0) 
	{
		player_food = 0; 
			
		player_health -= 1; 

		printf("\x1b[1;40f");

		printf("Hungry!          \n");
	}

	return;
};

// add total fog between two tiles
int CalculateFog(int px, int py, int tx, int ty)
{
	int total_fog = 0;

	int cx = px, cy = py;

	while (cx != tx || cy != ty)
	{
		if (cx > tx)
		{
			if (cy > ty)
			{
				cx -= 1;
				cy -= 1;
			}
			else if (cy < ty)
			{
				cx -= 1;
				cy += 1;
			}
			else if (cy == ty)
			{
				cx -= 1;
			}
		}
		else if (cx < tx)
		{
			if (cy > ty)
			{
				cx += 1;
				cy -= 1;
			}
			else if (cy < ty)
			{
				cx += 1;
				cy += 1;
			}
			else if (cy == ty)
			{
				cx += 1;
			}
		}
		else if (cx == tx)
		{
			if (cy > ty)
			{
				cy -= 1;
			}
			else if (cy < ty)
			{
				cy += 1;
			}
			else if (cy == ty)
			{
				// nothing	
			}
		}

		total_fog += map_fog[cx][cy];
	}

	return total_fog;
};

// simple printing
void PrintTiles()
{
	int calc_map_fog[MAP_X][MAP_Y];

	int test;

	for (int i=0; i<MAP_X; i++)
	{
		for (int j=0; j<MAP_Y; j++)
		{
			calc_map_fog[i][j] = CalculateFog(pos_x, pos_y, i, j);
		}
	}

	printf("\x1b[2;1f");

	for (int j=0; j<MAP_Y; j++)
	{
		for (int i=0; i<MAP_X; i++)
		{
			if (i == pos_x && j == pos_y) printf("@");
			else
			{
				test = false;

				if (calc_map_fog[i][j] < 10) test = true;
				else
				{
					if (i-1 >= 0) if (calc_map_fog[i-1][j] < 10) test = true;
					if (i+1 < MAP_X) if (calc_map_fog[i+1][j] < 10) test = true;
					if (j-1 >= 0) if (calc_map_fog[i][j-1] < 10) test = true;
					if (j+1 < MAP_Y) if (calc_map_fog[i][j+1] < 10) test = true;
					if (i-1 >= 0 && j-1 >= 0) if (calc_map_fog[i-1][j-1] < 10) test = true;
					if (i+1 < MAP_X && j-1 >= 0) if (calc_map_fog[i+1][j-1] < 10) test = true;
					if (i-1 >= 0 && j+1 < MAP_Y) if (calc_map_fog[i-1][j+1] < 10) test = true;
					if (i+1 < MAP_X && j+1 < MAP_Y) if (calc_map_fog[i+1][j+1] < 10) test = true;
				}

				if (test == true || map_memory[i][j] == true)
				{	
					if (test == true && monster_class[i][j] == CLASS_AMOEBA) printf("A");
					else if (test == true && monster_class[i][j] == CLASS_BAT) printf("B");
					else if (test == true && monster_class[i][j] == CLASS_FUNGUS) printf("F");
					else if (test == true && monster_class[i][j] == CLASS_GOBLIN) printf("G");
					else if (test == true && monster_class[i][j] == CLASS_JAGUAR) printf("J");
					else if (test == true && monster_class[i][j] == CLASS_MUMMY) printf("M");
					else if (test == true && monster_class[i][j] == CLASS_NYMPH) printf("N");
					else if (test == true && monster_class[i][j] == CLASS_ORC) printf("O");
					else if (test == true && monster_class[i][j] == CLASS_SNAKE) printf("S");
					else if (test == true && monster_class[i][j] == CLASS_TROLL) printf("T");
					else if (test == true && monster_class[i][j] == CLASS_VAMPIRE) printf("V");
					else if (test == true && monster_class[i][j] == CLASS_ZOMBIE) printf("Z");
					else if (test == true && item_description[i][j] == DESCRIPTION_DAGGER) printf(")");
					else if (test == true && item_description[i][j] == DESCRIPTION_MACE) printf(")");
					else if (test == true && item_description[i][j] == DESCRIPTION_AXE) printf(")");
					else if (test == true && item_description[i][j] == DESCRIPTION_SWORD) printf(")");
					else if (test == true && item_description[i][j] == DESCRIPTION_LEATHER) printf("]");
					else if (test == true && item_description[i][j] == DESCRIPTION_CHAINMAIL) printf("]");
					else if (test == true && item_description[i][j] == DESCRIPTION_PLATE) printf("]");
					else if (test == true && item_description[i][j] == DESCRIPTION_QUIVER) printf("/");
					else if (test == true && item_description[i][j] == DESCRIPTION_GOLD) printf("$");
					else if (test == true && item_description[i][j] == DESCRIPTION_FOOD) printf("%%");
					else if (test == true && item_description[i][j] == DESCRIPTION_POTION) printf("!");
					else if (test == true && item_description[i][j] == DESCRIPTION_SCROLL) printf("?");
					else if (test == true && item_description[i][j] == DESCRIPTION_AMULET_OF_YENDOR) printf("*");
					else if (map_tile[i][j] == TILE_CLOSED) printf("#");
					else if (test == true && map_tile[i][j] == TILE_OPEN) printf(".");
					else if (map_tile[i][j] == TILE_DOOR) printf("+");
					else if (map_tile[i][j] == TILE_UPSTAIRS) printf("<");
					else if (map_tile[i][j] == TILE_DOWNSTAIRS) printf(">");
					else if (map_tile[i][j] == TILE_SECRET) printf("#");
					else printf("^"); // when you teleport away, very strange, try to fix

					if (map_tile[i][j] != TILE_OPEN) map_memory[i][j] = true;
				}
				else printf(" ");

				if (map_tile[i][j] == TILE_OPEN) map_memory[i][j] = false; // for secrets that have been discovered
			}
		}
		
		printf("\n");
	}

	for (int i=0; i<80; i++) printf(" ");
	printf("\n");

	printf("\x1b[%d;1f", MAP_Y+2);

	printf("HP=%d(%d)", player_health, player_max_health);
	printf(", WPN=");
	if (player_weapon == DESCRIPTION_NONE) printf("Fist");
	else if (player_weapon == DESCRIPTION_DAGGER) printf("Dagg");
	else if (player_weapon == DESCRIPTION_MACE) printf("Mace");
	else if (player_weapon == DESCRIPTION_AXE) printf(" Axe");
	else if (player_weapon == DESCRIPTION_SWORD) printf("Swrd");
	printf(", ARM=");
	if (player_armor == DESCRIPTION_NONE) printf("Clth");
	else if (player_armor == DESCRIPTION_LEATHER) printf("Lthr");
	else if (player_armor == DESCRIPTION_CHAINMAIL) printf("Chml");
	else if (player_armor == DESCRIPTION_PLATE) printf("Plat");
	printf(", Lvl/Dpth=%d/%d", player_level, player_depth);
	printf(", %%=%d", player_food);
	printf(", /=%d", player_arrows);
	printf(", !=%d", player_potions);
	printf(", ?=%d", player_scrolls);
	printf(", $=%d\n", player_gold);

	printf("\x1b[%d;%df", pos_y + 2, pos_x + 1);

	return;
};

int main()
{
	int random_number, initials_count;
	int timeout_death;

	char initials[3];
	int ascended;
	int player_number;

	int init_x, init_y;
	char init_value;

	FILE *scores;

	char score_init[1000][3];
	int score_gold[1000];
	int score_ascended[1000];
	int score_count;
	int bytes;
	char temp_char;
	int temp_int;

	unsigned long time_since_last_button;

	char ch;
	
	while (true)
	{
		// semi-random now
		for (int loop=0; loop<(int)time(0)%1000; loop++) random_number = rand() % 1000;

		for (int i=0; i<40; i++) printf("\n");

		// starting health
		player_health = 20;
		player_max_health = player_health;
		
		// starting weapons (fists), and armor (cloth)
		player_weapon = DESCRIPTION_NONE;
		player_armor = DESCRIPTION_NONE;
	
		// starting level and experience
		player_level = 1;
		player_experience = 0;
	
		// starting arrows and gold
		player_arrows = 5;
		player_gold = 0;
	
		// starting depth and direction
		player_depth = 1;
		player_direction = 1; // +1 = down, -1 = up
	
		// starting turns and food
		player_turns = 0;
		player_food = 250;
		
		// starting potions and scrolls
		player_potions = 0;
		player_scrolls = 0;

		// player can move
		player_cannot_move = false;

		// the reason for the game!
		player_has_amulet_of_yendor = false;

		// this player is active
		time_since_last_button = time(0);
		timeout_death = 0;
	
		// starting out
		CreateGridRooms();
	
		SpreadMonsters();
	
		AddItems();
		
		// title
		printf("\x1b[1;1f");
		
		printf("Arcade Rogue: Get the Amulet of Yendor at depth 5, then re-ascend to surface!   \n");
	
		PrintTiles();

		// main loop
		while (player_health > 0 && player_depth > 0)
		{
			PlayerControls();
			
			if (action_done == true)
			{
				action_done = false;
	 
				CharacterEvents();
	
				BehaviorAI();
	
			}
			
			if (key_pressed == true)
			{
				PrintTiles();

				time_since_last_button = time(0);

			}

			// Only 1.5 minutes until computer talks of killing you
			if (time(0) - time_since_last_button > 90)
			{
				printf("\x1b[1;1f");

				printf("Press a button within %lu seconds or die!          \n",
					120 - (time(0) - time_since_last_button));
			}

			// Only 2 minutes until computers does kill you
			if (time(0) - time_since_last_button > 120)
			{
				player_health = 0;
	
				timeout_death = 1;
			}
		}

		ascended = 0;
	
		// end game
		if (player_depth <= 0 && player_has_amulet_of_yendor == true)
		{
			player_gold = player_gold * 2;

			printf("\x1b[1;1f");

			printf("You ascended! Gold x2 = %d                                                         \n", player_gold);
			
			ascended = 1;
		}
		else if (player_health <= 0)
		{
			player_gold = (int)((float)player_gold * 0.9f);
	
			printf("\x1b[1;1f");
	
			printf("You died! Gold (minus 10%%) = %d                                                \n", player_gold);

			ascended = 0;
		}
		else player_gold = 0; // shouldn't happen

		if (player_gold > 9999) player_gold = 9999; // for safety
	
		if (timeout_death == 0)
		{
			printf("                                                                                \n");

			printf("[ Press Enter to continue ]                                                     \n");
		
			printf("                                                                                \n");

			ch = 0;

			while (ch != 10) { ch = getchar(); }
		}

		// putting in initials for saving
		initials_count = 0;

		initials[0] = 0;
		initials[1] = 0;
		initials[2] = 0;

		init_x = 0;
		init_y = 0;

		if (timeout_death == 0)
		{
			while (initials_count < 4)
			{
				if (initials_count == 3) initials_count++;

				printf("\x1b[3;1f");
	
				printf("Put in your initials! ==> %c%c%c                                                \n",
					initials[0], initials[1], initials[2]);
				
				printf("                                                                                \n");
	
				init_value = 'A';
	
				for (int j=0; j<5; j++)
				{
					for (int i=0; i<6; i++)
					{
						if (i == init_x && j == init_y && initials_count < 3) printf(" <");
						else printf("  ");
	
						if (init_value <= 'Z') printf("%c", init_value);
						else printf(" ");
		
						if (i == init_x && j == init_y && initials_count < 3) printf("> ");
						else printf("  ");
		
						init_value += 1;
					}

					printf("     \n");
				}
	
				ch = 0;

				while (ch == 0 && initials_count < 3) { ch = getchar(); }
	
				if (ch == '4') init_x--;
				if (ch == '6') init_x++;
				if (ch == '2') init_y++;
				if (ch == '8') init_y--;
				if (ch == '7') { init_x--; init_y--; }
				if (ch == '1') { init_x--; init_y++; }
				if (ch == '9') { init_x++; init_y--; }
				if (ch == '3') { init_x++; init_y++; }
				if (ch == 10) // enter
				{ 
					if (!(init_y == 4 && (init_x >= 2 && init_x <= 5)))
					{
						initials[initials_count] = (char)(init_y*6+init_x+(int)('A')); 
	
						initials_count++;
					}
					else
					{
						initials[initials_count] = ' ';
		
						initials_count++;
					}
				}
		
				if (init_x < 0) init_x = 0;
				if (init_x >= 6) init_x = 5;
				if (init_y < 0) init_y = 0;
				if (init_y >= 5) init_y = 4;
			}
	
			printf("\x1b[10;1f");
	
			printf("                                                                                \n");
	
			printf("[ Press Enter to continue ]                                                     \n");	
			
			printf("                                                                                \n");
	
			ch = 0;
	
			while (ch != 10) { ch = getchar(); }
		}
		else if (timeout_death == 1)
		{
			initials[0] = 'N';
			initials[1] = '/';
			initials[2] = 'A';
		}
		
		// get old scores
		scores = NULL;

		scores = fopen("ArcadeRogueScores.txt", "rt");
		if (!scores)
		{
			scores = NULL;

			scores = fopen("ArcadeRogueScores.txt", "wt");

			for (int i=0; i<10; i++) fprintf(scores, "N/A -1 0\n");
			
			fclose(scores);

			scores = NULL;

			scores = fopen("ArcadeRogueScores.txt", "rt");
		}

		score_count = 0;

		bytes = 1;

		while (bytes > 0)
		{
			bytes = fscanf(scores, "%c%c%c %d %d\n", &score_init[score_count][0], &score_init[score_count][1], &score_init[score_count][2],
					&score_gold[score_count], &score_ascended[score_count]);

			if (bytes > 0) score_count++;

			if (score_count >= 1000) bytes = 0;
		}

		fclose(scores);

		// write over it
		scores = NULL;

		scores = fopen("ArcadeRogueScores.txt", "wt");
		
		for (int i=0; i<score_count; i++)
		{
			if (player_gold > score_gold[i])
			{
				fprintf(scores, "%c%c%c %d %d\n", initials[0], initials[1], initials[2], player_gold, ascended);

				player_gold = -1;

				player_number = i;
			}
			
			fprintf(scores, "%c%c%c %d %d\n", score_init[i][0], score_init[i][1], score_init[i][2], score_gold[i], score_ascended[i]);
		}

		fclose(scores);

		// print off a big list
		for (int i=0; i<60; i++) printf("\n");

		scores = NULL;

		scores = fopen("ArcadeRogueScores.txt", "rt");

		printf("\x1b[1;1f");

		printf("Arcade Rogue Top Scores!                                                        \n");

		printf("[ Press Enter to restart ]                                                      \n");
		
		printf("                                                                                \n");

		printf("  Rank   Player    Gold   Status                                                \n");

		if (player_number < 10)
		{
			for (int i=0; i<10; i++)
			{
				fscanf(scores, "%c%c%c %d %d\n", &score_init[0][0], &score_init[0][1], &score_init[0][2],
					&score_gold[0], &score_ascended[0]);

				if (i == player_number) printf(" <");
				else printf("  ");
				printf("%4d    %c%c%c      $%4d   ", i+1, score_init[0][0], score_init[0][1], score_init[0][2],
					score_gold[0]);
				if (score_ascended[0] == 1) printf("Ascended");
				else printf("Died");
				if (i == player_number) printf("> ");
				else printf("  ");
				printf("     \n");
			}

			//printf("-----------------------------------\n");
		}
		else
		{
			for (int i=0; i<9; i++)
			{
				fscanf(scores, "%c%c%c %d %d\n", &score_init[0][0], &score_init[0][1], &score_init[0][2],
					&score_gold[0], &score_ascended[0]);

				printf("  ");
				printf("%4d    %c%c%c     $%4d   ", i+1, score_init[0][0], score_init[0][1], score_init[0][2],
					score_gold[0]);
				if (score_ascended[0] == 1) printf("Ascended");
				else printf("Died");
				printf("       \n");
			}

			//printf("-----------------------------------\n");

			for (int i=9; i<=player_number; i++)
			{
				fscanf(scores, "%c%c%c %d %d\n", &score_init[0][0], &score_init[0][1], &score_init[0][2],
					&score_gold[0], &score_ascended[0]);

			}

			printf(" <");
			printf("%4d    %c%c%c     $%4d   ", player_number+1, score_init[0][0], score_init[0][1], score_init[0][2], score_gold[0]);
			if (score_ascended[0] == 1) printf("Ascended");
			else printf("Died");
			printf(">      \n");
		}

		fclose(scores);

		ch = 0;

		while (ch != 10) { ch = getchar(); }
	}

	return 0;
};
		
			
