// Male Hair 1

#include <GL/gl.h>

const float male_hair1_point[65*3] = {

-0.162000, 1.413300, -0.171600, // used by both, don't change this point!
0.162000, 1.413300, -0.171600, // used by both, don't change this point!
-0.142704, 1.511259, -0.092425,
0.142704, 1.511259, -0.092425,
-0.090811, 1.504765, 0.055361,
0.090811, 1.504765, 0.055361,
-0.038919, 1.459296, 0.252406,
0.038919, 1.459296, 0.252406,
-0.228000, 1.440800, -0.050600, // used by both, don't change this point!
0.228000, 1.440800, -0.050600, // used by both, don't change this point!
-0.246488, 1.498255, 0.055361,
0.246488, 1.498255, 0.055361,
-0.220542, 1.472282, 0.178514,
0.220542, 1.472282, 0.178514,
-0.149190, 1.394366, 0.326298,
0.149190, 1.394366, 0.326298,
-0.261000, 1.330800, 0.014400, // used by both, don't change this point!
0.261000, 1.330800, 0.014400, // used by both, don't change this point!
-0.311352, 1.316448, 0.116936,
0.311352, 1.316448, 0.116936,
-0.285407, 1.348914, 0.277037,
0.285407, 1.348914, 0.277037,
-0.168650, 1.316448, 0.357087,
0.168650, 1.316448, 0.357087,
-0.264000, 1.245000, -0.038500, // used by both, don't change this point!
0.264000, 1.245000, -0.038500, // used by both, don't change this point!
-0.300000, 1.190000, 0.000000, // used by both, don't change this point!
0.300000, 1.190000, 0.000000, // used by both, don't change this point!
-0.300000, 1.217500, 0.066000,
0.300000, 1.217500, 0.066000,
-0.324326, 1.154115, 0.178514,
0.324326, 1.154115, 0.178514,
-0.285407, 1.154115, 0.313984,
0.285407, 1.154115, 0.313984,
-0.129730, 1.154115, 0.375560,
0.129730, 1.154115, 0.375560,
-0.300000, 1.190000, 0.033000, // used by both, don't change this point!
0.300000, 1.190000, 0.033000, // used by both, don't change this point!
-0.276000, 1.135000, 0.022000, // used by both, don't change this point!
0.276000, 1.135000, 0.022000, // used by both, don't change this point!
-0.272434, 1.024246, 0.141568,
0.272434, 1.024246, 0.141568,
-0.311352, 1.089179, 0.160041,
0.311352, 1.089179, 0.160041,
-0.259461, 1.024246, 0.289352,
0.259461, 1.024246, 0.289352,
-0.116757, 1.024246, 0.357087,
0.116757, 1.024246, 0.357087,
-0.276000, 0.945000, 0.000000, // used by both, don't change this point!
0.276000, 0.945000, 0.000000, // used by both, don't change this point!
-0.240000, 1.025000, 0.022000, // used by both, don't change this point!
0.240000, 1.025000, 0.022000, // used by both, don't change this point!
-0.214000, 0.915000, 0.176000, // used by both, don't change this point!
0.214000, 0.915000, 0.176000, // used by both, don't change this point!
-0.060000, 0.915000, 0.187000, // used by both, don't change this point!
0.060000, 0.915000, 0.187000, // used by both, don't change this point!
0.000000, 1.348914, 0.363245,
0.000000, 1.154115, 0.387875,
0.000000, 1.024246, 0.363245,
0.000000, 0.915000, 0.198000, // used by both, don't change this point!
-0.181622, 0.829465, 0.252406,
0.181622, 0.829465, 0.252406,
-0.064865, 0.829465, 0.264722,
0.064865, 0.829465, 0.264722,
0.000000, 0.829465, 0.277037,

};

const int male_hair1_bone[65] = {

0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,

};

const int male_hair1_indice[105*3] = {

0, 1, 3,
0, 3, 2,
2, 3, 5,
2, 5, 4,
4, 5, 7,
4, 7, 6,
0, 2, 8,
2, 10, 8,
1, 9, 3,
3, 9, 11,
2, 4, 10,
4, 12, 10,
3, 11, 5,
5, 11, 13,
4, 6, 12,
6, 14, 12,
5, 13, 7,
7, 13, 15,
8, 18, 16,
8, 10, 18,
9, 17, 19,
9, 19, 11,
10, 12, 18,
12, 20, 18,
11, 19, 13,
19, 21, 13,
12, 14, 20,
14, 22, 20,
13, 21, 15,
23, 15, 21,
16, 18, 28,
18, 30, 28,
16, 28, 24,
24, 28, 26,
17, 29, 19,
19, 29, 31,
17, 25, 29,
25, 27, 29,
18, 32, 30,
18, 20, 32,
19, 31, 33,
19, 33, 21,
20, 22, 34,
20, 34, 32,
21, 33, 35,
21, 35, 23,
26, 28, 36,
28, 30, 36,
30, 42, 36,
42, 40, 36,
40, 38, 36,
27, 37, 29,
29, 37, 31,
31, 37, 43,
43, 37, 41,
41, 37, 39,
30, 32, 44,
30, 44, 42,
31, 45, 33,
31, 43, 45,
32, 34, 46,
32, 46, 44,
33, 47, 35,
33, 45, 47,
38, 50, 48,
38, 40, 50,
39, 49, 51,
39, 51, 41,
40, 42, 44,
40, 44, 60,
41, 45, 43,
41, 61, 45,
40, 60, 50,
41, 51, 61,
46, 60, 44,
46, 62, 60,
47, 45, 61,
47, 61, 63,
6, 7, 56,
14, 6, 56,
22, 14, 56,
7, 15, 56,
15, 23, 56,
22, 56, 57,
22, 57, 34,
23, 57, 56,
23, 35, 57,
34, 57, 58,
34, 58, 46,
35, 58, 57,
35, 47, 58,
46, 58, 64,
46, 64, 62,
47, 64, 58,
47, 63, 64,
64, 59, 62,
62, 59, 54,
64, 63, 59,
63, 55, 59,
62, 54, 60,
60, 54, 52,
63, 61, 55,
61, 53, 55,
50, 60, 52,
51, 53, 61,

};

// 0 = hair, 1 = cloth
const float male_hair1_color[105*3] = {

0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
2,
0,
2,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,
0,

};

void DrawMaleHair1(float hair_r, float hair_g, float hair_b, float cloth_r, float cloth_g, float cloth_b, float skin_r, float skin_g, float skin_b)
{
	glBegin(GL_TRIANGLES);

	for (int i=0; i<105; i++)
	{
		if (male_hair1_color[i] == 0) // skin
		{
			glColor3f(hair_r, hair_g, hair_b);
		}
		else if (male_hair1_color[i] == 1) // cloth
		{
			glColor3f(cloth_r, cloth_g, cloth_b);
		}
		else if (male_hair1_color[i] == 2) // skin
		{
			glColor3f(skin_r, skin_g, skin_b);
		}
		glNormal3f(-(male_hair1_point[male_hair1_indice[i*3+1]*3+1] - male_hair1_point[male_hair1_indice[i*3+0]*3+1]) * 
			(male_hair1_point[male_hair1_indice[i*3+2]*3+2] - male_hair1_point[male_hair1_indice[i*3+0]*3+2]) +
			(male_hair1_point[male_hair1_indice[i*3+1]*3+2] - male_hair1_point[male_hair1_indice[i*3+0]*3+2]) *
			(male_hair1_point[male_hair1_indice[i*3+2]*3+1] - male_hair1_point[male_hair1_indice[i*3+0]*3+1]),
			(male_hair1_point[male_hair1_indice[i*3+1]*3+0] - male_hair1_point[male_hair1_indice[i*3+0]*3+0]) * 
			(male_hair1_point[male_hair1_indice[i*3+2]*3+2] - male_hair1_point[male_hair1_indice[i*3+0]*3+2]) -
			(male_hair1_point[male_hair1_indice[i*3+1]*3+2] - male_hair1_point[male_hair1_indice[i*3+0]*3+2]) *
			(male_hair1_point[male_hair1_indice[i*3+2]*3+0] - male_hair1_point[male_hair1_indice[i*3+0]*3+0]),
			-(male_hair1_point[male_hair1_indice[i*3+1]*3+0] - male_hair1_point[male_hair1_indice[i*3+0]*3+0]) * 
			(male_hair1_point[male_hair1_indice[i*3+2]*3+1] - male_hair1_point[male_hair1_indice[i*3+0]*3+1]) +
			(male_hair1_point[male_hair1_indice[i*3+1]*3+1] - male_hair1_point[male_hair1_indice[i*3+0]*3+1]) *
			(male_hair1_point[male_hair1_indice[i*3+2]*3+0] - male_hair1_point[male_hair1_indice[i*3+0]*3+0]));
		glVertex3f(male_hair1_point[male_hair1_indice[i*3+0]*3+0], male_hair1_point[male_hair1_indice[i*3+0]*3+1], male_hair1_point[male_hair1_indice[i*3+0]*3+2]);
		glVertex3f(male_hair1_point[male_hair1_indice[i*3+1]*3+0], male_hair1_point[male_hair1_indice[i*3+1]*3+1], male_hair1_point[male_hair1_indice[i*3+1]*3+2]);
		glVertex3f(male_hair1_point[male_hair1_indice[i*3+2]*3+0], male_hair1_point[male_hair1_indice[i*3+2]*3+1], male_hair1_point[male_hair1_indice[i*3+2]*3+2]);
	}

	glEnd();

	return;
};
