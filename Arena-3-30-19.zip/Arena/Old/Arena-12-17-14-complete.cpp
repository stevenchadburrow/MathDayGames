// Arena.cpp

// This program is for the Math Day 2014 presentation.  It has 4 bots, and will have 2 player side-by-side support in a Deathmatch Arena.

/*
Some notes for future use:
- Joysticks using /dev/input/js0 are slow, use 'xboxdrv' instead.  For two controllers, use --wid 0 and --wid 1 when setting up two seperate instances of xboxdrv.
	Or -D --next-controller, or even in the config file specifying next-controller = true.  Remember to 'sudo rmmod xpad' beforehand!!!
- V-Sync on Linux is built in with the Nvidia drivers.  If you go to Nvidia Settings, and turn off V-Sync, the FPS will skyrocket.  I recommend keeping it on, so you stay at 60 FPS.
- The last textures I had used were really messing up.  Haven't checked it here 100%.  Be careful, something about a formatting issue?
- There is a way to do dual-screens, PIP really, involving drawing the first scene with all of the normal setup stuff, NO glutSwapBuffer(), glClear(DEPTH_BUFFER) again and redo
	the settings with now glViewport() smaller and gluPerspective() changed.  Draw it all over again.  Finally you glutSwapBuffer() when you are done with both.
- For sounds, I used: system("play -q -v 1.0 Laser.mp3 &");  You need to: sudo apt-get install libsox-fmt-mp3 for this to work.  This is using the 'sox' tools. 

*/

/*
This game is intended to run at 60 FPS, this is almost always done through V-Sync, but just incase...

Also, I'm stealing the human models for this particular project.  If you want to change them, no problems.

In order to run this on Linux, you must include -lglut and -lGLU when compiling.
g++ -o Main.o Main.cpp -lglut -lGLU -lGL
./Main.o
Also make sure you have all of the glut and/or freeglut packages downloaded, GLU, maybe OpenGL Mesa Dev packages??

In order to run this on Windows, use Dev-C++ (Code::Blocks also works?).  Start a Multimedia Project with glut, not an empty project like normal.
To get that project, you need to go to Tools->Packages and download all glut and/or freeglut packages.
Remember that the Project Options->Linker has to have stuff like -lwinmm -lglut -lglut32 -lopengl32  (Something with GLU) etc....
*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <GL/freeglut.h>
#include <GL/gl.h>
#include <GL/glu.h>

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

int mod_key; // for  GLUT_ACTIVE_SHIFT, GLUT_ACTIVE_CTRL, and GLUT_ACTIVE_ALT
bool keyboard[256], special_keyboard[256];
bool joystick_enabled = false;
int joystick_button[32];
GLuint tex[15];
int frames_per_second = 0, frames_per_second_counter = 0, frames_per_second_timer = 0;

class _Point {
public:
	_Point()
	{
		x = y = z = 0.0f;
	}

	float x, y, z;
	
	void Set(float my_x, float my_y, float my_z)
	{
		x = my_x;
		y = my_y;
		z = my_z;
	
		return;
	}
};

_Point *camera_pos, *camera_rot;

class _Mouse {
public:
	_Mouse()
	{
		x = y = 0;
	
		button = 0;
		state = 0;
	}

	int x, y;

	int button, state;

} *mouse;

class _Joystick {
public:
	_Joystick()
	{
		x = y = z = 0;
	}

	int x, y, z;

} *joystick_axis;





const float arena_point[26*4*3 + 2*3*3 + 6*4*3] = {

// middle floor
-100.0f, 0.0f, -100.0f,
-100.0f, 0.0f, 100.0f,
100.0f, 0.0f, 100.0f,
100.0f, 0.0f, -100.0f,

// side floors
-300.0f, 0.0f, -25.0f,
-300.0f, 0.0f, 25.0f,
-100.0f, 0.0f, 25.0f,
-100.0f, 0.0f, -25.0f,

100.0f, 0.0f, -25.0f,
100.0f, 0.0f, 25.0f,
300.0f, 0.0f, 25.0f,
300.0f, 0.0f, -25.0f,

// middle big walls
-100.0f, 100.0f, -100.0f,
-100.0f, 0.0f, -100.0f,
100.0f, 0.0f, -100.0f,
100.0f, 100.0f, -100.0f,

100.0f, 100.0f, 100.0f,
100.0f, 0.0f, 100.0f,
-100.0f, 0.0f, 100.0f,
-100.0f, 100.0f, 100.0f,

// middle small walls
-100.0f, 100.0f, -25.0f,
-100.0f, 0.0f, -25.0f,
-100.0f, 0.0f, -100.0f,
-100.0f, 100.0f, -100.0f,

-100.0f, 100.0f, 100.0f,
-100.0f, 0.0f, 100.0f,
-100.0f, 0.0f, 25.0f,
-100.0f, 100.0f, 25.0f,

100.0f, 100.0f, -100.0f,
100.0f, 0.0f, -100.0f,
100.0f, 0.0f, -25.0f,
100.0f, 100.0f, -25.0f,

100.0f, 100.0f, 25.0f,
100.0f, 0.0f, 25.0f,
100.0f, 0.0f, 100.0f,
100.0f, 100.0f, 100.0f,

// side big walls
-300.0f, 100.0f, -25.0f,
-300.0f, 0.0f, -25.0f,
-100.0f, 0.0f, -25.0f,
-100.0f, 100.0f, -25.0f,

-100.0f, 100.0f, 25.0f,
-100.0f, 0.0f, 25.0f,
-300.0f, 0.0f, 25.0f,
-300.0f, 100.0f, 25.0f,

100.0f, 100.0f, -25.0f,
100.0f, 0.0f, -25.0f,
300.0f, 0.0f, -25.0f,
300.0f, 100.0f, -25.0f,

300.0f, 100.0f, 25.0f,
300.0f, 0.0f, 25.0f,
100.0f, 0.0f, 25.0f,
100.0f, 100.0f, 25.0f,

// far side walls
-300.0f, 100.0f, 25.0f,
-300.0f, 0.0f, 25.0f,
-300.0f, 0.0f, -25.0f,
-300.0f, 100.0f, -25.0f,

300.0f, 100.0f, -25.0f,
300.0f, 0.0f, -25.0f,
300.0f, 0.0f, 25.0f,
300.0f, 100.0f, 25.0f,

// middle ceiling
-100.0f, 100.0f, 100.0f,
-100.0f, 100.0f, -100.0f,
100.0f, 100.0f, -100.0f,
100.0f, 100.0f, 100.0f,

// side ceilings
-300.0f, 100.0f, 25.0f,
-300.0f, 100.0f, -25.0f,
-100.0f, 100.0f, -25.0f,
-100.0f, 100.0f, 25.0f,

100.0f, 100.0f, 25.0f,
100.0f, 100.0f, -25.0f,
300.0f, 100.0f, -25.0f,
300.0f, 100.0f, 25.0f,


// left stairs
-300.0f, 25.0f, -25.0f,
-300.0f, 25.0f, 25.0f,
-275.0f, 25.0f, 25.0f,
-275.0f, 25.0f, -25.0f,

-275.0f, 25.0f, -25.0f,
-275.0f, 25.0f, 0.0f,
-225.0f, 50.0f, 0.0f,
-225.0f, 50.0f, -25.0f,

-275.0f, 25.0f, 0.0f,
-275.0f, 25.0f, 25.0f,
-225.0f, 0.0f, 25.0f,
-225.0f, 0.0f, 0.0f,

// right stairs
275.0f, 25.0f, -25.0f,
275.0f, 25.0f, 25.0f,
300.0f, 25.0f, 25.0f,
300.0f, 25.0f, -25.0f,

225.0f, 50.0f, 0.0f,
225.0f, 50.0f, 25.0f,
275.0f, 25.0f, 25.0f,
275.0f, 25.0f, 0.0f,

225.0f, 0.0f, -25.0f,
225.0f, 0.0f, 0.0f,
275.0f, 25.0f, 0.0f,
275.0f, 25.0f, -25.0f, 

// stair walls
-225.0f, 50.0f, 0.0f,
-225.0f, 0.0f, 0.0f,
-225.0f, 0.0f, -25.0f,
-225.0f, 50.0f, -25.0f,

225.0f, 50.0f, 0.0f,
225.0f, 0.0f, 0.0f,
225.0f, 0.0f, 25.0f,
225.0f, 50.0f, 25.0f,

-275.0f, 25.0f, 0.0f, // just one triangle
-225.0f, 0.0f, 0.0f,
-225.0f, 50.0f, 0.0f,

275.0f, 25.0f, 0.0f, // just one triangle
225.0f, 0.0f, 0.0f,
225.0f, 50.0f, 0.0f,

// side upper floors
-225.0f, 50.0f, -25.0f,
-225.0f, 50.0f, 25.0f,
-100.0f, 50.0f, 25.0f,
-100.0f, 50.0f, -25.0f,

100.0f, 50.0f, -25.0f,
100.0f, 50.0f, 25.0f,
225.0f, 50.0f, 25.0f,
225.0f, 50.0f, -25.0f,

// middle upper floors
-100.0f, 50.0f, -100.0f,
-50.0f, 50.0f, -50.0f,
50.0f, 50.0f, -50.0f,
100.0f, 50.0f, -100.0f,

-100.0f, 50.0f, -100.0f,
-100.0f, 50.0f, 100.0f,
-50.0f, 50.0f, 50.0f,
-50.0f, 50.0f, -50.0f,

-50.0f, 50.0f, 50.0f,
-100.0f, 50.0f, 100.0f,
100.0f, 50.0f, 100.0f,
50.0f, 50.0f, 50.0f,

50.0f, 50.0f, -50.0f,
50.0f, 50.0f, 50.0f,
100.0f, 50.0f, 100.0f,
100.0f, 50.0f, -100.0f,

}; 

const int arena_indice[26*2*3 + 2*3 + 6*2*3] = {

0, 1, 2,
0, 2, 3,

4, 5, 6,
4, 6, 7,

8, 9, 10,
8, 10, 11,

12, 13, 14,
12, 14, 15,

16, 17, 18,
16, 18, 19,

20, 21, 22,
20, 22, 23,

24, 25, 26,
24, 26, 27,

28, 29, 30,
28, 30, 31,

32, 33, 34,
32, 34, 35,

36, 37, 38,
36, 38, 39,

40, 41, 42,
40, 42, 43,

44, 45, 46,
44, 46, 47,

48, 49, 50,
48, 50, 51,

52, 53, 54,
52, 54, 55,

56, 57, 58,
56, 58, 59,

60, 61, 62,
60, 62, 63,

64, 65, 66,
64, 66, 67,

68, 69, 70,
68, 70, 71,


72, 73, 74,
72, 74, 75,

76, 77, 78,
76, 78, 79,

80, 81, 82,
80, 82, 83,

84, 85, 86,
84, 86, 87,

88, 89, 90,
88, 90, 91,

92, 93, 94,
92, 94, 95,

96, 97, 98,
96, 98, 99,

100, 101, 102,
100, 102, 103,

104, 105, 106, // only one triangle

107, 108, 109, // only one triangle

110, 111, 112,
110, 112, 113,

114, 115, 116,
114, 116, 117,

118, 119, 120,
118, 120, 121,

122, 123, 124,
122, 124, 125,

126, 127, 128,
126, 128, 129,

130, 131, 132,
130, 132, 133,

};

const float arena_tex_coord[26*2*6 + 2*6 + 6*2*6] = {

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,


0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  1.0f, 1.0f,
0.0f, 0.0f,  1.0f, 1.0f,  1.0f, 0.0f,

0.0f, 0.5f,  1.0f, 1.0f,  1.0f, 0.0f, // only one triangle

0.0f, 0.5f,  1.0f, 1.0f,  1.0f, 0.0f, // only one triangle

0.25f, 0.25f,  0.25f, 0.75f,  0.75f, 0.75f,
0.25f, 0.25f,  0.75f, 0.75f,  0.75f, 0.25f,

0.25f, 0.25f,  0.25f, 0.75f,  0.75f, 0.75f,
0.25f, 0.25f,  0.75f, 0.75f,  0.75f, 0.25f,

0.0f, 0.0f,  0.25f, 0.25f,  0.75f, 0.25f,
0.0f, 0.0f,  0.75f, 0.25f,  1.0f, 0.0f,

0.0f, 0.0f,  0.0f, 1.0f,  0.25f, 0.75f,
0.0f, 0.0f,  0.25f, 0.75f,  0.25f, 0.25f,

0.25f, 0.75f,  0.0f, 1.0f,  1.0f, 1.0f,
0.25f, 0.75f,  1.0f, 1.0f,  0.75f, 0.75f,

0.75f, 0.25f,  0.75f, 0.75f,  1.0f, 1.0f,
0.75f, 0.25f,  1.0f, 1.0f,  1.0f, 0.0f,

};

const int arena_texture[26*2 + 2 + 6*2] = {

0,
0,
1,
1,
1,
1,
2,
2,
2,
2,
3,
3,
3,
3,
3,
3,
3,
3,
4,
4,
4,
4,
4,
4,
4,
4,
5,
5,
5,
5,
6,
6,
7,
7,
7,
7,

8,
8,
9,
9,
9,
9,
8,
8,
9,
9,
9,
9,
10,
10,
10,
10,
11,
11,
12,
12,
12,
12,
12,
12,
12,
12,
12,
12,
12,
12,

};

const float arena_way_point[11*3 + 16*3] = {

0.0f, 0.0f, 0.0f,
-65.0f, 0.0f, -65.0f,
-65.0f, 0.0f, 0.0f,
-65.0f, 0.0f, 65.0f,
0.0f, 0.0f, 65.0f,
65.0f, 0.0f, 65.0f,
65.0f, 0.0f, 0.0f,
65.0f, 0.0f, -65.0f,
0.0f, 0.0f, -65.0f,
-225.0f, 0.0f, 12.0f,
225.0f, 0.0f, -12.0f,

-275.0f, 25.0f, 12.0f,
-285.0f, 25.0f, 0.0f,
-275.0f, 25.0f, -12.0f,
-225.0f, 50.0f, -12.0f,
275.0f, 25.0f, -12.0f,
285.0f, 25.0f, 0.0f,
275.0f, 25.0f, 12.0f,
225.0f, 50.0f, 12.0f,
-55.0f, 50.0f, -55.0f,
-55.0f, 50.0f, 0.0f,
-55.0f, 50.0f, 55.0f,
0.0f, 50.0f, 55.0f,
55.0f, 50.0f, 55.0f,
55.0f, 50.0f, 0.0f,
55.0f, 50.0f, -55.0f,
0.0f, 50.0f, -55.0f,



};

const int arena_way_indice[11*8 + 16*8] = {

1, 2, 3, 4, 5, 6, 7, 8,
0, 2, 8, -1, -1, -1, -1, -1,
0, 1, 3, 4, 8, 9, -1, -1,
0, 2, 4, -1, -1, -1, -1, -1,
0, 2, 3, 5, 6, -1, -1, -1,
0, 4, 6, -1, -1, -1, -1, -1,
0, 4, 5, 7, 8, 10, -1, -1,
0, 6, 8, -1, -1, -1, -1, -1,
0, 1, 2, 6, 7, -1, -1, -1,
2, 11, -1, -1, -1, -1, -1, -1, 
6, 15, -1, -1, -1, -1, -1, -1,

9, 12, -1, -1, -1, -1, -1, -1,
11, 13, -1, -1, -1, -1, -1, -1,
12, 14, -1, -1, -1, -1, -1, -1,
13, 20, -1, -1, -1, -1, -1, -1,
10, 16, -1, -1, -1, -1, -1, -1,
15, 17, -1, -1, -1, -1, -1, -1,
16, 18, -1, -1, -1, -1, -1, -1,
17, 24, -1, -1, -1, -1, -1, -1,
20, 26, 0, -1, -1, -1, -1, -1,
14, 19, 21, 0, -1, -1, -1, -1,
20, 22, 0, -1, -1, -1, -1, -1,
21, 23, 0, -1, -1, -1, -1, -1,
22, 24, 0, -1, -1, -1, -1, -1,
18, 23, 25, 0, -1, -1, -1, -1,
24, 26, 0, -1, -1, -1, -1, -1,
19, 25, 0, -1, -1, -1, -1, -1,


};


// Robot models
const float male_upper_torso_point[6*3] = {

-1.0f, 0.0f, 0.5f,
0.0f, -2.0f, 0.25f,
1.0f, 0.0f, 0.5f,
-1.0f, 0.0f, -0.5f,
0.0f, -2.0f, -0.25f,
1.0f, 0.0f, -0.5f,

};

const int male_upper_torso_indice[8*3] = {

0, 1, 2,
5, 4, 3,
3, 0, 2,
3, 2, 5,
3, 4, 1,
3, 1, 0,
2, 1, 4,
2, 4, 5,

};

const float female_upper_torso_point[8*3] = {

-0.5f, 0.0f, 0.25f,
0.0f, -1.5f, 0.25f,
0.5f, 0.0f, 0.25f,
-0.5f, 0.0f, -0.25f,
0.0f, -1.5f, -0.25f,
0.5f, 0.0f, -0.25f,
-0.3f, -0.6f, 0.4f,
0.3f, -0.6f, 0.4f,

};

const int female_upper_torso_indice[12*3] = {

0, 1, 6,
2, 7, 1,
0, 6, 7,
0, 7, 2,
6, 1, 7,
5, 4, 3,
3, 0, 2,
3, 2, 5,
3, 4, 1,
3, 1, 0,
2, 1, 4,
2, 4, 5,

};

const float male_middle_torso_point[10*3] = {

0.0f, 0.25f, 0.0f,
-0.25f, 0.0f, 0.0f,
-0.18f, 0.0f, 0.18f,
0.0f, 0.0f, 0.25f,
0.18f, 0.0f, 0.18f,
0.25f, 0.0f, 0.0f,
0.18f, 0.0f, -0.18f,
0.0f, 0.0f, -0.25f,
-0.18f, 0.0f, -0.18f,
0.0f, -0.25f, 0.0f,

};

const int male_middle_torso_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float female_middle_torso_point[10*3] = {

0.0f, 0.125f, 0.0f,
-0.125f, 0.0f, 0.0f,
-0.09f, 0.0f, 0.09f,
0.0f, 0.0f, 0.125f,
0.09f, 0.0f, 0.09f,
0.125f, 0.0f, 0.0f,
0.09f, 0.0f, -0.09f,
0.0f, 0.0f, -0.125f,
-0.09f, 0.0f, -0.09f,
0.0f, -0.125f, 0.0f,

};

const int female_middle_torso_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float male_lower_torso_point[6*3] = {

0.0f, 0.0f, 0.25f,
-0.5f, -0.5f, 0.25f,
0.5f, -0.5f, 0.25f,
0.0f, 0.0f, -0.25f,
-0.5f, -0.5f, -0.25f,
0.5f, -0.5f, -0.25f,

};

const int male_lower_torso_indice[8*3] = {

0, 1, 2,
3, 5, 4,
3, 4, 1,
3, 1, 0,
0, 2, 5,
0, 5, 3,
1, 4, 5,
1, 5, 2,

};

const float female_lower_torso_point[6*3] = {

0.0f, 0.0f, 0.25f,
-0.75f, -1.0f, 0.25f,
0.75f, -1.0f, 0.25f,
0.0f, 0.0f, -0.25f,
-0.75f, -1.0f, -0.25f,
0.75f, -1.0f, -0.25f,

};

const int female_lower_torso_indice[8*3] = {

0, 1, 2,
3, 5, 4,
3, 4, 1,
3, 1, 0,
0, 2, 5,
0, 5, 3,
1, 4, 5,
1, 5, 2,

};

const float male_upper_arm_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.05f, -1.5f, 0.05f,
0.05f, -1.5f, 0.05f,
0.05f, -1.5f, -0.05f,
-0.05f, -1.5f, -0.05f,

};

const int male_upper_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_upper_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.05f, -1.25f, 0.05f,
0.05f, -1.25f, 0.05f,
0.05f, -1.25f, -0.05f,
-0.05f, -1.25f, -0.05f,

};

const int female_upper_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_lower_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.25f, -1.5f, 0.25f,
0.25f, -1.5f, 0.25f,
0.25f, -1.5f, -0.25f,
-0.25f, -1.5f, -0.25f,

};

const int male_lower_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_lower_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.15f, -1.25f, 0.15f,
0.15f, -1.25f, 0.15f,
0.15f, -1.25f, -0.15f,
-0.15f, -1.25f, -0.15f,

};

const int female_lower_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_upper_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.15f, -2.0f, 0.15f,
0.15f, -2.0f, 0.15f,
0.15f, -2.0f, -0.15f,
-0.15f, -2.0f, -0.15f,

};

const int male_upper_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_upper_leg_point[8*3] = {

-0.25f, -0.1f, 0.25f,
0.25f, -0.1f, 0.25f,
0.25f, -0.1f, -0.25f,
-0.25f, -0.1f, -0.25f,
-0.15f, -2.0f, 0.15f,
0.15f, -2.0f, 0.15f,
0.15f, -2.0f, -0.15f,
-0.15f, -2.0f, -0.15f,

};

const int female_upper_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_lower_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.35f, -2.0f, 0.35f,
0.35f, -2.0f, 0.35f,
0.35f, -2.0f, -0.35f,
-0.35f, -2.0f, -0.35f,

};

const int male_lower_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_lower_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.35f, -2.0f, 0.35f,
0.35f, -2.0f, 0.35f,
0.35f, -2.0f, -0.35f,
-0.35f, -2.0f, -0.35f,

};

const int female_lower_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_head_point[16*3] = {

0.5f, 1.0f, 0.25f,
0.5f, 1.0f, -0.25f,
-0.5f, 1.0f, -0.25f,
-0.5f, 1.0f, 0.25f,
0.5f, 0.0f, 0.25f,
0.5f, 0.0f, -0.25f,
-0.5f, 0.0f, -0.25f,
-0.5f, 0.0f, 0.25f,

};

const int male_head_indice[12*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
5, 4, 7,
5, 7, 6,

};

const float female_head_point[16*3] = {

0.4f, 1.0f, 0.25f,
0.4f, 1.0f, -0.25f,
-0.4f, 1.0f, -0.25f,
-0.4f, 1.0f, 0.25f,
0.25f, 0.0f, 0.25f,
0.25f, 0.0f, -0.25f,
-0.25f, 0.0f, -0.25f,
-0.25f, 0.0f, 0.25f,

};

const int female_head_indice[12*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
5, 4, 7,
5, 7, 6,

};

const float male_visor_point[8*3] = {

0.4f, 0.55f, -0.25f,
0.4f, 0.55f, -0.3f,
-0.4f, 0.55f, -0.3f,
-0.4f, 0.55f, -0.25f,
0.4f, 0.45f, -0.25f,
0.4f, 0.45f, -0.3f,
-0.4f, 0.45f, -0.3f,
-0.4f, 0.45f, -0.25f,

};

const int male_visor_indice[10*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
5, 4, 7,
5, 7, 6,

};

const float female_visor_point[8*3] = {

0.275f, 0.55f, -0.25f,
0.275f, 0.55f, -0.3f,
-0.275f, 0.55f, -0.3f,
-0.275f, 0.55f, -0.25f,
0.275f, 0.45f, -0.25f,
0.275f, 0.45f, -0.3f,
-0.275f, 0.45f, -0.3f,
-0.275f, 0.45f, -0.25f,

};

const int female_visor_indice[10*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
5, 4, 7,
5, 7, 6,

};

const float large_joint_point[10*3] = {

0.0f, 0.25f, 0.0f,
-0.25f, 0.0f, 0.0f,
-0.18f, 0.0f, 0.18f,
0.0f, 0.0f, 0.25f,
0.18f, 0.0f, 0.18f,
0.25f, 0.0f, 0.0f,
0.18f, 0.0f, -0.18f,
0.0f, 0.0f, -0.25f,
-0.18f, 0.0f, -0.18f,
0.0f, -0.25f, 0.0f,

};

const int large_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float medium_joint_point[10*3] = {

0.0f, 0.15f, 0.0f,
-0.15f, 0.0f, 0.0f,
-0.11f, 0.0f, 0.11f,
0.0f, 0.0f, 0.15f,
0.11f, 0.0f, 0.11f,
0.15f, 0.0f, 0.0f,
0.11f, 0.0f, -0.11f,
0.0f, 0.0f, -0.15f,
-0.11f, 0.0f, -0.11f,
0.0f, -0.15f, 0.0f,

};

const int medium_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float small_joint_point[10*3] = {

0.0f, 0.05f, 0.0f,
-0.05f, 0.0f, 0.0f,
-0.04f, 0.0f, 0.04f,
0.0f, 0.0f, 0.05f,
0.04f, 0.0f, 0.04f,
0.05f, 0.0f, 0.0f,
0.04f, 0.0f, -0.04f,
0.0f, 0.0f, -0.05f,
-0.04f, 0.0f, -0.04f,
0.0f, -0.05f, 0.0f,

};

const int small_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};


// Any picture in the .bmp format, 24 bit, should be good to go now.
bool LoadBitmap(const char *filename, GLuint &tex)
{
	FILE *bitmap;

	unsigned long int width, height;
	
	unsigned char *bits, *final;
	unsigned char header[54], temp;

	bitmap = fopen(filename, "rb");
	if (!bitmap) return false;

	fread(&header, 54, 1, bitmap);

	// If it's not a Bitmap, exit!
	if (256 * header[1] + header[0] != 19778)
	{
		fclose(bitmap);

		return false;
	}

	width = 256 * header[19] + header[18];
	height = 256 * header[23] + header[22];

	// Once the size is found, malloc() that much to 'bits' and read.
	bits = (unsigned char *) malloc(width*height*3);

	fread(bits, width*height*3, 1, bitmap);

	fclose(bitmap);

	// Flip the BGR pixels to RGB.
	for (int i=0; i<width*height*3; i+=3)
	{
		temp = bits[i];
		bits[i] = bits[i+2];
		bits[i+2] = temp;
	}

	final = (unsigned char *) malloc(width*height*4);

	unsigned long int count = 0;

	// Put in Alpha values.
	for (int i=0; i<width*height*3; i+=3)
	{
		final[count] = bits[i];
		count++;
		final[count] = bits[i+1];
		count++;
		final[count] = bits[i+2];
		count++;
		
		if (bits[i] == 0 && bits[i+1] == 0 && bits[i+2] == 0)
		{
			final[count] = 0;
			count++;
		}
		else
		{
			final[count] = 255;
			count++;
		}
	}
	
	// Remember each malloc() needs a free().
	free(bits);

	glGenTextures(1, &tex);
	glBindTexture(GL_TEXTURE_2D, tex);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, final);
	
	// Remember each malloc() needs a free().
	free(final);

	return true;
};

// This has everything needed for the character(s), plan on using 2 of them soon.
class _Character {
public:
	_Character()
	{
		pos[0] = 0.0f;
		pos[1] = 10.0f;
		pos[2] = 0.0f;

		rot[0] = 0.0f;
		rot[1] = 0.0f;

		hit_timer = 0.0f;
		cool_down = 0.0f;

		health = 100;

		kills = 0;
		deaths = 0;

		ammo = 100;

		for (int i=0; i<256; i++) message[i] = 0;
		
		message_timer = 0;
	}

	~_Character()
	{

	}

	float pos[3], rot[2], y_vel;
	bool last_bounded; // Holds on to the fact that you are on the ground, and can jump now. 
	float hit_timer, cool_down; // hit_timer is to turn the screen red, cool_down is until you can shoot again.
	int health;
	int kills, deaths;
	float ammo;
	char message[256];
	int message_timer;

};

// Everything you need for a bot.
class _Bot {
public:
	_Bot()
	{
		rot[0] = 0.0f;
		rot[1] = 0.0f;

		hate = -3;

		old_way = rand() % 9;
		new_way = rand() % 9;

		pos[0] = arena_way_point[old_way*3+0] + ((float)(rand() % 200) - 100.0f) / 100.0f;
		pos[1] = arena_way_point[old_way*3+1] + ((float)(rand() % 200) - 100.0f) / 100.0f;
		pos[2] = arena_way_point[old_way*3+2] + ((float)(rand() % 200) - 100.0f) / 100.0f;

		hit_timer = 0.0f;
		cool_down = 0.0f;

		health = 100;

		preferred_weapon = rand() % 2;

		kills = 0;
		deaths = 0;

		ammo = 100;

		standing_still = 0.0f;

		animation_type = 0;
		animation_timer = 0.0f;
		
		enemy_focus = -1;
	}

	~_Bot()
	{

	}

	float pos[3], rot[2], y_vel;
	int old_way, new_way, hate; // from and to way_points, hate is who they are focused on: -1 is character[0], and if it's itself, it's no-one.
	float hit_timer, cool_down;
	int health;
	int preferred_weapon; // can change over time.
	int kills, deaths;
	float ammo;
	float standing_still; // how long until they can move again.	
	int animation_type;
	float animation_timer;
	int enemy_focus; // chase after particular enemy

};

// Pretty simple bullet info.
class _Bullet {
public:
	_Bullet()
	{
		type = -1;
		owner = -3;

		pos[0] = 0.0f;
		pos[1] = 0.0f;
		pos[2] = 0.0f;
		
		vel[0] = 0.0f;
		vel[1] = 0.0f;
		vel[2] = 0.0f;
	}

	~_Bullet()
	{

	}

	int type, owner;
	float pos[3], vel[3];

};

// Health and Ammo pickups.
class _Pickup {
public:
	_Pickup()
	{
		type = -1;

		pos[0] = 0.0f;
		pos[1] = 0.0f;
		pos[2] = 0.0f;
	}

	~_Pickup()
	{

	}

	int type;
	float pos[3];

};

// Used for particle effects.
class _Particle {
public:
	_Particle()
	{
		type = -1;

		timer = 0.0f;
		gravity = 0.0f;

		pos[0] = 0.0f;
		pos[1] = 0.0f;
		pos[2] = 0.0f;
		vel[0] = 0.0f;
		vel[1] = 0.0f;
		vel[2] = 0.0f;
	}

	~_Particle()
	{

	}

	int type;
	float timer;
	float gravity;
	float pos[3];
	float vel[3];

};

// Transparent triangles.
class _Prism {
public:
	_Prism()
	{
		type = -1;
	
		timer = 0.0f;

		pos[0] = 0.0f;
		pos[1] = 0.0f;
		pos[2] = 0.0f;
	}

	~_Prism()
	{

	}

	int type;
	float timer;
	float pos[3];

};


// Draws the arena.  Kindof generalized, needs to have textures put in somehow from another list.
void DrawArena(const float *point, const int *indice, const float *tex_coord, const int *texture, const int NUM_TRIANGLES)
{
	for (int i=0; i<NUM_TRIANGLES; i++)
	{
		glColor3f(1,1,1);

		if (texture[i] == 0) glBindTexture(GL_TEXTURE_2D, tex[1]);
		else if (texture[i] == 1) glBindTexture(GL_TEXTURE_2D, tex[1]);
		else if (texture[i] == 2) glBindTexture(GL_TEXTURE_2D, tex[2]);
		else if (texture[i] == 3) glBindTexture(GL_TEXTURE_2D, tex[2]);
		else if (texture[i] == 4) glBindTexture(GL_TEXTURE_2D, tex[2]);
		else if (texture[i] == 5) glBindTexture(GL_TEXTURE_2D, tex[2]);
		else if (texture[i] == 6) glBindTexture(GL_TEXTURE_2D, tex[3]);
		else if (texture[i] == 7) glBindTexture(GL_TEXTURE_2D, tex[3]);
		else if (texture[i] == 8) glBindTexture(GL_TEXTURE_2D, tex[1]);
		else if (texture[i] == 9) glBindTexture(GL_TEXTURE_2D, tex[5]);
		else if (texture[i] == 10) glBindTexture(GL_TEXTURE_2D, tex[2]);
		else if (texture[i] == 11) glBindTexture(GL_TEXTURE_2D, tex[2]);
		else if (texture[i] == 12) glBindTexture(GL_TEXTURE_2D, tex[4]);
		
		
		glBegin(GL_TRIANGLES);
		
		glNormal3f((point[indice[i*3+1]*3+1] - point[indice[i*3+0]*3+1]) * (point[indice[i*3+2]*3+2] - point[indice[i*3+0]*3+2]) -
			(point[indice[i*3+1]*3+2] - point[indice[i*3+0]*3+2]) * (point[indice[i*3+2]*3+1] - point[indice[i*3+0]*3+1]),
			-(point[indice[i*3+1]*3+0] - point[indice[i*3+0]*3+0]) * (point[indice[i*3+2]*3+2] - point[indice[i*3+0]*3+2]) +
			(point[indice[i*3+1]*3+2] - point[indice[i*3+0]*3+2]) * (point[indice[i*3+2]*3+0] - point[indice[i*3+0]*3+0]),
			(point[indice[i*3+1]*3+0] - point[indice[i*3+0]*3+0]) * (point[indice[i*3+2]*3+1] - point[indice[i*3+0]*3+1]) -
			(point[indice[i*3+1]*3+1] - point[indice[i*3+0]*3+1]) * (point[indice[i*3+2]*3+0] - point[indice[i*3+0]*3+0]));
		glTexCoord2f(tex_coord[i*6+0], tex_coord[i*6+1]);
		glVertex3f(point[indice[i*3+0]*3+0], point[indice[i*3+0]*3+1], point[indice[i*3+0]*3+2]);
		glTexCoord2f(tex_coord[i*6+2], tex_coord[i*6+3]);
		glVertex3f(point[indice[i*3+1]*3+0], point[indice[i*3+1]*3+1], point[indice[i*3+1]*3+2]);
		glTexCoord2f(tex_coord[i*6+4], tex_coord[i*6+5]);
		glVertex3f(point[indice[i*3+2]*3+0], point[indice[i*3+2]*3+1], point[indice[i*3+2]*3+2]);

		glEnd();
	}

	glBindTexture(GL_TEXTURE_2D, tex[0]); // blank

	return;
};

// Draws single component
void DrawComponent(const float *point, const int *indice, const int NUM_TRIANGLES)
{
	glBindTexture(GL_TEXTURE_2D, tex[0]); // blank

	for (int i=0; i<NUM_TRIANGLES; i++)
	{	
		glBegin(GL_TRIANGLES);
		
		glNormal3f((point[indice[i*3+1]*3+1] - point[indice[i*3+0]*3+1]) * (point[indice[i*3+2]*3+2] - point[indice[i*3+0]*3+2]) -
			(point[indice[i*3+1]*3+2] - point[indice[i*3+0]*3+2]) * (point[indice[i*3+2]*3+1] - point[indice[i*3+0]*3+1]),
			-(point[indice[i*3+1]*3+0] - point[indice[i*3+0]*3+0]) * (point[indice[i*3+2]*3+2] - point[indice[i*3+0]*3+2]) +
			(point[indice[i*3+1]*3+2] - point[indice[i*3+0]*3+2]) * (point[indice[i*3+2]*3+0] - point[indice[i*3+0]*3+0]),
			(point[indice[i*3+1]*3+0] - point[indice[i*3+0]*3+0]) * (point[indice[i*3+2]*3+1] - point[indice[i*3+0]*3+1]) -
			(point[indice[i*3+1]*3+1] - point[indice[i*3+0]*3+1]) * (point[indice[i*3+2]*3+0] - point[indice[i*3+0]*3+0]));
		glVertex3f(point[indice[i*3+0]*3+0], point[indice[i*3+0]*3+1], point[indice[i*3+0]*3+2]);
		glVertex3f(point[indice[i*3+1]*3+0], point[indice[i*3+1]*3+1], point[indice[i*3+1]*3+2]);
		glVertex3f(point[indice[i*3+2]*3+0], point[indice[i*3+2]*3+1], point[indice[i*3+2]*3+2]);

		glEnd();
	}

	return;
};

void DrawRobot(int sex, float rot[2], float *primary_color, float *secondary_color, int animation_type, float &animation_timer)
{
	animation_timer += 0.1f;
	if (animation_timer > 6.28f) animation_timer -= 6.28f;

	float hip[3][2], knee[3][2], shoulder[3][2], elbow[3][2], neck[3];

	if (animation_type == 0) // standing
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		shoulder[0][0] = 90.0f; // gun hand up
		elbow[0][1] = 90.0f;
	}
	else if (animation_type == 1) // jumping in place
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		hip[0][0] = 60.0f;
		hip[0][1] = 60.0f;
		knee[0][0] = -120.0f;
		knee[0][1] = -120.0f;

		shoulder[0][0] = 90.0f; // gun hand up
		elbow[0][1] = 90.0f;
	}
	else if (animation_type == 2) // running
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		hip[0][0] = 60.0f * sin(animation_timer);
		hip[0][1] = 60.0f * sin(animation_timer + 3.14159f);
		knee[0][0] = -60.0f * sin(animation_timer + 1.57f) - 60.0f;
		knee[0][1] = -60.0f * sin(animation_timer + 3.14159f + 1.57f) - 60.0f;

		shoulder[0][0] = 90.0f; // gun hand up
		shoulder[0][1] = 45.0f * sin(animation_timer); 
		elbow[0][1] = 90.0f;
	}

	if (sex == 0) // male
	{
		glRotatef(-rot[0] * 180.0f / 3.14159f + 90.0f, 0.0f, 1.0f, 0.0f);
		glTranslatef(0.0f, 4.5f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_torso_point, male_lower_torso_indice, 8);

		glTranslatef(-0.25f, -0.5f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_leg_point, male_upper_leg_indice, 8);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_leg_point, male_lower_leg_indice, 8);

		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.25f, 0.5f, 0.0f);

		glTranslatef(0.25f, -0.5f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_leg_point, male_upper_leg_indice, 8);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_leg_point, male_lower_leg_indice, 8);

		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.25f, 0.5f, 0.0f);

		glRotatef(rot[1]/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(male_middle_torso_point, male_middle_torso_indice, 16);
	
		glRotatef(rot[1]/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_torso_point, male_upper_torso_indice, 8);

		glTranslatef(-1.0f, -0.25f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_arm_point, male_upper_arm_indice, 8);

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_arm_point, male_lower_arm_indice, 8);

		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(1.0f, 0.25f, 0.0f);

		glTranslatef(1.0f, -0.25f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_arm_point, male_upper_arm_indice, 8);

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);	
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_arm_point, male_lower_arm_indice, 8);

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-1.0f, 0.25f, 0.0f);

		glTranslatef(0.0f, 0.1f, 0.0f);
		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_head_point, male_head_indice, 12);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(male_visor_point, male_visor_indice, 10);

		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, -0.1f, 0.0f);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		
		glTranslatef(0.0f, -4.5f, 0.0f);
		glRotatef(rot[0] * 180.0f / 3.14159f - 90.0f, 0.0f, 1.0f, 0.0f);
	}
	else if (sex == 1) // female
	{
		glRotatef(-rot[0] * 180.0f / 3.14159f + 90.0f, 0.0f, 1.0f, 0.0f);
		glTranslatef(0.0f, 5.0f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_torso_point, female_lower_torso_indice, 8);

		glTranslatef(-0.25f, -1.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_leg_point, female_upper_leg_indice, 8);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_leg_point, female_lower_leg_indice, 8);

		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.25f, 1.0f, 0.0f);

		glTranslatef(0.25f, -1.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_leg_point, female_upper_leg_indice, 8);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_leg_point, female_lower_leg_indice, 8);

		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.25f, 1.0f, 0.0f);

		glRotatef(rot[1]/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(female_middle_torso_point, female_middle_torso_indice, 16);
	
		glRotatef(rot[1]/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);

		glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_torso_point, female_upper_torso_indice, 12);
		glRotatef(-180.0f, 0.0f, 1.0f, 0.0f);

		glTranslatef(-0.475f, -0.225f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);

		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_arm_point, female_upper_arm_indice, 8);

		glTranslatef(0.0f, -1.25f, 0.0f);
		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);	
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_arm_point, female_lower_arm_indice, 8);

		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.25f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.475f, 0.225f, 0.0f);

		glTranslatef(0.475f, -0.225f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);

		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_arm_point, female_upper_arm_indice, 8);

		glTranslatef(0.0f, -1.25f, 0.0f);
		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_arm_point, female_lower_arm_indice, 8);

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.25f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.475f, 0.225f, 0.0f);

		glTranslatef(0.0f, 0.05f, 0.0f);
		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_head_point, female_head_indice, 12);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(female_visor_point, female_visor_indice, 10);

		glRotatef(-neck[0], 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1], 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[2], 1.0f, 0.0f, 0.0f);
		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, -0.05f, 0.0f);

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(-rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		
		glTranslatef(0.0f, -5.0f, 0.0f);
		glRotatef(rot[0] * 180.0f / 3.14159f - 90.0f, 0.0f, 1.0f, 0.0f);
	}


	return;
};

// The sides of the arena, HARD-CODED!!!  Best only used for character(s), and bullets.
bool BoundArenaXZ(float pos[3])
{
	bool test = false;

	// sides
	// middle sides
	if (pos[2] < -99.0f) 
	{
		pos[2] = -99.0f;
		test = true;
	}
	else if (pos[2] > 99.0f) 
	{
		pos[2] = 99.0f;
		test = true;
	}

	// far sides
	if (pos[0] < -299.0f) 
	{
		pos[0] = -299.0f;
		test = true;
	}
	else if (pos[0] > 299.0f) 
	{
		pos[0] = 299.0f;
		test = true;
	}
	
	// left side
	if (pos[0] >= -299.0f && pos[0] < -99.0f)
	{
		if (pos[2] < -24.0f)
		{
			if (fabs(pos[2] + 24.0f) < fabs(pos[0] + 99.0f))
			{
				pos[2] = -24.0f;
				test = true;
			}
			else
			{
				pos[0] = -99.0f;
				test = true;
			}
		}

		if (pos[2] > 24.0f)
		{
			if (fabs(pos[2] - 24.0f) < fabs(pos[0] + 99.0f))
			{
				pos[2] = 24.0f;
				test = true;
			}
			else
			{
				pos[0] = -99.0f;
				test = true;
			}
		}
	}

	// left side
	if (pos[0] > 99.0f && pos[0] <= 299.0f)
	{
		if (pos[2] < -24.0f)
		{
			if (fabs(pos[2] + 24.0f) < fabs(pos[0] - 99.0f))
			{
				pos[2] = -24.0f;
				test = true;
			}
			else
			{
				pos[0] = 99.0f;
				test = true;
			}
		}

		if (pos[2] > 24.0f)
		{
			if (fabs(pos[2] - 24.0f) < fabs(pos[0] - 99.0f))
			{
				pos[2] = 24.0f;
				test = true;
			}
			else
			{
				pos[0] = 99.0f;
				test = true;
			}
		}
	}

	// left stairs
	if (pos[2] >= -24.0f && pos[2] <= 1.0f)
	{
		if (pos[0] < -224.0f)
		{
			if (pos[1] + 2.0f < 0.5f * pos[0] + 162.5f)
			{
				if (fabs(pos[2] - 1.0f) < fabs(pos[0] + 224.0f))
				{
					pos[2] = 1.0f;
					test = true;
				}
				else
				{
					pos[0] = -224.0f;
					test = true;
				}
			}
		}
	}


	// right stairs
	if (pos[2] >= -1.0f && pos[2] <= 24.0f)
	{
		if (pos[0] > 224.0f)
		{
			if (pos[1] + 2.0f < -0.5f * pos[0] + 162.5f)
			{
				if (fabs(pos[2] + 1.0f) < fabs(pos[0] - 224.0f))
				{
					pos[2] = -1.0f;
					test = true;
				}
				else
				{
					pos[0] = 224.0f;
					test = true;
				}
			}
		}
	}

	return test;
};

// For floors and ceilings.  Used by both bots and characters, and bullets!  Has gravity built in from y_vel.
bool BoundArenaY(float pos[3], float &y_vel)
{
	bool test = false;

	pos[1] += y_vel; // gravity

	// heights
	// middle
	if ((pos[0] >= -100.0f && pos[0] <= 100.0f) && (pos[2] >= -100.0f && pos[2] <= 100.0f))
	{
		if (!((pos[0] >= -50.0f && pos[0] <= 50.0f) && (pos[2] >= -50.0f && pos[2] <= 50.0f)))
		{
			if (50.0f - pos[1] < 2.0f && 50.0f - pos[1] >= 0.0f) 
			{
				pos[1] = 50.0f;
				y_vel = 0.0f;
				test = true;
			}
		}

		if (pos[1] < 0.0f) 
		{
			pos[1] = 0.0f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}
	// left side
	else if ((pos[0] >= -225.0f && pos[0] <= -100.0f) && (pos[2] >= -25.0f && pos[2] <= 25.0f))
	{
		if (50.0f - pos[1] < 2.0f && 50.0f - pos[1] >= 0.0f) 
		{
			pos[1] = 50.0f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] < 0.0f) 
		{
			pos[1] = 0.0f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}
	// right side
	else if ((pos[0] >= 100.0f && pos[0] <= 225.0f) && (pos[2] >= -25.0f && pos[2] <= 25.0f))
	{
		if (50.0f - pos[1] < 2.0f && 50.0f - pos[1] >= 0.0f) 
		{
			pos[1] = 50.0f;
			y_vel = 0.0f;
			test = true;
		}

		if (pos[1] < 0.0f) 
		{
			pos[1] = 0.0f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}
	// far left side
	else if ((pos[0] >= -300.0f && pos[0] <= -275.0f) && (pos[2] >= -25.0f && pos[2] <= 25.0f))
	{
		if (pos[1] < 25.0f) 
		{
			pos[1] = 25.0f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}
	// far right side
	else if ((pos[0] >= 275.0f && pos[0] <= 300.0f) && (pos[2] >= -25.0f && pos[2] <= 25.0f))
	{
		if (pos[1] < 25.0f) 
		{
			pos[1] = 25.0f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}
	// low left stairs
	else if ((pos[0] >= -275.0f && pos[0] <= -225.0f) && (pos[2] >= 0.0f && pos[2] <= 25.0f))
	{
		if (pos[1] < -0.5f * pos[0] - 112.5f) 
		{
			pos[1] = -0.5f * pos[0] - 112.5f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}
	// high left stairs
	else if ((pos[0] >= -275.0f && pos[0] <= -225.0f) && (pos[2] >= -25.0f && pos[2] <= 0.0f))
	{
		if (pos[1] < 0.5f * pos[0] + 162.5f) 
		{
			pos[1] = 0.5f * pos[0] + 162.5f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}
	// low right stairs
	else if ((pos[0] >= 225.0f && pos[0] <= 275.0f) && (pos[2] >= -25.0f && pos[2] <= 0.0f))
	{
		if (pos[1] < 0.5f * pos[0] - 112.5f) 
		{
			pos[1] = 0.5f * pos[0] - 112.5f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}
	// high right stairs
	else if ((pos[0] >= 225.0f && pos[0] <= 275.0f) && (pos[2] >= 0.0f && pos[2] <= 25.0f))
	{
		if (pos[1] < -0.5f * pos[0] + 162.5f) 
		{
			pos[1] = -0.5f * pos[0] + 162.5f;
			y_vel = 0.0f;
			test = true;
		}
		if (pos[1] > 100.0f) 
		{
			pos[1] = 100.0f;
			y_vel = 0.0f;
			test = true;
		}
	}

	return test;
};

// Everything the bots think or do is here.  Will replace the character_pos with _Character ** later I'm sure.
void BotAI(_Bot **bot, float character_pos[3], _Bullet **bullet, const int TOTAL_BOTS, int difficulty)
{
	float theta, phi, dist;
	int very_old_way;
	bool test;

	char command_string[256];
	float sound_distance;

	float bot_speed;

	if (difficulty == 1) bot_speed = 0.6f;
	else if (difficulty == 2) bot_speed = 1.2f;
	else if (difficulty == 3) bot_speed = 1.8f;

	// default animation
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		bot[i]->animation_type = -1; // default in air (until otherwise stated)
	}

	// bot waypoint and enemy focus
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		bot[i]->standing_still -= 0.05f;
		if (bot[i]->standing_still < 0.0f) bot[i]->standing_still = 0.0f;

		if (bot[i]->enemy_focus == i)
		{
			if (fabs(arena_way_point[bot[i]->new_way*3+0] + bot[i]->pos[0]) < 0.2f) 
			{
				if (bot[i]->pos[2] > arena_way_point[bot[i]->new_way*3+2]) theta = -3.14159f / 2.0f;
				else theta = 3.14159f / 2.0f;	
			}
			else 
			{
				theta = atan((arena_way_point[bot[i]->new_way*3+2] - bot[i]->pos[2]) / (arena_way_point[bot[i]->new_way*3+0] - bot[i]->pos[0]));
		
				if (bot[i]->pos[0] > arena_way_point[bot[i]->new_way*3+0]) theta += 3.14159f;
			}
		
			if (bot[i]->pos[1] != arena_way_point[bot[i]->new_way*3+1])
			{
				if (bot[i]->standing_still == 0.0f)
				{
					bot[i]->pos[0] += bot_speed * 0.894f * cos(theta);
					bot[i]->pos[2] += bot_speed * 0.894f * sin(theta);
	
					if (bot[i]->pos[1] < arena_way_point[bot[i]->new_way*3+1]) bot[i]->pos[1] += bot_speed * 0.447f;
					else bot[i]->pos[1] -= bot_speed * 0.447f;
				}
	
				bot[i]->rot[0] = theta;
				bot[i]->rot[1] = 0.0f;
			}
			else
			{
				if (bot[i]->standing_still == 0.0f)
				{
					bot[i]->pos[0] += bot_speed * cos(theta);
					bot[i]->pos[2] += bot_speed * sin(theta);
				}
	
				bot[i]->rot[0] = theta;
				bot[i]->rot[1] = 0.0f;
			}

			bot[i]->rot[0] += 3.14159f;

			if (pow(arena_way_point[bot[i]->new_way*3+0] - bot[i]->pos[0], 2.0f) + pow(arena_way_point[bot[i]->new_way*3+2] - bot[i]->pos[2], 2.0f) <= 16.0f)
			{
				//bot[i]->pos[1] = arena_way_point[bot[i]->new_way*3+1]; // leads to weird jumping super high?
	
				if (fabs(bot[i]->pos[1] - arena_way_point[bot[i]->new_way*3+1]) > 16.0f)
				{
					bot[i]->new_way = 0; // default
				}
				else
				{
					very_old_way = bot[i]->old_way;
					bot[i]->old_way = bot[i]->new_way;
	
					bot[i]->new_way = -1;
	
					while (bot[i]->new_way == -1 || bot[i]->new_way == very_old_way)
					{
						bot[i]->new_way = arena_way_indice[bot[i]->old_way*8+(rand()%8)];
					}
				}
			}
		}
		else if (bot[i]->enemy_focus == -1) // chase player
		{
			if (fabs(character_pos[0] + bot[i]->pos[0]) < 0.2f) 
			{
				if (bot[i]->pos[2] > character_pos[2]) theta = -3.14159f / 2.0f;
				else theta = 3.14159f / 2.0f;	
			}
			else 
			{
				theta = atan((character_pos[2] - bot[i]->pos[2]) / (character_pos[0] - bot[i]->pos[0]));
		
				if (bot[i]->pos[0] > character_pos[0]) theta += 3.14159f;
			}
		
			if (bot[i]->standing_still == 0.0f) // should just follow character, bounds with stairs in ArenaBoundsY(), just like player.
			{
				bot[i]->pos[0] += bot_speed * cos(theta);
				bot[i]->pos[2] += bot_speed * sin(theta);
			}
	
			bot[i]->rot[0] = theta;
			bot[i]->rot[1] = 0.0f;

			bot[i]->rot[0] += 3.14159f;

			if (pow(character_pos[0] - bot[i]->pos[0], 2.0f) + pow(character_pos[2] - bot[i]->pos[2], 2.0f) <= 49.0f)
			{
				if (rand() % 100 < 50) bot[i]->enemy_focus = i;
				else bot[i]->standing_still = 0.1f * (4 - difficulty);
			}
		}
		else if (bot[i]->enemy_focus < TOTAL_BOTS) // chase bot
		{
			if (fabs(bot[bot[i]->enemy_focus]->pos[0] + bot[i]->pos[0]) < 0.2f) 
			{
				if (bot[i]->pos[2] > bot[bot[i]->enemy_focus]->pos[2]) theta = -3.14159f / 2.0f;
				else theta = 3.14159f / 2.0f;	
			}
			else 
			{
				theta = atan((bot[bot[i]->enemy_focus]->pos[2] - bot[i]->pos[2]) / (bot[bot[i]->enemy_focus]->pos[0] - bot[i]->pos[0]));
		
				if (bot[i]->pos[0] > bot[bot[i]->enemy_focus]->pos[0]) theta += 3.14159f;
			}
		
			if (bot[i]->standing_still == 0.0f) // should just follow bot, bounds with stairs in ArenaBoundsY(), just like player.
			{
				bot[i]->pos[0] += bot_speed * cos(theta);
				bot[i]->pos[2] += bot_speed * sin(theta);
			}
	
			bot[i]->rot[0] = theta;
			bot[i]->rot[1] = 0.0f;

			bot[i]->rot[0] += 3.14159f;

			if (pow(bot[bot[i]->enemy_focus]->pos[0] - bot[i]->pos[0], 2.0f) + pow(bot[bot[i]->enemy_focus]->pos[2] - bot[i]->pos[2], 2.0f) <= 49.0f)
			{
				if (rand() % 100 < 50) bot[i]->enemy_focus = i;
				else bot[i]->standing_still = 0.1f * (4 - difficulty);
			}
		}
	}

	// bot bounding with bot
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		for (int j=0; j<i; j++)
		{
			if (pow(bot[j]->pos[0]-bot[i]->pos[0], 2.0f) + pow(bot[j]->pos[2]-bot[i]->pos[2], 2.0f) <= 9.0f)
			{
				if (fabs(bot[i]->pos[0] + bot[j]->pos[0]) < 0.2f) 
				{
					if (bot[j]->pos[2] > bot[i]->pos[2]) theta = -3.14159f / 2.0f;
					else theta = 3.14159f / 2.0f;
				}
				else 
				{
					theta = atan((bot[i]->pos[2] - bot[j]->pos[2]) / (bot[i]->pos[0] - bot[j]->pos[0]));
	
					if (bot[j]->pos[0] > bot[i]->pos[0]) theta += 3.14159f;
				}

				theta += ((float)(rand() % 200)-100.0f) * 3.14159f / 6.0f;

				bot[j]->pos[0] += 2.0f * cos(theta);
				bot[j]->pos[2] += 2.0f * sin(theta);
			}
		}
	}

	// bot bounding with character
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		if (pow(character_pos[0]-bot[i]->pos[0], 2.0f) + pow(character_pos[2]-bot[i]->pos[2], 2.0f) <= 9.0f)
		{
			if (fabs(bot[i]->pos[0] + character_pos[0]) < 0.2f) 
			{
				if (character_pos[2] > bot[i]->pos[2]) theta = -3.14159f / 2.0f;
				else theta = 3.14159f / 2.0f;
			}
			else 
			{
				theta = atan((bot[i]->pos[2] - character_pos[2]) / (bot[i]->pos[0] - character_pos[0]));
	
				if (character_pos[0] > bot[i]->pos[0]) theta += 3.14159f;
			}

			theta += ((float)(rand() % 200)-100.0f) * 3.14159f / 6.0f;

			bot[i]->pos[0] += 2.0f * cos(theta);
			bot[i]->pos[2] += 2.0f * sin(theta);
		}
	}

	// bot hating
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		// hate who they are following
		if (bot[i]->enemy_focus != i)
		{
			bot[i]->hate = bot[i]->enemy_focus;
		}

		if ((bot[i]->hate < -2 || bot[i]->hate >= TOTAL_BOTS || bot[i]->hate == i) && rand() % 100 < (difficulty*3))
		{
			if (rand() % 100 < 50)
			{
				for (int j=0; j<TOTAL_BOTS; j++)
				{
					if (pow(bot[i]->pos[0] - bot[j]->pos[0], 2.0f) + 
						0.1f * pow(bot[i]->pos[1] - bot[j]->pos[1], 2.0f) + 
						pow(bot[i]->pos[2] - bot[j]->pos[2], 2.0f) <= 10000.0f)
					{
						bot[i]->hate = j;
						bot[j]->hate = i;
					}
				}
			}
			else
			{
				if (pow(bot[i]->pos[0] - character_pos[0], 2.0f) + 
					0.1f * pow(bot[i]->pos[1] - character_pos[1], 2.0f) + 
					pow(bot[i]->pos[2] - character_pos[2], 2.0f) <= 10000.0f)
				{
					bot[i]->hate = -1;
				}
			}	
		}
		else
		{
			if (bot[i]->hate >= 0 && bot[i]->hate < TOTAL_BOTS && bot[i]->hate != i)
			{
				if (pow(bot[i]->pos[0] - bot[bot[i]->hate]->pos[0], 2.0f) + 
					0.1f * pow(bot[i]->pos[1] - bot[bot[i]->hate]->pos[1], 2.0f) + 
					pow(bot[i]->pos[2] - bot[bot[i]->hate]->pos[2], 2.0f) > 10000.0f)
				{
					bot[i]->hate = i;
				}
			}
			else if (bot[i]->hate == -1 || bot[i]->hate == -2)
			{
				if (pow(bot[i]->pos[0] - character_pos[0], 2.0f) + 
					0.1f * pow(bot[i]->pos[1] - character_pos[1], 2.0f) + 
					pow(bot[i]->pos[2] - character_pos[2], 2.0f) > 10000.0f)
				{
					bot[i]->hate = i;
				}
			}
			
			// might decide to stop hating
			if (bot[i]->hate != i && rand() % 2000 < 1)
			{
				bot[i]->hate = i;
			}
		}

		// might decide to chase down enemies
		if (bot[i]->hate == -1)
		{
			if (rand() % 1000 < difficulty) bot[i]->enemy_focus = -1;
		}
		else if (bot[i]->hate < TOTAL_BOTS && bot[i]->hate >= 0 && bot[i]->hate != i)
		{
			if (rand() % 1000 < difficulty) bot[i]->enemy_focus = bot[i]->hate;
		}

		// might decide to stop all that business
		if (bot[i]->enemy_focus != i && rand() % 2000 < 1)
		{
			bot[i]->enemy_focus = i;
		}
	}		

	// bot facing (the hate)
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		if (bot[i]->hate >= -2 && bot[i]->hate < TOTAL_BOTS && bot[i]->hate != i)
		{
			if (bot[i]->hate == -1) // for player
			{
				if (fabs(bot[i]->pos[0] + character_pos[0]) < 0.2f) 
				{
					if (character_pos[2] > bot[i]->pos[2]) theta = -3.14159f / 2.0f;
					else theta = 3.14159f / 2.0f;
				}
				else 
				{
					theta = atan((bot[i]->pos[2] - character_pos[2]) / (bot[i]->pos[0] - character_pos[0]));
	
					if (character_pos[0] > bot[i]->pos[0]) theta += 3.14159f;
				}

				dist = sqrt(pow(bot[i]->pos[0] - character_pos[0], 2.0f) + pow(bot[i]->pos[2] - character_pos[2], 2.0f));

				phi = atan((character_pos[1] - bot[i]->pos[1]) / dist);

				bot[i]->rot[0] = theta;
				bot[i]->rot[1] = phi;
			}
			else if (bot[i]->hate >= 0 && bot[i]->hate < TOTAL_BOTS && bot[i]->hate != i)
			{
				if (fabs(bot[i]->pos[0] + bot[bot[i]->hate]->pos[0]) < 0.2f) 
				{
					if (bot[bot[i]->hate]->pos[2] > bot[i]->pos[2]) theta = -3.14159f / 2.0f;
					else theta = 3.14159f / 2.0f;
				}
				else 
				{
					theta = atan((bot[i]->pos[2] - bot[bot[i]->hate]->pos[2]) / (bot[i]->pos[0] - bot[bot[i]->hate]->pos[0]));
	
					if (bot[bot[i]->hate]->pos[0] > bot[i]->pos[0]) theta += 3.14159f;
				}

				dist = sqrt(pow(bot[i]->pos[0] - bot[bot[i]->hate]->pos[0], 2.0f) + pow(bot[i]->pos[2] - bot[bot[i]->hate]->pos[2], 2.0f));

				phi = atan((bot[bot[i]->hate]->pos[1] - bot[i]->pos[1]) / dist);

				bot[i]->rot[0] = theta;
				bot[i]->rot[1] = phi;
			}
		}
	}

	// bot jumping, for some reason, bots are able to JUMP UP a level??  Or fall up???? FIX THAT.
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		bot[i]->y_vel -= 0.2f;

		BoundArenaXZ(bot[i]->pos);

		test = BoundArenaY(bot[i]->pos, bot[i]->y_vel);

		if (test == true)
		{
			bot[i]->animation_type = -2; // default (now) on the ground

			if (difficulty == 1 && rand() % 100 < 1) bot[i]->y_vel = 2.0f;
			else if (difficulty == 2 && rand() % 100 < 2) bot[i]->y_vel = 2.0f;
			else if (difficulty == 3 && rand() % 100 < 3) bot[i]->y_vel = 2.0f;
		}
	}

	// bot standing still
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		if (bot[i]->hate != i)
		{
			if (difficulty == 1 && rand() % 100 < 5) bot[i]->standing_still = (float)(rand() % 10) + 2.0f;
			else if (difficulty == 2 && rand() % 100 < 3) bot[i]->standing_still = (float)(rand() % 5) + 2.0f;
			else if (difficulty == 3 && rand() % 100 < 1) bot[i]->standing_still = (float)(rand() % 2) + 1.0f;
		}
	}

	// bot shooting
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		if (rand() % 1000 < 1) bot[i]->preferred_weapon = rand() % 2;

		if (bot[i]->cool_down <= 0.0f && bot[i]->hate != i && bot[i]->hate != -3)
		{
			if (bot[i]->ammo >= 5.0f && bot[i]->preferred_weapon == 0 && rand() % 100 < (difficulty))
			{
				// Play a sound with volume decreased over distance
				sound_distance = (400.0f - fabs(bot[i]->pos[0] - character_pos[0]) - 
					fabs(bot[i]->pos[1] - character_pos[1]) - fabs(bot[i]->pos[2] - character_pos[2])) / 400.0f;
				if (sound_distance < 0.0f) sound_distance = 0.0f;
				if (sound_distance > 1.0f) sound_distance = 1.0f;
				for (int j=0; j<256; j++) command_string[j] = 0;		
				sprintf(command_string, "play -q -v %f Photon.mp3 &", sound_distance);
				system(command_string);

				bot[i]->ammo -= 5.0f;
				if (bot[i]->ammo < 0.0f) bot[i]->ammo = 0.0f;

				bot[i]->cool_down = 1.0f;

				for (int j=0; j<1000; j++)
				{
					if (bullet[j]->type == -1)
					{
						bullet[j]->type = 0;

						bullet[j]->owner = i;

						bullet[j]->pos[0] = bot[i]->pos[0] - 1.0f * sin(-bot[i]->rot[0] + 3.14159f / 2.0f - 3.14159f / 4.0f);
						bullet[j]->pos[1] = bot[i]->pos[1] + 5.0f;
						bullet[j]->pos[2] = bot[i]->pos[2] - 1.0f * cos(-bot[i]->rot[0] + 3.14159f / 2.0f - 3.14159f / 4.0f);
				
						bullet[j]->vel[2] = -3.0f * cos(bot[i]->rot[1] +
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty))) * 
							cos(-bot[i]->rot[0] + 3.14159f / 2.0f + 
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty)));
						bullet[j]->vel[0] = -3.0f * cos(bot[i]->rot[1] + 
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty))) * 
							sin(-bot[i]->rot[0] + 3.14159f / 2.0f +
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty)));
						bullet[j]->vel[1] = 3.0f * sin(bot[i]->rot[1] +
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty)));

						j = 1001;
					}
				}
			}
			else if (bot[i]->ammo >= 1.0f && bot[i]->preferred_weapon == 1 && rand() % 100 < (difficulty*2))
			{
				// Play a sound with volume decreased over distance
				sound_distance = (400.0f - fabs(bot[i]->pos[0] - character_pos[0]) - 
					fabs(bot[i]->pos[1] - character_pos[1]) - fabs(bot[i]->pos[2] - character_pos[2])) / 400.0f;
				if (sound_distance < 0.0f) sound_distance = 0.0f;
				if (sound_distance > 1.0f) sound_distance = 1.0f;
				for (int j=0; j<256; j++) command_string[j] = 0;		
				sprintf(command_string, "play -q -v %f Laser.mp3 &", sound_distance);
				system(command_string);

				bot[i]->ammo -= 1.0f;
				if (bot[i]->ammo < 0.0f) bot[i]->ammo = 0.0f;

				bot[i]->cool_down = 0.5f;

				for (int j=0; j<1000; j++)
				{
					if (bullet[j]->type == -1)
					{
						bullet[j]->type = 1;

						bullet[j]->owner = i;

						bullet[j]->pos[0] = bot[i]->pos[0] - 1.0f * sin(-bot[i]->rot[0] + 3.14159f / 2.0f - 3.14159f / 4.0f);
						bullet[j]->pos[1] = bot[i]->pos[1] + 5.0f;
						bullet[j]->pos[2] = bot[i]->pos[2] - 1.0f * cos(-bot[i]->rot[0] + 3.14159f / 2.0f - 3.14159f / 4.0f);
				
						bullet[j]->vel[2] = -20.0f * cos(bot[i]->rot[1] +
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty)) +
							(((float)(rand() % 200)/100.0f)-1.0f)*0.02f) * 
							cos(-bot[i]->rot[0] + 3.14159f / 2.0f + 
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty)) +
							(((float)(rand() % 200)/100.0f)-1.0f)*0.02f);
						bullet[j]->vel[0] = -20.0f * cos(bot[i]->rot[1] + 
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty)) +
							(((float)(rand() % 200)/100.0f)-1.0f)*0.02f) * 
							sin(-bot[i]->rot[0] + 3.14159f / 2.0f +
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty)) +
							(((float)(rand() % 200)/100.0f)-1.0f)*0.02f);
						bullet[j]->vel[1] = 20.0f * sin(bot[i]->rot[1] +
							((float)(rand() % 200) - 100.0f) / 100.0f * 3.14159f / (6.0f * pow(2.0f,(float)difficulty)) +
							(((float)(rand() % 200)/100.0f)-1.0f)*0.02f);

						j = 1001;
					}
				}
			}
		}
	}	

	// animation summerization
	for (int i=0; i<TOTAL_BOTS; i++)
	{
		if (bot[i]->animation_type == -1) bot[i]->animation_type = 1; // jumping
		else if (bot[i]->animation_type == -2) // on the ground
		{
			if (bot[i]->standing_still > 0.0f) bot[i]->animation_type = 0; // standing
			else bot[i]->animation_type = 2; // running
		}
	}

	return;
};

// A random point in the map that you and/or a bot can respawn at.  All is HARD-CODED!
void RandomSpawn(float pos[3], float rot[2], int &bot_old_way, int &bot_new_way)
{
	int random_number = rand() % 8;

	if (random_number == 0)
	{
		pos[0] = -90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		pos[1] = 20.0f;
		pos[2] = -90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;

		rot[0] = -3.14159f / 2.0f;
		rot[1] = 0.0f;

		bot_old_way = 0;
		bot_new_way = 1;
	}
	else if (random_number == 1)
	{
		pos[0] = 90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		pos[1] = 20.0f;
		pos[2] = -90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;

		rot[0] = -3.0f * 3.14159f / 2.0f;
		rot[1] = 0;

		bot_old_way = 0;
		bot_new_way = 7;
	}
	else if (random_number == 2)
	{
		pos[0] = 90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		pos[1] = 20.0f;
		pos[2] = 90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
	
		rot[0] = -3.0f * 3.14159f / 2.0f;
		rot[1] = 0.0f;

		bot_old_way = 0;
		bot_new_way = 5;
	}
	else if (random_number == 3)
	{
		pos[0] = -90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		pos[1] = 20.0f;
		pos[2] = 90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		
		rot[0] = -3.14159f / 2.0f;
		rot[1] = 0.0f;
		
		bot_old_way = 0;
		bot_new_way = 3;
	}
	else if (random_number == 4)
	{
		pos[0] = -90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		pos[1] = 70.0f;
		pos[2] = -90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;

		rot[0] = -3.14159f / 2.0f;
		rot[1] = 0.0f;

		bot_old_way = 0;
		bot_new_way = 19;
	}
	else if (random_number == 5)
	{
		pos[0] = 90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		pos[1] = 70.0f;
		pos[2] = -90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;

		rot[0] = -3.0f * 3.14159f / 2.0f;
		rot[1] = 0.0f;

		bot_old_way = 0;
		bot_new_way = 25;
	}
	else if (random_number == 6)
	{
		pos[0] = 90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		pos[1] = 70.0f;
		pos[2] = 90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;

		rot[0] = -3.0f * 3.14159f / 2.0f;
		rot[1] = 0.0f;

		bot_old_way = 0;
		bot_new_way = 23;
	}
	else if (random_number == 7)
	{
		pos[0] = -90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;
		pos[1] = 70.0f;
		pos[2] = 90.0f + ((float)(rand() % 200) - 100.0f) / 100.0f * 5.0f;

		rot[0] = -3.14159f / 2.0f;
		rot[1] = 0.0f;

		bot_old_way = 0;
		bot_new_way = 21;
	}

	return;
};
	
	




_Character *character[2];
_Bot *bot[4];
_Bullet *bullet[1000];
_Pickup *pickup[26];
_Particle *particle[1000];
_Prism *prism[12];

unsigned long start_time;

//int frame_ticker = 0;

bool jump_button1_down = false; // Probably will need a second one for character[1] later.
bool diff_button1_down = false;

int difficulty_level = 1; // 1 = easy, 2 = medium, 3 = hard
float look_sensitivity = 1.0f; // for buttons really...

int current_screen = 0; // leaderboard start
float effects_timer = 0.0f; // to move and flash the Leaderboard and such
int random_bot = 0; // random bot spinning on loading screen


// All you need to setup.
void SetupAll(int w0, int h0, int w1, int h1)
{
	glViewport(w0, h0, w1, h1);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (float)(w1-w0)/(float)(h1-h0), 0.1f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity(); 
	glEnable(GL_TEXTURE_2D);  
	glShadeModel(GL_SMOOTH);
	glClearColor(0.05f, 0.05f, 0.05f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);					
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glEnable(GL_NORMALIZE); // now I don't need to make glNormal3f() into unit.
	
	glAlphaFunc(GL_GREATER, 0.9f);									
	glEnable(GL_ALPHA_TEST);

	// lighting    
//	GLfloat ambient[] = { 0.7f, 0.7f, 0.7f, 1.0f };  
//	GLfloat diffuse[] = { 0.7f, 0.7f, 0.7f, 0.7f }; 
//	GLfloat light_pos[] = { 10.0f, 10.0f, 10.0f, 1.0f };
//	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);                          
//	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse); 
//	glLightfv(GL_LIGHT1, GL_POSITION, light_pos);
//	glEnable(GL_LIGHT1);         
//	glEnable(GL_LIGHTING);

	// more stuff for lighting                                  
	glFrontFace(GL_CCW);
	glEnable(GL_NORMALIZE);     
	//glCullFace(GL_FRONT);                   

	// allows colors to be still lit up      
	glEnable(GL_COLOR_MATERIAL);

	// lighting    
	GLfloat ambient[] = { 0.3f, 0.3f, 0.3f, 1.0f };  
	GLfloat diffuse[] = { 0.7f, 0.7f, 0.7f, 0.7f }; 
	GLfloat light_pos[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);                          
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse); 
	glLightfv(GL_LIGHT1, GL_POSITION, light_pos);
	glEnable(GL_LIGHT1);  
	
	return;
};


// This draws everything.  Keep it clean and ONLY drawing things! :P
void MainDraw(int v)
{
	float primary_color[3], secondary_color[3];

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glDisable(GL_TEXTURE_2D);
	
	glDisable(GL_LIGHTING);

	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);
	//glDisable(GL_DEPTH_TEST);

	// All of the info up for the player.  MAKE MORE STREAMLINED AND BETTER LOOKING!!!
	// You can also use size 10 and 24 for Times New Roman.
	glColor3f(1,1,1);
	glRasterPos3f(-0.475f, 0.35f, -0.95f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'F');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 10000) - (frames_per_second % 1000)) / 1000 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 1000) - (frames_per_second % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 100) - (frames_per_second % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((frames_per_second % 10) + 48));

	glColor3f(1,1,1);
	glRasterPos3f(-0.475f, 0.3f, -0.95f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'K');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '/');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->kills % 1000) - (character[0]->kills % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->kills % 100) - (character[0]->kills % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((character[0]->kills % 10) + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '/');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->deaths % 1000) - (character[0]->deaths % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->deaths % 100) - (character[0]->deaths % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((character[0]->deaths % 10) + 48));

	if (3*60+start_time-time(0) <= 10)
	{
		glColor3f(0.5f*sin(effects_timer*6.28f)+0.5f, 0.5f*sin(effects_timer*6.28f)+0.5f, 1.0f);
	}
	else
	{
		glColor3f(1,1,1);
	}
	glRasterPos3f(-0.475f, 0.25f, -0.95f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'T');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'i');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'm');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'e');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((((3*60+start_time-time(0)) % 1000) - ((3*60+start_time-time(0)) % 60)) / 60 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ':');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((((3*60+start_time-time(0)) % 60) - ((3*60+start_time-time(0)) % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((3*60+start_time-time(0)) % 10) + 48));

	if (character[0]->health <= 25)
	{
		glColor3f(1.0f, 0.5f*sin(effects_timer*6.28f)+0.5f, 0.5f*sin(effects_timer*6.28f)+0.5f);
	}
	else
	{
		glColor3f(1,1,1);
	}
	glRasterPos3f(-0.475f, -0.3f, -0.95f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'H');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'e');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'l');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'h');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->health % 1000) - (character[0]->health % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->health % 100) - (character[0]->health % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((character[0]->health % 10) + 48));
	
	if (character[0]->ammo < 10)
	{
		glColor3f(0.5f*sin(effects_timer*6.28f)+0.5f, 0.5f*sin(effects_timer*6.28f)+0.5f, 1.0f);
	}
	else
	{
		glColor3f(1,1,1);
	}
	glRasterPos3f(0.3f, -0.3f, -0.95f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'A');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'm');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'm');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((((int)character[0]->ammo % 1000) - ((int)character[0]->ammo % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((((int)character[0]->ammo % 100) - ((int)character[0]->ammo % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((int)character[0]->ammo % 10) + 48));
	
	glColor3f(1,1,1);
	glRasterPos3f(0.3f, 0.3f, -0.95f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'i');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'f');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'f');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '=');
	if (difficulty_level == 1)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'E');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'A');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'S');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'Y');
	}
	else if (difficulty_level == 2)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'M');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'E');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'I');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'U');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'M');
	}
	else if (difficulty_level == 3)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'H');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'A');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'R');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
	}
       
	if (v == 0)
	{
		if (character[0]->message_timer > 0)
		{
			glColor3f(1.0f, 0.5f*sin(effects_timer*6.28f)+0.5f, 0.5f*sin(effects_timer*6.28f)+0.5f);
			glRasterPos3f(-0.05f, 0.2f, -0.95f);
			for (int i=0; i<256; i++) if (character[0]->message[i] != 0) glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, character[0]->message[i]);
		}
			
		// Crosshairs
		glColor3f(1,1,1);
		glRasterPos3f(-0.001f, -0.0015f, -0.1f); // z = -0.1f
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '>');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '<');
	}

	//glEnable(GL_DEPTH_TEST);
	glDisable(GL_BLEND);
	glEnable(GL_ALPHA_TEST);

	glEnable(GL_TEXTURE_2D);

	// Blank texture.
	glBindTexture(GL_TEXTURE_2D, tex[0]);


	glEnable(GL_LIGHTING);

	if (v == 0)
	{
		// Rotate and translate for character view.
		glRotatef(-character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glRotatef(-character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);

		glTranslatef(-character[0]->pos[0], -character[0]->pos[1] - 7.0f, -character[0]->pos[2]);
	}
	else if (v == 1)
	{
		
	}
	
	// Draw arena.
	if (v == 0)
	{
		DrawArena(arena_point, arena_indice, arena_tex_coord, arena_texture, 26*2 + 2 + 6*2);
	}
	else if (v == 1)
	{
		DrawArena(arena_point, arena_indice, arena_tex_coord, arena_texture, 26*2 + 2 + 6*2);
	}
	
	// Weapon and Character
	if (v == 0)
	{
		

	}
	else if (v == 1)
	{
		
	}
	
	// For all bots...
	for (int i=0; i<4; i++)
	{
		glTranslatef(bot[i]->pos[0], bot[i]->pos[1], bot[i]->pos[2]);

		glDisable(GL_LIGHTING);

		// names over the head
		glTranslatef(0.0f, 7.0f, 0.0f);
		glColor3f(1,1,1);
		glRasterPos3f(0.0f, 2.0f, 0.0f);
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'B');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'o');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 't');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(i + 48 + 1));
		glTranslatef(0.0f, -7.0f, 0.0f);
		
		glEnable(GL_LIGHTING);

		//glRotatef(-bot[i]->rot[0] * 180.0f / 3.14159f + 90.0f, 0.0f, 1.0f, 0.0f);
		//glRotatef(-bot_rot[i][1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);

		// If they are not hit, color them normal...
		if (bot[i]->hit_timer == 0.0f)
		{
			if (i == 0)
			{
				primary_color[0] = 0.0f;
				primary_color[1] = 0.25f;
				primary_color[2] = 0.0f;
			}
			else if (i == 1)
			{
				primary_color[0] = 0.75f;
				primary_color[1] = 0.75f;
				primary_color[2] = 0.0f;
			}
			else if (i == 2)
			{
				primary_color[0] = 0.0f;
				primary_color[1] = 0.0f;
				primary_color[2] = 0.5f;
			}
			else if (i == 3)
			{
				primary_color[0] = 0.5f;
				primary_color[1] = 0.0f;
				primary_color[2] = 0.75f;
			}
		}
		// Else, color them red.
		else
		{
			primary_color[0] = 1.0f;
			primary_color[1] = 0.0f;
			primary_color[2] = 0.0f;
		}
	
		secondary_color[0] = 1.0f;
		secondary_color[1] = 1.0f;
		secondary_color[2] = 1.0f;

		DrawRobot(i % 2, bot[i]->rot, primary_color, secondary_color, bot[i]->animation_type, bot[i]->animation_timer);

		//glRotatef(bot_rot[i][1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		//glRotatef(bot[i]->rot[0] * 180.0f / 3.14159f - 90.0f, 0.0f, 1.0f, 0.0f);

		glTranslatef(-bot[i]->pos[0], -bot[i]->pos[1], -bot[i]->pos[2]);
	}

	glDisable(GL_LIGHTING);	

	// For all bullets...
	for (int i=0; i<1000; i++)
	{
		// Draw big and slow
		if (bullet[i]->type == 0)
		{
			glTranslatef(bullet[i]->pos[0], bullet[i]->pos[1], bullet[i]->pos[2]);

			if (v == 0)
			{
				glRotatef(character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
				glRotatef(character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
			}
			else if (v == 1)
			{
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			}

			if (frames_per_second_counter % 6 == 0 || frames_per_second_counter % 6 == 1) glBindTexture(GL_TEXTURE_2D, tex[8]);
			else if (frames_per_second_counter % 6 == 2 || frames_per_second_counter % 6 == 3) glBindTexture(GL_TEXTURE_2D, tex[9]);
			else if (frames_per_second_counter % 6 == 4 || frames_per_second_counter % 6 == 5) glBindTexture(GL_TEXTURE_2D, tex[10]);

			glColor3f(1,0,1);

			glBegin(GL_QUADS);

			glTexCoord2f(1,1);
			glVertex3f(-2.0f, 2.0f, 0.0f);
			glTexCoord2f(1,0);
			glVertex3f(-2.0f, -2.0f, 0.0f);
			glTexCoord2f(0,0);
			glVertex3f(2.0f, -2.0f, 0.0f);
			glTexCoord2f(0,1);
			glVertex3f(2.0f, 2.0f, 0.0f);

			glEnd();

			if (v == 0)
			{
				glRotatef(-character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
				glRotatef(-character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
			}
			else if (v == 1)
			{
				glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			}

			glTranslatef(-bullet[i]->pos[0], -bullet[i]->pos[1], -bullet[i]->pos[2]);
		}
		// Draw small and fast
		else if (bullet[i]->type == 1)
		{
			glTranslatef(bullet[i]->pos[0], bullet[i]->pos[1], bullet[i]->pos[2]);

			glBindTexture(GL_TEXTURE_2D, tex[0]); // blank

			glColor3f(1,1,0);

			glBegin(GL_LINES); // dragging line

			glTexCoord2f(0,0);
			glVertex3f(0.0f, 0.0f, 0.0f);
			glTexCoord2f(1,1);
			glVertex3f(-bullet[i]->vel[0], -bullet[i]->vel[1], -bullet[i]->vel[2]);
		
			glEnd();

			glTranslatef(-bullet[i]->pos[0], -bullet[i]->pos[1], -bullet[i]->pos[2]);
		}

	}

	// For all pickups...
	for (int i=0; i<26; i++)
	{
		// Health
		if (pickup[i]->type == 0)
		{
			glBindTexture(GL_TEXTURE_2D, tex[6]);

			glTranslatef(pickup[i]->pos[0], pickup[i]->pos[1]+0.5f, pickup[i]->pos[2]);

			if (v == 0)
			{
				glRotatef(character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
				//glRotatef(character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
			}
			else if (v == 1)
			{
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			}

			glColor3f(1,0.75,0.75);

			glBegin(GL_QUADS);

			glTexCoord2f(1.05,1);
			glVertex3f(-2.0f, 4.0f, 0.0f);
			glTexCoord2f(1.05,0);
			glVertex3f(-2.0f, 0.0f, 0.0f);
			glTexCoord2f(0.05,0);
			glVertex3f(2.0f, 0.0f, 0.0f);
			glTexCoord2f(0.05,1);
			glVertex3f(2.0f, 4.0f, 0.0f);

			glEnd();

			if (v == 0)
			{
				//glRotatef(-character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
				glRotatef(-character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
			}
			else if (v == 1)
			{
				glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			}

			glTranslatef(-pickup[i]->pos[0], -pickup[i]->pos[1]-0.5f, -pickup[i]->pos[2]);
		}
		// Ammo
		else if (pickup[i]->type == 1)
		{
			glBindTexture(GL_TEXTURE_2D, tex[7]);

			glTranslatef(pickup[i]->pos[0], pickup[i]->pos[1], pickup[i]->pos[2]);

			if (v == 0)
			{
				glRotatef(character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
				//glRotatef(character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
			}
			else if (v == 1)
			{
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			}

			glColor3f(0.75,0.75,1);

			glBegin(GL_QUADS);

			glTexCoord2f(1.05,1);
			glVertex3f(-2.0f, 4.0f, 0.0f);
			glTexCoord2f(1.05,0);
			glVertex3f(-2.0f, 0.0f, 0.0f);
			glTexCoord2f(0.05,0);
			glVertex3f(2.0f, 0.0f, 0.0f);
			glTexCoord2f(0.05,1);
			glVertex3f(2.0f, 4.0f, 0.0f);

			glEnd();

			if (v == 0)
			{
				//glRotatef(-character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
				glRotatef(-character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
			}
			else if (v == 1)
			{
				glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			}

			glTranslatef(-pickup[i]->pos[0], -pickup[i]->pos[1], -pickup[i]->pos[2]);
		}
	}

	// For all particles...
	for (int i=0; i<1000; i++)
	{
		if (particle[i]->type == 0 || particle[i]->type == 1) // typical
		{
			glBindTexture(GL_TEXTURE_2D, tex[0]); // blank

			glTranslatef(particle[i]->pos[0], particle[i]->pos[1], particle[i]->pos[2]);

			if (v == 0)
			{
				glRotatef(character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
				//glRotatef(character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
			}
			else if (v == 1)
			{
				glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			}

			if (particle[i]->type == 0) glColor3f(0.01f,0.01f,0.01f);
			else if (particle[i]->type == 1) glColor3f(0.99f,0.99f,0.99f);

			glBegin(GL_QUADS);

			glTexCoord2f(1,1);
			glVertex3f(-0.25f, 1.25f, 0.0f);
			glTexCoord2f(1,0);
			glVertex3f(-0.25f, 0.75f, 0.0f);
			glTexCoord2f(0,0);
			glVertex3f(0.25f, 0.75f, 0.0f);
			glTexCoord2f(0,1);
			glVertex3f(0.25f, 1.25f, 0.0f);

			glEnd();

			if (v == 0)
			{
				//glRotatef(-character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
				glRotatef(-character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
			}
			else if (v == 1)
			{
				glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			}

			glTranslatef(-particle[i]->pos[0], -particle[i]->pos[1], -particle[i]->pos[2]);
		}
	}

	//glEnable(GL_LIGHTING);

	//glDisable(GL_LIGHTING);
	
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);

	glBindTexture(GL_TEXTURE_2D, tex[0]); // blank
	
	// For all prisms...
	for (int i=0; i<12; i++)
	{
		if (prism[i]->type == 0 || prism[i]->type == 1) // typical
		{
			glTranslatef(prism[i]->pos[0], prism[i]->pos[1], prism[i]->pos[2]);

			glRotatef(360.0f * 5.0f * prism[i]->timer, 0.0f, 1.0f, 0.0f);	

			glScalef(3.0f*prism[i]->timer, 3.0f*prism[i]->timer, 3.0f*prism[i]->timer);		

			glColor4f(1.0f,1.0f,1.0f,0.25f);

			glBegin(GL_TRIANGLES);

			glTexCoord2f(0.5f,1.0f);
			glVertex3f(0.0f, 8.0f, 0.0f);
			glTexCoord2f(0.0f,0.0f);
			glVertex3f(4.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f,0.0f);
			glVertex3f(4.0f*cos(2.0f*3.14159f/3.0f), 0.0f, 4.0f*sin(2.0f*3.14159f/3.0f));

			glTexCoord2f(0.5f,1.0f);
			glVertex3f(0.0f, 8.0f, 0.0f);
			glTexCoord2f(0.0f,0.0f);
			glVertex3f(4.0f*cos(2.0f*3.14159f/3.0f), 0.0f, 4.0f*sin(2.0f*3.14159f/3.0f));
			glTexCoord2f(1.0f,0.0f);
			glVertex3f(4.0f*cos(4.0f*3.14159f/3.0f), 0.0f, 4.0f*sin(4.0f*3.14159f/3.0f));

			glTexCoord2f(0.5f,1.0f);
			glVertex3f(0.0f, 8.0f, 0.0f);
			glTexCoord2f(0.0f,0.0f);
			glVertex3f(4.0f*cos(4.0f*3.14159f/3.0f), 0.0f, 4.0f*sin(4.0f*3.14159f/3.0f));
			glTexCoord2f(1.0f,0.0f);
			glVertex3f(4.0f, 0.0f, 0.0f);

			glTexCoord2f(0.5f,1.0f);
			glVertex3f(4.0f, 0.0f, 0.0f);
			glTexCoord2f(0.0f,0.0f);
			glVertex3f(4.0f*cos(2.0f*3.14159f/3.0f), 0.0f, 4.0f*sin(2.0f*3.14159f/3.0f));
			glTexCoord2f(1.0f,0.0f);
			glVertex3f(4.0f*cos(4.0f*3.14159f/3.0f), 0.0f, 4.0f*sin(4.0f*3.14159f/3.0f));

			glEnd();

			glScalef(1.0f / (3.0f*prism[i]->timer), 1.0f / (3.0f*prism[i]->timer), 1.0f / (3.0f*prism[i]->timer));

			glRotatef(-360.0f * 5.0f * prism[i]->timer, 0.0f, 1.0f, 0.0f);
			
			glTranslatef(-prism[i]->pos[0], -prism[i]->pos[1], -prism[i]->pos[2]);
		}
	}

	if (v == 0)
	{
		// If you are hit, show it on the screen.  Make it transparent!!!!!
		if (character[0]->hit_timer > 0.0f)
		{
			glTranslatef(character[0]->pos[0], character[0]->pos[1] + 6.0f, character[0]->pos[2]);
	
			glRotatef(character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
			glRotatef(character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);

			glColor4f(1.0f,0,0,0.5f);

			glBegin(GL_QUADS);

			glVertex3f(-2.0f, 2.0f, -0.5f);
			glVertex3f(-2.0f, -2.0f, -0.5f);
			glVertex3f(2.0f, -2.0f, -0.5f);
			glVertex3f(2.0f, 2.0f, -0.5f);

			glEnd();

			glRotatef(-character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
			glRotatef(-character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);

			glTranslatef(-character[0]->pos[0], -character[0]->pos[1] - 6.0f, -character[0]->pos[2]);
		}
	}


	glDisable(GL_BLEND);
	glEnable(GL_ALPHA_TEST);

	//glEnable(GL_LIGHTING);


	if (v == 0)
	{
		// Untranslate and unrotate :)
		glTranslatef(character[0]->pos[0], character[0]->pos[1] + 7.0f, character[0]->pos[2]);
	
		glRotatef(character[0]->rot[0] * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glRotatef(character[0]->rot[1] * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
	}
	else if (v == 1)
	{
		
	}

	glutSwapBuffers();

	return;
};

void LeaderboardLoop()
{
	// Automatic exit.  Apparently this DOESN'T 'delete' things a the end, MUST FIX THAT SOMEHOW!!!
	if (keyboard[27]) 
	{
		exit(1);
	}

	if (keyboard['e']) // switch to main loop!
	{
		random_bot = rand() % 4;

		current_screen = 1;

		// Start of the match stuff.  Try to set up diffculty level here somehow.
		for (int i=0; i<4; i++)
		{
			RandomSpawn(bot[i]->pos, bot[i]->rot, bot[i]->old_way, bot[i]->new_way);
	
			bot[i]->hate = i;
		}

		int temp1, temp2;

		RandomSpawn(character[0]->pos, character[0]->rot, temp1, temp2);

		start_time = time(0);

		difficulty_level = 1; // start on easy

		character[0]->health = 100;

		character[0]->kills = 0;
		character[0]->deaths = 0;

		character[0]->ammo = 100;

		for (int i=0; i<4; i++)
		{
			bot[i]->health = 100;

			bot[i]->preferred_weapon = rand() % 2;

			bot[i]->kills = 0;
			bot[i]->deaths = 0;

			bot[i]->ammo = 100;

			bot[i]->standing_still = 0.0f;

			bot[i]->animation_type = 0;
			bot[i]->animation_timer = 0.0f;

			bot[i]->enemy_focus = i;
		}
	}

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	glDisable(GL_LIGHTING);

	// Blank texture.
	glBindTexture(GL_TEXTURE_2D, tex[0]);

	// All of the info up for the player.  MAKE MORE STREAMLINED AND BETTER LOOKING!!!
	// You can also use size 10 and 24 for Times New Roman.
	glColor3f(1.0f, 0.5f*sin(effects_timer*6.28f)+0.5f, 0.5f*sin(effects_timer*6.28f)+0.5f);		
	glRasterPos3f(-0.3f+0.01f*cos(effects_timer*6.28f), 0.30f+0.01f*sin(effects_timer*6.28f), -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'A');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'R');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'E');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'N');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'A');

	glRasterPos3f(-0.3f+0.01f*cos(effects_timer*6.28f), 0.295f+0.01f*sin(effects_timer*6.28f), -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '_');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '_');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '_');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '_');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '_');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '_');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '_');

	glColor3f(1,1,1);
	glRasterPos3f(-0.35f, 0.2f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'l');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'y');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'e');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '1');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'K');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '/');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->kills % 1000) - (character[0]->kills % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->kills % 100) - (character[0]->kills % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((character[0]->kills % 10) + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '/');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->deaths % 1000) - (character[0]->deaths % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((character[0]->deaths % 100) - (character[0]->deaths % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((character[0]->deaths % 10) + 48));

	for (int i=0; i<4; i++)
	{
		glRasterPos3f(-0.35f, 0.15f-(float)i*0.05f, -0.9f);
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'B');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(i+48+1));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'K');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '/');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '=');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((bot[i]->kills % 1000) - (bot[i]->kills % 100)) / 100 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((bot[i]->kills % 100) - (bot[i]->kills % 10)) / 10 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((bot[i]->kills % 10) + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '/');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((bot[i]->deaths % 1000) - (bot[i]->deaths % 100)) / 100 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((bot[i]->deaths % 100) - (bot[i]->deaths % 10)) / 10 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((bot[i]->deaths % 10) + 48));
	}

	glColor3f(1.0f, 0.5f*sin(effects_timer*6.28f)+0.5f, 0.5f*sin(effects_timer*6.28f)+0.5f);	
	glRasterPos3f(-0.325f+0.01f*cos(effects_timer*6.28f), -0.1f+0.01f*sin(effects_timer*6.28f), -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'e');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 's');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 's');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '[');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'A');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ']');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');

	glColor3f(1,1,1);
	glRasterPos3f(-0.4f, -0.2f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'C');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'n');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'l');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 's');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ':');

	glRasterPos3f(-0.4f, -0.225f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '[');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'A');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ']');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'J');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'u');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'm');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'p');

	glRasterPos3f(-0.4f, -0.25f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'R');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '/');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'L');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '-');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'T');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'i');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'g');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'g');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'e');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 's');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'h');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');

	glRasterPos3f(-0.4f, -0.275f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'R');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '-');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'i');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'c');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'k');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'L');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'k');

	glRasterPos3f(-0.4f, -0.3f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'L');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '-');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'i');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'c');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'k');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'M');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'v');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'e');

	glRasterPos3f(-0.4f, -0.325f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '-');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'd');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'U');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'p');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '/');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'w');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'n');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'C');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'h');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'n');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'g');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'e');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'D');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'i');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'f');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'f');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'i');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'c');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'u');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'l');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'y');

	glRasterPos3f(0.1f, 0.325f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'A');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'M');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'h');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'D');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'y');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'e');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 's');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'e');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'n');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 't');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'i');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'n');

	glRasterPos3f(0.125f, 0.31f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'b');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'y');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'C');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'h');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'a');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'd');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, ' ');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'B');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'u');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'r');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'o');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'w');

	// Loading Screen
	glColor3f(0.2f,0.2f,0.2f);
	glBindTexture(GL_TEXTURE_2D, tex[1]);
	glBegin(GL_QUADS);
	glTexCoord2f(0,0);
	glVertex3f(-2.0f, -1.25f, -3.0f);
	glTexCoord2f(1,0);
	glVertex3f(2.0f, -1.25f, -3.0f);
	glTexCoord2f(1,1);
	glVertex3f(2.0f, 1.25f, -3.0f);
	glTexCoord2f(0,1);
	glVertex3f(-2.0f, 1.25f, -3.0f);
	glEnd();

	glEnable(GL_LIGHTING);

	glTranslatef(0.25f, -0.3f, -0.9f);
	glRotatef(effects_timer * 360.0f, 0.0f, 1.0f, 0.0f);
	glScalef(1.0f / 14.0f, 1.0f / 14.0f, 1.0f / 14.0f);

	float primary_color[3], secondary_color[3];

	if (random_bot == 0)
	{
		primary_color[0] = 0.0f;
		primary_color[1] = 0.25f;
		primary_color[2] = 0.0f;
	}
	else if (random_bot == 1)
	{
		primary_color[0] = 0.75f;
		primary_color[1] = 0.75f;
		primary_color[2] = 0.0f;
	}
	else if (random_bot == 2)
	{
		primary_color[0] = 0.0f;
		primary_color[1] = 0.0f;
		primary_color[2] = 0.5f;
	}
	else if (random_bot == 3)
	{
		primary_color[0] = 0.5f;
		primary_color[1] = 0.0f;
		primary_color[2] = 0.75f;
	}
	
	secondary_color[0] = 1.0f;
	secondary_color[1] = 1.0f;
	secondary_color[2] = 1.0f;

	bot[random_bot]->rot[0] = 0.0f;
	bot[random_bot]->rot[1] = 0.0f;
	bot[random_bot]->animation_type = 2; // running
	bot[random_bot]->animation_timer += 0.01f;
	if (bot[random_bot]->animation_timer > 6.28f) bot[random_bot]->animation_timer -= 6.28f;

	DrawRobot(random_bot % 2, bot[random_bot]->rot, primary_color, secondary_color, bot[random_bot]->animation_type, bot[random_bot]->animation_timer);

	glScalef(14.0f, 14.0f, 14.0f);
	glRotatef(-effects_timer * 360.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-0.25f, 0.3f, 0.9f);
	

	glutSwapBuffers();

	return;
};

void MainLoop()
{
	char command_string[256];
	float sound_distance;

	float player_move = 0.0f;

	if (difficulty_level == 1) player_move = 0.6f;
	else if (difficulty_level == 2) player_move = 1.2f;
	else if (difficulty_level == 3) player_move = 1.8f;

	// This is temporary, but shows what to do, show leaderboard after 3 minutes.
	if (time(0) - start_time > 3*60)
	{
		current_screen = 0; // Leaderboard after 3 MINUTES!
	}

	frames_per_second_counter++;

	if (frames_per_second_timer != time(0))
	{
		frames_per_second = frames_per_second_counter;
		frames_per_second_counter = 0;
		frames_per_second_timer = time(0);
	}

	if (character[0]->message_timer > 0) character[0]->message_timer -= 1;

	// Mainly for Linux, Windows will automatically receive inputs	
	if (joystick_enabled) 
	{
		FILE *joystick_fd = NULL;

		joystick_fd = fopen("/dev/input/js0", "rt");
		if (joystick_fd > 0) // IF IT'S JUST > 0, THEN NO SEG FAULT AFTER UNPLUGGING CONTROLLER!!!
		{
			int bytes = 1;
			char temp;

			// A little note on joysticks:
			// Apparently taking data from /dev/input/js0 is slow.  Somehow, someway, it got slow.
			// And so, I recommend using 'xboxdrv' to do the job right.  Set up a configuration
			// file that contains the button mapping, done.  Seriously.

			// This is specifically for the SNES controller.  
			// 8 bytes per button, some are -1 and +1 (D-pad).
			// The 5th byte is always the value of that button.
			// 104 is the total needed for SNES controller
			for (int i=0; i<104; i++)
			{
				bytes = fscanf(joystick_fd, "%c", &temp);

				if (bytes > 0 && i % 8 == 4)
				{
					joystick_button[(i-4)/8] = (int)temp;

					printf("%d ", (int)temp);
				}
			}

			printf("\n");
/*
			// This is designed for the Xbox 360 controller.
			// 8 bytes per button, 5th is value.  If read as
			// integer or boolean, joysticks are just -1 and +1.
			// 152 (basically just 19 * 8) is needed for Xbox 360 controller
			for (int i=0; i<152; i++)
			{
				bytes = fscanf(joystick_fd, "%c", &temp);

				if (bytes > 0 && i % 8 == 4)
				{
					joystick_button[(i-4)/8] = (int)temp;
	
					printf("%d ", (int)temp);
				}
			}

			printf("\n");
*/

			fclose(joystick_fd);
		}
	}
			
	// Automatic exit.  Apparently this DOESN'T 'delete' things a the end, MUST FIX THAT SOMEHOW!!!
	if (keyboard[27]) 
	{
		exit(1);
	}

	// keyboard controls, but up stairs players will go faster... (but who cares)
	// Moving
	if (keyboard['w'])
	{
		if (keyboard['a'])
		{
			character[0]->pos[2] -= player_move * cos(character[0]->rot[0] + 3.14159f / 4.0f);
			character[0]->pos[0] -= player_move * sin(character[0]->rot[0] + 3.14159f / 4.0f);
		}
		else if (keyboard['d'])
		{
			character[0]->pos[2] -= player_move * cos(character[0]->rot[0] - 3.14159f / 4.0f);
			character[0]->pos[0] -= player_move * sin(character[0]->rot[0] - 3.14159f / 4.0f);
		}
		else
		{
			character[0]->pos[2] -= player_move * cos(character[0]->rot[0]);
			character[0]->pos[0] -= player_move * sin(character[0]->rot[0]);
		}
	}
	else if (keyboard['s'])
	{
		if (keyboard['a'])
		{
			character[0]->pos[2] += player_move * cos(character[0]->rot[0] - 3.14159f / 4.0f);
			character[0]->pos[0] += player_move * sin(character[0]->rot[0] - 3.14159f / 4.0f);
		}
		else if (keyboard['d'])
		{
			character[0]->pos[2] += player_move * cos(character[0]->rot[0] + 3.14159f / 4.0f);
			character[0]->pos[0] += player_move * sin(character[0]->rot[0] + 3.14159f / 4.0f);
		}
		else
		{
			character[0]->pos[2] += player_move * cos(character[0]->rot[0]);
			character[0]->pos[0] += player_move * sin(character[0]->rot[0]);
		}
	}
	else if (keyboard['a'])
	{
		character[0]->pos[2] -= player_move * cos(character[0]->rot[0] + 3.14159f / 2.0f);
		character[0]->pos[0] -= player_move * sin(character[0]->rot[0] + 3.14159f / 2.0f);
	}
	else if (keyboard['d'])
	{
		character[0]->pos[2] -= player_move * cos(character[0]->rot[0] - 3.14159f / 2.0f);
		character[0]->pos[0] -= player_move * sin(character[0]->rot[0] - 3.14159f / 2.0f);
	}
		
	// Jumping
	if (keyboard['e'] && character[0]->last_bounded == true && jump_button1_down == false) 
	{
		system("play -q -v 1.0 Grunt.mp3 &");

		character[0]->y_vel += 2.0f;
	}	
	character[0]->y_vel -= 0.2f; // gravity

	if (keyboard['e']) jump_button1_down = true;
	if (!keyboard['e']) jump_button1_down = false;	

	// Difficulty Level Changing
	if (keyboard['-'] && diff_button1_down == false) difficulty_level -= 1;
	if (keyboard['='] && diff_button1_down == false) difficulty_level += 1;

	if (keyboard['-'] || keyboard['=']) diff_button1_down = true;
	if (!keyboard['-'] && !keyboard['=']) diff_button1_down = false;

	if (difficulty_level < 1) difficulty_level = 1;
	if (difficulty_level > 3) difficulty_level = 3;

	// Looking around
	if (keyboard['i']) character[0]->rot[1] += 1.2f / 35.0f * look_sensitivity;
	if (keyboard['k']) character[0]->rot[1] -= 1.2f / 35.0f * look_sensitivity;
	if (keyboard['j']) character[0]->rot[0] += 1.2f / 30.0f * look_sensitivity;
	if (keyboard['l']) character[0]->rot[0] -= 1.2f / 30.0f * look_sensitivity;

	// MOUSE CONTROLS!
	float mouse_sensitivity = 0.005f;

	if (mouse->x != WINDOW_WIDTH/2) character[0]->rot[0] -= mouse_sensitivity * (float)(mouse->x - WINDOW_WIDTH/2);
	if (mouse->y != WINDOW_HEIGHT/2) character[0]->rot[1] -= mouse_sensitivity * (float)(mouse->y - WINDOW_HEIGHT/2); 
	
	glutWarpPointer(WINDOW_WIDTH/2, WINDOW_HEIGHT/2);

	if (character[0]->rot[1] > 3.14159f / 2.0f) character[0]->rot[1] = 3.14159f / 2.0f;
	if (character[0]->rot[1] < -3.14159f / 2.0f) character[0]->rot[1] = -3.14159f / 2.0f;


	// All of the AI for the bots, this also takes care of bounding and whatnot too.
	BotAI(bot, character[0]->pos, bullet, 4, difficulty_level); // SHOULD BE 4 BOTS TOTAL (is anyways).

	// Bounding for character.
	BoundArenaXZ(character[0]->pos);
	character[0]->last_bounded = BoundArenaY(character[0]->pos, character[0]->y_vel);


	// Shooting for character.
	if ((keyboard[';'] || keyboard['f']) && character[0]->cool_down <= 0.0f && character[0]->ammo >= 5.0f)
	{
		system("play -q -v 1.0 Photon.mp3 &");

		character[0]->ammo -= 5;
		if (character[0]->ammo < 0) character[0]->ammo = 0;

		character[0]->cool_down = 1.0f;

		for (int i=0; i<1000; i++)
		{
			if (bullet[i]->type == -1)
			{
				bullet[i]->type = 0;

				bullet[i]->owner = -1;

				bullet[i]->pos[0] = character[0]->pos[0] - 1.0f * sin(character[0]->rot[0] - 3.14159f / 4.0f);
				bullet[i]->pos[1] = character[0]->pos[1] + 5.0f;
				bullet[i]->pos[2] = character[0]->pos[2] - 1.0f * cos(character[0]->rot[0] - 3.14159f / 4.0f);
				
				bullet[i]->vel[2] = -3.0f * cos(character[0]->rot[1]) * cos(character[0]->rot[0]);
				bullet[i]->vel[0] = -3.0f * cos(character[0]->rot[1]) * sin(character[0]->rot[0]);
				bullet[i]->vel[1] = 3.0f * sin(character[0]->rot[1]);

				i = 1001;
			}
		}

	}
	if ((keyboard['\''] || keyboard['g']) && character[0]->cool_down <= 0.0f && character[0]->ammo >= 1.0f)
	{
		system("play -q -v 1.0 Laser.mp3 &");

		character[0]->ammo -= 1;
		if (character[0]->ammo < 0) character[0]->ammo = 0;
	
		character[0]->cool_down = 0.25f;

		for (int i=0; i<1000; i++)
		{
			if (bullet[i]->type == -1)
			{
				bullet[i]->type = 1;

				bullet[i]->owner = -1;

				bullet[i]->pos[0] = character[0]->pos[0] - 1.0f * sin(character[0]->rot[0] - 3.14159f / 4.0f);
				bullet[i]->pos[1] = character[0]->pos[1] + 5.0f;
				bullet[i]->pos[2] = character[0]->pos[2] - 1.0f * cos(character[0]->rot[0] - 3.14159f / 4.0f);
				
				bullet[i]->vel[2] = -20.0f * cos(character[0]->rot[1] + (((float)(rand() % 200)/100.0f)-1.0f)*0.02f) * 
					cos(character[0]->rot[0] + (((float)(rand() % 200)/100.0f)-1.0f)*0.02f);
				bullet[i]->vel[0] = -20.0f * cos(character[0]->rot[1] + (((float)(rand() % 200)/100.0f)-1.0f)*0.02f) * 
					sin(character[0]->rot[0] + (((float)(rand() % 200)/100.0f)-1.0f)*0.02f);
				bullet[i]->vel[1] = 20.0f * sin(character[0]->rot[1] + (((float)(rand() % 200)/100.0f)-1.0f)*0.02f);

				i = 1001;
			}
		}

	}

/*
	if (((keyboard[';'] || keyboard['f']) && character[0]->cool_down <= 0.0f && character[0]->ammo < 5.0f) ||
		((keyboard['\''] || keyboard['g']) && character[0]->cool_down <= 0.0f && character[0]->ammo < 1.0f))
	{
		for (int i=0; i<256; i++) character[0]->message[i] = 0;
	
		character[0]->message[0] = 'L';
		character[0]->message[1] = 'o';
		character[0]->message[2] = 'w';
		character[0]->message[3] = ' ';
		character[0]->message[4] = 'A';
		character[0]->message[5] = 'm';
		character[0]->message[6] = 'm';
		character[0]->message[7] = 'o';

		character[0]->message_timer = 120;
	}
*/

	// VERY temporary...
	float temp_var = 0.0f; // used in two places!

	// Check all bullets...
	for (int i=0; i<1000; i++)
	{
		// Did it hit the side?
		if (BoundArenaXZ(bullet[i]->pos))
		{
			if (bullet[i]->type == 0)
			{
				// Particle effects!	
				for (int k=0; k<40; k++)
				{
					while (particle[k]->type != -1 && k < 1000) { k++; }

					particle[k]->type = 1;
					particle[k]->timer = 0.75f;
					particle[k]->gravity = 0.02f;

					particle[k]->pos[0] = bullet[i]->pos[0];
					particle[k]->pos[1] = bullet[i]->pos[1];
					particle[k]->pos[2] = bullet[i]->pos[2];
					particle[k]->vel[0] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
					particle[k]->vel[1] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
					particle[k]->vel[2] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
				}
			} 
			else if (bullet[i]->type == 1)
			{
				// Particle effects!	
				for (int k=0; k<10; k++)
				{
					while (particle[k]->type != -1 && k < 1000) { k++; }

					particle[k]->type = 1;
					particle[k]->timer = 0.75f;
					particle[k]->gravity = 0.02f;

					particle[k]->pos[0] = bullet[i]->pos[0];
					particle[k]->pos[1] = bullet[i]->pos[1];
					particle[k]->pos[2] = bullet[i]->pos[2];
					particle[k]->vel[0] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
					particle[k]->vel[1] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
					particle[k]->vel[2] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
				}
			} 

			bullet[i]->type = -1;
		}

		temp_var = 0.0f;

		// Did it hit the ground?
		if (BoundArenaY(bullet[i]->pos, temp_var))
		{
			if (bullet[i]->type == 0)
			{
				// Particle effects!	
				for (int k=0; k<40; k++)
				{
					while (particle[k]->type != -1 && k < 1000) { k++; }

					particle[k]->type = 1;
					particle[k]->timer = 0.75f;
					particle[k]->gravity = 0.02f;

					particle[k]->pos[0] = bullet[i]->pos[0];
					particle[k]->pos[1] = bullet[i]->pos[1];
					particle[k]->pos[2] = bullet[i]->pos[2];
					particle[k]->vel[0] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
					particle[k]->vel[1] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
					particle[k]->vel[2] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
				}
			} 
			else if (bullet[i]->type == 1)
			{
				// Particle effects!	
				for (int k=0; k<10; k++)
				{
					while (particle[k]->type != -1 && k < 1000) { k++; }

					particle[k]->type = 1;
					particle[k]->timer = 0.75f;
					particle[k]->gravity = 0.02f;

					particle[k]->pos[0] = bullet[i]->pos[0];
					particle[k]->pos[1] = bullet[i]->pos[1];
					particle[k]->pos[2] = bullet[i]->pos[2];
					particle[k]->vel[0] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
					particle[k]->vel[1] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
					particle[k]->vel[2] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
				}
			} 

			bullet[i]->type = -1;
		}

		// If not, then lets see who it hits.
		if (bullet[i]->type != -1)
		{
			// Check to see if bots are hit
			for (int j=0; j<4; j++)
			{
				// Don't have it hit yourself!!!
				if (bullet[i]->owner != j)
				{
					temp_var = (-(bullet[i]->pos[0] - bot[j]->pos[0]) * bullet[i]->vel[0] +
						-(bullet[i]->pos[1] - bot[j]->pos[1]) * bullet[i]->vel[1] +
						-(bullet[i]->pos[2] - bot[j]->pos[2]) * bullet[i]->vel[2]) /
						(bullet[i]->vel[0]*bullet[i]->vel[0] +
						bullet[i]->vel[1]*bullet[i]->vel[1] +
						bullet[i]->vel[2]*bullet[i]->vel[2]);

					if (temp_var >= 0.0f && temp_var <= 1.0f)
					{
						if (bullet[i]->type == 0)
						{
							if (bullet[i]->pos[1] + bullet[i]->vel[1] * temp_var >= bot[j]->pos[1] - 2.0f &&
								bullet[i]->pos[1] + bullet[i]->vel[1] * temp_var <= bot[j]->pos[1] + 8.0f)
							{
								if (pow(bullet[i]->pos[0] + bullet[i]->vel[0] * temp_var - bot[j]->pos[0], 2.0f) +
									pow(bullet[i]->pos[2] + bullet[i]->vel[2] * temp_var - bot[j]->pos[2], 2.0f) <= 9.0f)
								{
									bot[j]->health -= 20;
		
									bot[j]->hit_timer = 1.0f;
								
									bullet[i]->type = -1;

									if ((bot[j]->hate == j && rand() % 100 < 50) ||
										(bot[j]->enemy_focus == j && rand() % 100 < 15) ||
										(bot[j]->hate == bot[j]->enemy_focus && rand() % 100 < 5))
									{
										bot[j]->hate = bullet[i]->owner;
									}

									// Particle effects!
									for (int k=0; k<20; k++)
									{
										while (particle[k]->type != -1 && k < 1000) { k++; }

										particle[k]->type = 0;
										particle[k]->timer = 0.75f;
										particle[k]->gravity = 0.02f;

										particle[k]->pos[0] = bot[j]->pos[0];
										particle[k]->pos[1] = bot[j]->pos[1] + 4.0f;
										particle[k]->pos[2] = bot[j]->pos[2];
										particle[k]->vel[0] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
										particle[k]->vel[1] = (((float)(rand() % 200) / 100.0f) + 1.0f) * 0.35f;
										particle[k]->vel[2] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
									} 
								}
							}
						}
						else if (bullet[i]->type == 1)
						{
							if (bullet[i]->pos[1] + bullet[i]->vel[1] * temp_var >= bot[j]->pos[1] - 1.0f &&
								bullet[i]->pos[1] + bullet[i]->vel[1] * temp_var <= bot[j]->pos[1] + 7.0f)
							{
								if (pow(bullet[i]->pos[0] + bullet[i]->vel[0] * temp_var - bot[j]->pos[0], 2.0f) +
									pow(bullet[i]->pos[2] + bullet[i]->vel[2] * temp_var - bot[j]->pos[2], 2.0f) <= 4.0f)
								{
									bot[j]->health -= 5;
	
									bot[j]->hit_timer = 0.5f;
								
									bullet[i]->type = -1;

									if ((bot[j]->hate == j && rand() % 100 < 50) ||
										(bot[j]->enemy_focus == j && rand() % 100 < 15) ||
										(bot[j]->hate == bot[j]->enemy_focus && rand() % 100 < 5))
									{
										bot[j]->hate = bullet[i]->owner;
									}

									// Particle effects!
									for (int k=0; k<5; k++)
									{
										while (particle[k]->type != -1 && k < 1000) { k++; }

										particle[k]->type = 0;
										particle[k]->timer = 0.75f;
										particle[k]->gravity = 0.02f;

										particle[k]->pos[0] = bot[j]->pos[0];
										particle[k]->pos[1] = bot[j]->pos[1] + 4.0f;
										particle[k]->pos[2] = bot[j]->pos[2];
										particle[k]->vel[0] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
										particle[k]->vel[1] = (((float)(rand() % 200) / 100.0f) + 1.0f) * 0.35f;
										particle[k]->vel[2] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
									} 
								}
							}
						}
					}
	
					// Bot death.
					if (bot[j]->health <= 0.0f)
					{
						bot[j]->health = 100;
						bot[j]->ammo = 100.0f;
						bot[j]->deaths += 1;

						if (bullet[i]->owner != -1)
						{
							bot[bullet[i]->owner]->hate = bullet[i]->owner;
							bot[bullet[i]->owner]->enemy_focus = bullet[i]->owner;
						}

						bot[j]->hate = j;
						bot[j]->enemy_focus = j;
	
						if (bullet[i]->owner == -1) 
						{
							character[0]->kills += 1;

							for (int k=0; k<256; k++) character[0]->message[k] = 0;

							character[0]->message[0] = 'F';
							character[0]->message[1] = 'r';
							character[0]->message[2] = 'a';
							character[0]->message[3] = 'g';
							character[0]->message[4] = '\'';
							character[0]->message[5] = 'd';
							character[0]->message[6] = ' ';
							character[0]->message[7] = 'B';
							character[0]->message[8] = 'o';
							character[0]->message[9] = 't';
							character[0]->message[10] = (char)(j+48+1);

							character[0]->message_timer = 120;
						}
						else bot[bullet[i]->owner]->kills += 1;
						
						for (int k=0; k<12; k++) 
						{
							while (prism[k]->type != -1 && k < 12) { k++; }

							prism[k]->type = 0;
							prism[k]->timer = 1.0f;

							prism[k]->pos[0] = bot[j]->pos[0];
							prism[k]->pos[1] = bot[j]->pos[1];
							prism[k]->pos[2] = bot[j]->pos[2];

							k = 12;
						}

						// Play a sound with volume decreased over distance
						sound_distance = (400.0f - fabs(bot[j]->pos[0] - character[0]->pos[0]) - 
							fabs(bot[j]->pos[1] - character[0]->pos[1]) - fabs(bot[j]->pos[2] - character[0]->pos[2])) / 400.0f;
						if (sound_distance < 0.0f) sound_distance = 0.0f;
						if (sound_distance > 1.0f) sound_distance = 1.0f;
						for (int k=0; k<256; k++) command_string[k] = 0;		
						sprintf(command_string, "play -q -v %f Woosh.mp3 &", sound_distance);
						system(command_string);

						RandomSpawn(bot[j]->pos, bot[j]->rot, bot[j]->old_way, bot[j]->new_way);

						for (int k=0; k<12; k++) 
						{
							while (prism[k]->type != -1 && k < 12) { k++; }

							prism[k]->type = 1;
							prism[k]->timer = 1.0f;

							prism[k]->pos[0] = bot[j]->pos[0];
							prism[k]->pos[1] = bot[j]->pos[1];
							prism[k]->pos[2] = bot[j]->pos[2];

							k = 12;
						}

						// Play a sound with volume decreased over distance
						sound_distance = (400.0f - fabs(bot[j]->pos[0] - character[0]->pos[0]) - 
							fabs(bot[j]->pos[1] - character[0]->pos[1]) - fabs(bot[j]->pos[2] - character[0]->pos[2])) / 400.0f;
						if (sound_distance < 0.0f) sound_distance = 0.0f;
						if (sound_distance > 1.0f) sound_distance = 1.0f;
						for (int k=0; k<256; k++) command_string[k] = 0;		
						sprintf(command_string, "play -q -v %f Woosh.mp3 &", sound_distance);
						system(command_string);
					}
				}
			}	

			// And, you cannot kill yourself, see if character is hit.
			if (bullet[i]->owner != -1)
			{
				// Check to see if I'm hit
				temp_var = (-(bullet[i]->pos[0] - character[0]->pos[0]) * bullet[i]->vel[0] +
					-(bullet[i]->pos[1] - character[0]->pos[1]) * bullet[i]->vel[1] +
					-(bullet[i]->pos[2] - character[0]->pos[2]) * bullet[i]->vel[2]) /
					(bullet[i]->vel[0]*bullet[i]->vel[0] +
					bullet[i]->vel[1]*bullet[i]->vel[1] +
					bullet[i]->vel[2]*bullet[i]->vel[2]);
	
				if (temp_var >= 0.0f && temp_var <= 1.0f)
				{
					if (bullet[i]->type == 0)
					{
						if (bullet[i]->pos[1] + bullet[i]->vel[1] * temp_var >= character[0]->pos[1] - 1.0f &&
							bullet[i]->pos[1] + bullet[i]->vel[1] * temp_var <= character[0]->pos[1] + 7.0f)
						{
							if (pow(bullet[i]->pos[0] + bullet[i]->vel[0] * temp_var - character[0]->pos[0], 2.0f) +
								pow(bullet[i]->pos[2] + bullet[i]->vel[2] * temp_var - character[0]->pos[2], 2.0f) <= 9.0f)
							{
								character[0]->health -= 20;
		
								character[0]->hit_timer = 1.0f;
							
								bullet[i]->type = -1;

								// Particle effects!
								for (int k=0; k<20; k++)
								{
									while (particle[k]->type != -1 && k < 1000) { k++; }

									particle[k]->type = 0;
									particle[k]->timer = 0.75f;
									particle[k]->gravity = 0.02f;

									particle[k]->pos[0] = character[0]->pos[0];
									particle[k]->pos[1] = character[0]->pos[1] + 4.0f;
									particle[k]->pos[2] = character[0]->pos[2];
									particle[k]->vel[0] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
									particle[k]->vel[1] = (((float)(rand() % 200) / 100.0f) + 1.0f) * 0.35f;
									particle[k]->vel[2] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
								} 
							}
						}
					}
					else if (bullet[i]->type == 1)
					{
						if (bullet[i]->pos[1] + bullet[i]->vel[1] * temp_var >= character[0]->pos[1] - 0.0f &&
							bullet[i]->pos[1] + bullet[i]->vel[1] * temp_var <= character[0]->pos[1] + 6.0f)
						{
							if (pow(bullet[i]->pos[0] + bullet[i]->vel[0] * temp_var - character[0]->pos[0], 2.0f) +
								pow(bullet[i]->pos[2] + bullet[i]->vel[2] * temp_var - character[0]->pos[2], 2.0f) <= 4.0f)
							{
								character[0]->health -= 5;
		
								character[0]->hit_timer = 0.5f;
							
								bullet[i]->type = -1;

								// Particle effects!
								for (int k=0; k<5; k++)
								{
									while (particle[k]->type != -1 && k < 1000) { k++; }

									particle[k]->type = 0;
									particle[k]->timer = 0.75f;
									particle[k]->gravity = 0.02f;

									particle[k]->pos[0] = character[0]->pos[0];
									particle[k]->pos[1] = character[0]->pos[1] + 4.0f;
									particle[k]->pos[2] = character[0]->pos[2];
									particle[k]->vel[0] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
									particle[k]->vel[1] = (((float)(rand() % 200) / 100.0f) + 1.0f) * 0.35f;
									particle[k]->vel[2] = (((float)(rand() % 200) / 100.0f) - 1.0f) * 0.35f;
								} 
							}
						}
					}
				}
	
				// Character death.
				if (character[0]->health <= 0.0f)
				{
					character[0]->health = 100;
					character[0]->ammo = 100.0f;
					character[0]->deaths += 1;
				
					if (bullet[i]->owner != -1)
					{
						bot[bullet[i]->owner]->hate = bullet[i]->owner;
						bot[bullet[i]->owner]->enemy_focus = bullet[i]->owner;
					}
	
					if (bullet[i]->owner == -1) character[0]->kills += 1;
					else bot[bullet[i]->owner]->kills += 1;
	
					int temp1, temp2;
						
					for (int k=0; k<12; k++) 
					{
						while (prism[k]->type != -1 && k < 12) { k++; }

						prism[k]->type = 0;
						prism[k]->timer = 1.0f;

						prism[k]->pos[0] = character[0]->pos[0];
						prism[k]->pos[1] = character[0]->pos[1];
						prism[k]->pos[2] = character[0]->pos[2];

						k = 12;
					}

					RandomSpawn(character[0]->pos, character[0]->rot, temp1, temp2);

					for (int k=0; k<12; k++) 
					{
						while (prism[k]->type != -1 && k < 12) { k++; }

						prism[k]->type = 1;
						prism[k]->timer = 1.0f;

						prism[k]->pos[0] = character[0]->pos[0];
						prism[k]->pos[1] = character[0]->pos[1];
						prism[k]->pos[2] = character[0]->pos[2];

						k = 12;
					}
					
					system("play -q -v 1.0 Woosh.mp3 &");

					for (int k=0; k<256; k++) character[0]->message[k] = 0;

					character[0]->message[0] = 'B';
					character[0]->message[1] = 'o';
					character[0]->message[2] = 't';
					character[0]->message[3] = (char)(bullet[i]->owner+48+1);
					character[0]->message[4] = ' ';
					character[0]->message[5] = 'F';
					character[0]->message[6] = 'r';
					character[0]->message[7] = 'a';
					character[0]->message[8] = 'g';
					character[0]->message[9] = '\'';
					character[0]->message[10] = 'd';
					character[0]->message[11] = ' ';
					character[0]->message[12] = 'Y';
					character[0]->message[13] = 'o';
					character[0]->message[14] = 'u';
					
					character[0]->message_timer = 120;
				}
			}

			// Make the bullet speed along.
			bullet[i]->pos[0] += bullet[i]->vel[0];
			bullet[i]->pos[1] += bullet[i]->vel[1];
			bullet[i]->pos[2] += bullet[i]->vel[2];	
		}
	}

	// For all particles...
	for (int i=0; i<1000; i++)
	{
		if (particle[i]->type != -1)
		{
			particle[i]->timer -= 0.01f;

			if (particle[i]->timer < 0.0f)
			{
				particle[i]->type = -1;
			}
		
			particle[i]->pos[0] += particle[i]->vel[0];
			//particle[i]->pos[1] += particle[i]->vel[1]; // done in BoundArenaY();
			particle[i]->pos[2] += particle[i]->vel[2];

			particle[i]->vel[1] -= particle[i]->gravity; // gravity

			if (BoundArenaXZ(particle[i]->pos))
			{
				particle[i]->vel[0] = 0.0f;
				particle[i]->vel[1] = 0.0f;
				particle[i]->vel[2] = 0.0f;
				particle[i]->gravity = 0.0f;
			}

			if (BoundArenaY(particle[i]->pos, particle[i]->vel[1]))
			{
				particle[i]->vel[0] = 0.0f;
				particle[i]->vel[1] = 0.0f;
				particle[i]->vel[2] = 0.0f;
				particle[i]->gravity = 0.0f;
			}
		}
	}

	// For all prisms...
	for (int i=0; i<12; i++)
	{
		if (prism[i]->type != -1)
		{
			prism[i]->timer -= 0.01f;

			if (prism[i]->timer < 0.0f)
			{
				prism[i]->type = -1;
			}
		}
	}	

	// Hit timer and cool down for character.
	character[0]->hit_timer -= 0.05f;
	if (character[0]->hit_timer < 0.0f) character[0]->hit_timer = 0.0f;

	character[0]->cool_down -= 0.05f;
	if (character[0]->cool_down < 0.0f) character[0]->cool_down = 0.0f;

	// Recharge ammo over time, no need for melee now!
	character[0]->ammo += 0.02f;
	if (character[0]->ammo > 200) character[0]->ammo = 200.0f;
	
	// Hit timer and cool down for bots.
	for (int i=0; i<4; i++)
	{
		bot[i]->hit_timer -= 0.05f;
		if (bot[i]->hit_timer < 0.0f) bot[i]->hit_timer = 0.0f;

		bot[i]->cool_down -= 0.05f;
		if (bot[i]->cool_down < 0.0f) bot[i]->cool_down = 0.0f;

		bot[i]->ammo += 0.02f;
		if (bot[i]->ammo > 200.0f) bot[i]->ammo = 200.0f;
	}


	// Random Pickups, where they are placed.
	if (rand() % 100 < 1)
	{
		int minitest = 0;

		int random_number;

		for (int i=0; i<26; i++)
		{
			if (pickup[i]->type == -1) minitest += 1;
		}

		if (minitest > 6)
		{
			random_number = rand() % 26;
	
			while (pickup[random_number]->type != -1)
			{
				 random_number = rand() % 26;
			}

			if (rand() % 100 < 25) pickup[random_number]->type = 0;
			else pickup[random_number]->type = 1;

			pickup[random_number]->pos[0] = arena_way_point[random_number*3+0];
			pickup[random_number]->pos[1] = arena_way_point[random_number*3+1];
			pickup[random_number]->pos[2] = arena_way_point[random_number*3+2];
		}
	}

	// And if any pickups are actually taken.
	for (int i=0; i<26; i++)
	{
		if (pickup[i]->type != -1)
		{
			// By the character...
			if (pow(character[0]->pos[0] - pickup[i]->pos[0], 2.0f) +
				pow(character[0]->pos[1] - pickup[i]->pos[1], 2.0f) +
				pow(character[0]->pos[2] -pickup[i]->pos[2], 2.0f) <= 25.0f)
			{
				if (pickup[i]->type == 0) // health
				{
					system("play -q -v 1.0 Chant.mp3 &");

					character[0]->health += 20;
					if (character[0]->health > 100) character[0]->health = 100;
				}
				else if (pickup[i]->type == 1)
				{
					system("play -q -v 1.0 Reload.mp3 &");

					character[0]->ammo += 100.0f;
					if (character[0]->ammo > 200.0f) character[0]->ammo = 200.0f;
				}

				pickup[i]->type = -1;
			}

			// By any bot...
			for (int j=0; j<4; j++)
			{
				if (pow(bot[j]->pos[0] - pickup[i]->pos[0], 2.0f) +
					pow(bot[j]->pos[1] - pickup[i]->pos[1], 2.0f) +
					pow(bot[j]->pos[2] -pickup[i]->pos[2], 2.0f) <= 9.0f)
				{
					if (pickup[i]->type == 0) // health
					{
						bot[j]->health += 20;
						if (bot[j]->health > 100) bot[j]->health = 100;
					}
					else if (pickup[i]->type == 1)
					{
						bot[j]->ammo += 100.0f;
						if (bot[j]->ammo > 200.0f) bot[j]->ammo = 200.0f;
					}

					pickup[i]->type = -1;
				}
			}
		}
	}

	// DRAW HERE!!!

/*
frame_ticker += 1;
if (frame_ticker >= 100) frame_ticker = 0;

// Don't draw each time!!!  It makes it much faster!! :P
if (frame_ticker % 4 == 0)
{
*/

	
/*
	// For dual-screens
	
	SetupAll(WINDOW_WIDTH/4,0, WINDOW_WIDTH,WINDOW_HEIGHT); // weird to draw over some of the other screen, but that's how to center it???
	DrawAll(1);
	
	glClear(GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();	

	SetupAll(0,0, WINDOW_WIDTH/2,WINDOW_HEIGHT);
	DrawAll(0);
*/

	// For a single screen
	MainDraw(0);


//}

	return;
};

void OpenGLSetupFunction()
{
	glutWarpPointer(WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);

	for (int i=0; i<256; i++) 
	{
		keyboard[i] = false;
		special_keyboard[i] = false;
	}

	for (int i=0; i<32; i++) joystick_button[i] = 0;
	joystick_axis->x = 0;
	joystick_axis->y = 0;
	joystick_axis->z = 0;

	// If there is a joystick...
	if (glutDeviceGet(GLUT_HAS_JOYSTICK)) 
	{
		printf("Joystick Detected!\n");

		joystick_enabled = true;
	}
	

	LoadBitmap("Blank.bmp", tex[0]); // text
	LoadBitmap("ConcreteFloors.bmp", tex[1]); // floor
	LoadBitmap("BrickOldRounded.bmp", tex[2]); // walls
	LoadBitmap("WindowsBlocks.bmp", tex[3]); // ceiling
	LoadBitmap("HighRiseGlass.bmp", tex[4]); // glass
	LoadBitmap("WoodLogs.bmp", tex[5]); // stairs
	LoadBitmap("Apple.bmp", tex[6]); // health
	LoadBitmap("Door.bmp", tex[7]); // ammo
	LoadBitmap("Fireworks1.bmp", tex[8]); // shots
	LoadBitmap("Fireworks2.bmp", tex[9]); // shots
	LoadBitmap("Fireworks3.bmp", tex[10]); // shots
	

	// INITIALIZE HERE!!!

	SetupAll(0,0,WINDOW_WIDTH,WINDOW_HEIGHT);
	
	random_bot = rand() % 4;
	
	return;
};

void OpenGLDisplayFunction()
{
	return;
};

void OpenGLIdleFunction()
{
	effects_timer += 0.01f;
	if (effects_timer > 1.0f) effects_timer -= 1.0f;

	if (current_screen == 0) // leaderboard
	{
		LeaderboardLoop();
	}
	else if (current_screen == 1) // main loop
	{
		MainLoop();
	}

	return;
};

void OpenGLKeyboardUpFunction(unsigned char key, int x, int y)
{
	keyboard[key] = false;

	mod_key = 0;

	return;
};

void OpenGLKeyboardFunction(unsigned char key, int x, int y)
{
	keyboard[key] = true;

	mod_key = glutGetModifiers(); 

	return;
};

void OpenGLSpecialKeyboardFunction(int key, int x, int y)
{
	special_keyboard[key] = true;

	return;
};	

void OpenGLSpecialKeyboardUpFunction(int key, int x, int y)
{
	special_keyboard[key] = false;

	return;
};

// GLUT in Linux does support joystick detection but not input.
// GLUT in Windows supports both
void OpenGLJoystickFunction(unsigned int button, int x, int y, int z)
{
	joystick_axis->x = x;
	joystick_axis->y = y;
	joystick_axis->z = z;

	// Bitwise AND
	joystick_button[0] = button & 0x0001;
	joystick_button[1] = button & 0x0002;
	joystick_button[2] = button & 0x0004;
	joystick_button[3] = button & 0x0008;
	joystick_button[4] = button & 0x0010;
	joystick_button[5] = button & 0x0020;
	joystick_button[6] = button & 0x0040;
	joystick_button[7] = button & 0x0080;
	joystick_button[8] = button & 0x0100;
	joystick_button[9] = button & 0x0200;
	joystick_button[10] = button & 0x0400;
	joystick_button[11] = button & 0x0800;

	return;
};

void OpenGLMouseFunction(int button, int state, int x, int y)
{
	mouse->button = button;
	mouse->state = state;
	mouse->x = x;
	mouse->y = y;

	return;
};

void OpenGLPassiveMotionFunction(int x, int y)
{
	mouse->x = x;
	mouse->y = y;

	return;
};

void my_randomize()
{
	int stime = 0;
	long ltime = 0;
	ltime = time(NULL);
	stime = (unsigned)ltime/2;
	srand(stime);
};

int main(int argc, char **argv)
{
	my_randomize();

	camera_pos = new _Point();
	camera_rot = new _Point();

	joystick_axis = new _Joystick();
	mouse = new _Mouse();

	// Make sure classes are all 'new'
	character[0] = new _Character;
	character[1] = new _Character;

	for (int i=0; i<4; i++) bot[i] = new _Bot;

	for (int i=0; i<1000; i++) bullet[i] = new _Bullet;

	for (int i=0; i<26; i++) pickup[i] = new _Pickup();

	for (int i=0; i<1000; i++) particle[i] = new _Particle();
	
	for (int i=0; i<12; i++) prism[i] = new _Prism();


	glutInit(&argc, argv);

	glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);

	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

	glutCreateWindow("Arena");
	glutFullScreen();
	glutSetCursor(GLUT_CURSOR_NONE); 

	glutDisplayFunc(OpenGLDisplayFunction);
	glutIdleFunc(OpenGLIdleFunction);
	glutKeyboardFunc(OpenGLKeyboardFunction);
	glutKeyboardUpFunc(OpenGLKeyboardUpFunction);
	glutSpecialFunc(OpenGLSpecialKeyboardFunction);
	glutSpecialUpFunc(OpenGLSpecialKeyboardUpFunction);
	glutJoystickFunc(OpenGLJoystickFunction, 50);
	glutMouseFunc(OpenGLMouseFunction);
	glutPassiveMotionFunc(OpenGLPassiveMotionFunction);

	OpenGLSetupFunction();


   	glutMainLoop();


	delete camera_pos;
	delete camera_rot;

	delete joystick_axis;
	delete mouse;


	// THESE DELETE'S DONT HAPPEN!!!  Figure out why later....

	delete character[0];
	delete character[1];

	for (int i=0; i<4; i++)
	{
		delete bot[i];
	}

	for (int i=0; i<1000; i++)
	{
		delete bullet[i];
	}

	for (int i=0; i<26; i++)
	{
		delete pickup[i];
	}

	for (int i=0; i<1000; i++)
	{
		delete particle[i];
	}

	for (int i=0; i<12; i++)
	{
		delete prism[i];
	}

	return 0;
}


