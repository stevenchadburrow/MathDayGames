/*
In order to run this on Linux, you must include -lglut and -lGLU when compiling.
g++ -o Main.o Main.cpp -lglut -lGLU -lGL
./Main.o
Also make sure you have all of the glut and/or freeglut packages downloaded, GLU, maybe OpenGL Mesa Dev packages??

In order to run this on Windows, use Dev-C++.  Start a Multimedia Project with glut, not an empty project like normal.
To get that project, you need to go to Tools->Packages and download all glut and/or freeglut packages.
Remember that the Project Options->Linker has to have stuff like -lwinmm -lglut -lglut32 -lopengl32  (Something with GLU) etc....
*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <GL/glut.h>

// can only take a 640x480 snapshot.  Be sure the view window is set appropriately!
// gotta be after 'Swap Buffers' I think.
// also, it's comes from the bottom left corner on the screen, so beware of that.
int TakeSnapshot(const char *filename)
{
	FILE *input = NULL;

	input = fopen("BMP-640x480-Template.bmp", "rb");
	if (!input) return 0;

	FILE *output = NULL;

	output = fopen(filename, "wb");
	if (!output) return 0;

	for (int i=0; i<54; i++)
	{
		putc(getc(input), output);
	}

	unsigned char color_array[3];

	for (int j=0; j<480; j++)
	{
		for (int i=0; i<640; i++)
		{
			glReadPixels(i, j, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, color_array);		

			putc(color_array[2], output);
			putc(color_array[1], output);
			putc(color_array[0], output);
		}
	}

	fclose(input);

	fclose(output);

	return 1;
};	

const int TEXTURE_BLANK = 0;
const int TEXTURE_TRANSPARENT = 1;
const int TEXTURE_HUMAN_EYES = 2;
const int TEXTURE_HUMAN_SKIN = 3;
const int TEXTURE_HUMAN_HAIR = 4;
const int TEXTURE_HUMAN_SHIRT = 5;
const int TEXTURE_HUMAN_BOOTS = 6;
const int TEXTURE_BOX = 7;
const int TEXTURE_FLOOR = 8;
const int TEXTURE_WALL = 9;
const int TEXTURE_CEILING = 10;
const int TEXTURE_HURT = 11;

GLuint texture[15];

class _Point {
public:
	_Point()
	{
		x = y = z = 0.0f;
	}

	float x, y, z;
	
	void Set(float my_x, float my_y, float my_z)
	{
		x = my_x;
		y = my_y;
		z = my_z;
	
		return;
	}

};

#include "RobotModels.h"
#include "HumanModels.h"

#define WINDOW_WIDTH 640
#define WINDOW_HEIGHT 480

bool keyboard[256], special_keyboard[256];
int joystick_button[32];
bool joystick_enabled = false;
int frames_per_second = 0, frames_per_second_counter = 0, frames_per_second_timer = 0;

_Point *camera_pos, *camera_rot, *camera_vel;

class _Mouse {
public:
	_Mouse()
	{
		x = y = 0;
	
		button = 0;
		state = 0;
	}

	int x, y;

	int button, state;

} *mouse;

/*
class _Joystick {
public:
	_Joystick()
	{
		x = y = z = 0;
	}

	int x, y, z;

} *joystick_axis;
*/

int user_input_story_progression = 0; // used in program arguments
int completion_delay = 0;

char command[512];

const int MAX_BOTS = 100;
const int MAX_PARTICLES = 1000;
const int MAX_BOXES = 100;
const int MAX_ITEMS = 50;
const int MAX_WALLS = 200;
const int MAX_MAP_X = 50;
const int MAX_MAP_Z = 50;
const float MAX_TILE_X = 20.0f;
const float MAX_TILE_Z = 20.0f;

int right_handed_weapon = 0;
int left_handed_weapon = 0;
float right_handed_angle = 0.0f;
float left_handed_angle = 0.0f;
int right_handed_down = 0;
int left_handed_down = 0;
int right_handed_ammo = 0;
int left_handed_ammo = 0;
int right_handed_projectile_on = 0;
int left_handed_projectile_on = 0;

int jump_button = 0;
int right_equip_button = 0;
int left_equip_button = 0;
int save_button = 0;
int reset_held = 0;
int idle_time = 0;
int equip_recent = 0;
int human_recent = 0;

_Point *projectile_pos[2];
_Point *projectile_rot[2];

int player_health = 100;
int player_hurt_timer = 0;
int highlighted_item = -1;
int near_save = 0;

_Point *bot_pos[MAX_BOTS];
_Point *bot_rot[MAX_BOTS];
_Point *bot_primary_color[MAX_BOTS];
_Point *bot_secondary_color[MAX_BOTS];
int bot_sex[MAX_BOTS];
int bot_weapon[MAX_BOTS];
int bot_action[MAX_BOTS];
float bot_timer[MAX_BOTS];
int bot_health[MAX_BOTS];
int bot_sighted[MAX_BOTS];

_Point *particle_pos[MAX_PARTICLES];
_Point *particle_vel[MAX_PARTICLES];
float particle_size[MAX_PARTICLES];

_Point *box_pos[MAX_BOXES];
_Point *box_size[MAX_BOXES];
_Point *box_color[MAX_BOXES];

_Point *item_pos[MAX_ITEMS];
int item_type[MAX_ITEMS];

_Point *x_wall[MAX_WALLS]; // y-value in each determines length in positive direction
_Point *x_wall_color[MAX_WALLS];
_Point *z_wall[MAX_WALLS];
_Point *z_wall_color[MAX_WALLS];

char map_tile[MAX_MAP_X][MAX_MAP_Z];
int map_bounds[MAX_MAP_X][MAX_MAP_Z];

long unsigned start_time, level_time;

int bots_killed = 0;
int player_deaths = 0;

int story_progression = 0;

_Rotations *human_rotations;
_Rotations *human_prev_rot, *human_next_rot;

float human_animation_timer = 0.0f; // not really used
int human_current_animation = 0; // not really used

float human_transition_scale = 0.0f;

char human_subtitle[512];

void HumanEvent(int pose, const char *speech, int sound, int tutorial)
{
	if ((tutorial == 0 && abs(time(0) - level_time) < 10) || 
		(tutorial == 0 && abs(time(0) - level_time) < 18 && story_progression == 10)) return;

	SetTransitionRotation(human_rotations, human_prev_rot, human_next_rot, pose);

	for (int i=0; i<512; i++) human_subtitle[i] = 0;

	sprintf(human_subtitle, "%s", speech);

	human_transition_scale = 0.0f;

	if (sound > 0)
	{
		// play voice sound here!
	}

	human_recent = 5 * 60;

	return;
};

void Reset()
{
	camera_pos->x = 0.0f;
	camera_pos->y = 0.0f;
	camera_pos->z = 0.0f;
	
	camera_rot->x = 0.0f;
	camera_rot->y = 0.0f;
	camera_rot->z = 0.0f;
	
	camera_vel->x = 0.0f;
	camera_vel->y = 0.0f;
	camera_vel->z = 0.0f;

	//right_handed_weapon = 0;
	//right_handed_ammo = 0;
	//left_handed_weapon = 0;
	//left_handed_ammo = 0;

	idle_time = 0;

	for (int i=0; i<MAX_BOTS; i++) // needs to happen at beginning of each new game!
	{
		bot_health[i] = 0;
	}

	for (int i=0; i<MAX_PARTICLES; i++)
	{
		particle_size[i] = 0.0f;
	}

	for (int i=0; i<MAX_BOXES; i++)
	{
		box_size[i]->x = 0.0f;
		box_size[i]->y = 0.0f;
		box_size[i]->z = 0.0f;
	}
	
	for (int i=0; i<MAX_ITEMS; i++)
	{
		item_type[i] = 0;
	}

	for (int i=0; i<MAX_WALLS; i++)
	{
		x_wall[i]->y = 0.0f;
		z_wall[i]->y = 0.0f;
	}

	for (int i=0; i<MAX_MAP_X; i++)
	{
		for (int j=0; j<MAX_MAP_Z; j++)
		{
			map_tile[i][j] = '#';
			map_bounds[i][j] = 0;
		}
	}

	return;
};

int CreateLevel(const char *filename)
{
	FILE *input = NULL;

	input = fopen(filename, "rt");
	if (!input) return 0;

	char return_character;

	for (int i=0; i<MAX_MAP_Z; i++) // notice here it's backwards!
	{
		for (int j=0; j<MAX_MAP_X; j++)
		{
			fscanf(input, "%c", &map_tile[j][i]);
		}

		fscanf(input, "%c", &return_character);
	}

	fclose(input);

	for (int i=0; i<MAX_MAP_X; i++) // take care of enemies, items, and boxes first
	{
		for (int j=0; j<MAX_MAP_Z; j++)
		{
			if (map_tile[i][j] == 'B') // enemy
			{
				for (int k=0; k<MAX_BOTS; k++)
				{
					if (bot_health[k] <= 0)
					{
						bot_pos[k]->x = (float)i * MAX_TILE_X;
						bot_pos[k]->y = 0.0f;
						bot_pos[k]->z = (float)j * MAX_TILE_Z;
					
						bot_rot[k]->x = 0.0f;
						bot_rot[k]->y = 0.0f;
						bot_rot[k]->z = 0.0f;

						bot_primary_color[k]->x = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
						bot_primary_color[k]->y = (float)(rand() % 100) / 100.0f * 0.5f + 0.3f;
						bot_primary_color[k]->z = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;

						bot_secondary_color[k]->x = 1.0f;
						bot_secondary_color[k]->y = 1.0f;
						bot_secondary_color[k]->z = 1.0f;

						bot_sex[k] = rand() % 2;
						bot_weapon[k] = rand() % 2 + 1;

						bot_action[k] = 0;
						bot_timer[k] = 0.0f;
						bot_health[k] = rand() % 51 + 50;
						bot_sighted[k] = 0;

						k = MAX_BOTS + 1;
					}
				}
			}
			else if (map_tile[i][j] == 'P') // hammer
			{
				for (int k=0; k<MAX_ITEMS; k++)
				{
					if (item_type[k] == 0)
					{
						item_pos[k]->x = (float)i * MAX_TILE_X;
						item_pos[k]->y = 0.0f;
						item_pos[k]->z = (float)j * MAX_TILE_Z;
						
						item_type[k] = 99; // full hammer

						k = MAX_ITEMS + 1;
					}
				}
			}
			else if (map_tile[i][j] == 'C') // scythe
			{
				for (int k=0; k<MAX_ITEMS; k++)
				{
					if (item_type[k] == 0)
					{
						item_pos[k]->x = (float)i * MAX_TILE_X;
						item_pos[k]->y = 0.0f;
						item_pos[k]->z = (float)j * MAX_TILE_Z;
						
						item_type[k] = 120; // ok scythe

						k = MAX_ITEMS + 1;
					}
				}
			}
			else if (map_tile[i][j] == 'I') // spikes
			{
				for (int k=0; k<MAX_ITEMS; k++)
				{
					if (item_type[k] == 0)
					{
						item_pos[k]->x = (float)i * MAX_TILE_X;
						item_pos[k]->y = 0.0f;
						item_pos[k]->z = (float)j * MAX_TILE_Z;
						
						item_type[k] = 205; // 10 spikes

						k = MAX_ITEMS + 1;
					}
				}
			}
			else if (map_tile[i][j] == 'H') // health
			{
				for (int k=0; k<MAX_ITEMS; k++)
				{
					if (item_type[k] == 0)
					{
						item_pos[k]->x = (float)i * MAX_TILE_X;
						item_pos[k]->y = 0.0f;
						item_pos[k]->z = (float)j * MAX_TILE_Z;
						
						item_type[k] = 350; // 50% health

						k = MAX_ITEMS + 1;
					}
				}
			}
			else if (map_tile[i][j] == 'S') // save
			{
				for (int k=0; k<MAX_ITEMS; k++)
				{
					if (item_type[k] == 0)
					{
						item_pos[k]->x = (float)i * MAX_TILE_X;
						item_pos[k]->y = 0.0f;
						item_pos[k]->z = (float)j * MAX_TILE_Z;
						
						item_type[k] = 400; // just a save

						k = MAX_ITEMS + 1;
					}
				}
			}
			else if (map_tile[i][j] == '<') // starting point of level
			{
				camera_pos->x = (float)i * MAX_TILE_X;
				camera_pos->y = 0.0f;
				camera_pos->z = (float)j * MAX_TILE_Z;

				camera_rot->x = 0.0f;
				camera_rot->y = -3.14159f / 2.0f;
				camera_rot->z = 0.0f;
			}
			else if (map_tile[i][j] == '>') // ending point of level
			{
				for (int k=0; k<MAX_ITEMS; k++)
				{
					if (item_type[k] == 0)
					{
						item_pos[k]->x = (float)i * MAX_TILE_X;
						item_pos[k]->y = 0.0f;
						item_pos[k]->z = (float)j * MAX_TILE_Z;
						
						item_type[k] = 500; // just a teleport

						k = MAX_ITEMS + 1;
					}
				}
			}
			else if (map_tile[i][j] == '1') // box config 1
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z;
				
						box_size[k]->x = 10.0f;
						box_size[k]->y = 10.0f;
						box_size[k]->z = 10.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
			else if (map_tile[i][j] == '2') // box config 2
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z;
				
						box_size[k]->x = 10.0f;
						box_size[k]->y = 20.0f;
						box_size[k]->z = 10.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
			else if (map_tile[i][j] == '3') // box config 3
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z;
				
						box_size[k]->x = 3.5f;
						box_size[k]->y = 20.0f;
						box_size[k]->z = 2.5f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}

				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z - 4.0f;
				
						box_size[k]->x = 1.5f;
						box_size[k]->y = 10.0f;
						box_size[k]->z = 1.5f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
				
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z + 4.0f;
				
						box_size[k]->x = 1.5f;
						box_size[k]->y = 10.0f;
						box_size[k]->z = 1.5f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
			else if (map_tile[i][j] == '4') // box config 4
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z;
				
						box_size[k]->x = 5.0f;
						box_size[k]->y = 5.0f;
						box_size[k]->z = 5.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}

				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z;
				
						box_size[k]->x = 2.0f;
						box_size[k]->y = 15.0f;
						box_size[k]->z = 2.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
			else if (map_tile[i][j] == '5') // box config 5
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X - MAX_TILE_X * 0.25f;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z - MAX_TILE_X * 0.25f;
				
						box_size[k]->x = 1.0f;
						box_size[k]->y = 2.0f;
						box_size[k]->z = 1.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}

				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X + MAX_TILE_X * 0.25f;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z - MAX_TILE_X * 0.25f;
				
						box_size[k]->x = 1.0f;
						box_size[k]->y = 2.0f;
						box_size[k]->z = 1.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
				
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X + MAX_TILE_X * 0.25f;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z + MAX_TILE_X * 0.25f;
				
						box_size[k]->x = 1.0f;
						box_size[k]->y = 2.0f;
						box_size[k]->z = 1.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}

				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X - MAX_TILE_X * 0.25f;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z + MAX_TILE_X * 0.25f;
				
						box_size[k]->x = 1.0f;
						box_size[k]->y = 2.0f;
						box_size[k]->z = 1.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
			else if (map_tile[i][j] == '6') // box config 6
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z;
				
						box_size[k]->x = 2.0f;
						box_size[k]->y = 10.0f;
						box_size[k]->z = 2.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
			else if (map_tile[i][j] == '7') // box config 7
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z;
				
						box_size[k]->x = 1.0f;
						box_size[k]->y = 20.0f;
						box_size[k]->z = 1.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
			else if (map_tile[i][j] == '8') // box config 8
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z;
				
						box_size[k]->x = 1.0f;
						box_size[k]->y = 30.0f;
						box_size[k]->z = 1.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
			else if (map_tile[i][j] == '9') // box config 9
			{
				for (int k=0; k<MAX_BOXES; k++)
				{
					if (box_size[k]->y <= 0.0f)
					{
						box_pos[k]->x = (float)i * MAX_TILE_X;
						box_pos[k]->y = 0.0f;
						box_pos[k]->z = (float)j * MAX_TILE_Z + MAX_TILE_Z * 0.4f;
				
						box_size[k]->x = 10.0f;
						box_size[k]->y = 25.0f;
						box_size[k]->z = 1.0f;

						box_color[k]->x = (float)(rand() % 100) / 100.0f * 0.4f + 0.2f;
						box_color[k]->y = (float)(rand() % 100) / 100.0f * 0.15f + 0.1f;
						box_color[k]->z = (float)(rand() % 100) / 100.0f * 0.05f + 0.05f;

						k = MAX_BOXES + 1;
					}
				}
			}
		}
	}
			
	for (int i=0; i<MAX_MAP_Z; i++) // designating open or closed
	{
		for (int j=0; j<MAX_MAP_X; j++)
		{
			if (map_tile[j][i] == 'B' ||
				map_tile[j][i] == 'P' ||
				map_tile[j][i] == 'C' ||
				map_tile[j][i] == 'I' ||
				map_tile[j][i] == 'H' ||
				map_tile[j][i] == 'S' ||
				map_tile[j][i] == '<' ||
				map_tile[j][i] == '>' ||
				map_tile[j][i] == '1' ||
				map_tile[j][i] == '2' ||
				map_tile[j][i] == '3' ||
				map_tile[j][i] == '4' ||
				map_tile[j][i] == '5' ||
				map_tile[j][i] == '6' ||
				map_tile[j][i] == '7' ||
				map_tile[j][i] == '8' ||
				map_tile[j][i] == '9' ||
				map_tile[j][i] == '.')
			{
				map_bounds[j][i] = 1; // open
			}
			else
			{
				map_bounds[j][i] = 0; // closed
			}
		}
	}

	for (int i=1; i<MAX_MAP_X-1; i++) // now for walls
	{
		for (int j=1; j<MAX_MAP_Z-1; j++)
		{
			if (map_bounds[i][j] == 1) // open
			{
				if (map_bounds[i-1][j] == 0) // closed on left
				{
					for (int k=0; k<MAX_WALLS; k++)
					{
						if (z_wall[k]->y <= 0.0f)
						{
							z_wall[k]->x = (float)i * MAX_TILE_X - MAX_TILE_X * 0.5f;
							z_wall[k]->z = (float)j * MAX_TILE_Z - MAX_TILE_Z * 0.5f;
							z_wall[k]->y = MAX_TILE_Z;

							z_wall_color[k]->x = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
							z_wall_color[k]->y = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
							z_wall_color[k]->z = (float)(rand() % 100) / 100.0f * 0.4f + 0.4f;
	
							k = MAX_WALLS + 1;
						}
					}
				}
				
				if (map_bounds[i+1][j] == 0) // closed on right
				{
					for (int k=0; k<MAX_WALLS; k++)
					{
						if (z_wall[k]->y <= 0.0f)
						{
							z_wall[k]->x = (float)(i+1) * MAX_TILE_X - MAX_TILE_X * 0.5f;
							z_wall[k]->z = (float)j * MAX_TILE_Z - MAX_TILE_Z * 0.5f;
							z_wall[k]->y = MAX_TILE_Z;

							z_wall_color[k]->x = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
							z_wall_color[k]->y = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
							z_wall_color[k]->z = (float)(rand() % 100) / 100.0f * 0.4f + 0.4f;
	
							k = MAX_WALLS + 1;
						}
					}
				}
				
				if (map_bounds[i][j-1] == 0) // closed on top
				{
					for (int k=0; k<MAX_WALLS; k++)
					{
						if (x_wall[k]->y <= 0.0f)
						{
							x_wall[k]->x = (float)i * MAX_TILE_X - MAX_TILE_X * 0.5f;
							x_wall[k]->z = (float)j * MAX_TILE_Z - MAX_TILE_Z * 0.5f;
							x_wall[k]->y = MAX_TILE_X;

							x_wall_color[k]->x = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
							x_wall_color[k]->y = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
							x_wall_color[k]->z = (float)(rand() % 100) / 100.0f * 0.4f + 0.4f;
	
							k = MAX_WALLS + 1;
						}
					}
				}
				
				if (map_bounds[i][j+1] == 0) // closed on top
				{
					for (int k=0; k<MAX_WALLS; k++)
					{
						if (x_wall[k]->y <= 0.0f)
						{
							x_wall[k]->x = (float)i * MAX_TILE_X - MAX_TILE_X * 0.5f;
							x_wall[k]->z = (float)(j+1) * MAX_TILE_Z - MAX_TILE_Z * 0.5f;
							x_wall[k]->y = MAX_TILE_X;

							x_wall_color[k]->x = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
							x_wall_color[k]->y = (float)(rand() % 100) / 100.0f * 0.1f + 0.1f;
							x_wall_color[k]->z = (float)(rand() % 100) / 100.0f * 0.4f + 0.4f;
	
							k = MAX_WALLS + 1;
						}
					}
				}
			}
		}
	}
	
	return 1;
};

int Save()
{
	FILE *output = NULL;

	output = fopen("SaveData.txt", "wt");
	if (!output) return 0;

	fprintf(output, "%f %f %f %f %f %f %f %f %f\n",
		camera_pos->x, camera_pos->y, camera_pos->z,
		camera_rot->x, camera_rot->y, camera_rot->z,
		camera_vel->x, camera_vel->y, camera_vel->z);

	fprintf(output, "%d %d %f %f %d %d %d %d %d %d\n",
		right_handed_weapon, left_handed_weapon, right_handed_angle, left_handed_angle, right_handed_down, left_handed_down,
		right_handed_ammo, left_handed_ammo, right_handed_projectile_on, left_handed_projectile_on);

	fprintf(output, "%f %f %f %f %f %f %f %f %f %f %f %f\n",
		projectile_pos[0]->x, projectile_pos[0]->y, projectile_pos[0]->z,
		projectile_rot[0]->x, projectile_rot[0]->y, projectile_rot[0]->z,
		projectile_pos[1]->x, projectile_pos[1]->y, projectile_pos[1]->z,
		projectile_rot[1]->x, projectile_rot[1]->y, projectile_rot[1]->z);

	fprintf(output, "%d %d %d %d %d %d\n", player_health, highlighted_item, near_save, idle_time, equip_recent, human_recent);

	for (int i=0; i<MAX_BOTS; i++)
	{
		fprintf(output, "%f %f %f %f %f %f %f %f %f %f %f %f\n", bot_pos[i]->x, bot_pos[i]->y, bot_pos[i]->z,
			bot_rot[i]->x, bot_rot[i]->y, bot_rot[i]->z, bot_primary_color[i]->x, bot_primary_color[i]->y, bot_primary_color[i]->z,
			bot_secondary_color[i]->x, bot_secondary_color[i]->y, bot_secondary_color[i]->z);

		fprintf(output, "%d %d %d %f %d %d\n", bot_sex[i], bot_weapon[i], bot_action[i], bot_timer[i], bot_health[i], bot_sighted[i]);
	}

	for (int i=0; i<MAX_PARTICLES; i++)
	{
		particle_size[i] = 0.0f; // don't save particles!
	}

	for (int i=0; i<MAX_BOXES; i++)
	{
		fprintf(output, "%f %f %f %f %f %f %f %f %f\n", box_pos[i]->x, box_pos[i]->y, box_pos[i]->z,
			box_size[i]->x, box_size[i]->y, box_size[i]->z, box_color[i]->x, box_color[i]->y, box_color[i]->z);
	}

	for (int i=0; i<MAX_ITEMS; i++)
	{
		fprintf(output, "%f %f %f %d\n", item_pos[i]->x, item_pos[i]->y, item_pos[i]->z, item_type[i]);
	}

	for (int i=0; i<MAX_WALLS; i++)
	{
		fprintf(output, "%f %f %f %f %f %f\n", x_wall[i]->x, x_wall[i]->y, x_wall[i]->z,
			x_wall_color[i]->x, x_wall_color[i]->y, x_wall_color[i]->z);
	}

	for (int i=0; i<MAX_WALLS; i++)
	{
		fprintf(output, "%f %f %f %f %f %f\n", z_wall[i]->x, z_wall[i]->y, z_wall[i]->z,
			z_wall_color[i]->x, z_wall_color[i]->y, z_wall_color[i]->z);
	}

	for (int i=0; i<MAX_MAP_Z; i++)
	{
		for (int j=0; j<MAX_MAP_X; j++)
		{
			fprintf(output, "%c", map_tile[j][i]);
		}

		fprintf(output, "\n");
	}

	for (int i=0; i<MAX_MAP_Z; i++)
	{
		for (int j=0; j<MAX_MAP_X; j++)
		{
			fprintf(output, "%d ", map_bounds[j][i]);
		}

		fprintf(output, "\n");
	}


	fprintf(output, "%lu %lu %d %d %d\n", start_time, level_time, bots_killed, player_deaths, story_progression);

	fclose(output);

	return 1;
};

int Load()
{
	FILE *input = NULL;

	input = fopen("SaveData.txt", "rt");
	if (!input) return 0;

	fscanf(input, "%f %f %f %f %f %f %f %f %f\n",
		&camera_pos->x, &camera_pos->y, &camera_pos->z,
		&camera_rot->x, &camera_rot->y, &camera_rot->z,
		&camera_vel->x, &camera_vel->y, &camera_vel->z);

	fscanf(input, "%d %d %f %f %d %d %d %d %d %d\n",
		&right_handed_weapon, &left_handed_weapon, &right_handed_angle, &left_handed_angle, &right_handed_down, &left_handed_down,
		&right_handed_ammo, &left_handed_ammo, &right_handed_projectile_on, &left_handed_projectile_on);
	
	fscanf(input, "%f %f %f %f %f %f %f %f %f %f %f %f\n",
		&projectile_pos[0]->x, &projectile_pos[0]->y, &projectile_pos[0]->z,
		&projectile_rot[0]->x, &projectile_rot[0]->y, &projectile_rot[0]->z,
		&projectile_pos[1]->x, &projectile_pos[1]->y, &projectile_pos[1]->z,
		&projectile_rot[1]->x, &projectile_rot[1]->y, &projectile_rot[1]->z);

	fscanf(input, "%d %d %d %d %d %d\n", &player_health, &highlighted_item, &near_save, &idle_time, &equip_recent, &human_recent);

	for (int i=0; i<MAX_BOTS; i++)
	{
		fscanf(input, "%f %f %f %f %f %f %f %f %f %f %f %f\n", &bot_pos[i]->x, &bot_pos[i]->y, &bot_pos[i]->z,
			&bot_rot[i]->x, &bot_rot[i]->y, &bot_rot[i]->z, &bot_primary_color[i]->x, &bot_primary_color[i]->y, &bot_primary_color[i]->z,
			&bot_secondary_color[i]->x, &bot_secondary_color[i]->y, &bot_secondary_color[i]->z);

		fscanf(input, "%d %d %d %f %d %d\n", &bot_sex[i], &bot_weapon[i], &bot_action[i], &bot_timer[i], &bot_health[i], &bot_sighted[i]);
	}

	for (int i=0; i<MAX_PARTICLES; i++)
	{
		particle_size[i] = 0.0f; // don't save particles!
	}

	for (int i=0; i<MAX_BOXES; i++)
	{
		fscanf(input, "%f %f %f %f %f %f %f %f %f\n", &box_pos[i]->x, &box_pos[i]->y, &box_pos[i]->z,
			&box_size[i]->x, &box_size[i]->y, &box_size[i]->z, &box_color[i]->x, &box_color[i]->y, &box_color[i]->z);
	}

	for (int i=0; i<MAX_ITEMS; i++)
	{
		fscanf(input, "%f %f %f %d\n", &item_pos[i]->x, &item_pos[i]->y, &item_pos[i]->z, &item_type[i]);
	}

	for (int i=0; i<MAX_WALLS; i++)
	{
		fscanf(input, "%f %f %f %f %f %f\n", &x_wall[i]->x, &x_wall[i]->y, &x_wall[i]->z,
			&x_wall_color[i]->x, &x_wall_color[i]->y, &x_wall_color[i]->z);
	}

	for (int i=0; i<MAX_WALLS; i++)
	{
		fscanf(input, "%f %f %f %f %f %f\n", &z_wall[i]->x, &z_wall[i]->y, &z_wall[i]->z,
			&z_wall_color[i]->x, &z_wall_color[i]->y, &z_wall_color[i]->z);
	}

	for (int i=0; i<MAX_MAP_Z; i++)
	{
		for (int j=0; j<MAX_MAP_X; j++)
		{
			fscanf(input, "%c", &map_tile[j][i]);
		}

		fscanf(input, "\n");
	}

	for (int i=0; i<MAX_MAP_Z; i++)
	{
		for (int j=0; j<MAX_MAP_X; j++)
		{
			fscanf(input, "%d ", &map_bounds[j][i]);
		}

		fscanf(input, "\n");
	}

	fscanf(input, "%lu %lu %d %d %d\n", &start_time, &level_time, &bots_killed, &player_deaths, &story_progression);

	fclose(input);

	return 1;
};


void DrawPersonalWeapons(int right_attachment, int left_attachment, float right_angle, float left_angle)
{
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

	glTranslatef(1.0f, 0.0f, -1.0f);

	if (right_attachment == 1) glTranslatef(0.25f, 0.0f, 0.0f);

	glRotatef(45.0f, 1.0f, 0.0f, 0.0f);

	if (right_attachment == 1) glRotatef(-15.0f, 0.0f, 0.0f, 1.0f);

	glRotatef(-right_angle * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
	
	if (right_attachment == 1)
	{
		glTranslatef(0.0f, -0.95f, 0.0f);
		glColor3f(0.75f, 0.75f, 0.75f);
		DrawComponent(hammer_point, hammer_indice, 26);
		glTranslatef(0.0f, 0.95f, 0.0f);
	}
	else if (right_attachment == 2)
	{
		glTranslatef(0.0f, -0.95f, 0.0f);
		glColor3f(0.75f, 0.75f, 0.75f);
		DrawComponent(scythe_point, scythe_indice, 30);
		glTranslatef(0.0f, 0.95f, 0.0f);
	}
	else if (right_attachment == 3)
	{
		glTranslatef(0.0f, -0.95f, 0.0f);
		glColor3f(0.75f, 0.75f, 0.75f);
		DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
		glTranslatef(0.0f, 0.95f, 0.0f);
	}

	glRotatef(right_angle * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);

	if (right_attachment == 1) glRotatef(15.0f, 0.0f, 0.0f, 1.0f);

	glRotatef(-45.0f, 1.0f, 0.0f, 0.0f);

	if (right_attachment == 1) glTranslatef(-0.25f, 0.0f, 0.0f);

	glTranslatef(-2.0f, 0.0f, 0.0f);
	glRotatef(45.0f, 1.0f, 0.0f, 0.0f);

	glRotatef(-left_angle * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
	
	if (left_attachment == 2)
	{
		glTranslatef(0.0f, -0.95f, 0.0f);
		glColor3f(0.75f, 0.75f, 0.75f);
		DrawComponent(scythe_point, scythe_indice, 30);
		glTranslatef(0.0f, 0.95f, 0.0f);
	}
	else if (left_attachment == 3)
	{
		glTranslatef(0.0f, -0.95f, 0.0f);
		glColor3f(0.75f, 0.75f, 0.75f);
		DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
		glTranslatef(0.0f, 0.95f, 0.0f);
	}

	glRotatef(left_angle * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);

	glRotatef(-45.0f, 1.0f, 0.0f, 0.0f);
	glTranslatef(1.0f, 0.0f, 1.0f);

	return;
};

// still bounds below y = 0, but doesn't get drawn
void DrawBox(float sx, float sy, float sz, float *c)
{
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BOX]); // REPLACE WITH STANDARD BOX TEXTURE!!!
	
	glColor3f(c[0], c[1], c[2]);

	glBegin(GL_QUADS);

	glNormal3f(1.0f, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(sx, sy, sz);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(sx, 0.0f, sz);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(sx, 0.0f, -sz);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(sx, sy, -sz);

	glNormal3f(-1.0f, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-sx, sy, -sz);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-sx, 0.0f, -sz);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-sx, 0.0f, sz);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-sx, sy, sz);

	glNormal3f(0.0f, 0.0f, 1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-sx, sy, sz);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-sx, 0.0f, sz);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(sx, 0.0f, sz);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(sx, sy, sz);

	glNormal3f(0.0f, 0.0f, -1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(sx, sy, -sz);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(sx, 0.0f, -sz);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-sx, 0.0f, -sz);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-sx, sy, -sz);

	glNormal3f(0.0f, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-sx, sy, sz);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-sx, sy, -sz);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(sx, sy, -sz);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(sx, sy, sz);

	glNormal3f(0.0f, -1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-sx, 0.0f, -sz);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-sx, 0.0f, sz);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(sx, 0.0f, sz);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(sx, 0.0f, -sz);

	
	glEnd();

	return;
};

void RequestParticles(float px, float py, float pz, int count)
{
	int total = 0;

	for (int i=0; i<MAX_PARTICLES; i++)
	{
		if (particle_size[i] <= 0.0f)
		{
			particle_pos[i]->x = px;
			particle_pos[i]->y = py;
			particle_pos[i]->z = pz;

			particle_vel[i]->x = ((float)(rand() % 200) / 1000.0f) - 0.1f;
			particle_vel[i]->y = ((float)(rand() % 100) / 300.0f);
			particle_vel[i]->z = ((float)(rand() % 200) / 1000.0f) - 0.1f;

			particle_size[i] = 0.2f;
		
			total++;

			if (total >= count) i = MAX_PARTICLES + 1; // exit loop
		}
	}

	return;
};

void CheckMeleeAttack(int hand)
{
	float min_dist = 99999.0f;
	int min_index = -1;
	float temp_dist;

	for (int i=0; i<MAX_BOTS; i++) // check 3 ft in front of player, in 3 ft radius
	{
		if (bot_health[i] > 0)
		{
			temp_dist = sqrt(pow((camera_pos->x - 3.0f * sin(camera_rot->y)) - bot_pos[i]->x, 2.0f) +
				pow(camera_pos->y - bot_pos[i]->y, 2.0f) +
				pow((camera_pos->z - 3.0f * cos(camera_rot->y)) - bot_pos[i]->z, 2.0f));
	
			if (temp_dist < min_dist && temp_dist <= 3.0f)
			{
				min_dist = temp_dist;
	
				min_index = i;
			}
		}
	}

	if (min_index != -1)
	{
		if (hand == 1) // right
		{
			right_handed_ammo -= 1;

			if (right_handed_weapon == 1) right_handed_ammo = 99; // always

			if (right_handed_ammo <= 0)
			{
				right_handed_weapon = 0;
			}

			if (right_handed_weapon == 1)
			{
				if (bot_sighted[min_index] == 0) bot_health[min_index] -= 30 + (int)(rand() % 20);
				else bot_health[min_index] -= 20 + (int)(rand() % 10);
			}
			else if (right_handed_weapon == 2)
			{
				if (bot_sighted[min_index] == 0) bot_health[min_index] -= 40 + (int)(rand() % 20);
				else bot_health[min_index] -= 30 + (int)(rand() % 10);
			}
		}
		else if (hand == 2) // left
		{
			left_handed_ammo -= 1;

			if (left_handed_ammo <= 0)
			{
				left_handed_weapon = 0;
			}

			if (left_handed_weapon == 2)
			{
				if (bot_sighted[min_index] == 0) bot_health[min_index] -= 40 + (int)(rand() % 20);
				else bot_health[min_index] -= 30 + (int)(rand() % 10);
			}
		}

		float quick_volume_number_break = (float)((sqrt(pow(bot_pos[min_index]->x - camera_pos->x, 2.0f) + 
				pow(bot_pos[min_index]->z - camera_pos->z, 2.0f))) * -0.01f + 0.75f);

		if (quick_volume_number_break > 0.75f) quick_volume_number_break = 0.75f;
		if (quick_volume_number_break < 0.25f) quick_volume_number_break = 0.25f;

		sprintf(command, "play -q -v %f Sounds/Break.wav &", quick_volume_number_break);

		// sound effect
		system(command);

		HumanEvent(5, "Break them to pieces!", 0, 0);

		if (bot_sighted[min_index] == 0)
		{
			float quick_volume_number = (float)((sqrt(pow(bot_pos[min_index]->x - camera_pos->x, 2.0f) + 
				pow(bot_pos[min_index]->z - camera_pos->z, 2.0f))) * -0.019f + 0.95f);

			if (quick_volume_number > 0.95f) quick_volume_number = 0.95f;
			if (quick_volume_number < 0.0f) quick_volume_number = 0.0f;

			sprintf(command, "play -q -v %f Sounds/DoesNotCompute.wav &", quick_volume_number);

			// sound effect
			system(command);
		}

		bot_sighted[min_index] = 2;

		RequestParticles(bot_pos[min_index]->x, bot_pos[min_index]->y + 4.0f, bot_pos[min_index]->z, 20);

		if (bot_health[min_index] <= 0)
		{
			// randomly put item on ground?

			bots_killed++;

			// sound effect
			system("play -q -v 1.0 Sounds/Explosion.wav &");

			HumanEvent(9, "Destroyed!", 0, 0);

			RequestParticles(bot_pos[min_index]->x, bot_pos[min_index]->y + 4.0f, bot_pos[min_index]->z, 100);
		}
	}
	else
	{
		// sound effect
		system("play -q -v 0.90 Sounds/Swipe.wav &");
	}

	return;
};

void CheckRangedAttacks()
{
	float min_dist, temp_dist;
	int min_index;

	if (right_handed_projectile_on == 1)
	{
		min_dist = 99999.0f;
		min_index = -1;

		for (int i=0; i<MAX_BOTS; i++) // check projectile, in 2 ft radius, 8 ft high cylinder
		{
			if (bot_health[i] > 0)
			{
				temp_dist = sqrt(pow(projectile_pos[0]->x - bot_pos[i]->x, 2.0f) +
					pow(projectile_pos[0]->z - bot_pos[i]->z, 2.0f));
	
				if (temp_dist < min_dist && temp_dist <= 2.0f && fabs(projectile_pos[0]->y - bot_pos[i]->y - 4.0f) <= 4.0f)
				{
					min_dist = temp_dist;
		
					min_index = i;
				}
			}
		}

		for (int i=0; i<MAX_BOXES; i++)
		{
			if (box_size[i]->x > 0 && box_size[i]->y > 0 && box_size[i]->z > 0)
			{
				if (fabs(projectile_pos[0]->x - box_pos[i]->x) <= box_size[i]->x + 1.0f &&
					fabs(projectile_pos[0]->y - box_pos[i]->y) <= box_size[i]->y &&
					fabs(projectile_pos[0]->z - box_pos[i]->z) <= box_size[i]->z + 1.0f) // bounds with boxes
				{
					min_index = -1;
	
					right_handed_projectile_on = 0;
				}
			}
		}

		if (min_index != -1)
		{
			right_handed_projectile_on = 0;

			bot_health[min_index] -= 20 + (int)(rand() % 10);

			float quick_volume_number_break = (float)((sqrt(pow(bot_pos[min_index]->x - camera_pos->x, 2.0f) + 
				pow(bot_pos[min_index]->z - camera_pos->z, 2.0f))) * -0.01f + 0.75f);

			if (quick_volume_number_break > 0.75f) quick_volume_number_break = 0.75f;
			if (quick_volume_number_break < 0.25f) quick_volume_number_break = 0.25f;

			sprintf(command, "play -q -v %f Sounds/Break.wav &", quick_volume_number_break);

			// sound effect
			system(command);

			HumanEvent(3, "Nice shot!", 0, 0);

			if (bot_sighted[min_index] == 0)
			{
				float quick_volume_number = (float)((sqrt(pow(bot_pos[min_index]->x - camera_pos->x, 2.0f) + 
					pow(bot_pos[min_index]->z - camera_pos->z, 2.0f))) * -0.019f + 0.95f);

				if (quick_volume_number > 0.95f) quick_volume_number = 0.95f;
				if (quick_volume_number < 0.0f) quick_volume_number = 0.0f;

				sprintf(command, "play -q -v %f Sounds/DoesNotCompute.wav &", quick_volume_number);
	
				// sound effect
				system(command);
			}

			bot_sighted[min_index] = 2;
	
			RequestParticles(bot_pos[min_index]->x, bot_pos[min_index]->y + 4.0f, bot_pos[min_index]->z, 20);
		
			if (bot_health[min_index] <= 0)
			{
				// randomly put item on ground?

				bots_killed++;

				// sound effect
				system("play -q -v 1.0 Sounds/Explosion.wav &");

				HumanEvent(9, "Destroyed!", 0, 0);

				RequestParticles(bot_pos[min_index]->x, bot_pos[min_index]->y + 4.0f, bot_pos[min_index]->z, 100);
			}
		}
		else
		{
			projectile_pos[0]->x -= 1.5f * sin(projectile_rot[0]->y) * cos(projectile_rot[0]->x);
			projectile_pos[0]->z -= 1.5f * cos(projectile_rot[0]->y) * cos(projectile_rot[0]->x);
			projectile_pos[0]->y += 1.5f * sin(projectile_rot[0]->x);

			if (sqrt(pow(projectile_pos[0]->x - camera_pos->x, 2.0f) +
				pow(projectile_pos[0]->z - camera_pos->z, 2.0f)) > 100.0f) // out of range
			{
				right_handed_projectile_on = 0;
			}
		}
	}

	if (left_handed_projectile_on == 1)
	{
		min_dist = 99999.0f;
		min_index = -1;

		for (int i=0; i<MAX_BOTS; i++) // check projectile, in 2 ft radius, 8 ft high cylinder
		{
			if (bot_health[i] > 0)
			{
				temp_dist = sqrt(pow(projectile_pos[1]->x - bot_pos[i]->x, 2.0f) +
					pow(projectile_pos[1]->z - bot_pos[i]->z, 2.0f));
	
				if (temp_dist < min_dist && temp_dist <= 2.0f && fabs(projectile_pos[1]->y - bot_pos[i]->y - 4.0f) <= 4.0f)
				{
					min_dist = temp_dist;
		
					min_index = i;
				}
			}
		}

		for (int i=0; i<MAX_BOXES; i++)
		{
			if (box_size[i]->x > 0 && box_size[i]->y > 0 && box_size[i]->z > 0)
			{
				if (fabs(projectile_pos[1]->x - box_pos[i]->x) <= box_size[i]->x + 1.0f &&
					fabs(projectile_pos[1]->y - box_pos[i]->y) <= box_size[i]->y &&
					fabs(projectile_pos[1]->z - box_pos[i]->z) <= box_size[i]->z + 1.0f) // bounds with boxes
				{
					min_index = -1;
	
					left_handed_projectile_on = 0;
				}
			}
		}
	
		if (min_index != -1)
		{
			left_handed_projectile_on = 0;

			bot_health[min_index] -= 20 + (int)(rand() % 10);

			float quick_volume_number_break = (float)((sqrt(pow(bot_pos[min_index]->x - camera_pos->x, 2.0f) + 
				pow(bot_pos[min_index]->z - camera_pos->z, 2.0f))) * -0.01f + 0.75f);

			if (quick_volume_number_break > 0.75f) quick_volume_number_break = 0.75f;
			if (quick_volume_number_break < 0.25f) quick_volume_number_break = 0.25f;

			sprintf(command, "play -q -v %f Sounds/Break.wav &", quick_volume_number_break);

			// sound effect
			system(command);
			
			HumanEvent(3, "Nice shot!", 0, 0);

			if (bot_sighted[min_index] == 0)
			{
				float quick_volume_number = (float)((sqrt(pow(bot_pos[min_index]->x - camera_pos->x, 2.0f) + 
					pow(bot_pos[min_index]->z - camera_pos->z, 2.0f))) * -0.019f + 0.95f);

				if (quick_volume_number > 0.95f) quick_volume_number = 0.95f;
				if (quick_volume_number < 0.0f) quick_volume_number = 0.0f;

				sprintf(command, "play -q -v %f Sounds/DoesNotCompute.wav &", quick_volume_number);
	
				// sound effect
				system(command);
			}

			bot_sighted[min_index] = 2;

			RequestParticles(bot_pos[min_index]->x, bot_pos[min_index]->y + 4.0f, bot_pos[min_index]->z, 20);
		
			if (bot_health[min_index] <= 0)
			{
				// randomly put item on ground?

				bots_killed++;

				// sound effect
				system("play -q -v 1.0 Sounds/Explosion.wav &");

				HumanEvent(9, "Destroyed!", 0, 0);

				RequestParticles(bot_pos[min_index]->x, bot_pos[min_index]->y + 4.0f, bot_pos[min_index]->z, 100);
			}
		}
		else
		{
			projectile_pos[1]->x -= 1.5f * sin(projectile_rot[1]->y) * cos(projectile_rot[1]->x);
			projectile_pos[1]->z -= 1.5f * cos(projectile_rot[1]->y) * cos(projectile_rot[1]->x);
			projectile_pos[1]->y += 1.5f * sin(projectile_rot[1]->x);

			if (sqrt(pow(projectile_pos[1]->x - camera_pos->x, 2.0f) +
				pow(projectile_pos[1]->z - camera_pos->z, 2.0f)) > 100.0f) // out of range
			{
				left_handed_projectile_on = 0;
			}
		}
	}
	
	return;
};
		

// Any picture in the .bmp format, 24 bit, should be good to go now.
bool LoadBitmap(const char *filename, GLuint &tex)
{
	FILE *bitmap;

	unsigned long int width, height;
	
	unsigned char *bits, *final;
	unsigned char header[54], temp;

	bitmap = fopen(filename, "rb");
	if (!bitmap) return false;

	fread(&header, 54, 1, bitmap);

	// If it's not a Bitmap, exit!
	if (256 * header[1] + header[0] != 19778)
	{
		fclose(bitmap);

		return false;
	}

	width = 256 * header[19] + header[18];
	height = 256 * header[23] + header[22];

	// Once the size is found, malloc() that much to 'bits' and read.
	bits = (unsigned char *) malloc(width*height*3);

	fread(bits, width*height*3, 1, bitmap);

	fclose(bitmap);

	// Flip the BGR pixels to RGB.
	for (int i=0; i<width*height*3; i+=3)
	{
		temp = bits[i];
		bits[i] = bits[i+2];
		bits[i+2] = temp;
	}

	final = (unsigned char *) malloc(width*height*4);

	unsigned long int count = 0;

	// Put in Alpha values.
	for (int i=0; i<width*height*3; i+=3)
	{
		final[count] = bits[i];
		count++;
		final[count] = bits[i+1];
		count++;
		final[count] = bits[i+2];
		count++;
		
		if (bits[i] == 0 && bits[i+1] == 0 && bits[i+2] == 0)
		{
			final[count] = 0;
			count++;
		}
		else
		{
			final[count] = 255;
			count++;
		}
	}
	
	// Remember each malloc() needs a free().
	free(bits);

	glGenTextures(1, &tex);
	glBindTexture(GL_TEXTURE_2D, tex);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, final);
	
	// Remember each malloc() needs a free().
	free(final);

	return true;
};

void OpenGLSetupFunction(int width, int height)
{
	glutWarpPointer(WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);


	for (int i=0; i<256; i++) 
	{
		keyboard[i] = false;
		special_keyboard[i] = false;
	}
/*
	for (int i=0; i<32; i++) joystick_button[i] = 0;
	joystick_axis->x = 0;
	joystick_axis->y = 0;
	joystick_axis->z = 0;

	// If there is a joystick...
	if (glutDeviceGet(GLUT_HAS_JOYSTICK)) 
	{
		printf("Joystick Detected!\n");

		joystick_enabled = true;
	}
*/

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (float)(width)/(float)(height), 0.01f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity(); 
	glEnable(GL_TEXTURE_2D);  
	glShadeModel(GL_SMOOTH);
	glClearColor(0.1f, 0.1f, 0.1f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);					
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	
	glAlphaFunc(GL_GREATER, 0.9f);									
	glEnable(GL_ALPHA_TEST);

	//glDisable(GL_ALPHA_TEST);
	//glEnable(GL_BLEND);
	//glBlendFunc(GL_SRC_ALPHA,GL_ONE);

	// more stuff for lighting                                  
	glFrontFace(GL_CCW);
	glEnable(GL_NORMALIZE);     
	glCullFace(GL_FRONT);                   

	// allows colors to be still lit up      
	glEnable(GL_COLOR_MATERIAL);

	// lighting    
	GLfloat ambient[] = { 0.3f, 0.3f, 0.3f, 1.0f };  
	GLfloat diffuse[] = { 0.7f, 0.7f, 0.7f, 0.7f }; 
	GLfloat light_pos[] = { 0.0f, 0.0f, 0.0f, 1.0f };
	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);                          
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse); 
	glLightfv(GL_LIGHT1, GL_POSITION, light_pos);
	glEnable(GL_LIGHT1); 

	// fog
	GLfloat fogColor[4]= {0.01f, 0.01f, 0.01f, 1.0f};

	glFogi(GL_FOG_MODE, GL_LINEAR);
	glFogfv(GL_FOG_COLOR, fogColor);
	glFogf(GL_FOG_DENSITY, 0.35f);
	glHint(GL_FOG_HINT, GL_DONT_CARE);
	glFogf(GL_FOG_START, 0.0f);
	glFogf(GL_FOG_END, 5000.0f);
	glEnable(GL_FOG);
 
	LoadBitmap("Textures/Blank.bmp", texture[TEXTURE_BLANK]);
	LoadBitmap("Textures/Transparent.bmp", texture[TEXTURE_TRANSPARENT]);
	LoadBitmap("Textures/BlueEyesMediumSkin.bmp", texture[TEXTURE_HUMAN_EYES]);
	LoadBitmap("Textures/MediumSkin.bmp", texture[TEXTURE_HUMAN_SKIN]);
	LoadBitmap("Textures/DarkBrownHair.bmp", texture[TEXTURE_HUMAN_HAIR]);
	LoadBitmap("Textures/NavyBlue.bmp", texture[TEXTURE_HUMAN_SHIRT]);
	LoadBitmap("Textures/MediumGrey.bmp", texture[TEXTURE_HUMAN_BOOTS]);
	LoadBitmap("Textures/Box.bmp", texture[TEXTURE_BOX]);
	LoadBitmap("Textures/Floor.bmp", texture[TEXTURE_FLOOR]);
	LoadBitmap("Textures/Wall.bmp", texture[TEXTURE_WALL]);
	LoadBitmap("Textures/Ceiling.bmp", texture[TEXTURE_CEILING]);
	LoadBitmap("Textures/Hurt.bmp", texture[TEXTURE_HURT]);
	
	// INITIALIZE HERE!!!

	Reset();

	CreateLevel("Level1.txt");

	story_progression = 0;

	right_handed_weapon = 0;
	right_handed_ammo = 0;
	left_handed_weapon = 0;
	left_handed_ammo = 0;

	// this part is permanent
	if (!Save()) printf("Error while saving!\n");

	return;
};

void OpenGLDisplayFunction()
{
	return;
};

float title_flash = 0.0f;

void OpenGLIdleFunction()
{
	title_flash += 0.25f;
	if (title_flash > 6.28f) title_flash -= 6.28f;

	bool whole_second = false;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	frames_per_second_counter++;

	if (frames_per_second_timer != time(0))
	{
		frames_per_second = frames_per_second_counter;
		frames_per_second_counter = 0;
		frames_per_second_timer = time(0);

		whole_second = true;
	}

	if (whole_second == true && time(0) % 7 == 0 && abs(time(0) - start_time) > 10 && story_progression >= 1 && story_progression <= 10)
	{
		// sound effect
		system("play -q -v 0.5 Sounds/Loop2.wav &");
	}

	if (keyboard[27]) exit(1);

	idle_time++;

	if (idle_time < 0 && idle_time >= -60 * 60) idle_time = 0;

	// elizabeth tutorial stuff
	if (story_progression == 1)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(0, "Use the controller to interact with the level.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(4, "Jump over boxes to continue.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(5, "Go through the teleport at the end of the level!", 0, 1);
		}
	}
	else if (story_progression == 2)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(9, "This time we will attack something!", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(10, "But they could hurt you, so watch out.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(5, "Destroy that robot, and then teleport!", 0, 1);
		}
	}
	else if (story_progression == 3)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(4, "That is a scythe in your right hand, spikes in your left.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(6, "They only have a few uses each though.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(5, "Destroy the next robots, and then off we go!", 0, 1);
		}
	}
	else if (story_progression == 4)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(4, "Grab the hammer on the ground. You will need it.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(6, "Ahead is a save point. Save the game, just in case...", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(3, "Off you go, good luck!", 0, 1);
		}
	}
	else if (story_progression == 5)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			if (player_health < 100) HumanEvent(10, "Looks like you were hurt!", 0, 1);
			else HumanEvent(7, "Amazingly, you weren't even hurt!", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(4, "There is a health pack ahead, use it.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(5, "Ahead are various weapons, pick which you would like to use.", 0, 1);
		}
	}
	else if (story_progression == 6)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(0, "There is a large room ahead.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(5, "Beat up those robots! Use the boxes to your advantage.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(7, "There will be difficulties, but I'm sure you can handle it.", 0, 1);
		}
	}
	else if (story_progression == 7)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(6, "There is a choice ahead.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(2, "Either use the jumps, or face the robots.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(3, "Your decision, you can do it!", 0, 1);
		}
	}
	else if (story_progression == 8)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(0, "This level is a maze.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(6, "Remember all of the tricks you've learned.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(8, "I'll be here with you the whole time :)", 0, 1);
		}
	}
	else if (story_progression == 9)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(4, "This is just a big, fun level.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(5, "Just go out there and destroy robots.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(10, "And try not to die!", 0, 1);
		}
	}
	else if (story_progression == 10)
	{
		if (abs(time(0) - level_time) >= 3 && abs(time(0) - level_time) < 4 && whole_second == true)
		{
			HumanEvent(5, "Get stocked up now, because this will be a tough one.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 6 && abs(time(0) - level_time) < 7 && whole_second == true)
		{
			HumanEvent(10, "Actually there is no way out besides destroying them all.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 9 && abs(time(0) - level_time) < 10 && whole_second == true)
		{
			HumanEvent(8, "Or dying, of course. :)", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 12 && abs(time(0) - level_time) < 13 && whole_second == true)
		{
			HumanEvent(1, "You only get one life here, and then the game ends.", 0, 1);
		}
		else if (abs(time(0) - level_time) >= 15 && abs(time(0) - level_time) < 18 && whole_second == true)
		{
			HumanEvent(3, "Have fun out there. This is it!", 0, 1);
		}
	}

// elizabeth code starts here

	human_recent--;
	if (human_recent == 0 && story_progression != 11)
	{
		HumanEvent(0, "I'm ready for anything...", 0, 0);
	}
	if (human_recent < 0) human_recent = 0;

	MoveTransitionRotation(human_rotations, human_prev_rot, human_next_rot, human_transition_scale);

	glTranslatef(-0.0225f, -0.02f, -0.05f);
	//glRotatef(-15.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(20.0f, 0.0f, 1.0f, 0.0f);
	glScalef(0.002f, 0.00175f, 0.002f);
	DrawFemaleModel(0, human_rotations, 1, 1, 2, 0, 0, texture[TEXTURE_HUMAN_EYES], texture[TEXTURE_HUMAN_SKIN], texture[TEXTURE_HUMAN_HAIR],
		texture[TEXTURE_HUMAN_SHIRT], texture[TEXTURE_HUMAN_SHIRT], texture[TEXTURE_HUMAN_SHIRT],
		texture[TEXTURE_HUMAN_SHIRT], texture[TEXTURE_HUMAN_SKIN], texture[TEXTURE_HUMAN_BOOTS]);
	glScalef(1.0f / 0.002f, 1.0f / 0.00175f, 1.0f / 0.002f);
	glRotatef(-20.0f, 0.0f, 1.0f, 0.0f);
	//glRotatef(15.0f, 1.0f, 0.0f, 0.0f);
	glTranslatef(0.0225f, 0.02f, 0.05f);

	human_transition_scale += 0.05f;
	if (human_transition_scale > 1.0f) human_transition_scale = 1.0f;

// elizabeth code ends here
	
	glDisable(GL_LIGHTING);

	// Blank texture.
	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glLineWidth(3);

	glColor3f(1,1,1);

	glPushMatrix();
	glTranslatef(-0.0375f, -0.04f, -0.1f);
	glScalef(0.00002f, 0.00002f, 0.00002f);
	for (int i=0; i<512; i++)
	{
		glutStrokeCharacter(GLUT_STROKE_ROMAN, human_subtitle[i]);
	}
	glPopMatrix();

/*
	// GET RID OF THIS IN FINAL PRODUCTION!!!
	glColor3f(1,1,1);
	glRasterPos3f(-0.47f, 0.33f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'F');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((frames_per_second % 10000) - (frames_per_second % 1000)) / 1000 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((frames_per_second % 1000) - (frames_per_second % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)(((frames_per_second % 100) - (frames_per_second % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, (char)((frames_per_second % 10) + 48));
*/
	glColor3f(1,1,1);

	if (story_progression == 0)
	{
		glColor3f(((sin(title_flash) + 1.0f) / 2.0f) * 0.5f + 0.5f,
			((sin(title_flash) + 1.0f) / 2.0f) * 0.5f + 0.5f,
			((sin(title_flash) + 1.0f) / 2.0f) * 0.5f + 0.5f);

		glPushMatrix();
		glTranslatef(-0.0275f, 0.0125f, -0.1f);
		glScalef(0.0001f, 0.0001f, 0.0001f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0275f, 0.0125f, -0.1f);
		glScalef(0.0001f, 0.0001f, 0.0001f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glPopMatrix();

		glColor3f(1,1,1);

		glPushMatrix();
		glTranslatef(-0.0325f, -0.0125f, -0.1f);
		glScalef(0.00007f, 0.00007f, 0.00007f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'b');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0275f, -0.0225f, -0.1f);
		glScalef(0.00007f, 0.00007f, 0.00007f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'b');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '!');
		glPopMatrix();

		completion_delay--;
		if (completion_delay < 0) completion_delay = 0;

		if ((keyboard[32] ||
			keyboard[13] ||
			keyboard['q'] ||
			keyboard['e'] ||
			keyboard['f'] ||
			keyboard['h']) && completion_delay == 0) // some kind of button
		{
			if (user_input_story_progression != 0)
			{
				story_progression = user_input_story_progression;
				
				char level_filename[256];

				for (int i=0; i<256; i++) level_filename[i] = 0;

				sprintf(level_filename, "Level%d.txt", story_progression);

				Reset();
				CreateLevel(level_filename);
			}
			else
			{
				story_progression = 1;
			}

			glutWarpPointer(WINDOW_WIDTH/2, WINDOW_HEIGHT/2);
		
			right_handed_weapon = 0;
			right_handed_ammo = 0;
	
			left_handed_weapon = 0;
			left_handed_ammo = 0;

			player_health = 100;

			bots_killed = 0;
			player_deaths = 0;

			idle_time = 0;

			// sound effect
			system("play -q -v 0.65 Sounds/Intro.wav &");

			HumanEvent(1, "Welcome to Linearity! My name is Elizabeth.", 0, 1);

			start_time = time(0);
			level_time = time(0);

			if (!Save()) printf("Error while saving!\n");
		}

		if (whole_second == true)
		{
			if ((time(0) / 5) % 5 == 0)
			{
				if (time(0) % 2 == 0)
				{
					HumanEvent(0, "Hello there! Please play my game!", 0, 1);
				}
				else
				{
					HumanEvent(1, "Hello there! Please play my game!", 0, 1);
				}
			}
			else if ((time(0) / 5) % 5 == 1)
			{
				if (time(0) % 2 == 0)
				{
					HumanEvent(0, "You get to play the game with me. :)", 0, 1);
				}
				else
				{
					HumanEvent(2, "You get to play the game with me. :)", 0, 1);
				}
			}
			else if ((time(0) / 5) % 5 == 2)
			{
				if (time(0) % 2 == 0)
				{
					HumanEvent(0, "Prove that you can win the game.", 0, 1);
				}
				else
				{
					HumanEvent(3, "Prove that you can win the game.", 0, 1);
				}
			}
			else if ((time(0) / 5) % 5 == 3)
			{
				if (time(0) % 2 == 0)
				{
					HumanEvent(4, "You there! Play this game!", 0, 1);
				}
				else
				{
					HumanEvent(5, "You there! Play this game!", 0, 1);
				}
			}
			else if ((time(0) / 5) % 5 == 4)
			{
				if (time(0) % 2 == 0)
				{
					HumanEvent(8, "I am the star of this game!", 0, 1);
				}
				else
				{
					HumanEvent(9, "I am the star of this game!", 0, 1);
				}
			}
		}

		glutSwapBuffers();

		return;
	}
	else if (story_progression == 11) // end
	{
		completion_delay--;
		if (completion_delay < 0) completion_delay = 0;

		if (((keyboard[32] ||
			keyboard[13] ||
			keyboard['q'] ||
			keyboard['e'] ||
			keyboard['f'] ||
			keyboard['h']) || idle_time > 60*60) && completion_delay == 0) // some kind of button
		{
			story_progression = 0;

			completion_delay = 120;

			right_handed_weapon = 0;
			right_handed_ammo = 0;
	
			left_handed_weapon = 0;
			left_handed_ammo = 0;

			player_health = 100;
		
			Reset();
			CreateLevel("Level1.txt");
			if (!Save()) printf("Error while saving!\n");
		}

		glColor3f(1,1,1);

		glPushMatrix();
		glTranslatef(-0.0275f, 0.0125f, -0.1f);
		glScalef(0.0001f, 0.0001f, 0.0001f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0275f, 0.0125f, -0.1f);
		glScalef(0.0001f, 0.0001f, 0.0001f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '_');
		glPopMatrix();

		glColor3f(1,1,1);

		glPushMatrix();
		glTranslatef(-0.0325f, -0.0075f, -0.1f);
		glScalef(0.00003f, 0.00003f, 0.00003f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'b');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '-');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((bots_killed % 1000) - (bots_killed % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((bots_killed % 100) - (bots_killed % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((bots_killed % 10) + 48));
		glPopMatrix();

		int p_minutes = abs(level_time - start_time) / 60;
		int p_seconds = abs(level_time - start_time) % 60;	

		glPushMatrix();
		glTranslatef(-0.0325f, -0.0125f, -0.1f);
		glScalef(0.00003f, 0.00003f, 0.00003f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '-');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((p_minutes % 100) - (p_minutes % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((p_minutes % 10) + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((p_seconds % 100) - (p_seconds % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((p_seconds % 10) + 48));
		glPopMatrix();

		glColor3f(((sin(title_flash) + 1.0f) / 2.0f) * 0.5f + 0.5f,
			((sin(title_flash) + 1.0f) / 2.0f) * 0.5f + 0.5f,
			((sin(title_flash) + 1.0f) / 2.0f) * 0.5f + 0.5f);

		glPushMatrix();
		glTranslatef(-0.0225f, -0.02f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'b');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0205f, -0.025f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'Q');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();

		glutSwapBuffers();

		return;
	}

	if (keyboard['r'])
	{
		if (reset_held >= 0)
		{
			reset_held++;
	
			if (reset_held % 15 == 0)
			{
				// sound effect
				system("play -q -v 0.65 Sounds/Energy.wav &");
			}

			if (reset_held > 120) // shorter than normal timers
			{
				Reset();
			
				CreateLevel("Level1.txt");

				story_progression = 0;

				right_handed_weapon = 0;
				right_handed_ammo = 0;
				left_handed_weapon = 0;
				left_handed_ammo = 0;
				
				if (!Save()) printf("Error while saving!\n");
	
				reset_held = -1;
				idle_time = 0;
			}
		}
	}
	else reset_held = 0;

	if (reset_held > 0)
	{
		glColor3f((sin((float)reset_held / 2.0f) + 1.0f) / 2.0f * 0.5f + 0.5f,
			(sin((float)reset_held / 2.0f) + 1.0f) / 2.0f * 0.5f + 0.5f,
			(sin((float)reset_held / 2.0f) + 1.0f) / 2.0f * 0.5f + 0.5f);

		glPushMatrix();
		glTranslatef(-0.0425f, -0.0025f, -0.1f);
		glScalef(0.00004f, 0.00004f, 0.00004f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'H');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '-');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((((reset_held * 100 / 120) % 100) - ((reset_held * 100 / 120) % 10)) / 10 + 48));
		//glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((reset_held * 100 / 120) % 10) + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '0');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '%');
		glPopMatrix();

		if (whole_second == true)
		{
			HumanEvent(8, "Oh, so you want to play a new game together?", 0, 0);
		}
	}
	else if (reset_held == 0 && fabs(idle_time) >= 60 * 60)
	{
		//idle_time = 60 * 60;

		glColor3f((sin((float)idle_time / 2.0f) + 1.0f) / 2.0f * 0.5f + 0.5f,
			(sin((float)idle_time / 2.0f) + 1.0f) / 2.0f * 0.5f + 0.5f,
			(sin((float)idle_time / 2.0f) + 1.0f) / 2.0f * 0.5f + 0.5f);

		glPushMatrix();
		glTranslatef(-0.0205f, -0.0125f, -0.1f);
		glScalef(0.00003f, 0.00003f, 0.00003f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'H');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();

		if (idle_time >= 60 * 60)
		{
			if (whole_second == true) HumanEvent(6, "I wonder how long that person will be gone...", 0, 0);
		}

		if (idle_time >= 120 * 60) // it's been two minutes, just reset it.
		{
			Reset();
			
			CreateLevel("Level1.txt");

			story_progression = 0;

			right_handed_weapon = 0;
			right_handed_ammo = 0;
			left_handed_weapon = 0;
			left_handed_ammo = 0;
				
			if (!Save()) printf("Error while saving!\n");
	
			reset_held = -1;
			idle_time = 0;
		}
	}

	glColor3f(1,1,1);

	if (player_health <= 0) // game over, now reset and load
	{
		player_health += 1;
		if (player_health == 0)
		{
			Reset();
			
			if (!Load()) printf("Error while loading!\n");

			// sound effect
			system("play -q -v 0.95 Sounds/Teleport.wav &");

			HumanEvent(7, "But, do not disappoint me this time.", 0, 0);
		}
		
		glPushMatrix();
		glTranslatef(-0.0225f, 0.0125f, -0.1f);
		glScalef(0.00007f, 0.00007f, 0.00007f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'Y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'D');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '!');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0175f, -0.0125f, -0.1f);
		glScalef(0.00005f, 0.00005f, 0.00005f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '.');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '.');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '.');
		glPopMatrix();
		
		glutSwapBuffers();

		return;
	}

	if (right_handed_weapon != 1)
	{
		if (left_handed_weapon != 0)
		{
			glPushMatrix();
			glTranslatef(-0.040f, -0.035f, -0.1f);
			glScalef(0.00005f, 0.00005f, 0.00005f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((left_handed_ammo % 100) - (left_handed_ammo % 10)) / 10 + 48));
			glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((left_handed_ammo % 10) + 48));
			glPopMatrix();
		}
	
		if (right_handed_weapon != 0)
		{
			glPushMatrix();
			glTranslatef(0.035f, -0.035f, -0.1f);
			glScalef(0.00005f, 0.00005f, 0.00005f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((right_handed_ammo % 100) - (right_handed_ammo % 10)) / 10 + 48));
			glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((right_handed_ammo % 10) + 48));
			glPopMatrix();
		}
	}

	glBegin(GL_QUADS);
	glColor3f(1,1,1);
	glVertex3f(-0.03f, -0.0325f, -0.101f);
	glVertex3f(-0.03f, -0.0375f, -0.101f);
	glVertex3f(0.03f, -0.0375f, -0.101f);
	glVertex3f(0.03f, -0.0325f, -0.101f);
	glColor3f(1,0,0);
	glVertex3f(-0.03f * (float)player_health / 100.0f, -0.033f, -0.1f);
	glVertex3f(-0.03f * (float)player_health / 100.0f, -0.0365f, -0.1f);
	glVertex3f(0.03f * (float)player_health / 100.0f, -0.0365f, -0.1f);
	glVertex3f(0.03f * (float)player_health / 100.0f, -0.033f, -0.1f);
	glEnd();

	glColor3f((sin((float)idle_time / 8.0f) + 1.0f) / 2.0f * 0.5f + 0.5f,
		(sin((float)idle_time / 8.0f) + 1.0f) / 2.0f * 0.5f + 0.5f,
		(sin((float)idle_time / 8.0f) + 1.0f) / 2.0f * 0.5f + 0.5f);

	glLineWidth(2);

	glPushMatrix();
	glTranslatef(0.035f, 0.0365f, -0.1f);
	glScalef(0.0000125f, 0.0000125f, 0.0000125f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'H');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'x');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glPopMatrix();

	glLineWidth(3);

	glColor3f(1,1,1);

	// more tutorial stuff
	if (abs(time(0) - level_time) < 5 && story_progression == 1)
	{
		glColor3f(1,1,1);
		glPushMatrix();
		glTranslatef(-0.0135f, -0.0275f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'f');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'k');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0125f, -0.03f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'k');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'k');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glPopMatrix();
	}
	else if (abs(time(0) - level_time) < 15 && story_progression == 1)
	{
		glColor3f(1,1,1);
		glPushMatrix();
		glTranslatef(-0.0135f, -0.0275f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glColor3f(0,1,0);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
		glColor3f(1,1,1);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'j');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
		glPopMatrix();
	}
	else if (abs(time(0) - level_time) < 15 && story_progression == 2)
	{
		glColor3f(1,1,1);
		glPushMatrix();
		glTranslatef(-0.0135f, -0.0275f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'f');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0125f, -0.03f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'k');
		glPopMatrix();
	}
	else if (abs(time(0) - level_time) < 20 && story_progression == 3)
	{
		glColor3f(1,1,1);
		glPushMatrix();
		glTranslatef(-0.0145f, -0.025f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'b');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0135f, -0.0275f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'f');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0125f, -0.03f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'k');
		glPopMatrix();
	}

	if (highlighted_item != -1)
	{
		if (item_type[highlighted_item] < 100) // hammer
		{
			glColor3f(1,1,1);
			glPushMatrix();
			glTranslatef(-0.0135f, -0.0275f, -0.1f);
			glScalef(0.00002f, 0.00002f, 0.00002f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glColor3f(0,0,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'X');
			glColor3f(1,1,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glColor3f(1,0,0);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
			glColor3f(1,1,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
			glPopMatrix();

			glPushMatrix();
			glTranslatef(-0.0125f, -0.03f, -0.1f);
			glScalef(0.00002f, 0.00002f, 0.00002f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'q');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'H');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glPopMatrix();

			if (equip_recent == 0)
			{
				if (whole_second == true) HumanEvent(4, "Hammers are durable and hit hard, but require both hands.", 0, 0);
			}
		}
		else if (item_type[highlighted_item] < 200) // scythe
		{
			glColor3f(1,1,1);
			glPushMatrix();
			glTranslatef(-0.0135f, -0.0275f, -0.1f);
			glScalef(0.00002f, 0.00002f, 0.00002f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glColor3f(0,0,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'X');
			glColor3f(1,1,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glColor3f(1,0,0);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
			glColor3f(1,1,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
			glPopMatrix();

			glPushMatrix();
			glTranslatef(-0.0125f, -0.03f, -0.1f);
			glScalef(0.00002f, 0.00002f, 0.00002f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'q');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glPopMatrix();

			if (equip_recent == 0)
			{
				if (whole_second == true) HumanEvent(4, "Scythes will break, but you can wield them in either hand.", 0, 0);
			}
		}
		else if (item_type[highlighted_item] < 300) // spikes
		{
			glColor3f(1,1,1);
			glPushMatrix();
			glTranslatef(-0.0135f, -0.0275f, -0.1f);
			glScalef(0.00002f, 0.00002f, 0.00002f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glColor3f(0,0,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'X');
			glColor3f(1,1,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glColor3f(1,0,0);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
			glColor3f(1,1,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
			glPopMatrix();

			glPushMatrix();
			glTranslatef(-0.0125f, -0.03f, -0.1f);
			glScalef(0.00002f, 0.00002f, 0.00002f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'q');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'k');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glPopMatrix();

			if (equip_recent == 0)
			{
				if (whole_second == true) HumanEvent(4, "Spikes are ranged weapons and can go in either hand.", 0, 0);
			}
		}
		else if (item_type[highlighted_item] < 400) // health
		{
			glColor3f(1,1,1);
			glPushMatrix();
			glTranslatef(-0.0135f, -0.0275f, -0.1f);
			glScalef(0.00002f, 0.00002f, 0.00002f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glColor3f(0,0,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'X');
			glColor3f(1,1,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glColor3f(1,0,0);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
			glColor3f(1,1,1);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
			glPopMatrix();

			glPushMatrix();
			glTranslatef(-0.0125f, -0.03f, -0.1f);
			glScalef(0.00002f, 0.00002f, 0.00002f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'U');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'H');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
			glPopMatrix();

			if (equip_recent == 0)
			{
				if (whole_second == true) HumanEvent(5, "Health packs regenerate your health, of course.", 0, 0);
			}
		}
	}

	if (near_save == 1)
	{
		glColor3f(1,1,1);
		glPushMatrix();
		glTranslatef(-0.0135f, -0.0275f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glColor3f(1,1,0);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'Y');
		glColor3f(1,1,1);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.0125f, -0.03f, -0.1f);
		glScalef(0.00002f, 0.00002f, 0.00002f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'G');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glPopMatrix();

		if (human_recent < 2 * 60)
		{
			if (whole_second == true) HumanEvent(6, "You can save your progress here.", 0, 0);
		}
	}
	else if (near_save > 1)
	{
		glPushMatrix();
		glTranslatef(-0.0135f, 0.0275f, -0.1f);
		glScalef(0.00003f, 0.00003f, 0.00003f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'G');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
		glPopMatrix();

		if (whole_second == true)
		{
			// sound effect
			system("play -q -v 0.95 Sounds/Success.wav &");

			HumanEvent(8, "Looks like our progress is saved now.", 0, 0);
		}
	}

	if (story_progression == 10 && abs(time(0) - level_time) < 18)
	{
		glPushMatrix();
		glTranslatef(-0.014f, 0.0275f, -0.1f);
		glScalef(0.00004f, 0.00004f, 0.00004f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'F');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glPopMatrix();
	}

	glLineWidth(1);

	glPushMatrix();
	glTranslatef(-0.0008f, -0.0006f, -0.1f);
	glScalef(0.00002f, 0.00002f, 0.00002f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '+');
	glPopMatrix();

	glEnable(GL_LIGHTING);
/*
	// Mainly for Linux, Windows will automatically receive inputs	
	if (joystick_enabled) 
	{
		FILE *joystick_fd = NULL;

		joystick_fd = fopen("/dev/input/js0", "rt");
		if (joystick_fd >= 0) // This is where Windows will fail
		{
			int bytes = 1;
			char temp;

			// This is specifically for the SNES controller.  
			// 8 bytes per button, some are -1 and +1 (D-pad).
			// The 5th byte is always the value of that button.
			// 104 is the total needed for SNES controller
			for (int i=0; i<104; i++)
			{
				bytes = fscanf(joystick_fd, "%c", &temp);

				if (bytes > 0 && i % 8 == 4)
				{
					joystick_button[(i-4)/8] = (int)temp;
				}
			}

			fclose(joystick_fd);
		}
	}
*/

	const float move = 0.375f;

	float old_x, old_z, temp_angle, second_angle;

	for (int i=0; i<MAX_BOTS; i++)
	{
		if (bot_health[i] > 0)
		{
			if (bot_action[i] == 0)
			{
				if (bot_sighted[i] == 0)
				{
					if (rand() % 100 < 1)
					{
						bot_action[i] = rand() % 50;

						bot_rot[i]->y = (float)(rand() % 100) / 100.0f * 3.141459f * 2.0f;
					}
				}
				else if (bot_sighted[i] == 2)
				{
					if (rand() % 100 < 5)
					{
						bot_action[i] = 1000;

						bot_timer[i] = 0.0f;

						int quick_sound_rand_num = rand() % 4;

						if (quick_sound_rand_num == 0)
						{
							// sound effect
							system("play -q -v 0.65 Sounds/Malfunction.wav &");
						}
						else if (quick_sound_rand_num == 1)
						{
							// sound effect
							system("play -q -v 0.65 Sounds/Malfunction2.wav &");
						}
					}
				}
			}
			else
			{
				bot_action[i]--;

				if (bot_sighted[i] == 1)
				{
					bot_action[i] = 0;
				}
			}

			old_x = bot_pos[i]->x;
			old_z = bot_pos[i]->z;

			if (bot_sighted[i] == 0)
			{
				if (bot_pos[i]->x - camera_pos->x > 0.0f)
				{
					temp_angle = atan((bot_pos[i]->z - camera_pos->z) / (bot_pos[i]->x - camera_pos->x));
				}
				else if (bot_pos[i]->x - camera_pos->x < 0.0f)
				{
					temp_angle = atan((bot_pos[i]->z - camera_pos->z) / (bot_pos[i]->x - camera_pos->x)) + 3.14159f;
				}
				else
				{
					if (bot_pos[i]->z - camera_pos->z >= 0.0f)
					{
						temp_angle = 3.14159f / 2.0f;
					}
					else temp_angle = -3.14159f / 2.0f;
				}

				second_angle = temp_angle - bot_rot[i]->y;

				while (second_angle < 0.0f) second_angle += 2.0f * 3.14159f;
				while (second_angle >= 2.0f * 3.14159f) second_angle -= 2.0f * 3.14159f; 

				if (second_angle < 3.14159f / 3.0f || second_angle > 3.14159f * 5.0f / 3.0f)
				{
					if (sqrt(pow(bot_pos[i]->x - camera_pos->x, 2.0f) +
						pow(bot_pos[i]->z - camera_pos->z, 2.0f)) <= 40.0f)
					{
						bot_sighted[i] = 1;
					}
				}

				if (bot_sighted[i] == 1)
				{
					float quick_volume_number = (float)((sqrt(pow(bot_pos[i]->x - camera_pos->x, 2.0f) + 
						pow(bot_pos[i]->z - camera_pos->z, 2.0f))) * -0.019f + 0.95f);

					if (quick_volume_number > 0.95f) quick_volume_number = 0.95f;
					if (quick_volume_number < 0.0f) quick_volume_number = 0.0f;

					sprintf(command, "play -q -v %f Sounds/DoesNotCompute.wav &", quick_volume_number);

					// sound effect
					system(command);
				}
			
				if (bot_sighted[i] == 0) // still zero
				{
					if (bot_action[i] > 0)
					{
						bot_pos[i]->x -= move / 4.0f * cos(bot_rot[i]->y); // just walk around
						bot_pos[i]->z -= move / 4.0f * sin(bot_rot[i]->y);
					}
				}
			}
			else if (bot_sighted[i] == 1)
			{
				if (bot_pos[i]->x - camera_pos->x > 0.0f)
				{
					bot_rot[i]->y = atan((bot_pos[i]->z - camera_pos->z) / (bot_pos[i]->x - camera_pos->x));
				}
				else if (bot_pos[i]->x - camera_pos->x < 0.0f)
				{
					bot_rot[i]->y = atan((bot_pos[i]->z - camera_pos->z) / (bot_pos[i]->x - camera_pos->x)) + 3.14159f;
				}
				else
				{
					if (bot_pos[i]->z - camera_pos->z >= 0.0f)
					{
						bot_rot[i]->y = 3.14159f / 2.0f;
					}
					else bot_rot[i]->y = -3.14159f / 2.0f;
				}

				bot_pos[i]->x -= move / 1.0f * cos(bot_rot[i]->y); // run after player!
				bot_pos[i]->z -= move / 1.0f * sin(bot_rot[i]->y);

				if (sqrt(pow(bot_pos[i]->x - camera_pos->x, 2.0f) +
					pow(bot_pos[i]->z - camera_pos->z, 2.0f)) <= 5.0f)
				{
					bot_sighted[i] = 2;
				}
			}
			else if (bot_sighted[i] == 2 && bot_action[i] == 0)
			{
				if (sqrt(pow(bot_pos[i]->x - camera_pos->x, 2.0f) +
					pow(bot_pos[i]->z - camera_pos->z, 2.0f)) > 5.0f)
				{
					bot_sighted[i] = 1;
				}
			}

			for (int j=0; j<MAX_BOTS; j++)
			{
				if (bot_health[j] > 0 && i != j)
				{
					if (sqrt(pow(bot_pos[i]->x - bot_pos[j]->x, 2.0f) +
						pow(bot_pos[i]->z - bot_pos[j]->z, 2.0f)) <= 3.0f) // bounds with bots
					{
						bot_pos[i]->x = old_x;
						bot_pos[i]->z = old_z;
					}
				}
			}
		
			for (int j=0; j<MAX_BOXES; j++)
			{
				if (box_size[j]->x > 0 && box_size[j]->y > 0 && box_size[j]->z > 0)
				{
					if (fabs(bot_pos[i]->x - box_pos[j]->x) <= box_size[j]->x + 1.0f &&
						fabs(bot_pos[i]->y - box_pos[j]->y) <= box_size[j]->y &&
						fabs(bot_pos[i]->z - box_pos[j]->z) <= box_size[j]->z + 1.0f) // bounds with boxes
					{
						bot_pos[i]->x = old_x;
						bot_pos[i]->z = old_z;
					}
				}
			}

			for (int j=0; j<MAX_WALLS; j++)
			{
				if (x_wall[j]->y > 0.0f)
				{
					if (bot_pos[i]->x >= x_wall[j]->x - 0.5f && bot_pos[i]->x <= x_wall[j]->x + x_wall[j]->y + 0.5f)
					{
						if (bot_pos[i]->z >= x_wall[j]->z - 2.0f && bot_pos[i]->z <= x_wall[j]->z + 2.0f) // bounds with wall
						{
							bot_pos[i]->x = old_x;
							bot_pos[i]->z = old_z;
						}
					}
				}
		
				if (z_wall[j]->y > 0.0f)
				{
					if (bot_pos[i]->z >= z_wall[j]->z - 0.5f && bot_pos[i]->z <= z_wall[j]->z + z_wall[j]->y + 0.5f)
					{
						if (bot_pos[i]->x >= z_wall[j]->x - 2.0f && bot_pos[i]->x <= z_wall[j]->x + 2.0f) // bounds with wall
						{
							bot_pos[i]->x = old_x;
							bot_pos[i]->z = old_z;
						}
					}
				}
			}
		}
	}

	old_x = camera_pos->x;
	old_z = camera_pos->z;

	if (keyboard['w']) 
	{
		camera_pos->z -= move * cos(camera_rot->y);
		camera_pos->x -= move * sin(camera_rot->y);

		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	if (keyboard['s']) 
	{
		camera_pos->z += move * cos(camera_rot->y);
		camera_pos->x += move * sin(camera_rot->y);
		
		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	if (keyboard['a']) 
	{
		camera_pos->z -= move * cos(camera_rot->y + 3.14f / 2.0f);
		camera_pos->x -= move * sin(camera_rot->y + 3.14f / 2.0f);

		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	if (keyboard['d']) 
	{
		camera_pos->z -= move * cos(camera_rot->y - 3.14f / 2.0f);
		camera_pos->x -= move * sin(camera_rot->y - 3.14f / 2.0f);

		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	if (keyboard[32]) // spacebar?
	{
		if (jump_button == 0)
		{
			jump_button = 3;

			camera_vel->y += move * 2.0f;

			// sound effect
			system("play -q -v 0.70 Sounds/Impact2.wav &");

			if (rand() % 5 == 0)
			{
				if (story_progression == 10)
				{
					// do nothing here
				}
				else HumanEvent(10, "All this jumping is scaring me!", 0, 0);
			}
		}
		else jump_button = 3;

		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	else
	{
		if (jump_button == 3)
		{
			jump_button = 2;
		}
		else if (jump_button == 1)
		{
			jump_button = 0;
		}
	}
	//if (keyboard['q']) camera_pos->y -= move;
	//if (keyboard['e']) camera_pos->y += move;

	camera_pos->y += camera_vel->y;
	camera_vel->y -= 0.02f; // gravity

	for (int i=0; i<MAX_BOTS; i++)
	{
		if (bot_health[i] > 0)
		{
			if (sqrt(pow(camera_pos->x - bot_pos[i]->x, 2.0f) +
				pow(camera_pos->y - bot_pos[i]->y, 2.0f) +
				pow(camera_pos->z - bot_pos[i]->z, 2.0f)) < 2.0f) // bounds with bots
			{
				camera_pos->x = old_x;
				camera_pos->z = old_z;
			}
		}
	}

	// WORK ON THIS LATER, CLIMB UP ONTO THE BOX IF HALF HEIGHT AWAY! (like stairs, etc)
	for (int i=0; i<MAX_BOXES; i++)
	{
		if (box_size[i]->x > 0 && box_size[i]->y > 0 && box_size[i]->z > 0)
		{
			if (fabs(camera_pos->x - box_pos[i]->x) <= box_size[i]->x + 1.0f &&
				fabs(camera_pos->y - box_pos[i]->y) <= box_size[i]->y &&
				fabs(camera_pos->z - box_pos[i]->z) <= box_size[i]->z + 1.0f) // bounds with boxes
			{
				if (fabs(old_x - box_pos[i]->x) <= box_size[i]->x + 1.0f &&
					fabs(camera_pos->y - box_pos[i]->y) <= box_size[i]->y &&
					fabs(old_z - box_pos[i]->z) <= box_size[i]->z + 1.0f) // still bounds with boxes
				{
					camera_pos->y = box_pos[i]->y + box_size[i]->y; // standing on top!
		
					camera_vel->y = 0.0f;

					if (jump_button == 3) jump_button = 1;
					else if (jump_button == 2) jump_button = 0;
				}
				else
				{
					camera_pos->x = old_x; // on it's side
					camera_pos->z = old_z;
				}
			}
		}
	}

	for (int i=0; i<MAX_WALLS; i++)
	{
		if (x_wall[i]->y > 0.0f)
		{
			if (camera_pos->x >= x_wall[i]->x - 0.5f && camera_pos->x <= x_wall[i]->x + x_wall[i]->y + 0.5f)
			{
				if (camera_pos->z >= x_wall[i]->z - 2.0f && camera_pos->z <= x_wall[i]->z + 2.0f) // bounds with wall
				{
					camera_pos->x = old_x;
					camera_pos->z = old_z;
				}
			}
		}
	
		if (z_wall[i]->y > 0.0f)
		{
			if (camera_pos->z >= z_wall[i]->z - 0.5f && camera_pos->z <= z_wall[i]->z + z_wall[i]->y + 0.5f)
			{
				if (camera_pos->x >= z_wall[i]->x - 2.0f && camera_pos->x <= z_wall[i]->x + 2.0f) // bounds with wall
				{
					camera_pos->x = old_x;
					camera_pos->z = old_z;
				}
			}
		}
	}

	if (camera_pos->y < 0.0f) // absolute bottom
	{
		if (fabs(camera_vel->y) > 0.05f)
		{
			// sound effect
			system("play -q -v 0.70 Sounds/Impact.wav &");
		}

		camera_pos->y = 0.0f;
		
		camera_vel->y = 0.0f;

		if (jump_button == 3) jump_button = 1;
		else if (jump_button == 2) jump_button = 0;
	}

	if (keyboard['i'])
	{
		camera_rot->x += move / 10.0f;

		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	if (keyboard['k'])
	{
		camera_rot->x -= move / 10.0f;
		
		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	if (keyboard['j'])
	{
		camera_rot->y += move / 10.0f;
		
		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	if (keyboard['l'])
	{
		camera_rot->y -= move / 10.0f;
		
		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}

	// MOUSE CONTROLS!
	float mouse_sensitivity = 0.005f;

	if (mouse->x != WINDOW_WIDTH/2) camera_rot->y -= mouse_sensitivity * (float)(mouse->x - WINDOW_WIDTH/2);
	if (mouse->y != WINDOW_HEIGHT/2) camera_rot->x -= mouse_sensitivity * (float)(mouse->y - WINDOW_HEIGHT/2); 

	glutWarpPointer(WINDOW_WIDTH/2, WINDOW_HEIGHT/2);

	if (camera_rot->x > 3.14159f / 2.0f) camera_rot->x = 3.14159f / 2.0f;
	if (camera_rot->x < -3.14159f / 2.0f) camera_rot->x = -3.14159f / 2.0f;

	if (keyboard['f'])
	{
		if (left_handed_down == 0 && left_handed_projectile_on == 0)
		{
			left_handed_down = 1;

			left_handed_angle += 1.5f * 3.14159f;
		}

		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	else
	{
		if (left_handed_angle == 0.0f) left_handed_down = 0;
	}

	if (left_handed_angle > 0.0f)
	{
		left_handed_angle += 0.1f;

		if (left_handed_angle > 2.5f * 3.14159f && left_handed_down == 1)
		{
			left_handed_down = 2;

			if (left_handed_weapon == 1 || left_handed_weapon == 2) CheckMeleeAttack(2);
			else if (left_handed_weapon == 3)
			{
				// sound effect
				system("play -q -v 0.8 Sounds/Swipe.wav &");

				left_handed_ammo -= 1;

				if (left_handed_ammo <= 0)
				{
					left_handed_weapon = 0;
				}

				projectile_pos[1]->x = camera_pos->x;
				projectile_pos[1]->y = camera_pos->y + 5.5f;
				projectile_pos[1]->z = camera_pos->z;
		
				projectile_rot[1]->x = camera_rot->x + 3.14159f / 256.0f;
				projectile_rot[1]->y = camera_rot->y;
				projectile_rot[1]->z = camera_rot->z;

				left_handed_projectile_on = 1;
			}
		}
	
		if (left_handed_angle > 3.0f * 3.14159f) left_handed_angle = 0.0f;
	}

	if (keyboard['h'])
	{
		if (right_handed_down == 0 && right_handed_projectile_on == 0)
		{
			right_handed_down = 1;

			right_handed_angle += 1.5f * 3.14159f;
		}

		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }
	}
	else
	{
		if (right_handed_angle == 0.0f) right_handed_down = 0;
	}

	if (right_handed_angle > 0.0f)
	{
		right_handed_angle += 0.1f;

		if (right_handed_angle > 2.5f * 3.14159f && right_handed_down == 1)
		{
			right_handed_down = 2;

			if (right_handed_weapon == 1 || right_handed_weapon == 2) CheckMeleeAttack(1);
			else if (right_handed_weapon == 3)
			{
				// sound effect
				system("play -q -v 0.8 Sounds/Swipe.wav &");

				right_handed_ammo -= 1;

				if (right_handed_ammo <= 0)
				{
					right_handed_weapon = 0;
				}

				projectile_pos[0]->x = camera_pos->x;
				projectile_pos[0]->y = camera_pos->y + 5.5f;
				projectile_pos[0]->z = camera_pos->z;
		
				projectile_rot[0]->x = camera_rot->x + 3.14159f / 256.0f;
				projectile_rot[0]->y = camera_rot->y;
				projectile_rot[0]->z = camera_rot->z;

				right_handed_projectile_on = 1;
			}
		}
	
		if (right_handed_angle > 3.0f * 3.14159f) right_handed_angle = 0.0f;
	}

	equip_recent--;
	if (equip_recent < 0) equip_recent = 0;

	if (keyboard['q'])
	{
		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }

		if (highlighted_item != -1 && left_equip_button == 0)
		{
			left_equip_button = 1;

			equip_recent = 60 * 5;

			if (item_type[highlighted_item] < 100) // hammer requires two hands
			{
				int temp_type = item_type[highlighted_item];

				if (right_handed_weapon != 0)
				{
					item_type[highlighted_item] = (right_handed_weapon-1) * 100 + right_handed_ammo;
				}
				else
				{
					item_type[highlighted_item] = 0;

					highlighted_item = -1;
				}
		
				right_handed_weapon = (int)(temp_type / 100) + 1;
				right_handed_ammo = (int)(temp_type % 100);

				if (left_handed_weapon != 0)
				{
					for (int i=0; i<MAX_ITEMS; i++)
					{
						if (item_type[i] == 0)
						{
							item_type[i] = (left_handed_weapon-1) * 100 + left_handed_ammo;

							item_pos[i]->x = camera_pos->x;
							item_pos[i]->y = camera_pos->y;
							item_pos[i]->z = camera_pos->z;

							left_handed_weapon = 0;
							left_handed_ammo = 0;
			
							i = MAX_ITEMS + 1;
						}
					}
				}

				// sound effect
				system("play -q -v 0.8 Sounds/Pickup.wav &");

				HumanEvent(3, "I always thought the hammer was a good choice.", 0, 0);
			}
			else if (item_type[highlighted_item] < 200 ||
				(item_type[highlighted_item] < 300 && left_handed_weapon != 3)) // scythe and spikes
			{
				int temp_type = item_type[highlighted_item];

				if (left_handed_weapon != 0)
				{
					item_type[highlighted_item] = (left_handed_weapon-1) * 100 + left_handed_ammo;

					item_pos[highlighted_item]->x = camera_pos->x;
					item_pos[highlighted_item]->y = camera_pos->y;
					item_pos[highlighted_item]->z = camera_pos->z;
				}
				else if (right_handed_weapon == 1)
				{
					item_type[highlighted_item] = (right_handed_weapon-1) * 100 + right_handed_ammo;

					item_pos[highlighted_item]->x = camera_pos->x;
					item_pos[highlighted_item]->y = camera_pos->y;
					item_pos[highlighted_item]->z = camera_pos->z;

					right_handed_weapon = 0;
					right_handed_ammo = 0;
				}
				else
				{
					item_type[highlighted_item] = 0;

					highlighted_item = -1;
				}
		
				left_handed_weapon = (int)(temp_type / 100) + 1;
				left_handed_ammo = (int)(temp_type % 100);

				if (left_handed_weapon == 3 && left_handed_ammo > 10) left_handed_ammo = 10;

				// sound effect
				system("play -q -v 0.8 Sounds/Pickup.wav &");

				HumanEvent(7, "I hope you know how to use that.", 0, 0);
			}
			else if (item_type[highlighted_item] < 300 && left_handed_weapon == 3) // add to existing spikes
			{
				left_handed_ammo += (int)(item_type[highlighted_item] % 100);

				if (left_handed_ammo > 10)
				{
					item_type[highlighted_item] = 200 + (left_handed_ammo - 10);

					item_pos[highlighted_item]->x = camera_pos->x;
					item_pos[highlighted_item]->y = camera_pos->y;
					item_pos[highlighted_item]->z = camera_pos->z;

					left_handed_ammo = 10;
				}
				else
				{
					item_type[highlighted_item] = 0;
					
					highlighted_item = -1;
				}

				// sound effect
				system("play -q -v 0.8 Sounds/Pickup.wav &");

				HumanEvent(6, "It is good to stock up.", 0, 0);
			}
			else if (item_type[highlighted_item] < 400) // health
			{
				player_health += (int)(item_type[highlighted_item] % 100);
				
				if (player_health > 100) player_health = 100;

				item_type[highlighted_item] = 0;
					
				highlighted_item = -1;

				// sound effect
				system("play -q -v 0.8 Sounds/Pickup.wav &");
		
				HumanEvent(8, "Trust me, I want you to stay alive.", 0, 0);
			}
		}
	}
	else
	{
		left_equip_button = 0;
	}

	if (keyboard['e'])
	{
		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }

		if (highlighted_item != -1 && right_equip_button == 0)
		{
			right_equip_button = 1;

			equip_recent = 60 * 5;

			if (item_type[highlighted_item] < 100) // hammer requires two hands
			{
				int temp_type = item_type[highlighted_item];

				if (right_handed_weapon != 0)
				{
					item_type[highlighted_item] = (right_handed_weapon-1) * 100 + right_handed_ammo;
				}
				else
				{
					item_type[highlighted_item] = 0;

					highlighted_item = -1;
				}
		
				right_handed_weapon = (int)(temp_type / 100) + 1;
				right_handed_ammo = (int)(temp_type % 100);

				if (left_handed_weapon != 0)
				{
					for (int i=0; i<MAX_ITEMS; i++)
					{
						if (item_type[i] == 0)
						{
							item_type[i] = (left_handed_weapon-1) * 100 + left_handed_ammo;

							item_pos[i]->x = camera_pos->x;
							item_pos[i]->y = camera_pos->y;
							item_pos[i]->z = camera_pos->z;

							left_handed_weapon = 0;
							left_handed_ammo = 0;
			
							i = MAX_ITEMS + 1;
						}
					}
				}

				// sound effect
				system("play -q -v 0.8 Sounds/Pickup.wav &");

				HumanEvent(3, "I always thought the hammer was a good choice.", 0, 0);
			}
			else if (item_type[highlighted_item] < 200 ||
				(item_type[highlighted_item] < 300 && right_handed_weapon != 3)) // scythe and spikes
			{
				int temp_type = item_type[highlighted_item];

				if (right_handed_weapon != 0)
				{
					item_type[highlighted_item] = (right_handed_weapon-1) * 100 + right_handed_ammo;

					item_pos[highlighted_item]->x = camera_pos->x;
					item_pos[highlighted_item]->y = camera_pos->y;
					item_pos[highlighted_item]->z = camera_pos->z;
				}
				else
				{
					item_type[highlighted_item] = 0;

					highlighted_item = -1;
				}
		
				right_handed_weapon = (int)(temp_type / 100) + 1;
				right_handed_ammo = (int)(temp_type % 100);

				if (right_handed_weapon == 3 && right_handed_ammo > 10) right_handed_ammo = 10;

				// sound effect
				system("play -q -v 0.8 Sounds/Pickup.wav &");

				HumanEvent(7, "I hope you know how to use that.", 0, 0);
			}
			else if (item_type[highlighted_item] < 300 && right_handed_weapon == 3) // additional spikes
			{
				right_handed_ammo += (int)(item_type[highlighted_item] % 100);

				if (right_handed_ammo > 10)
				{
					item_type[highlighted_item] = 200 + (right_handed_ammo - 10);

					item_pos[highlighted_item]->x = camera_pos->x;
					item_pos[highlighted_item]->y = camera_pos->y;
					item_pos[highlighted_item]->z = camera_pos->z;

					right_handed_ammo = 10;
				}
				else
				{
					item_type[highlighted_item] = 0;
					
					highlighted_item = -1;
				}

				// sound effect
				system("play -q -v 0.8 Sounds/Pickup.wav &");
		
				HumanEvent(6, "It is good to stock up.", 0, 0);
			}
			else if (item_type[highlighted_item] < 400) // health
			{
				player_health += (int)(item_type[highlighted_item] % 100);
				
				if (player_health > 100) player_health = 100;

				item_type[highlighted_item] = 0;
					
				highlighted_item = -1;

				// sound effect
				system("play -q -v 0.8 Sounds/Pickup.wav &");

				HumanEvent(8, "Trust me, I want you to stay alive.", 0, 0);
			}
		}
	}
	else
	{
		right_equip_button = 0;
	}

	if (keyboard[13] && save_button == 0) // return?
	{
		if (idle_time >= 60 * 60)
		{
			idle_time = -60 * (60+5);
			
			HumanEvent(9, "You're back! Let's get going :)", 0, 0);
		}
		else if (idle_time <= -60 * 60) {}
		else { idle_time = 0; }

		save_button = 1;

		if (near_save == 1)
		{
			if (!Save()) printf("Error while saving!\n");

			near_save = 120; // now is a timer!
		}
	}
	else
	{
		save_button = 0;
	}

	CheckRangedAttacks();


	// DRAW HERE!!!

	if (player_hurt_timer > 0)
	{
		player_hurt_timer--;

		glDisable(GL_LIGHTING);

		glColor3f(1,1,1);
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_HURT]);
		glBegin(GL_QUADS);
		glTexCoord2f(0,0);
		glVertex3f(-0.057f, -0.0425f, -0.101f);
		glTexCoord2f(0,1);
		glVertex3f(-0.057f, 0.0425f, -0.101f);
		glTexCoord2f(1,1);
		glVertex3f(0.057f, 0.0425f, -0.101f);
		glTexCoord2f(1,0);
		glVertex3f(0.057f, -0.0425f, -0.101f);
		glEnd();
	
		glEnable(GL_LIGHTING);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
	}

	DrawPersonalWeapons(right_handed_weapon, left_handed_weapon, right_handed_angle, left_handed_angle);

	glRotatef(-camera_rot->x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
	glRotatef(-camera_rot->y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
	glRotatef(-camera_rot->z * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);

	glTranslatef(-camera_pos->x, -camera_pos->y - 6.0f, -camera_pos->z);

	glDisable(GL_LIGHTING);

	glColor3f(0.1f, 0.5f, 0.1f);
	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

	for (int i=0; i<MAX_PARTICLES; i++)
	{
		if (particle_size[i] > 0.0f)
		{
			glTranslatef(particle_pos[i]->x, particle_pos[i]->y, particle_pos[i]->z);

			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
			glRotatef(camera_rot->x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);

			glBegin(GL_QUADS);

			glVertex3f(-particle_size[i], -particle_size[i], 0.0f);
			glVertex3f(-particle_size[i], particle_size[i], 0.0f);
			glVertex3f(particle_size[i], particle_size[i], 0.0f);
			glVertex3f(particle_size[i], -particle_size[i], 0.0f);
			
			glEnd();

			glRotatef(-camera_rot->x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
			glRotatef(-camera_rot->y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
			glRotatef(-camera_rot->z * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);

			glTranslatef(-particle_pos[i]->x, -particle_pos[i]->y, -particle_pos[i]->z);

			particle_size[i] -= 0.002f;

			particle_pos[i]->x += particle_vel[i]->x;
			particle_pos[i]->y += particle_vel[i]->y;
			particle_pos[i]->z += particle_vel[i]->z;

			particle_vel[i]->y -= 0.01f;
		}
	}

	glEnable(GL_LIGHTING);
		

	if (right_handed_projectile_on == 1)
	{
		glTranslatef(projectile_pos[0]->x, projectile_pos[0]->y, projectile_pos[0]->z);
		
		glRotatef(projectile_rot[0]->y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glRotatef(projectile_rot[0]->z * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
		glRotatef(projectile_rot[0]->x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);

		glColor3f(0.75f, 0.75f, 0.75f);
		DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
		
		glRotatef(-projectile_rot[0]->x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glRotatef(-projectile_rot[0]->z * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
		glRotatef(-projectile_rot[0]->y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);

		glTranslatef(-projectile_pos[0]->x, -projectile_pos[0]->y, -projectile_pos[0]->z);
	}

	if (left_handed_projectile_on == 1)
	{
		glTranslatef(projectile_pos[1]->x, projectile_pos[1]->y, projectile_pos[1]->z);
		
		glRotatef(projectile_rot[1]->y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glRotatef(projectile_rot[1]->z * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
		glRotatef(projectile_rot[1]->x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);

		glColor3f(0.75f, 0.75f, 0.75f);
		DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
		
		glRotatef(-projectile_rot[1]->x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glRotatef(-projectile_rot[1]->z * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
		glRotatef(-projectile_rot[1]->y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);

		glTranslatef(-projectile_pos[1]->x, -projectile_pos[1]->y, -projectile_pos[1]->z);
	}		

	float p_color[3], s_color[3];

	int total_living_bots = 0;

	for (int i=0; i<MAX_BOTS; i++)
	{
		if (bot_health[i] > 0)
		{
			total_living_bots++;

			p_color[0] = bot_primary_color[i]->x;
			p_color[1] = bot_primary_color[i]->y;
			p_color[2] = bot_primary_color[i]->z;
			
			s_color[0] = bot_secondary_color[i]->x;
			s_color[1] = bot_secondary_color[i]->y;
			s_color[2] = bot_secondary_color[i]->z;
	
			glTranslatef(bot_pos[i]->x, bot_pos[i]->y, bot_pos[i]->z);
			
			glRotatef(-bot_rot[i]->y * 180.0f / 3.14159f + 180.0f, 0.0f, 1.0f, 0.0f);

			if (bot_action[i] == 0 && bot_sighted[i] == 1) // chasing player
			{
				DrawRobot(bot_sex[i], bot_weapon[i], 0.0f, p_color, s_color, 3, bot_timer[i]);
			}
			else if (bot_action[i] == 0 && bot_sighted[i] == 0) // standing still
			{
				DrawRobot(bot_sex[i], bot_weapon[i], 0.0f, p_color, s_color, 0, bot_timer[i]);
			}
			else if (bot_action[i] > 0 && bot_sighted[i] == 0) // walking around
			{
				DrawRobot(bot_sex[i], bot_weapon[i], 0.0f, p_color, s_color, 2, bot_timer[i]);
			}
			else if (bot_action[i] > 0 && bot_sighted[i] == 2) // attacking player
			{
				DrawRobot(bot_sex[i], bot_weapon[i], 0.0f, p_color, s_color, 4, bot_timer[i]);
			}
			else // waiting to be allowed to attack player
			{
				DrawRobot(bot_sex[i], bot_weapon[i], 0.0f, p_color, s_color, 0, bot_timer[i]);
			}

			if (bot_sighted[i] != 2) bot_timer[i] += 3.14159f / 32.0f;
			else bot_timer[i] += 3.14159f / 16.0f; 

			if (bot_timer[i] >= 2.0f * 3.14159f)
			{
				bot_timer[i] -= 2.0f * 3.14159f;

				if (bot_action[i] != 0)
				{
					if (sqrt(pow(bot_pos[i]->x - camera_pos->x, 2.0f) +
						pow(bot_pos[i]->y - camera_pos->y, 2.0f) +
						pow(bot_pos[i]->z - camera_pos->z, 2.0f)) <= 12.0f)
					{
						player_health -= rand() % 10 + 5;

						player_hurt_timer = 5;

						int quick_sound_rand_num = rand() % 3;

						if (quick_sound_rand_num == 0)
						{
							// sound effect
							system("play -q -v 0.75 Sounds/Gasp.wav &");
						}
						else if (quick_sound_rand_num == 1)
						{
							// sound effect
							system("play -q -v 0.75 Sounds/Gasp2.wav &");
						}
						else if (quick_sound_rand_num == 2)
						{
							// sound effect
							system("play -q -v 0.75 Sounds/Gasp3.wav &");
						}

						HumanEvent(10, "They are hurting you, look out!", 0, 0);
					}
				}

				if (bot_sighted[i] == 2) bot_action[i] = 0;
			}

			glRotatef(bot_rot[i]->y * 180.0f / 3.14159f + 180.0f, 0.0f, 1.0f, 0.0f);

			glTranslatef(-bot_pos[i]->x, -bot_pos[i]->y, -bot_pos[i]->z);
		}
	}

	if (total_living_bots == 0 && story_progression == 10)
	{
		// sound effect
		system("play -q -v 0.85 Sounds/Winner.wav &");

		HumanEvent(9, "That was simply amazing! Great job, thank you for playing! :)", 0, 1);

		story_progression = 11;

		completion_delay = 120;

		level_time = time(0);
			
		Reset();
		if (!Save()) printf("Error while saving!\n");
	}

	for (int i=0; i<MAX_BOXES; i++)
	{
		if (box_size[i]->x > 0 && box_size[i]->y > 0 && box_size[i]->z > 0)
		{
			p_color[0] = box_color[i]->x;
			p_color[1] = box_color[i]->y;
			p_color[2] = box_color[i]->z;

			glTranslatef(box_pos[i]->x, box_pos[i]->y, box_pos[i]->z);

			DrawBox(box_size[i]->x, box_size[i]->y, box_size[i]->z, p_color);
		
			glTranslatef(-box_pos[i]->x, -box_pos[i]->y, -box_pos[i]->z);
		}
	}

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_WALL]); // MAKE THIS A COOL WALL TEXTURE!

	for (int i=0; i<MAX_WALLS; i++)
	{
		if (x_wall[i]->y > 0.0f)
		{
			glColor3f(x_wall_color[i]->x, x_wall_color[i]->y, x_wall_color[i]->z);

			glBegin(GL_QUADS);

			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(x_wall[i]->x - 0.0f, 60.0f, x_wall[i]->z + 0.5f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(x_wall[i]->x - 0.0f, 0.0f, x_wall[i]->z + 0.5f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(x_wall[i]->x + x_wall[i]->y + 0.0f, 0.0f, x_wall[i]->z + 0.5f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(x_wall[i]->x + x_wall[i]->y + 0.0f, 60.0f, x_wall[i]->z + 0.5f);

			glNormal3f(0.0f, 0.0f, -1.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(x_wall[i]->x - 0.0f, 60.0f, x_wall[i]->z - 0.5f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(x_wall[i]->x - 0.0f, 0.0f, x_wall[i]->z - 0.5f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(x_wall[i]->x + x_wall[i]->y + 0.0f, 0.0f, x_wall[i]->z - 0.5f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(x_wall[i]->x + x_wall[i]->y + 0.0f, 60.0f, x_wall[i]->z - 0.5f);

			glNormal3f(-1.0f, 0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(x_wall[i]->x, 60.0f, x_wall[i]->z + 0.5f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(x_wall[i]->x, 0.0f, x_wall[i]->z + 0.5f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(x_wall[i]->x, 0.0f, x_wall[i]->z - 0.5f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(x_wall[i]->x, 60.0f, x_wall[i]->z - 0.5f);
	
			glNormal3f(1.0f, 0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(x_wall[i]->x + x_wall[i]->y, 60.0f, x_wall[i]->z - 0.5f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(x_wall[i]->x + x_wall[i]->y, 0.0f, x_wall[i]->z - 0.5f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(x_wall[i]->x + x_wall[i]->y, 0.0f, x_wall[i]->z + 0.5f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(x_wall[i]->x + x_wall[i]->y, 60.0f, x_wall[i]->z + 0.5f);
		
			glEnd();
		}

		if (z_wall[i]->y > 0.0f)
		{
			glColor3f(z_wall_color[i]->x, z_wall_color[i]->y, z_wall_color[i]->z);

			glBegin(GL_QUADS);

			glNormal3f(1.0f, 0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(z_wall[i]->x + 0.5f, 60.0f, z_wall[i]->z - 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(z_wall[i]->x + 0.5f, 0.0f, z_wall[i]->z - 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(z_wall[i]->x + 0.5f, 0.0f, z_wall[i]->z + z_wall[i]->y + 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(z_wall[i]->x + 0.5f, 60.0f, z_wall[i]->z + z_wall[i]->y + 0.0f);

			glNormal3f(-1.0f, 0.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(z_wall[i]->x - 0.5f, 60.0f, z_wall[i]->z - 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(z_wall[i]->x - 0.5f, 0.0f, z_wall[i]->z - 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(z_wall[i]->x - 0.5f, 0.0f, z_wall[i]->z + z_wall[i]->y + 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(z_wall[i]->x - 0.5f, 60.0f, z_wall[i]->z + z_wall[i]->y + 0.0f);

			glNormal3f(0.0f, 0.0f, -1.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(z_wall[i]->x - 0.5f, 60.0f, z_wall[i]->z);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(z_wall[i]->x - 0.5f, 0.0f, z_wall[i]->z);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(z_wall[i]->x + 0.5f, 0.0f, z_wall[i]->z);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(z_wall[i]->x + 0.5f, 60.0f, z_wall[i]->z);

			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(z_wall[i]->x + 0.5f, 60.0f, z_wall[i]->z + z_wall[i]->y);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(z_wall[i]->x + 0.5f, 0.0f, z_wall[i]->z + z_wall[i]->y);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(z_wall[i]->x - 0.5f, 0.0f, z_wall[i]->z + z_wall[i]->y);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(z_wall[i]->x - 0.5f, 60.0f, z_wall[i]->z + z_wall[i]->y);
		
			glEnd();
		}
	}	

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_FLOOR]); // PUT IN FLOOR TEXTURE HERE!!!

	for (int i=0; i<MAX_MAP_X; i++)
	{
		for (int j=0; j<MAX_MAP_Z; j++)
		{
			if (map_bounds[i][j] == 1)
			{
				glBegin(GL_QUADS);

				glColor3f(0.25f, 0.25f, 0.25f);
			
				glNormal3f(0.0f, 1.0f, 0.0f);
	
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f((float)i * MAX_TILE_X - MAX_TILE_X * 0.5f, 0.0f, (float)j * MAX_TILE_Z - MAX_TILE_Z * 0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f((float)i * MAX_TILE_X - MAX_TILE_X * 0.5f, 0.0f, (float)j * MAX_TILE_Z + MAX_TILE_Z * 0.5f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f((float)i * MAX_TILE_X + MAX_TILE_X * 0.5f, 0.0f, (float)j * MAX_TILE_Z + MAX_TILE_Z * 0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f((float)i * MAX_TILE_X + MAX_TILE_X * 0.5f, 0.0f, (float)j * MAX_TILE_Z - MAX_TILE_Z * 0.5f);	
	
				glEnd();
			}
		}
	}	

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CEILING]); // PUT IN CEILING TEXTURE HERE!!!

	for (int i=0; i<MAX_MAP_X; i++)
	{
		for (int j=0; j<MAX_MAP_Z; j++)
		{
			if (map_bounds[i][j] == 1)
			{
				glBegin(GL_QUADS);

				glColor3f(0.95f, 0.95f, 0.95f);
				
				glNormal3f(0.0f, -1.0f, 0.0f);
	
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f((float)i * MAX_TILE_X - MAX_TILE_X * 0.5f, 60.0f, (float)j * MAX_TILE_Z - MAX_TILE_Z * 0.5f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f((float)i * MAX_TILE_X - MAX_TILE_X * 0.5f, 60.0f, (float)j * MAX_TILE_Z + MAX_TILE_Z * 0.5f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f((float)i * MAX_TILE_X + MAX_TILE_X * 0.5f, 60.0f, (float)j * MAX_TILE_Z + MAX_TILE_Z * 0.5f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f((float)i * MAX_TILE_X + MAX_TILE_X * 0.5f, 60.0f, (float)j * MAX_TILE_Z - MAX_TILE_Z * 0.5f);	
	
				glEnd();
			}
		}
	}		
	
	float min_dist = 9999.0f, temp_dist;
	int min_index = -1;

	bool rotater_flag;

	if (near_save <= 1) near_save = 0;
	else near_save--;

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

	for (int i=0; i<MAX_ITEMS; i++) // draw all items except for saves
	{
		if (item_type[i] != 0)
		{
			rotater_flag = false;

			glTranslatef(item_pos[i]->x, item_pos[i]->y + 0.25f, item_pos[i]->z);

			if (item_type[i] < 100) // hammer
			{
				glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
				glColor3f(0.75f, 0.75f, 0.75f);
				DrawComponent(hammer_point, hammer_indice, 26);
				glRotatef(-90.0f, 0.0f, 0.0f, 1.0f);
			}
			else if (item_type[i] < 200) // scythe
			{
				glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
				glColor3f(0.75f, 0.75f, 0.75f);
				DrawComponent(scythe_point, scythe_indice, 30);
				glRotatef(-90.0f, 0.0f, 0.0f, 1.0f);
			}
			else if (item_type[i] < 300) // spikes
			{
				glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
				glColor3f(0.75f, 0.75f, 0.75f);
				DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
				glRotatef(-90.0f, 0.0f, 0.0f, 1.0f);
			}
			else if (item_type[i] < 400) // health
			{
				//glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
				glScalef(3.0f, 3.0f, 3.0f);
				glColor3f(1.0f, 0.0f, 0.0f);
				DrawComponent(large_joint_point, large_joint_indice, 16);
				glScalef(1.0f / 3.0f, 1.0f / 3.0f, 1.0f / 3.0f);
				//glRotatef(-90.0f, 0.0f, 0.0f, 1.0f);
			}
			else if (item_type[i] < 500) // save
			{
				// do nothing here
			}
			else if (item_type[i] < 600) // teleport
			{
				// do nothing here
			}
		
			glTranslatef(-item_pos[i]->x, -item_pos[i]->y - 0.25f, -item_pos[i]->z);

			if (rotater_flag == true) item_pos[i]->y -= 5.0f;

			temp_dist = sqrt(pow(item_pos[i]->x - camera_pos->x, 2.0f) +
				pow(item_pos[i]->z - camera_pos->z, 2.0f));

			if (temp_dist < min_dist && temp_dist <= 5.0f && item_type[i] < 400) // not a save!
			{
				min_dist = temp_dist;
				min_index = i;
			}

			if (temp_dist <= 5.0f && item_type[i] >= 400 && item_type[i] < 500) // a save!
			{
				if (near_save <= 1) near_save = 1;
			}

			if (temp_dist <= 5.0f && item_type[i] >= 500 && item_type[i] < 600) // a teleport
			{
				story_progression++;

				char level_filename[256];

				for (int i=0; i<256; i++) level_filename[i] = 0;

				sprintf(level_filename, "Level%d.txt", story_progression);

				Reset();
				CreateLevel(level_filename);

				level_time = time(0);

				if (story_progression == 2)
				{
					right_handed_weapon = 1;
					right_handed_ammo = 99;
		
					left_handed_weapon = 0;
					left_handed_ammo = 0;

					player_health = 100;
				}
				else if (story_progression == 3)
				{
					right_handed_weapon = 2;
					right_handed_ammo = 20;

					left_handed_weapon = 3;
					left_handed_ammo = 10;

					player_health = 100;
				}
				else if (story_progression == 4)
				{
					right_handed_weapon = 0;
					right_handed_ammo = 0;
	
					left_handed_weapon = 0;
					left_handed_ammo = 0;

					player_health = 100;
				}

				if (!Save()) printf("Error while saving!\n");

				int shirt_color_random = rand() % 3;

				if (shirt_color_random == 0) LoadBitmap("Textures/NavyBlue.bmp", texture[TEXTURE_HUMAN_SHIRT]);
				else if (shirt_color_random == 1) LoadBitmap("Textures/BloodRed.bmp", texture[TEXTURE_HUMAN_SHIRT]);
				else if (shirt_color_random == 2) LoadBitmap("Textures/OliveGreen.bmp", texture[TEXTURE_HUMAN_SHIRT]);

				// sound effect
				system("play -q -v 0.95 Sounds/Teleport.wav &");

				if (story_progression == 2)
				{
					HumanEvent(8, "Oh wow! That's a nice hammer :)", 0, 1);
				}
				else if (story_progression == 3)
				{
					HumanEvent(1, "You are doing great. Oh look, new weapons!", 0, 1);
				}
				else if (story_progression == 4)
				{
					HumanEvent(7, "Ok, tutorial is over. Now for the real game.", 0, 1);
				}
				else if (story_progression == 5)
				{
					HumanEvent(6, "You are progressing quite well it seems.", 0, 1);
				}
				else if (story_progression == 6)
				{
					HumanEvent(2, "So what do you think so far?", 0, 1);
				}
				else if (story_progression == 7)
				{
					HumanEvent(8, "That was great :)", 0, 1);
				}
				else if (story_progression == 8)
				{
					HumanEvent(3, "Good decision.", 0, 1);
				}
				else if (story_progression == 9)
				{
					HumanEvent(7, "That seemed too easy!", 0, 1);
				}
				else if (story_progression == 10)
				{
					HumanEvent(4, "This is the last level!", 0, 1);
				}
				else
				{
					HumanEvent(2, "Another level?", 0, 1);
				}
			}
					
		}
	}

	glDisable(GL_LIGHTING);
	glDisable(GL_ALPHA_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE);

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

	for (int i=0; i<MAX_ITEMS; i++) // draw all save points last for blending
	{
		if (item_type[i] != 0)
		{
			rotater_flag = false;

			glTranslatef(item_pos[i]->x, item_pos[i]->y + 0.25f + 4.0f, item_pos[i]->z);

			if (item_type[i] < 400) // all else
			{
				// do nothing
			}
			else if (item_type[i] < 500) // save game
			{
				glRotatef(item_pos[i]->y * 180.0f / 2.5f, 0.0f, 1.0f, 0.0f);

				glTranslatef(0.0f, -item_pos[i]->y, 0.0f);
				//glRotatef(item_pos[i]->y * 180.0f / 5.0f, 0.0f, 0.0f, 1.0f);
				//glScalef(10.0f, 10.0f, 10.0f);

				glColor3f(0.5f, 0.0f, 0.5f);

				glBegin(GL_TRIANGLES);

				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(0.0f, 4.0f, 0.0f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f(-2.0f, -2.0f, 0.0f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(2.0f, -2.0f, 0.0f);
		
				glEnd();

				//glScalef(1.0f / 10.0f, 1.0f / 10.0f, 1.0f / 10.0f);
				//glRotatef(-item_pos[i]->y * 180.0f / 5.0f, 0.0f, 0.0f, 1.0f);
				glTranslatef(0.0f, item_pos[i]->y, 0.0f);

				glRotatef(-item_pos[i]->y * 180.0f / 2.5f, 0.0f, 1.0f, 0.0f);

				item_pos[i]->y += 0.05f;

				if (item_pos[i]->y >= 5.0f) rotater_flag = true;
			}
			else if (item_type[i] < 600) // teleport
			{
				glRotatef(item_pos[i]->y * 180.0f / 2.5f, 0.0f, 1.0f, 0.0f);
				
				glTranslatef(0.0f, -item_pos[i]->y - 4.0f, 0.0f);

				glColor3f(0.5f, 0.5f, 0.5f);

				glBegin(GL_QUADS);

				glNormal3f(0.0f, 0.0f, 1.0f);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-2.5f, 10.0f, 0.0f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-2.5f, 0.0f, 0.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f(2.5f, 0.0f, 0.0f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f(2.5f, 10.0f, 0.0f);

				glEnd();

				glTranslatef(0.0f, item_pos[i]->y + 4.0f, 0.0f);
				
				glRotatef(-item_pos[i]->y * 180.0f / 2.5f, 0.0f, 1.0f, 0.0f);
			
				item_pos[i]->y += 0.05f;

				if (item_pos[i]->y >= 5.0f) rotater_flag = true;
			}

			glTranslatef(-item_pos[i]->x, -item_pos[i]->y - 0.25f - 4.0f, -item_pos[i]->z);

			if (rotater_flag == true) item_pos[i]->y -= 5.0f;

			temp_dist = sqrt(pow(item_pos[i]->x - camera_pos->x, 2.0f) +
				pow(item_pos[i]->z - camera_pos->z, 2.0f));

			if (temp_dist < min_dist && temp_dist <= 5.0f && item_type[i] < 400) // not a save!
			{
				min_dist = temp_dist;
				min_index = i;
			}

			if (temp_dist <= 5.0f && item_type[i] >= 400) // a save!
			{
				if (near_save <= 1) near_save = 1;
			}	
		}
	}

	glDisable(GL_BLEND);
	glEnable(GL_ALPHA_TEST);
	glEnable(GL_LIGHTING);		

	if (min_index != -1) // close item found!
	{
		highlighted_item = min_index;
	}
	else highlighted_item = -1;

	if (player_health <= 0)
	{
		player_health = -180; // timer til reset

		player_deaths++;

		// GAME OVER!

		if (story_progression == 10)
		{
			// sound effect
			system("play -q -v 0.65 Sounds/Complete.wav &");

			HumanEvent(9, "You still did very well, great job, thanks for playing! :)", 0, 1);

			story_progression = 11;

			completion_delay = 120;

			level_time = time(0);
			
			Reset();
			if (!Save()) printf("Error while saving!\n");
		}
		else
		{
			// sound effect
			system("play -q -v 0.85 Sounds/Dead.wav &");

			HumanEvent(2, "It's ok, it happens to everyone.", 0, 0);
		}
	}

	glutSwapBuffers();

	if (keyboard['`'])
	{
		TakeSnapshot("Snapshot.bmp");
	}

	return;
};

void OpenGLKeyboardUpFunction(unsigned char key, int x, int y)
{
	keyboard[key] = false;

	return;
};

void OpenGLKeyboardFunction(unsigned char key, int x, int y)
{
	keyboard[key] = true;

	return;
};

void OpenGLSpecialKeyboardFunction(int key, int x, int y)
{
	special_keyboard[key] = true;

	return;
};	

void OpenGLSpecialKeyboardUpFunction(int key, int x, int y)
{
	special_keyboard[key] = false;

	return;
};

void OpenGLMouseFunction(int button, int state, int x, int y)
{
	mouse->button = button;
	mouse->state = state;
	mouse->x = x;
	mouse->y = y;

	return;
};

void OpenGLPassiveMotionFunction(int x, int y)
{
	mouse->x = x;
	mouse->y = y;

	return;
};
/*
// GLUT in Linux does support joystick detection but not input.
// GLUT in Windows supports both
void OpenGLJoystickFunction(unsigned int button, int x, int y, int z)
{
	joystick_axis->x = x;
	joystick_axis->y = y;
	joystick_axis->z = z;

	// Bitwise AND
	joystick_button[0] = button & 0x0001;
	joystick_button[1] = button & 0x0002;
	joystick_button[2] = button & 0x0004;
	joystick_button[3] = button & 0x0008;
	joystick_button[4] = button & 0x0010;
	joystick_button[5] = button & 0x0020;
	joystick_button[6] = button & 0x0040;
	joystick_button[7] = button & 0x0080;
	joystick_button[8] = button & 0x0100;
	joystick_button[9] = button & 0x0200;
	joystick_button[10] = button & 0x0400;
	joystick_button[11] = button & 0x0800;

	return;
};
*/

void my_randomize()
{
	int stime = 0;
	long ltime = 0;
	ltime = time(NULL);
	stime = (unsigned)ltime/2;
	srand(stime);
};

int main(int argc, char **argv)
{
	if (argc == 2)
	{
		sscanf(argv[1], "%d", &user_input_story_progression);
	}
	else user_input_story_progression = 0;

	my_randomize();

	camera_pos = new _Point();
	camera_rot = new _Point();
	camera_vel = new _Point();

	mouse = new _Mouse();
//	joystick_axis = new _Joystick();

	projectile_pos[0] = new _Point();
	projectile_pos[1] = new _Point();
	projectile_rot[0] = new _Point();
	projectile_rot[1] = new _Point();

	for (int i=0; i<MAX_BOTS; i++)
	{
		bot_pos[i] = new _Point();
		bot_rot[i] = new _Point();
		bot_primary_color[i] = new _Point();
		bot_secondary_color[i] = new _Point();
	}

	for (int i=0; i<MAX_PARTICLES; i++)
	{
		particle_pos[i] = new _Point();
		particle_vel[i] = new _Point();
	}
	
	for (int i=0; i<MAX_BOXES; i++)
	{
		box_pos[i] = new _Point();
		box_size[i] = new _Point();
		box_color[i] = new _Point();
	}

	for (int i=0; i<MAX_ITEMS; i++)
	{	
		item_pos[i] = new _Point();
	}

	for (int i=0; i<MAX_WALLS; i++)
	{
		x_wall[i] = new _Point();
		x_wall_color[i] = new _Point();
		z_wall[i] = new _Point();
		z_wall_color[i] = new _Point();
	}

	human_rotations = new _Rotations();

	human_prev_rot = new _Rotations();
	human_next_rot = new _Rotations();

	glutInit(&argc, argv);

	glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);

	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

	glutCreateWindow("Linearity");

	glutDisplayFunc(OpenGLDisplayFunction);
	glutIdleFunc(OpenGLIdleFunction);
	glutKeyboardFunc(OpenGLKeyboardFunction);
	glutKeyboardUpFunc(OpenGLKeyboardUpFunction);
	glutSpecialFunc(OpenGLSpecialKeyboardFunction);
	glutSpecialUpFunc(OpenGLSpecialKeyboardUpFunction);
	glutMouseFunc(OpenGLMouseFunction);
	glutPassiveMotionFunc(OpenGLPassiveMotionFunction);
//	glutJoystickFunc(OpenGLJoystickFunction, 50);

	OpenGLSetupFunction(WINDOW_WIDTH, WINDOW_HEIGHT);

	glutFullScreen();
	glutSetCursor(GLUT_CURSOR_NONE);

   	glutMainLoop();


	delete camera_pos;
	delete camera_rot;
	delete camera_vel;

	delete mouse;
//	delete joystick_axis;

	delete projectile_pos[0];
	delete projectile_pos[1];
	delete projectile_rot[0];
	delete projectile_rot[1];

	for (int i=0; i<MAX_BOTS; i++)
	{
		delete bot_pos[i];
		delete bot_rot[i];
		delete bot_primary_color[i];
		delete bot_secondary_color[i];
	}

	for (int i=0; i<MAX_PARTICLES; i++)
	{
		delete particle_pos[i];
		delete particle_vel[i];
	}

	for (int i=0; i<MAX_BOXES; i++)
	{
		delete box_pos[i];
		delete box_size[i];
		delete box_color[i];
	}

	for (int i=0; i<MAX_ITEMS; i++)
	{	
		delete item_pos[i];
	}

	for (int i=0; i<MAX_WALLS; i++)
	{
		delete x_wall[i];
		delete x_wall_color[i];
		delete z_wall[i];
		delete z_wall_color[i];
	}

	delete human_rotations;

	delete human_prev_rot;
	delete human_next_rot;

	return 0;
}
