
/*
const int TEXTURE_BLANK = 0;
const int TEXTURE_TRANSPARENT = 1;

GLuint texture[10];
*/

// Robot models
const float male_upper_torso_point[6*3] = {

-1.0f, 0.0f, 0.5f,
0.0f, -2.0f, 0.25f,
1.0f, 0.0f, 0.5f,
-1.0f, 0.0f, -0.5f,
0.0f, -2.0f, -0.25f,
1.0f, 0.0f, -0.5f,

};

const int male_upper_torso_indice[8*3] = {

0, 1, 2,
5, 4, 3,
3, 0, 2,
3, 2, 5,
3, 4, 1,
3, 1, 0,
2, 1, 4,
2, 4, 5,

};

const float female_upper_torso_point[8*3] = {

-0.5f, 0.0f, 0.25f,
0.0f, -1.5f, 0.25f,
0.5f, 0.0f, 0.25f,
-0.5f, 0.0f, -0.25f,
0.0f, -1.5f, -0.25f,
0.5f, 0.0f, -0.25f,
-0.3f, -0.6f, 0.4f,
0.3f, -0.6f, 0.4f,

};

const int female_upper_torso_indice[12*3] = {

0, 1, 6,
2, 7, 1,
0, 6, 7,
0, 7, 2,
6, 1, 7,
5, 4, 3,
3, 0, 2,
3, 2, 5,
3, 4, 1,
3, 1, 0,
2, 1, 4,
2, 4, 5,

};

const float male_middle_torso_point[10*3] = {

0.0f, 0.25f, 0.0f,
-0.25f, 0.0f, 0.0f,
-0.18f, 0.0f, 0.18f,
0.0f, 0.0f, 0.25f,
0.18f, 0.0f, 0.18f,
0.25f, 0.0f, 0.0f,
0.18f, 0.0f, -0.18f,
0.0f, 0.0f, -0.25f,
-0.18f, 0.0f, -0.18f,
0.0f, -0.25f, 0.0f,

};

const int male_middle_torso_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float female_middle_torso_point[10*3] = {

0.0f, 0.125f, 0.0f,
-0.125f, 0.0f, 0.0f,
-0.09f, 0.0f, 0.09f,
0.0f, 0.0f, 0.125f,
0.09f, 0.0f, 0.09f,
0.125f, 0.0f, 0.0f,
0.09f, 0.0f, -0.09f,
0.0f, 0.0f, -0.125f,
-0.09f, 0.0f, -0.09f,
0.0f, -0.125f, 0.0f,

};

const int female_middle_torso_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float male_lower_torso_point[6*3] = {

0.0f, 0.0f, 0.25f,
-0.5f, -0.5f, 0.25f,
0.5f, -0.5f, 0.25f,
0.0f, 0.0f, -0.25f,
-0.5f, -0.5f, -0.25f,
0.5f, -0.5f, -0.25f,

};

const int male_lower_torso_indice[8*3] = {

0, 1, 2,
3, 5, 4,
3, 4, 1,
3, 1, 0,
0, 2, 5,
0, 5, 3,
1, 4, 5,
1, 5, 2,

};

const float female_lower_torso_point[6*3] = {

0.0f, 0.0f, 0.25f,
-0.75f, -1.0f, 0.25f,
0.75f, -1.0f, 0.25f,
0.0f, 0.0f, -0.25f,
-0.75f, -1.0f, -0.25f,
0.75f, -1.0f, -0.25f,

};

const int female_lower_torso_indice[8*3] = {

0, 1, 2,
3, 5, 4,
3, 4, 1,
3, 1, 0,
0, 2, 5,
0, 5, 3,
1, 4, 5,
1, 5, 2,

};

const float male_upper_arm_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.05f, -1.5f, 0.05f,
0.05f, -1.5f, 0.05f,
0.05f, -1.5f, -0.05f,
-0.05f, -1.5f, -0.05f,

};

const int male_upper_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_upper_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.05f, -1.25f, 0.05f,
0.05f, -1.25f, 0.05f,
0.05f, -1.25f, -0.05f,
-0.05f, -1.25f, -0.05f,

};

const int female_upper_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_lower_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.25f, -1.5f, 0.25f,
0.25f, -1.5f, 0.25f,
0.25f, -1.5f, -0.25f,
-0.25f, -1.5f, -0.25f,

};

const int male_lower_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_lower_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.15f, -1.25f, 0.15f,
0.15f, -1.25f, 0.15f,
0.15f, -1.25f, -0.15f,
-0.15f, -1.25f, -0.15f,

};

const int female_lower_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_upper_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.15f, -2.0f, 0.15f,
0.15f, -2.0f, 0.15f,
0.15f, -2.0f, -0.15f,
-0.15f, -2.0f, -0.15f,

};

const int male_upper_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_upper_leg_point[8*3] = {

-0.25f, -0.1f, 0.25f,
0.25f, -0.1f, 0.25f,
0.25f, -0.1f, -0.25f,
-0.25f, -0.1f, -0.25f,
-0.15f, -2.0f, 0.15f,
0.15f, -2.0f, 0.15f,
0.15f, -2.0f, -0.15f,
-0.15f, -2.0f, -0.15f,

};

const int female_upper_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_lower_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.35f, -2.0f, 0.35f,
0.35f, -2.0f, 0.35f,
0.35f, -2.0f, -0.35f,
-0.35f, -2.0f, -0.35f,

};


const int male_lower_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_lower_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.35f, -2.0f, 0.35f,
0.35f, -2.0f, 0.35f,
0.35f, -2.0f, -0.35f,
-0.35f, -2.0f, -0.35f,

};

const int female_lower_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_head_point[16*3] = {

0.5f, 1.0f, 0.25f,
0.5f, 1.0f, -0.25f,
-0.5f, 1.0f, -0.25f,
-0.5f, 1.0f, 0.25f,
0.5f, 0.0f, 0.25f,
0.5f, 0.0f, -0.25f,
-0.5f, 0.0f, -0.25f,
-0.5f, 0.0f, 0.25f,

};

const int male_head_indice[12*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
5, 4, 7,
5, 7, 6,

};

const float female_head_point[16*3] = {

0.4f, 1.0f, 0.25f,
0.4f, 1.0f, -0.25f,
-0.4f, 1.0f, -0.25f,
-0.4f, 1.0f, 0.25f,
0.25f, 0.0f, 0.25f,
0.25f, 0.0f, -0.25f,
-0.25f, 0.0f, -0.25f,
-0.25f, 0.0f, 0.25f,

};

const int female_head_indice[12*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
5, 4, 7,
5, 7, 6,

};

const float male_visor_point[8*3] = {

0.4f, 0.55f, -0.25f,
0.4f, 0.55f, -0.3f,
-0.4f, 0.55f, -0.3f,
-0.4f, 0.55f, -0.25f,
0.4f, 0.45f, -0.25f,
0.4f, 0.45f, -0.3f,
-0.4f, 0.45f, -0.3f,
-0.4f, 0.45f, -0.25f,

};

const int male_visor_indice[10*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
5, 4, 7,
5, 7, 6,

};

const float female_visor_point[8*3] = {

0.275f, 0.55f, -0.25f,
0.275f, 0.55f, -0.3f,
-0.275f, 0.55f, -0.3f,
-0.275f, 0.55f, -0.25f,
0.275f, 0.45f, -0.25f,
0.275f, 0.45f, -0.3f,
-0.275f, 0.45f, -0.3f,
-0.275f, 0.45f, -0.25f,

};

const int female_visor_indice[10*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
5, 4, 7,
5, 7, 6,

};

const float large_joint_point[10*3] = {

0.0f, 0.25f, 0.0f,
-0.25f, 0.0f, 0.0f,
-0.18f, 0.0f, 0.18f,
0.0f, 0.0f, 0.25f,
0.18f, 0.0f, 0.18f,
0.25f, 0.0f, 0.0f,
0.18f, 0.0f, -0.18f,
0.0f, 0.0f, -0.25f,
-0.18f, 0.0f, -0.18f,
0.0f, -0.25f, 0.0f,

};

const int large_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,

0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float medium_joint_point[10*3] = {

0.0f, 0.15f, 0.0f,
-0.15f, 0.0f, 0.0f,
-0.11f, 0.0f, 0.11f,
0.0f, 0.0f, 0.15f,
0.11f, 0.0f, 0.11f,
0.15f, 0.0f, 0.0f,
0.11f, 0.0f, -0.11f,
0.0f, 0.0f, -0.15f,
-0.11f, 0.0f, -0.11f,
0.0f, -0.15f, 0.0f,

};

const int medium_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float small_joint_point[10*3] = {

0.0f, 0.05f, 0.0f,
-0.05f, 0.0f, 0.0f,
-0.04f, 0.0f, 0.04f,
0.0f, 0.0f, 0.05f,
0.04f, 0.0f, 0.04f,
0.05f, 0.0f, 0.0f,
0.04f, 0.0f, -0.04f,
0.0f, 0.0f, -0.05f,
-0.04f, 0.0f, -0.04f,
0.0f, -0.05f, 0.0f,

};

const int small_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float hammer_point[18*3] = {

	-0.05f, 0.05f, 2.0f, // 0
	0.05f, 0.05f, 2.0f,
	0.05f, -0.05f, 2.0f,
	-0.05f, -0.05f, 2.0f,
	-0.05f, 0.05f, -1.0f,
	0.05f, 0.05f, -1.0f,
	0.05f, -0.05f, -1.0f,
	-0.05f, -0.05f, -1.0f,

	-0.1f, 0.1f, -1.0f, // 8
	0.1f, 0.1f, -1.0f,
	0.2f, -0.9f, -0.9f,
	-0.2f, -0.9f, -0.9f,
	-0.1f, 0.1f, -1.2f,
	0.1f, 0.1f, -1.2f,
	0.2f, -0.9f, -1.3f,
	-0.2f, -0.9f, -1.3f,
	
	0.0f, 1.0f, -0.9f, // 16
	0.0f, -1.0f, -1.1f,
};

const int hammer_indice[26*3] = {

	0, 5, 4, // 0
	0, 1, 5,
	1, 6, 5,
	1, 2, 6,
	2, 7, 6,
	2, 3, 7,
	3, 4, 7,
	3, 0, 4,

	0, 2, 1, // 8
	0, 3, 2,

	9, 14, 13, // 10
	9, 10, 14,
	11, 12, 15,
	11, 8, 12,

	8, 10, 9, // 14
	8, 11, 10,
	12, 14, 15,
	12, 13, 14,

	16, 13, 12, // 18
	16, 9, 13,
	16, 8, 9,
	16, 12, 8,
	
	17, 15, 14, // 22
	17, 11, 15,
	17, 10, 11,
	17, 14, 10,
};

const float scythe_point[20*3] = {

	-0.05f, 0.05f, 2.0f, // 0
	0.05f, 0.05f, 2.0f,
	0.05f, -0.05f, 2.0f,
	-0.05f, -0.05f, 2.0f,
	-0.05f, 0.05f, -1.0f,
	0.05f, 0.05f, -1.0f,
	0.05f, -0.05f, -1.0f,
	-0.05f, -0.05f, -1.0f,

	-0.1f, 0.1f, -1.0f, // 8
	0.1f, 0.1f, -1.0f,
	0.1f, -0.1f, -1.0f,
	-0.1f, -0.1f, -1.0f,
	-0.1f, 0.1f, -1.2f,
	0.1f, 0.1f, -1.2f,
	0.1f, -0.1f, -1.2f,
	-0.1f, -0.1f, -1.2f,

	-0.1f, -0.2f, -1.2f, // 16
	0.1f, -0.2f, -1.2f,
	0.0f, -0.2f, -1.0f,
	
	0.0f, -3.0f, -0.6f, // 19
};

const int scythe_indice[30*3] = {

	0, 5, 4, // 0
	0, 1, 5,
	1, 6, 5,
	1, 2, 6,
	2, 7, 6,
	2, 3, 7,
	3, 4, 7,
	3, 0, 4,

	0, 2, 1, // 8
	0, 3, 2,

	8, 13, 12, // 10
	8, 9, 13,
	9, 14, 13,
	9, 10, 14,
	11, 12, 15,
	11, 8, 12,

	8, 10, 9, // 16
	8, 11, 10,
	12, 14, 15,
	12, 13, 14,
	
	15, 17, 16, // 20
	15, 14, 17,
	15, 16, 18,
	15, 18, 11,
	14, 18, 17,
	14, 10, 18,
	18, 10, 11,
	
	16, 17, 19, // 27
	16, 19, 18,
	17, 18, 19,
};

const float fishing_pole_point[8*3] = {

	-0.05f, 0.05f, 1.0f, // 0
	0.05f, 0.05f, 1.0f,
	0.05f, -0.05f, 1.0f,
	-0.05f, -0.05f, 1.0f,
	-0.01f, 0.01f, -3.0f,
	0.01f, 0.01f, -3.0f,
	0.01f, -0.01f, -3.0f,
	-0.01f, -0.01f, -3.0f,
};

const int fishing_pole_indice[12*3] = {

	0, 5, 4, // 0
	0, 1, 5,
	1, 6, 5,
	1, 2, 6,
	2, 7, 6,
	2, 3, 7,
	3, 4, 7,
	3, 0, 4,

	0, 2, 1, // 8
	0, 3, 2,
	
	4, 7, 6,
	4, 6, 5,
};


// Draws single component
void DrawComponent(const float *point, const int *indice, const int NUM_TRIANGLES)
{
	//glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]); // blank

	for (int i=0; i<NUM_TRIANGLES; i++)
	{	
		glBegin(GL_TRIANGLES);
		
		glNormal3f((point[indice[i*3+1]*3+1] - point[indice[i*3+0]*3+1]) * (point[indice[i*3+2]*3+2] - point[indice[i*3+0]*3+2]) -
			(point[indice[i*3+1]*3+2] - point[indice[i*3+0]*3+2]) * (point[indice[i*3+2]*3+1] - point[indice[i*3+0]*3+1]),
			-(point[indice[i*3+1]*3+0] - point[indice[i*3+0]*3+0]) * (point[indice[i*3+2]*3+2] - point[indice[i*3+0]*3+2]) +
			(point[indice[i*3+1]*3+2] - point[indice[i*3+0]*3+2]) * (point[indice[i*3+2]*3+0] - point[indice[i*3+0]*3+0]),
			(point[indice[i*3+1]*3+0] - point[indice[i*3+0]*3+0]) * (point[indice[i*3+2]*3+1] - point[indice[i*3+0]*3+1]) -
			(point[indice[i*3+1]*3+1] - point[indice[i*3+0]*3+1]) * (point[indice[i*3+2]*3+0] - point[indice[i*3+0]*3+0]));
		glVertex3f(point[indice[i*3+0]*3+0], point[indice[i*3+0]*3+1], point[indice[i*3+0]*3+2]);
		glVertex3f(point[indice[i*3+1]*3+0], point[indice[i*3+1]*3+1], point[indice[i*3+1]*3+2]);
		glVertex3f(point[indice[i*3+2]*3+0], point[indice[i*3+2]*3+1], point[indice[i*3+2]*3+2]);

		glEnd();
	}

	return;
};

// sex: 0 = male, 1 = female
// attachment: 0 = none, 1 = hammer, 2 = scythe
// animation_type: 0 = standing, 1 = jumping, 2 = walking, 3 = running, 4 = melee attack, 5 = self-spell
void DrawRobot(int sex, int attachment, float universal_y_rot, float *primary_color, float *secondary_color, int animation_type, float &animation_timer)
{
	//animation_timer += 0.1f;
	//if (animation_timer > 6.28f) animation_timer -= 6.28f;

	float rot_x = 0.0f, rot_y = 0.0f;

	float hip[3][2], knee[3][2], shoulder[3][2], elbow[3][2], neck[3];

	if (animation_type == 0) // standing
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}
	}
	else if (animation_type == 1) // jumping in place
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		hip[0][0] = 60.0f;
		hip[0][1] = 60.0f;
		knee[0][0] = -120.0f;
		knee[0][1] = -120.0f;
	}
	else if (animation_type == 2) // walking
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		hip[0][0] = 30.0f * sin(animation_timer);
		hip[0][1] = 30.0f * sin(animation_timer + 3.14159f);
		knee[0][0] = -30.0f * sin(animation_timer + 1.57f) - 30.0f;
		knee[0][1] = -30.0f * sin(animation_timer + 3.14159f + 1.57f) - 30.0f;

		shoulder[0][0] = 30.0f * sin(animation_timer + 3.14159f); 
		shoulder[0][1] = 30.0f * sin(animation_timer); 
	}
	else if (animation_type == 3) // running
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		hip[0][0] = 60.0f * sin(animation_timer);
		hip[0][1] = 60.0f * sin(animation_timer + 3.14159f);
		knee[0][0] = -60.0f * sin(animation_timer + 1.57f) - 60.0f;
		knee[0][1] = -60.0f * sin(animation_timer + 3.14159f + 1.57f) - 60.0f;

		shoulder[0][0] = 45.0f * sin(animation_timer + 3.14159f); 
		elbow[0][0] = 90.0f;
		shoulder[0][1] = 45.0f * sin(animation_timer); 
		elbow[0][1] = 90.0f;
	}
	else if (animation_type == 4) // melee
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		shoulder[2][0] = 45.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		
		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;
	}
	else if (animation_type == 5) // spell
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		shoulder[2][0] = 45.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		
		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;
	}
	
	if (sex == 0) // male
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
		glTranslatef(0.0f, 4.5f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_torso_point, male_lower_torso_indice, 8);

		glTranslatef(-0.25f, -0.5f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_leg_point, male_upper_leg_indice, 12);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_leg_point, male_lower_leg_indice, 12);

		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.25f, 0.5f, 0.0f);

		glTranslatef(0.25f, -0.5f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_leg_point, male_upper_leg_indice, 12);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_leg_point, male_lower_leg_indice, 12);

		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.25f, 0.5f, 0.0f);
	
		glRotatef(rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glRotatef(rot_x/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(male_middle_torso_point, male_middle_torso_indice, 16);
	
		glRotatef(rot_x/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_torso_point, male_upper_torso_indice, 8);

		glTranslatef(-1.0f, -0.25f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_arm_point, male_upper_arm_indice, 12);

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_arm_point, male_lower_arm_indice, 12);

		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(1.0f, 0.25f, 0.0f);

		glTranslatef(1.0f, -0.25f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_arm_point, male_upper_arm_indice, 12);

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		if (attachment != 0 && animation_type < 3)
		{
			glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
		}

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);	

		if (attachment != 0 && animation_type < 3)
		{
			glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
		}
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_arm_point, male_lower_arm_indice, 12);
		
		if (attachment == 1) // hammer
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(hammer_point, hammer_indice, 26);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == 2) // scythe
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(scythe_point, scythe_indice, 30);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == 3) // pole
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		if (attachment != 0 && animation_type < 3)
		{
			glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
		}

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);

		if (attachment != 0 && animation_type < 3)
		{
			glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
		}

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-1.0f, 0.25f, 0.0f);

		glTranslatef(0.0f, 0.1f, 0.0f);
		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_head_point, male_head_indice, 12);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(male_visor_point, male_visor_indice, 10);

		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, -0.1f, 0.0f);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-rot_x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glRotatef(-rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);		

		glTranslatef(0.0f, -4.5f, 0.0f);
		glRotatef(90.0f, 0.0f, 1.0f, 0.0f);		
	}
	else if (sex == 1) // female
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
		glTranslatef(0.0f, 5.0f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_torso_point, female_lower_torso_indice, 8);

		glTranslatef(-0.25f, -1.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_leg_point, female_upper_leg_indice, 12);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_leg_point, female_lower_leg_indice, 12);

		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.25f, 1.0f, 0.0f);

		glTranslatef(0.25f, -1.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_leg_point, female_upper_leg_indice, 12);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_leg_point, female_lower_leg_indice, 12);

		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.25f, 1.0f, 0.0f);

		glRotatef(rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glRotatef(rot_x/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(female_middle_torso_point, female_middle_torso_indice, 16);
	
		glRotatef(rot_x/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);

		glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_torso_point, female_upper_torso_indice, 12);
		glRotatef(-180.0f, 0.0f, 1.0f, 0.0f);

		glTranslatef(-0.475f, -0.225f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);

		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_arm_point, female_upper_arm_indice, 12);

		glTranslatef(0.0f, -1.25f, 0.0f);
		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);	
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_arm_point, female_lower_arm_indice, 12);

		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.25f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.475f, 0.225f, 0.0f);

		glTranslatef(0.475f, -0.225f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);

		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_arm_point, female_upper_arm_indice, 12);

		glTranslatef(0.0f, -1.25f, 0.0f);
		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		if (attachment != 0 && animation_type < 3)
		{
			glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
		}

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		if (attachment != 0 && animation_type < 3)
		{
			glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
		}
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_arm_point, female_lower_arm_indice, 12);

		if (attachment == 1) // hammer
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(hammer_point, hammer_indice, 26);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == 2) // scythe
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(scythe_point, scythe_indice, 30);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == 3) // pole
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		if (attachment != 0 && animation_type < 3)
		{
			glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
		}

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);

		if (attachment != 0 && animation_type < 3)
		{
			glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
		}

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.25f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.475f, 0.225f, 0.0f);

		glTranslatef(0.0f, 0.05f, 0.0f);
		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_head_point, female_head_indice, 12);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(female_visor_point, female_visor_indice, 10);

		glRotatef(-neck[0], 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1], 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[2], 1.0f, 0.0f, 0.0f);
		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, -0.05f, 0.0f);

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(-rot_x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glRotatef(-rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		
		glTranslatef(0.0f, -5.0f, 0.0f);
		glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	}

	if (animation_type == 4) // melee
	{
		glTranslatef(0.0f, 0.3f, 0.0f);

		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 5) // spell
	{
		glTranslatef(0.0f, 0.3f, 0.0f);

		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}

	glColor3f(1,1,1);

	return;
};
