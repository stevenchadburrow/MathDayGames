// Roller.cpp

/*
This small game is for the 2016 Math Day video game presentations.  I created the basics within 5 hours on a rainy Friday :)

Drive the 'roller' around, and pick up coins, couldn't be easier.  Platforms hold the roller up, and boosters push the roller into the air.

It's not as cool as the 2015 Math Day "Arena / Zapper" combo, but I plan on putting this on a third or fourth computer along side them, just adding to the fun!
*/

/*
In order to run this on Linux, you must include -lglut and -lGLU when compiling.
g++ -o Main.o Main.cpp -lglut -lGLU -lGL
./Main.o
Also make sure you have all of the glut and/or freeglut packages downloaded, GLU, maybe OpenGL Mesa Dev packages??

In order to run this on Windows, use Dev-C++.  Start a Multimedia Project with glut, not an empty project like normal.
To get that project, you need to go to Tools->Packages and download all glut and/or freeglut packages.
Remember that the Project Options->Linker has to have stuff like -lwinmm -lglut -lglut32 -lopengl32  (Something with GLU) etc....
*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <GL/glut.h>

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

bool keyboard[256], special_keyboard[256];
int joystick_button[32];
bool joystick_enabled = false;
GLuint texture[5];
int frames_per_second = 0, frames_per_second_counter = 0, frames_per_second_timer = 0;

class _Point {
public:
	_Point()
	{
		x = y = z = 0.0f;
	}

	float x, y, z;
	
	void Set(float my_x, float my_y, float my_z)
	{
		x = my_x;
		y = my_y;
		z = my_z;
	
		return;
	}

} *camera_pos, *camera_rot;

class _Mouse {
public:
	_Mouse()
	{
		x = y = 0;
	
		button = 0;
		state = 0;
	}

	int x, y;

	int button, state;

} *mouse;

class _Joystick {
public:
	_Joystick()
	{
		x = y = z = 0;
	}

	int x, y, z;

} *joystick_axis;

_Point *roller_pos;
_Point *roller_vel;
_Point *roller_rot;

_Point *platform1[10];
_Point *platform2[10];

float platform_color_r[10] = { 1.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.0f, 0.75f, 0.75f, 0.0f, 1.0f };
float platform_color_g[10] = { 0.0f, 1.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.75f, 0.0f, 0.75f, 1.0f };
float platform_color_b[10] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.75f, 0.75f, 1.0f };

_Point *booster1[10];
_Point *booster2[10];

float booster_color_r[10] = { 0.75f, 0.75f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.5f, 0.0f, 0.0f };
float booster_color_g[10] = { 0.75f, 0.0f, 0.75f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.5f, 0.0f };
float booster_color_b[10] = { 0.0f, 0.75f, 0.75f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.5f };

_Point *wall1, *wall2;

_Point *coin_pos[20];
_Point *coin_rot[20];

bool sound_on = true; // turns on or off sound

int screen = 0;

bool key_down = false;

float effects_timer = 0.0f;

unsigned long start_time, old_start_time, finish_time;

int coins_collected;

char command_string[256];

clock_t compute_milli_timer;

void DrawRoller(float rotation)
{
	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glBegin(GL_TRIANGLES);

	glColor3f(0.75f, 0.75f, 1.0f);

	for (int i=0; i<6; i++)
	{
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glVertex3f(-1.0f, 0.0f, 0.0f);
		glVertex3f(-1.0f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(-1.0f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(1.0f, 0.0f, 0.0f);
		glVertex3f(-0.75f, 0.0f, 0.0f);
		glVertex3f(-0.75f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(-0.75f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(0.0f, sin(3.14159f * (float)(i+0.5f) / 3.0f), cos(3.14159f * (float)(i+0.5f) / 3.0f));
		glVertex3f(-1.0f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(-1.0f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));
		glVertex3f(-0.75f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(0.0f, sin(3.14159f * (float)(i+0.5f) / 3.0f), cos(3.14159f * (float)(i+0.5f) / 3.0f));
		glVertex3f(-1.0f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(-0.75f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));
		glVertex3f(-0.75f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));


		glNormal3f(-1.0f, 0.0f, 0.0f);
		glVertex3f(0.75f, 0.0f, 0.0f);
		glVertex3f(0.75f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(0.75f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(1.0f, 0.0f, 0.0f);
		glVertex3f(1.0f, 0.0f, 0.0f);
		glVertex3f(1.0f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(1.0f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(0.0f, sin(3.14159f * (float)(i+0.5f) / 3.0f), cos(3.14159f * (float)(i+0.5f) / 3.0f));
		glVertex3f(0.75f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(0.75f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));
		glVertex3f(1.0f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(0.0f, sin(3.14159f * (float)(i+0.5f) / 3.0f), cos(3.14159f * (float)(i+0.5f) / 3.0f));
		glVertex3f(0.75f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(1.0f, 1.0f * sin(3.14159f * (float)(i+1) / 3.0f), 1.0f * cos(3.14159f * (float)(i+1) / 3.0f));
		glVertex3f(1.0f, 1.0f * sin(3.14159f * (float)i / 3.0f), 1.0f * cos(3.14159f * (float)i / 3.0f));
	}

	glEnd();


	glRotatef(rotation * 180.0f / 3.14159f, 1, 0, 0);

	glBegin(GL_TRIANGLES);

	glColor3f(0.75f, 0.75f, 0.75f);

	for (int i=0; i<12; i++)
	{
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glVertex3f(-0.5f, 0.0f, 0.0f);
		glVertex3f(-0.5f, 2.0f * sin(3.14159f * (float)i / 6.0f), 2.0f * cos(3.14159f * (float)i / 6.0f));
		glVertex3f(-0.5f, 2.0f * sin(3.14159f * (float)(i+1) / 6.0f), 2.0f * cos(3.14159f * (float)(i+1) / 6.0f));

		glNormal3f(1.0f, 0.0f, 0.0f);
		glVertex3f(0.5f, 0.0f, 0.0f);
		glVertex3f(0.5f, 2.0f * sin(3.14159f * (float)i / 6.0f), 2.0f * cos(3.14159f * (float)i / 6.0f));
		glVertex3f(0.5f, 2.0f * sin(3.14159f * (float)(i+1) / 6.0f), 2.0f * cos(3.14159f * (float)(i+1) / 6.0f));

		glNormal3f(0.0f, sin(3.14159f * (float)(i+0.5f) / 6.0f), cos(3.14159f * (float)(i+0.5f) / 6.0f));
		glVertex3f(-0.5f, 2.0f * sin(3.14159f * (float)i / 6.0f), 2.0f * cos(3.14159f * (float)i / 6.0f));
		glVertex3f(-0.5f, 2.0f * sin(3.14159f * (float)(i+1) / 6.0f), 2.0f * cos(3.14159f * (float)(i+1) / 6.0f));
		glVertex3f(0.5f, 2.0f * sin(3.14159f * (float)(i+1) / 6.0f), 2.0f * cos(3.14159f * (float)(i+1) / 6.0f));

		glNormal3f(0.0f, sin(3.14159f * (float)(i+0.5f) / 6.0f), cos(3.14159f * (float)(i+0.5f) / 6.0f));
		glVertex3f(-0.5f, 2.0f * sin(3.14159f * (float)i / 6.0f), 2.0f * cos(3.14159f * (float)i / 6.0f));
		glVertex3f(0.5f, 2.0f * sin(3.14159f * (float)(i+1) / 6.0f), 2.0f * cos(3.14159f * (float)(i+1) / 6.0f));
		glVertex3f(0.5f, 2.0f * sin(3.14159f * (float)i / 6.0f), 2.0f * cos(3.14159f * (float)i / 6.0f));
	}

	glEnd();

	glRotatef(-rotation * 180.0f / 3.14159f, 1, 0, 0);

	return;
};

void DrawPlatform(float x1, float z1, float x2, float z2, float height)
{
	glBegin(GL_QUADS);
	
	glNormal3f(0,1,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z1);
	glTexCoord2f(0,2);
	glVertex3f(x1, height, z2);
	glTexCoord2f(2,2);
	glVertex3f(x2, height, z2);
	glTexCoord2f(2,0);
	glVertex3f(x2, height, z1);

	glNormal3f(0,-1,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height-5, z1);
	glTexCoord2f(0,2);
	glVertex3f(x1, height-5, z2);
	glTexCoord2f(2,2);
	glVertex3f(x2, height-5, z2);
	glTexCoord2f(2,0);
	glVertex3f(x2, height-5, z1);
	
	glNormal3f(-1,0,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z1);
	glTexCoord2f(0,0.1);
	glVertex3f(x1, height-5, z1);
	glTexCoord2f(2,0.1);
	glVertex3f(x1, height-5, z2);
	glTexCoord2f(2,0);
	glVertex3f(x1, height, z2);

	glNormal3f(1,0,0);
	glTexCoord2f(0,0);
	glVertex3f(x2, height, z1);
	glTexCoord2f(0,0.1);
	glVertex3f(x2, height-5, z1);
	glTexCoord2f(2,0.1);
	glVertex3f(x2, height-5, z2);
	glTexCoord2f(2,0);
	glVertex3f(x2, height, z2);

	glNormal3f(0,0,-1);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z1);
	glTexCoord2f(0,0.1);
	glVertex3f(x1, height-5, z1);
	glTexCoord2f(2,0.1);
	glVertex3f(x2, height-5, z1);
	glTexCoord2f(2,0);
	glVertex3f(x2, height, z1);

	glNormal3f(0,0,1);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z2);
	glTexCoord2f(0,0.1);
	glVertex3f(x1, height-5, z2);
	glTexCoord2f(2,0.1);
	glVertex3f(x2, height-5, z2);
	glTexCoord2f(2,0);
	glVertex3f(x2, height, z2);

	glEnd();

	return;
};

void DrawBridge(float x1, float z1, float x2, float z2, float height)
{
	glBegin(GL_QUADS);
	
	glNormal3f(0,1,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z1);
	glTexCoord2f(0,2);
	glVertex3f(x1, height, z2);
	glTexCoord2f(0.1,2);
	glVertex3f(x2, height, z2);
	glTexCoord2f(0.1,0);
	glVertex3f(x2, height, z1);

	glNormal3f(0,-1,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height-5, z1);
	glTexCoord2f(0,2);
	glVertex3f(x1, height-5, z2);
	glTexCoord2f(0.1,2);
	glVertex3f(x2, height-5, z2);
	glTexCoord2f(0.1,0);
	glVertex3f(x2, height-5, z1);
	
	glNormal3f(-1,0,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z1);
	glTexCoord2f(0,0.1);
	glVertex3f(x1, height-5, z1);
	glTexCoord2f(2,0.1);
	glVertex3f(x1, height-5, z2);
	glTexCoord2f(2,0);
	glVertex3f(x1, height, z2);

	glNormal3f(1,0,0);
	glTexCoord2f(0,0);
	glVertex3f(x2, height, z1);
	glTexCoord2f(0,0.1);
	glVertex3f(x2, height-5, z1);
	glTexCoord2f(2,0.1);
	glVertex3f(x2, height-5, z2);
	glTexCoord2f(2,0);
	glVertex3f(x2, height, z2);

	glNormal3f(0,0,-1);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z1);
	glTexCoord2f(0,0.1);
	glVertex3f(x1, height-5, z1);
	glTexCoord2f(0.1,0.1);
	glVertex3f(x2, height-5, z1);
	glTexCoord2f(0.1,0);
	glVertex3f(x2, height, z1);

	glNormal3f(0,0,1);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z2);
	glTexCoord2f(0,0.1);
	glVertex3f(x1, height-5, z2);
	glTexCoord2f(0.1,0.1);
	glVertex3f(x2, height-5, z2);
	glTexCoord2f(0.1,0);
	glVertex3f(x2, height, z2);

	glEnd();

	return;
};

void DrawBooster(float x1, float z1, float x2, float z2, float height)
{
	glBegin(GL_QUADS);
	
	glNormal3f(0,1,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height+0.5f, z1);
	glTexCoord2f(0,1);
	glVertex3f(x1, height+0.5f, z2);
	glTexCoord2f(1,1);
	glVertex3f(x2, height+0.5f, z2);
	glTexCoord2f(1,0);
	glVertex3f(x2, height+0.5f, z1);

	//glNormal3f(0,-1,0);
	//glVertex3f(x1, height, z1);
	//glVertex3f(x1, height, z2);
	//glVertex3f(x2, height, z2);
	//glVertex3f(x2, height, z1);
	
	glNormal3f(-1,0,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height+0.5f, z1);
	glTexCoord2f(0,1);
	glVertex3f(x1, height, z1);
	glTexCoord2f(1,1);
	glVertex3f(x1, height, z2);
	glTexCoord2f(1,0);
	glVertex3f(x1, height+0.5f, z2);

	glNormal3f(1,0,0);
	glTexCoord2f(0,0);
	glVertex3f(x2, height+0.5f, z1);
	glTexCoord2f(0,1);
	glVertex3f(x2, height, z1);
	glTexCoord2f(1,1);
	glVertex3f(x2, height, z2);
	glTexCoord2f(1,0);
	glVertex3f(x2, height+0.5f, z2);

	glNormal3f(0,0,-1);
	glTexCoord2f(0,0);
	glVertex3f(x1, height+0.5f, z1);
	glTexCoord2f(0,1);
	glVertex3f(x1, height, z1);
	glTexCoord2f(1,1);
	glVertex3f(x2, height, z1);
	glTexCoord2f(1,0);
	glVertex3f(x2, height+0.5f, z1);

	glNormal3f(0,0,1);
	glTexCoord2f(0,0);
	glVertex3f(x1, height+0.5f, z2);
	glTexCoord2f(0,1);
	glVertex3f(x1, height, z2);	
	glTexCoord2f(1,1);
	glVertex3f(x2, height, z2);
	glTexCoord2f(1,0);
	glVertex3f(x2, height+0.5f, z2);

	glEnd();

	return;
};

void DrawWalls(float x1, float z1, float x2, float z2, float height)
{
	glColor3f(1,1,1);

	glBindTexture(GL_TEXTURE_2D, texture[2]);

	glBegin(GL_QUADS);

	glNormal3f(1,0,0);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z1);
	glTexCoord2f(0,2);
	glVertex3f(x1, 0.0f, z1);
	glTexCoord2f(2,2);
	glVertex3f(x1, 0.0f, z2);
	glTexCoord2f(2,0);
	glVertex3f(x1, height, z2);

	glNormal3f(-1,0,0);
	glTexCoord2f(0,0);
	glVertex3f(x2, height, z1);
	glTexCoord2f(0,2);
	glVertex3f(x2, 0.0f, z1);
	glTexCoord2f(2,2);
	glVertex3f(x2, 0.0f, z2);
	glTexCoord2f(2,0);
	glVertex3f(x2, height, z2);

	glNormal3f(0,0,1);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z1);
	glTexCoord2f(0,2);
	glVertex3f(x1, 0.0f, z1);
	glTexCoord2f(2,2);
	glVertex3f(x2, 0.0f, z1);
	glTexCoord2f(2,0);
	glVertex3f(x2, height, z1);

	glNormal3f(0,0,-1);
	glTexCoord2f(0,0);
	glVertex3f(x1, height, z2);
	glTexCoord2f(0,2);
	glVertex3f(x1, 0.0f, z2);
	glTexCoord2f(2,2);
	glVertex3f(x2, 0.0f, z2);
	glTexCoord2f(2,0);
	glVertex3f(x2, height, z2);

	glEnd();

	return;
};

void DrawCoin()
{
	glBegin(GL_TRIANGLES);

	glColor3f(1.0f, 1.0f, 0.5f);

	glBindTexture(GL_TEXTURE_2D, texture[0]);

	for (int i=0; i<6; i++)
	{
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glVertex3f(-0.25f, 0.0f, 0.0f);
		glVertex3f(-0.25f, 2.0f * sin(3.14159f * (float)i / 3.0f), 2.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(-0.25f, 2.0f * sin(3.14159f * (float)(i+1) / 3.0f), 2.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(1.0f, 0.0f, 0.0f);
		glVertex3f(0.25f, 0.0f, 0.0f);
		glVertex3f(0.25f, 2.0f * sin(3.14159f * (float)i / 3.0f), 2.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(0.25f, 2.0f * sin(3.14159f * (float)(i+1) / 3.0f), 2.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(0.0f, sin(3.14159f * (float)(i+0.5f) / 3.0f), cos(3.14159f * (float)(i+0.5f) / 3.0f));
		glVertex3f(-0.25f, 2.0f * sin(3.14159f * (float)i / 3.0f), 2.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(-0.25f, 2.0f * sin(3.14159f * (float)(i+1) / 3.0f), 2.0f * cos(3.14159f * (float)(i+1) / 3.0f));
		glVertex3f(0.25f, 2.0f * sin(3.14159f * (float)(i+1) / 3.0f), 2.0f * cos(3.14159f * (float)(i+1) / 3.0f));

		glNormal3f(0.0f, sin(3.14159f * (float)(i+0.5f) / 3.0f), cos(3.14159f * (float)(i+0.5f) / 3.0f));
		glVertex3f(-0.25f, 2.0f * sin(3.14159f * (float)i / 3.0f), 2.0f * cos(3.14159f * (float)i / 3.0f));
		glVertex3f(0.25f, 2.0f * sin(3.14159f * (float)(i+1) / 3.0f), 2.0f * cos(3.14159f * (float)(i+1) / 3.0f));
		glVertex3f(0.25f, 2.0f * sin(3.14159f * (float)i / 3.0f), 2.0f * cos(3.14159f * (float)i / 3.0f));
	}

	glEnd();

	return;
};

// Any picture in the .bmp format, 24 bit, should be good to go now.
bool LoadBitmap(const char *filename, GLuint &tex)
{
	FILE *bitmap;

	unsigned long int width, height;
	
	unsigned char *bits, *final;
	unsigned char header[54], temp;

	bitmap = fopen(filename, "rb");
	if (!bitmap) return false;

	fread(&header, 54, 1, bitmap);

	// If it's not a Bitmap, exit!
	if (256 * header[1] + header[0] != 19778)
	{
		fclose(bitmap);

		return false;
	}

	width = 256 * header[19] + header[18];
	height = 256 * header[23] + header[22];

	// Once the size is found, malloc() that much to 'bits' and read.
	bits = (unsigned char *) malloc(width*height*3);

	fread(bits, width*height*3, 1, bitmap);

	fclose(bitmap);

	// Flip the BGR pixels to RGB.
	for (int i=0; i<width*height*3; i+=3)
	{
		temp = bits[i];
		bits[i] = bits[i+2];
		bits[i+2] = temp;
	}

	final = (unsigned char *) malloc(width*height*4);

	unsigned long int count = 0;

	// Put in Alpha values.
	for (int i=0; i<width*height*3; i+=3)
	{
		final[count] = bits[i];
		count++;
		final[count] = bits[i+1];
		count++;
		final[count] = bits[i+2];
		count++;
		
		if (bits[i] == 0 && bits[i+1] == 0 && bits[i+2] == 0)
		{
			final[count] = 0;
			count++;
		}
		else
		{
			final[count] = 255;
			count++;
		}
	}
	
	// Remember each malloc() needs a free().
	free(bits);

	glGenTextures(1, &tex);
	glBindTexture(GL_TEXTURE_2D, tex);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, final);
	
	// Remember each malloc() needs a free().
	free(final);

	return true;
};

void OpenGLSetupFunction(int width, int height)
{
	glutWarpPointer(WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);


	for (int i=0; i<256; i++) 
	{
		keyboard[i] = false;
		special_keyboard[i] = false;
	}

	for (int i=0; i<32; i++) joystick_button[i] = 0;
	joystick_axis->x = 0;
	joystick_axis->y = 0;
	joystick_axis->z = 0;

	// If there is a joystick...
	if (glutDeviceGet(GLUT_HAS_JOYSTICK)) 
	{
		printf("Joystick Detected!\n");

		joystick_enabled = true;
	}

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (float)(width)/(float)(height), 0.1f, 10000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity(); 
	glEnable(GL_TEXTURE_2D);  
	glShadeModel(GL_SMOOTH);
	glClearColor(0.1f, 0.1f, 0.1f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);					
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	
	glAlphaFunc(GL_GREATER, 0.9f);									
	glEnable(GL_ALPHA_TEST);

	// allows colors to be still lit up      
	glEnable(GL_COLOR_MATERIAL);

	// lighting    
	GLfloat ambient[] = { 0.3f, 0.3f, 0.3f, 1.0f };  
	GLfloat diffuse[] = { 0.7f, 0.7f, 0.7f, 0.7f }; 
	GLfloat light_pos[] = { 0.0f, 1.0f, 1.0f, 1.0f };
	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);                          
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse); 
	glLightfv(GL_LIGHT1, GL_POSITION, light_pos);
	glEnable(GL_LIGHT1); 

	glFrontFace(GL_CCW);
	glEnable(GL_NORMALIZE);
	glEnable(GL_TEXTURE_2D);

	LoadBitmap("Blank.bmp", texture[0]);
	LoadBitmap("Transparent.bmp", texture[1]);
	LoadBitmap("Wall1.bmp", texture[2]);
	LoadBitmap("Base1.bmp", texture[3]);
	LoadBitmap("Platform1.bmp", texture[4]);

	glLineWidth(3);
	
	// INITIALIZE HERE!!!


	return;
};

void Setup()
{
	roller_pos->x = 0.0f;
	roller_pos->y = 0.0f;
	roller_pos->z = 0.0f;
	roller_vel->x = 0.0f;
	roller_vel->y = 0.0f;
	roller_vel->z = 0.0f;
	roller_rot->x = 0.0f;
	roller_rot->y = -3.14159f / 2.0f;
	roller_rot->z = 0.0f;

	for (int i=0; i<10; i++)
	{
		platform1[i]->x = 0.0f;
		platform1[i]->y = -1000.0f;
		platform1[i]->z = 0.0f;
		platform2[i]->x = 0.0f;
		platform2[i]->y = -1000.0f;
		platform2[i]->z = 0.0f;

		booster1[i]->x = 0.0f;
		booster1[i]->y = -1000.0f;
		booster1[i]->z = 0.0f;
		booster2[i]->x = 0.0f;
		booster2[i]->y = -1000.0f;
		booster2[i]->z = 0.0f;
	}

	platform1[0]->x = -1050.0f; // kindof required here
	platform1[0]->y = 0.0f;
	platform1[0]->z = -1050.0f;
	platform2[0]->x = 1050.0f;
	platform2[0]->y = 0.0f;
	platform2[0]->z = 1050.0f;

	platform1[1]->x = 500.0f;
	platform1[1]->y = 50.0f;
	platform1[1]->z = -200.0f;
	platform2[1]->x = 1050.0f;
	platform2[1]->y = 50.0f;
	platform2[1]->z = 200.0f;

	platform1[2]->x = 750.0f;
	platform1[2]->y = 100.0f;
	platform1[2]->z = 500.0f;
	platform2[2]->x = 1050.0f;
	platform2[2]->y = 100.0f;
	platform2[2]->z = 1050.0f;

	platform1[3]->x = -1050.0f;
	platform1[3]->y = 50.0f;
	platform1[3]->z = -1050.0f;
	platform2[3]->x = -500.0f;
	platform2[3]->y = 50.0f;
	platform2[3]->z = 0.0f;

	platform1[4]->x = 0.0f;
	platform1[4]->y = 100.0f;
	platform1[4]->z = -1050.0f;
	platform2[4]->x = 1050.0f;
	platform2[4]->y = 100.0f;
	platform2[4]->z = -900.0f;

	platform1[5]->x = 800.0f;
	platform1[5]->y = 150.0f;
	platform1[5]->z = -1050.0f;
	platform2[5]->x = 1050.0f;
	platform2[5]->y = 150.0f;
	platform2[5]->z = -250.0f;

	platform1[6]->x = 250.0f;
	platform1[6]->y = 200.0f;
	platform1[6]->z = -250.0f;
	platform2[6]->x = 500.0f;
	platform2[6]->y = 200.0f;
	platform2[6]->z = 0.0f;

	platform1[7]->x = 0.0f;
	platform1[7]->y = 250.0f;
	platform1[7]->z = 0.0f;
	platform2[7]->x = 100.0f;
	platform2[7]->y = 250.0f;
	platform2[7]->z = 100.0f;

	platform1[8]->x = 0.0f;
	platform1[8]->y = 250.0f;
	platform1[8]->z = 100.0f;
	platform2[8]->x = 5.0f;
	platform2[8]->y = 250.0f;
	platform2[8]->z = 1050.0f;

	platform1[9]->x = -1050.0f;
	platform1[9]->y = 200.0f;
	platform1[9]->z = 800.0f;
	platform2[9]->x = 50.0f;
	platform2[9]->y = 200.0f;
	platform2[9]->z = 1050.0f;


	
	booster1[0]->x = 350.0f;
	booster1[0]->y = 0.0f;
	booster1[0]->z = -25.0f;
	booster2[0]->x = 400.0f;
	booster2[0]->y = 0.0f;
	booster2[0]->z = 25.0f;

	booster1[1]->x = 900.0f;
	booster1[1]->y = 50.0f;
	booster1[1]->z = 150.0f;
	booster2[1]->x = 950.0f;
	booster2[1]->y = 50.0f;
	booster2[1]->z = 200.0f;

	booster1[2]->x = -750.0f;
	booster1[2]->y = 0.0f;
	booster1[2]->z = 100.0f;
	booster2[2]->x = -700.0f;
	booster2[2]->y = 0.0f;
	booster2[2]->z = 150.0f;

	booster1[3]->x = -550.0f;
	booster1[3]->y = 50.0f;
	booster1[3]->z = -1000.0f;
	booster2[3]->x = -500.0f;
	booster2[3]->y = 50.0f;
	booster2[3]->z = -950.0f;

	booster1[4]->x = 400.0f;
	booster1[4]->y = 100.0f;
	booster1[4]->z = -1000.0f;
	booster2[4]->x = 450.0f;
	booster2[4]->y = 100.0f;
	booster2[4]->z = -950.0f;

	booster1[5]->x = 800.0f;
	booster1[5]->y = 150.0f;
	booster1[5]->z = -350.0f;
	booster2[5]->x = 850.0f;
	booster2[5]->y = 150.0f;
	booster2[5]->z = -300.0f;
	
	booster1[6]->x = 250.0f;
	booster1[6]->y = 200.0f;
	booster1[6]->z = -50.0f;
	booster2[6]->x = 300.0f;
	booster2[6]->y = 200.0f;
	booster2[6]->z = 0.0f;

	booster1[7]->x = 0.0f;
	booster1[7]->y = 200.0f;
	booster1[7]->z = 850.0f;
	booster2[7]->x = 50.0f;
	booster2[7]->y = 200.0f;
	booster2[7]->z = 900.0f;

	booster1[8]->x = 750.0f;
	booster1[8]->y = 100.0f;
	booster1[8]->z = 750.0f;
	booster2[8]->x = 800.0f;
	booster2[8]->y = 100.0f;
	booster2[8]->z = 800.0f;

	booster1[9]->x = -950.0f;
	booster1[9]->y = 50.0f;
	booster1[9]->z = -50.0f;
	booster2[9]->x = -900.0f;
	booster2[9]->y = 50.0f;
	booster2[9]->z = 0.0f;		
		


	wall1->x = -1000.0f;
	wall1->y = 500.0f;
	wall1->z = -1000.0f;
	wall2->x = 1000.0f;
	wall2->y = 500.0f;
	wall2->z = 1000.0f;

	for (int i=0; i<20; i++)
	{
		coin_pos[i]->x = 0.0f;
		coin_pos[i]->y = -1000.0f;
		coin_pos[i]->z = 0.0f;
		coin_rot[i]->x = 0.0f;
		coin_rot[i]->y = 0.0f;
		coin_rot[i]->z = 0.0f;
	}

	coin_pos[0]->x = 100.0f;
	coin_pos[0]->y = 0.0f;
	coin_pos[0]->z = 0.0f;

	coin_pos[1]->x = 800.0f;
	coin_pos[1]->y = 50.0f;
	coin_pos[1]->z = 0.0f;

	coin_pos[2]->x = 900.0f;
	coin_pos[2]->y = 100.0f;
	coin_pos[2]->z = 900.0f;
	
	coin_pos[3]->x = 800.0f;
	coin_pos[3]->y = 100.0f;
	coin_pos[3]->z = 775.0f;

	coin_pos[4]->x = -950.0f;
	coin_pos[4]->y = 50.0f;
	coin_pos[4]->z = -950.0f;

	coin_pos[5]->x = 25.0f;
	coin_pos[5]->y = 100.0f;
	coin_pos[5]->z = -975.0f;

	coin_pos[6]->x = 950.0f;
	coin_pos[6]->y = 150.0f;
	coin_pos[6]->z = -950.0f;

	coin_pos[7]->x = 275.0f;
	coin_pos[7]->y = 200.0f;
	coin_pos[7]->z = -225.0f;
	
	coin_pos[8]->x = 0.0f;
	coin_pos[8]->y = 250.0f;
	coin_pos[8]->z = 0.0f;

	coin_pos[9]->x = 2.5f;
	coin_pos[9]->y = 250.0f;
	coin_pos[9]->z = 100.0f;


	coin_pos[10]->x = 2.5f;
	coin_pos[10]->y = 250.0f;
	coin_pos[10]->z = 300.0f;

	coin_pos[11]->x = 2.5f;
	coin_pos[11]->y = 250.0f;
	coin_pos[11]->z = 500.0f;

	coin_pos[12]->x = 2.5f;
	coin_pos[12]->y = 250.0f;
	coin_pos[12]->z = 700.0f;
	
	coin_pos[13]->x = 2.5f;
	coin_pos[13]->y = 250.0f;
	coin_pos[13]->z = 900.0f;

	coin_pos[14]->x = 0.0f;
	coin_pos[14]->y = 200.0f;
	coin_pos[14]->z = 875.0f;

	coin_pos[15]->x = -950.0f;
	coin_pos[15]->y = 200.0f;
	coin_pos[15]->z = 900.0f;

	coin_pos[16]->x = -950.0f;
	coin_pos[16]->y = 200.0f;
	coin_pos[16]->z = 950.0f;

	coin_pos[17]->x = -925.0f;
	coin_pos[17]->y = 150.0f;
	coin_pos[17]->z = -25.0f;
	
	coin_pos[18]->x = 0.0f;
	coin_pos[18]->y = 25.0f;
	coin_pos[18]->z = 0.0f;

	coin_pos[19]->x = 0.0f;
	coin_pos[19]->y = 50.0f;
	coin_pos[19]->z = 0.0f;

	coins_collected = 0;

	start_time = time(0);

	return;
};

void DrawMenu()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	frames_per_second_counter++;

	if (frames_per_second_timer != time(0))
	{
		frames_per_second = frames_per_second_counter;
		frames_per_second_counter = 0;
		frames_per_second_timer = time(0);
	}

	effects_timer += 0.01f;
	if (effects_timer > 1.0f) effects_timer -= 1.0f;
	
	glDisable(GL_LIGHTING);

	// Blank texture.
	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glColor3f(1,1,1);
	glRasterPos3f(-0.475f, 0.35f, -0.95f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'F');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 10000) - (frames_per_second % 1000)) / 1000 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 1000) - (frames_per_second % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 100) - (frames_per_second % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((frames_per_second % 10) + 48));

	glColor3f(0.1f, 0.25f*sin(effects_timer*6.28f)+0.75f, 0.25f*sin(effects_timer*6.28f)+0.75f);
	glPushMatrix();	
	glTranslatef(-0.25f+0.02f*cos(effects_timer*6.28f), 0.225f+0.01f*sin(effects_timer*6.28f), -0.9f);
	glScalef(0.001f, 0.001f, 0.001f);	
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'O');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
	glPopMatrix();

	glColor3f(0.5f + 0.05f*sin(effects_timer*6.28f), 0.75f + 0.05f*sin(effects_timer*6.28f), 1.0f);
	glPushMatrix();	
	glTranslatef(-0.465f, 0.105f, -0.9f);
	glScalef(0.0005f, 0.0005f, 0.0005f);	
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'C');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'w');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
	glPopMatrix();

	glColor3f(0.95f + 0.05f*sin(effects_timer*6.28f), 0.95f + 0.05f*sin(effects_timer*6.28f), 0.95f + 0.05f*sin(effects_timer*6.28f));
	glPushMatrix();	
	glTranslatef(-0.355f, -0.355f, -0.9f);
	glScalef(0.0004f, 0.0004f, 0.0004f);	
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'b');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
	glPopMatrix();

	glEnable(GL_LIGHTING);

	if (keyboard[27] || joystick_button[9]) exit(1);

	if (special_keyboard[GLUT_KEY_UP] || special_keyboard[GLUT_KEY_DOWN] || 
		special_keyboard[GLUT_KEY_LEFT] || special_keyboard[GLUT_KEY_RIGHT])
	{
		if (key_down == false)
		{
			screen = 1; // start game

			Setup();
		}
	}
	else key_down = false;
	
	glPushMatrix();

	glTranslatef(0.0f, -1.0f, -10.0f);
	glRotatef(effects_timer * 360.0f, 0, 1, 0);

	DrawRoller(effects_timer * 6.28f);

	glPopMatrix();

	glPushMatrix();

	glTranslatef(7.0f, -1.0f, -20.0f);
	glRotatef(effects_timer / 2.0f * 360.0f, 0, 1, 0);

	DrawCoin();

	glPopMatrix();

	glPushMatrix();

	glTranslatef(-7.0f, -1.0f, -20.0f);
	glRotatef(effects_timer / 2.0f * 360.0f, 0, 1, 0);

	DrawCoin();

	glPopMatrix();

	glutSwapBuffers();

	return;
};

void DrawGame()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	frames_per_second_counter++;

	if (frames_per_second_timer != time(0))
	{
		frames_per_second = frames_per_second_counter;
		frames_per_second_counter = 0;
		frames_per_second_timer = time(0);
	}

	if (coins_collected >= 20 && 3*60+start_time-time(0) > 3)
	{
		start_time = 3 + time(0) - 3*60; // jump the timer to 3 seconds left
	}

	if (3*60+start_time-time(0) <= 0) 
	{
		screen = 0; // back to main menu
	}

	key_down = true; // just leave it on, it's only for the menu stuff anyways
	
	glDisable(GL_LIGHTING);

	// Blank texture.
	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glColor3f(1,1,1);
	glRasterPos3f(-0.475f, 0.35f, -0.95f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'F');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 10000) - (frames_per_second % 1000)) / 1000 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 1000) - (frames_per_second % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 100) - (frames_per_second % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((frames_per_second % 10) + 48));

	if (coins_collected >= 20)
	{
		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(-0.205f, 0.105f, -0.9f);
		glScalef(0.0006f, 0.0006f, 0.0006f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'G');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'j');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'b');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '!');
		glPopMatrix();
	}

	if (coins_collected < 20)
	{
		glPushMatrix();
		glTranslatef(-0.475f, -0.35f, -0.95f);
		glScalef(0.0003f, 0.0003f, 0.0003f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((((3*60+start_time-time(0)) % 1000) - ((3*60+start_time-time(0)) % 60)) / 60 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((((3*60+start_time-time(0)) % 60) - ((3*60+start_time-time(0)) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((3*60+start_time-time(0)) % 10) + 48));
		glPopMatrix();
	}
	else
	{
		glPushMatrix();
		glTranslatef(-0.475f, -0.35f, -0.95f);
		glScalef(0.0003f, 0.0003f, 0.0003f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((((3*60+old_start_time-finish_time) % 1000) - ((3*60+old_start_time-finish_time) % 60)) / 60 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((((3*60+old_start_time-finish_time) % 60) - ((3*60+old_start_time-finish_time) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((3*60+old_start_time-finish_time) % 10) + 48));
		glPopMatrix();
	}
	

	glPushMatrix();
	glTranslatef(-0.11f, -0.35f, -0.95f);
	glScalef(0.0003f, 0.0003f, 0.0003f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
	if (roller_vel->z <= 0.0f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '+');
	else glutStrokeCharacter(GLUT_STROKE_ROMAN, '-');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((((int)fabs(roller_vel->z*10.0f) % 100) - ((int)fabs(roller_vel->z*10.0f) % 10)) / 10 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((int)fabs(roller_vel->z*10.0f) % 10) + 48));
	glPopMatrix();


	glPushMatrix();
	glTranslatef(0.25f, -0.35f, -0.95f);
	glScalef(0.0003f, 0.0003f, 0.0003f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'C');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
	if (coins_collected > 9) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((coins_collected % 100) - (coins_collected % 10)) / 10 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((coins_collected % 10) + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '/');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '2');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '0');	
	glPopMatrix();

	glEnable(GL_LIGHTING);
/*
	// Mainly for Linux, Windows will automatically receive inputs	
	if (joystick_enabled) 
	{
		FILE *joystick_fd = NULL;

		joystick_fd = fopen("/dev/input/js0", "rt");
		if (joystick_fd >= 0) // This is where Windows will fail
		{
			int bytes = 1;
			char temp;

			// This is specifically for the SNES controller.  
			// 8 bytes per button, some are -1 and +1 (D-pad).
			// The 5th byte is always the value of that button.
			// 104 is the total needed for SNES controller
			for (int i=0; i<104; i++)
			{
				bytes = fscanf(joystick_fd, "%c", &temp);

				if (bytes > 0 && i % 8 == 4)
				{
					joystick_button[(i-4)/8] = (int)temp;
				}
			}

			fclose(joystick_fd);
		}
	}
*/

/*
	float move = 0.175f;

	if (keyboard['w'] || joystick_button[12] == 1) 
	{
		camera_pos->z -= move * cos(camera_rot->y);
		camera_pos->x -= move * sin(camera_rot->y);
	}
	if (keyboard['s'] || joystick_button[12] == -1) 
	{
		camera_pos->z += move * cos(camera_rot->y);
		camera_pos->x += move * sin(camera_rot->y);
	}
	if (keyboard['a'] || joystick_button[11] == 1) 
	{
		camera_pos->z -= move * cos(camera_rot->y + 3.14f / 2.0f);
		camera_pos->x -= move * sin(camera_rot->y + 3.14f / 2.0f);
	}
	if (keyboard['d'] || joystick_button[11] == -1) 
	{
		camera_pos->z -= move * cos(camera_rot->y - 3.14f / 2.0f);
		camera_pos->x -= move * sin(camera_rot->y - 3.14f / 2.0f);
	}
	if (keyboard['q'] || joystick_button[4]) camera_pos->y -= move;
	if (keyboard['e'] || joystick_button[5]) camera_pos->y += move;		

	if (keyboard['i'] || joystick_button[0]) camera_rot->x += move / 5.0f;
	if (keyboard['k'] || joystick_button[2]) camera_rot->x -= move / 5.0f;
	if (keyboard['j'] || joystick_button[3]) camera_rot->y += move / 5.0f;
	if (keyboard['l'] || joystick_button[1]) camera_rot->y -= move / 5.0f;
*/	
		
	if (keyboard[27] || joystick_button[9]) exit(1);

	
	roller_rot->z = 0.0f;
	
	if (special_keyboard[GLUT_KEY_UP])
	{
		roller_vel->z -= 0.03f;
	}
	if (special_keyboard[GLUT_KEY_DOWN])
	{
		roller_vel->z += 0.03f;
	}
	if (special_keyboard[GLUT_KEY_LEFT])
	{
		if (fabs(roller_vel->z) >= 1.0f) roller_rot->y -= 0.025f / roller_vel->z;
		else if (roller_vel->z != 0.0f) roller_rot->y -= 0.025f * roller_vel->z;

		roller_rot->z += 3.14159f / 16.0f;
	}
	if (special_keyboard[GLUT_KEY_RIGHT])
	{
		if (fabs(roller_vel->z) >= 1.0f) roller_rot->y += 0.025f / roller_vel->z;
		else if (roller_vel->z != 0.0f) roller_rot->y += 0.025f * roller_vel->z;

		roller_rot->z -= 3.14159f / 16.0f;
	}

	if (roller_vel->z > 0.51f) roller_vel->z = 0.51f; // max out reverse
	if (roller_vel->z < -9.99f) roller_vel->z = -9.99f; // max out forward

	roller_vel->y -= 0.05f; // gravity

	roller_pos->x += roller_vel->z * sin(roller_rot->y);
	roller_pos->y += roller_vel->y;
	roller_pos->z += roller_vel->z * cos(roller_rot->y);

	roller_rot->x += roller_vel->z * 0.1f;

	if (roller_pos->x - 2.0f <= wall1->x)
	{
		roller_pos->x = wall1->x + 2.0f;
		roller_vel->z /= 4.0f;
		
		if (fabs(roller_vel->z) >= 0.1f)
		{
			if (sound_on) system("play -q -v 0.99 Thud.mp3 &");
		}
	}
	if (roller_pos->x + 2.0f >= wall2->x)
	{
		roller_pos->x = wall2->x - 2.0f;
		roller_vel->z /= 4.0f;
	
		if (fabs(roller_vel->z) >= 0.05f)
		{
			if (sound_on) system("play -q -v 0.99 Thud.mp3 &");
		}	
	}
	if (roller_pos->z - 2.0f <= wall1->z)
	{
		roller_pos->z = wall1->z + 2.0f;
		roller_vel->z /= 4.0f;

		if (fabs(roller_vel->z) >= 0.05f)
		{
			if (sound_on) system("play -q -v 0.99 Thud.mp3 &");
		}	
	}
	if (roller_pos->z + 2.0f >= wall2->z)
	{
		roller_pos->z = wall2->z - 2.0f;
		roller_vel->z /= 4.0f;

		if (fabs(roller_vel->z) >= 0.05f)
		{
			if (sound_on) system("play -q -v 0.99 Thud.mp3 &");
		}	
	}

	// engine sound increases with higher speed.
	while (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second
	{	
		compute_milli_timer = clock();

		sprintf(command_string, "play -q -v %.2f Engine.mp3 &", fabs(roller_vel->z) / 10.0f * 0.90f + 0.09f);

		if (sound_on) system(command_string);
	}

	for (int i=0; i<10; i++) // collisions with platforms
	{
		if (roller_pos->x >= platform1[i]->x && roller_pos->x <= platform2[i]->x &&
			roller_pos->z >= platform1[i]->z && roller_pos->z <= platform2[i]->z &&
			roller_pos->y >= platform1[i]->y-5.0f && roller_pos->y <= platform1[i]->y)
		{
			roller_pos->y = platform1[i]->y;
			roller_vel->y = -roller_vel->y / 2.0f; // bounce?

			if (fabs(roller_vel->y) >= 0.05f)
			{
				if (sound_on) system("play -q -v 0.99 Bounce.mp3 &");
			}		
		}
	}

	for (int i=0; i<10; i++) // collisions with boosters
	{
		if (roller_pos->x >= booster1[i]->x && roller_pos->x <= booster2[i]->x &&
			roller_pos->z >= booster1[i]->z && roller_pos->z <= booster2[i]->z &&
			roller_pos->y >= booster1[i]->y-1.0f && roller_pos->y <= booster1[i]->y)
		{
			roller_vel->y = 3.5f; // shot in the air!

			if (sound_on) system("play -q -v 0.99 Woosh.mp3 &");
		}
	}

	for (int i=0; i<20; i++) // collisions with coins
	{
		if (roller_pos->x >= coin_pos[i]->x-4.0f && roller_pos->x <= coin_pos[i]->x+4.0f &&
			roller_pos->z >= coin_pos[i]->z-4.0f && roller_pos->z <= coin_pos[i]->z+4.0f &&
			roller_pos->y >= coin_pos[i]->y-3.0f && roller_pos->y <= coin_pos[i]->y+5.0f)
		{
			coins_collected++;

			coin_pos[i]->x = 0.0f;
			coin_pos[i]->y = -1000.0f;
			coin_pos[i]->z = 0.0f;

			if (sound_on) system("play -q -v 0.99 Coin.mp3 &");

			if (coins_collected >= 20)
			{
				old_start_time = start_time;

				finish_time = time(0);
			}
		}
	}

	if (roller_vel->z > 0.0f) roller_vel->z -= 0.01f;
	if (roller_vel->z < 0.0f) roller_vel->z += 0.01f;
	if (roller_vel->z <= 0.01f && roller_vel->z >= -0.01f) roller_vel->z = 0.0f;

	if (roller_vel->y > 0.0f) roller_vel->y -= 0.01f;
	if (roller_vel->y < 0.0f) roller_vel->y += 0.01f;
	if (roller_vel->y <= 0.01f && roller_vel->y >= -0.01f) roller_vel->y = 0.0f;

	camera_pos->x = roller_pos->x + 20.0f * sin(roller_rot->y);
	camera_pos->z = roller_pos->z + 20.0f * cos(roller_rot->y);
	camera_pos->y = roller_pos->y + 12.0f;

	camera_rot->y = roller_rot->y;
	camera_rot->x = -3.14159f / 12.0f;

	for (int i=0; i<20; i++)
	{
		coin_rot[i]->y += 0.025f;
	}


	// DRAW HERE!!!

	glRotatef(-camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
	glRotatef(-camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
	glRotatef(-camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);

	glTranslatef(-camera_pos->x, -camera_pos->y, -camera_pos->z);

/*	
	glBegin(GL_QUADS);

	glColor3f(0,0,1);

	glNormal3f(0,1,0);

	glVertex3f(-200.0f, 0.0f, -200.0f);
	glVertex3f(-200.0f, 0.0f, 200.0f);
	glVertex3f(200.0f, 0.0f, 200.0f);
	glVertex3f(200.0f, 0.0f, -200.0f);

	glEnd();
*/	
	

	glPushMatrix();
	
	glTranslatef(roller_pos->x, roller_pos->y, roller_pos->z);
	
	glTranslatef(0.0f, 2.0f, 0.0f);

	glRotatef(roller_rot->y * 180.0f / 3.14159f, 0, 1, 0);
	glRotatef(roller_rot->z * 180.0f / 3.14159f, 0, 0, 1);

	DrawRoller(roller_rot->x);

	glPopMatrix();

	for (int i=0; i<20; i++)
	{
		if (coin_pos[i]->y != -1000.0f)
		{
			glPushMatrix();
	
			glTranslatef(coin_pos[i]->x, coin_pos[i]->y, coin_pos[i]->z);
	
			glTranslatef(0.0f, 2.0f, 0.0f);

			glRotatef(coin_rot[i]->y * 180.0f / 3.14159f, 0, 1, 0);

			DrawCoin();

			glPopMatrix();
		}	
	}

	for (int i=0; i<10; i++)
	{
		if (i == 0)
		{
			glColor3f(1,1,1);

			glBindTexture(GL_TEXTURE_2D, texture[3]);
		}
		else
		{
			glColor3f(1,1,1);

			glBindTexture(GL_TEXTURE_2D, texture[4]);
		}

		if (fabs(platform1[i]->x - platform2[i]->x) <= 10.0f || fabs(platform1[i]->z - platform2[i]->z) <= 10.0f)
		{
			DrawBridge(platform1[i]->x, platform1[i]->z, platform2[i]->x, platform2[i]->z, platform1[i]->y);
		}
		else
		{
			DrawPlatform(platform1[i]->x, platform1[i]->z, platform2[i]->x, platform2[i]->z, platform1[i]->y);
		}
	}

	for (int i=0; i<10; i++)
	{
		glColor3f(0,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[0]);

		DrawBooster(booster1[i]->x, booster1[i]->z, booster2[i]->x, booster2[i]->z, booster1[i]->y);
	}

	DrawWalls(wall1->x, wall1->z, wall2->x, wall2->z, wall1->y);

	glutSwapBuffers();

	return;
};

void OpenGLDisplayFunction()
{
	return;
};

void OpenGLIdleFunction()
{
	if (screen == 0)
	{
		DrawMenu();
	}
	else if (screen == 1)
	{
		DrawGame();
	}

	return;
};

void OpenGLKeyboardUpFunction(unsigned char key, int x, int y)
{
	keyboard[key] = false;

	return;
};

void OpenGLKeyboardFunction(unsigned char key, int x, int y)
{
	keyboard[key] = true;

	return;
};

void OpenGLSpecialKeyboardFunction(int key, int x, int y)
{
	special_keyboard[key] = true;

	return;
};	

void OpenGLSpecialKeyboardUpFunction(int key, int x, int y)
{
	special_keyboard[key] = false;

	return;
};

void OpenGLMouseFunction(int button, int state, int x, int y)
{
	mouse->button = button;
	mouse->state = state;
	mouse->x = x;
	mouse->y = y;

	return;
};

void OpenGLPassiveMotionFunction(int x, int y)
{
	mouse->x = x;
	mouse->y = y;

	return;
};

// GLUT in Linux does support joystick detection but not input.
// GLUT in Windows supports both
void OpenGLJoystickFunction(unsigned int button, int x, int y, int z)
{
	joystick_axis->x = x;
	joystick_axis->y = y;
	joystick_axis->z = z;

	// Bitwise AND
	joystick_button[0] = button & 0x0001;
	joystick_button[1] = button & 0x0002;
	joystick_button[2] = button & 0x0004;
	joystick_button[3] = button & 0x0008;
	joystick_button[4] = button & 0x0010;
	joystick_button[5] = button & 0x0020;
	joystick_button[6] = button & 0x0040;
	joystick_button[7] = button & 0x0080;
	joystick_button[8] = button & 0x0100;
	joystick_button[9] = button & 0x0200;
	joystick_button[10] = button & 0x0400;
	joystick_button[11] = button & 0x0800;

	return;
};


void my_randomize()
{
	int stime = 0;
	long ltime = 0;
	ltime = time(NULL);
	stime = (unsigned)ltime/2;
	srand(stime);
};

int main(int argc, char **argv)
{
	my_randomize();

	compute_milli_timer = clock();

	camera_pos = new _Point();
	camera_rot = new _Point();

	mouse = new _Mouse();
	joystick_axis = new _Joystick();

	roller_pos = new _Point();
	roller_vel = new _Point();
	roller_rot = new _Point();

	for (int i=0; i<10; i++)
	{
		platform1[i] = new _Point();
		platform2[i] = new _Point();

		booster1[i] = new _Point();
		booster2[i] = new _Point();
	}

	wall1 = new _Point();
	wall2 = new _Point();

	for (int i=0; i<20; i++)
	{
		coin_pos[i] = new _Point();
		coin_rot[i] = new _Point();
	}

	glutInit(&argc, argv);

	glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);

	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

	glutCreateWindow("Roller");

	glutDisplayFunc(OpenGLDisplayFunction);
	glutIdleFunc(OpenGLIdleFunction);
	glutKeyboardFunc(OpenGLKeyboardFunction);
	glutKeyboardUpFunc(OpenGLKeyboardUpFunction);
	glutSpecialFunc(OpenGLSpecialKeyboardFunction);
	glutSpecialUpFunc(OpenGLSpecialKeyboardUpFunction);
	glutMouseFunc(OpenGLMouseFunction);
	glutPassiveMotionFunc(OpenGLPassiveMotionFunction);
	glutJoystickFunc(OpenGLJoystickFunction, 50);

	OpenGLSetupFunction(WINDOW_WIDTH, WINDOW_HEIGHT);

	glutFullScreen();
	glutSetCursor(GLUT_CURSOR_NONE);

   	glutMainLoop();

	for (int i=0; i<10; i++)
	{
		delete platform1[i];
		delete platform2[i];

		delete booster1[i];
		delete booster2[i];
	}

	delete wall1;
	delete wall2;

	for (int i=0; i<20; i++)
	{
		delete coin_pos[i];
		delete coin_rot[i];
	}

	delete roller_pos;
	delete roller_vel;
	delete roller_rot;
	
	delete camera_pos;
	delete camera_rot;

	delete mouse;
	delete joystick_axis;

	return 0;
}
