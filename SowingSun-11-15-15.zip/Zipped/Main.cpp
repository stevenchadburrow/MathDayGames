// Sowing Sun

// Robots farming a distant planet, controlled by the humans that are on their way to live there.


/*
Some notes for future use:
- Joysticks using /dev/input/js0 are slow, use 'xboxdrv' instead.  For two controllers, use --wid 0 and --wid 1 when setting up two seperate instances of xboxdrv.
	Or -D --next-controller, or even in the config file specifying next-controller = true.  Remember to 'sudo rmmod xpad' beforehand!!!
- V-Sync on Linux is built in with the Nvidia drivers.  If you go to Nvidia Settings, and turn off V-Sync, the FPS will skyrocket.  I recommend keeping it on, so you stay at 60 FPS.
- The last textures I had used were really messing up.  Haven't checked it here 100%.  Be careful, something about a formatting issue?
- There is a way to do dual-screens, PIP really, involving drawing the first scene with all of the normal setup stuff, NO glutSwapBuffer(), glClear(DEPTH_BUFFER) again and redo
	the settings with now glViewport() smaller and gluPerspective() changed.  Draw it all over again.  Finally you glutSwapBuffer() when you are done with both.
- For sounds, I used: system("play -q -v 1.0 ./Sounds/Laser.mp3 &");  You need to: sudo apt-get install libsox-fmt-mp3 for this to work.  This is using the 'sox' tools. 

*/

/*
This game is intended to run at 60 FPS, this is almost always done through V-Sync, but just incase...

In order to run this on Linux, you must include -lglut and -lGLU when compiling.
g++ -o Main.o Main.cpp -lglut -lGLU -lGL
./Main.o
Also make sure you have all of the glut and/or freeglut packages downloaded, GLU, maybe OpenGL Mesa Dev packages??

In order to run this on Windows, use Dev-C++ (Code::Blocks also works?).  Start a Multimedia Project with glut, not an empty project like normal.
To get that project, you need to go to Tools->Packages and download all glut and/or freeglut packages.
Remember that the Project Options->Linker has to have stuff like -lwinmm -lglut -lglut32 -lopengl32  (Something with GLU) etc....
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <GL/glut.h> // change to 'freeglut' on WINDOWS

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600


#define LINUX // change to false if on WINDOWS

#ifdef LINUX
bool linux_box = true;
bool PlaySound(const char *filename, FILE *location, int x) { };
const char *TEXT(const char *text) { return text; }
int SND_FILENAME = 0, SND_ASYNC = 0;
#endif

#ifdef WINDOWS
#include<windows.h>
#include<mmsystem.h>
bool linux_box = false;
#endif


bool keyboard[256], special_keyboard[256];
bool shift_key_active = false, ctrl_key_active = false;
int joystick_button[32];
bool joystick_enabled = false;
int frames_per_second1 = 0, frames_per_second_counter1 = 0, frames_per_second_timer1 = 0;
bool frame_change_button_down = false;

int control_up_key[32], control_down_key[32], control_left_key[32], control_right_key[32], control_activate_key[32], control_run_key[32];
int control_tool_left_key[32], control_tool_right_key[32], control_pray_key[32], control_status_key[32], control_menu_key[32];

int control_up_length, control_down_length, control_left_length, control_right_length, control_activate_length, control_run_length;
int control_tool_left_length, control_tool_right_length, control_pray_length, control_status_length, control_menu_length;

bool control_up_on = false, control_down_on = false, control_left_on = false, control_right_on = false, control_activate_on = false, control_run_on = false;
bool control_tool_left_on = false, control_tool_right_on = false, control_pray_on = false, control_status_on = false, control_menu_on = false;

int menu_system_active = 1; // starting screen
int menu_position = 0;
bool menu_button_down = true;
int menu_name_length = 0;

GLuint texture[200];

bool minigame_active = false;
unsigned long minigame_score = 0;
float minigame_pos_x = 0.0f, minigame_pos_y = 0.0f;
float minigame_enemy_pos_x[50], minigame_enemy_pos_y[50];
float minigame_bullet_pos_x[50], minigame_bullet_pos_y[50];
float minigame_star_pos_x[50], minigame_star_pos_y[50];
float minigame_speed = 0.1f;
float minigame_fire_delay = 0.0f;
int minigame_sound_delay = 0;

class _Point {
public:
	_Point()
	{
		x = y = z = 0.0f;
	}

	float x, y, z;
	
	void Set(float my_x, float my_y, float my_z)
	{
		x = my_x;
		y = my_y;
		z = my_z;
	
		return;
	}

} *camera_pos, *camera_rot;


#include "Mechanics.h"
#include "Models.h"
#include "Menu.h"


class _Mouse {
public:
	_Mouse()
	{
		x = y = 0;
	
		button = 0;
		state = 0;
	}

	int x, y;

	int button, state;

} *mouse;

class _Joystick {
public:
	_Joystick()
	{
		x = y = z = 0;
	}

	int x, y, z;

} *joystick_axis;


_Field *field[MAX_FIELDS];
_Inventory *inventory;
_Cast *cast;
_Stats *stats;

unsigned long last_time = 0;
int random_dialog = 0;
float constant_inventory_rotation = 0.0f;
float inventory_hang_time = 0.0f;

float rain_pos_x[10000], rain_pos_y[10000], rain_pos_z[10000];


void LoadControls()
{
	char buffer;

	char word[32];
	int word_length;

	FILE *controls = NULL;

	controls = fopen("ControlsFile.txt", "rt");
	if (!controls)
	{
		controls = NULL;

		controls = fopen("ControlsFile.txt", "wt");
		if (!controls)
		{
			// something is terribly wrong
		}
		
		fprintf(controls, "# Controls File for Sowing Sun\n\n");
			
		fprintf(controls, "# For each control, put the keys wanted after it.  There can be multiple keys for each control, space dividing.  Start and end with a semicolon.  Do not mix up order of commands.\n");
	
		fprintf(controls, "# Special keys start and end with colons.  Shift, Ctrl, and CapsLock works funny, be warned!  Listing - :UP: :DOWN: :LEFT: :RIGHT: :SPACE: :ENTER: :ESCAPE: :SHIFT: :CONTROL:\n");

		fprintf(controls, "# If it's not obvious by now, you cannot use ; or : as keys!  Any attempts at doing so will break the game.  You can always delete this file to reset everything :)\n\n");
		
		fprintf(controls, "$ Move Up ; i 8 :UP: ;\n");
		fprintf(controls, "$ Move Down ; k 2 :DOWN: ;\n");
		fprintf(controls, "$ Move Left ; j 4 :LEFT: ;\n");
		fprintf(controls, "$ Move Right ; l 6 :RIGHT: ;\n");
		fprintf(controls, "$ Activate ; a :ENTER: ;\n");
		fprintf(controls, "$ Run ; z :SPACE: ;\n");
		fprintf(controls, "$ Tool Left ; - _ , < 7 ;\n");
		fprintf(controls, "$ Tool Right ; = + . > 9 ;\n");
		fprintf(controls, "$ Pray ; q p ;\n");
		fprintf(controls, "$ Status ; w s ;\n");
		fprintf(controls, "$ Menu ; m :ESCAPE: ;\n");
		
		fprintf(controls, "\n");

		fclose(controls);

		FILE *controls = NULL;

		controls = fopen("ControlsFile.txt", "rt");
		if (!controls)
		{
			// something is terribly wrong
		}
	} 
 

	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_up_length = 0;
	
	while (buffer != ';') // up
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'w';
				control_up_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'s';
				control_up_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'a';
				control_up_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'d';
				control_up_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'b';
				control_up_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'r';
				control_up_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'x';
				control_up_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'h';
				control_up_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_up_key[control_up_length] = -1 * (int)'c';
				control_up_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_up_key[control_up_length] = buffer;
			control_up_length++;
		}
	}

	
	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_down_length = 0;
	
	while (buffer != ';') // down
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'w';
				control_down_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'s';
				control_down_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'a';
				control_down_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'d';
				control_down_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'b';
				control_down_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'r';
				control_down_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'x';
				control_down_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'h';
				control_down_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_down_key[control_down_length] = -1 * (int)'c';
				control_down_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_down_key[control_down_length] = buffer;
			control_down_length++;
		}
	}


	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_left_length = 0;
	
	while (buffer != ';') // left
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'w';
				control_left_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'s';
				control_left_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'a';
				control_left_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'d';
				control_left_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'b';
				control_left_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'r';
				control_left_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'x';
				control_left_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'h';
				control_left_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_left_key[control_left_length] = -1 * (int)'c';
				control_left_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_left_key[control_left_length] = buffer;
			control_left_length++;
		}
	}

	
	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_right_length = 0;
	
	while (buffer != ';') // right
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'w';
				control_right_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'s';
				control_right_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'a';
				control_right_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'d';
				control_right_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'b';
				control_right_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'r';
				control_right_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'x';
				control_right_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'h';
				control_right_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_right_key[control_right_length] = -1 * (int)'c';
				control_right_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_right_key[control_right_length] = buffer;
			control_right_length++;
		}
	}


	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_activate_length = 0;
	
	while (buffer != ';') // activate
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'w';
				control_activate_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'s';
				control_activate_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'a';
				control_activate_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'d';
				control_activate_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'b';
				control_activate_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'r';
				control_activate_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'x';
				control_activate_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'h';
				control_activate_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_activate_key[control_activate_length] = -1 * (int)'c';
				control_activate_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_activate_key[control_activate_length] = buffer;
			control_activate_length++;
		}
	}

	
	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_run_length = 0;
	
	while (buffer != ';') // run
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'w';
				control_run_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'s';
				control_run_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'a';
				control_run_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'d';
				control_run_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'b';
				control_run_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'r';
				control_run_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'x';
				control_run_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'h';
				control_run_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_run_key[control_run_length] = -1 * (int)'c';
				control_run_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_run_key[control_run_length] = buffer;
			control_run_length++;
		}
	}


	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_tool_left_length = 0;
	
	while (buffer != ';') // tool left
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'w';
				control_tool_left_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'s';
				control_tool_left_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'a';
				control_tool_left_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'d';
				control_tool_left_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'b';
				control_tool_left_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'r';
				control_tool_left_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'x';
				control_tool_left_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'h';
				control_tool_left_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_tool_left_key[control_tool_left_length] = -1 * (int)'c';
				control_tool_left_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_tool_left_key[control_tool_left_length] = buffer;
			control_tool_left_length++;
		}
	}


	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_tool_right_length = 0;
	
	while (buffer != ';') // tool right
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'w';
				control_tool_right_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'s';
				control_tool_right_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'a';
				control_tool_right_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'d';
				control_tool_right_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'b';
				control_tool_right_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'r';
				control_tool_right_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'x';
				control_tool_right_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'h';
				control_tool_right_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_tool_right_key[control_tool_right_length] = -1 * (int)'c';
				control_tool_right_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_tool_right_key[control_tool_right_length] = buffer;
			control_tool_right_length++;
		}
	}

	
	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_pray_length = 0;
	
	while (buffer != ';') // pray
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'w';
				control_pray_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'s';
				control_pray_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'a';
				control_pray_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'d';
				control_pray_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'b';
				control_pray_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'r';
				control_pray_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'x';
				control_pray_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'h';
				control_pray_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_pray_key[control_pray_length] = -1 * (int)'c';
				control_pray_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_pray_key[control_pray_length] = buffer;
			control_pray_length++;
		}
	}

	
	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_status_length = 0;
	
	while (buffer != ';') // status
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'w';
				control_status_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'s';
				control_status_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'a';
				control_status_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'d';
				control_status_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'b';
				control_status_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'r';
				control_status_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'x';
				control_status_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'h';
				control_status_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_status_key[control_status_length] = -1 * (int)'c';
				control_status_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_status_key[control_status_length] = buffer;
			control_status_length++;
		}
	}


	buffer = 0;

	while (buffer != '$') { fscanf(controls, "%c", &buffer); }
	while (buffer != ';') { fscanf(controls, "%c", &buffer); }

	buffer = 0;

	control_menu_length = 0;
	
	while (buffer != ';') // menu
	{
		fscanf(controls, "%c", &buffer);
		
		if (buffer == ':')
		{
			for (int i=0; i<32; i++) word[i] = 0;

			word_length = 0;

			buffer = 0;

			while (buffer != ':')
			{
				fscanf(controls, "%c", &buffer);

				if (buffer != ':')
				{
					word[word_length] = buffer;
					word_length++;
				}
			}

			if (strcmp(word, "UP") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'w';
				control_menu_length++;
			}
			else if (strcmp(word, "DOWN") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'s';
				control_menu_length++;
			}
			else if (strcmp(word, "LEFT") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'a';
				control_menu_length++;
			}
			else if (strcmp(word, "RIGHT") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'d';
				control_menu_length++;
			}
			else if (strcmp(word, "SPACE") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'b';
				control_menu_length++;
			}
			else if (strcmp(word, "ENTER") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'r';
				control_menu_length++;
			}
			else if (strcmp(word, "ESCAPE") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'x';
				control_menu_length++;
			}
			else if (strcmp(word, "SHIFT") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'h';
				control_menu_length++;
			}
			else if (strcmp(word, "CONTROL") == 0)
			{
				control_menu_key[control_menu_length] = -1 * (int)'c';
				control_menu_length++;
			}
		}
		else if (buffer != ';' && buffer != ' ')
		{
			control_menu_key[control_menu_length] = buffer;
			control_menu_length++;
		}
	}

	fclose(controls);

	return;
};

void OpenGLSetupFunction(int width, int height)
{
	glutWarpPointer(WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);


	for (int i=0; i<256; i++) 
	{
		keyboard[i] = false;
		special_keyboard[i] = false;
	}

	for (int i=0; i<32; i++) joystick_button[i] = 0;
	joystick_axis->x = 0;
	joystick_axis->y = 0;
	joystick_axis->z = 0;

	// If there is a joystick...
	if (glutDeviceGet(GLUT_HAS_JOYSTICK)) 
	{
		printf("Joystick Detected!\n");

		joystick_enabled = true;
	}

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (float)(width)/(float)(height), 0.1f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity(); 
	glEnable(GL_TEXTURE_2D);  
	glShadeModel(GL_SMOOTH);
	glClearColor(0.1f, 0.1f, 0.1f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);					
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	
	glAlphaFunc(GL_GREATER, 0.9f);									
	glEnable(GL_ALPHA_TEST);

	//glDisable(GL_ALPHA_TEST);
	//glEnable(GL_BLEND);
	//glBlendFunc(GL_SRC_ALPHA,GL_ONE);

	// more stuff for lighting                                  
	glFrontFace(GL_CCW);
	glEnable(GL_NORMALIZE);     
	//glCullFace(GL_FRONT);                   

	// allows colors to be still lit up      
	glEnable(GL_COLOR_MATERIAL);

	// lighting    
	GLfloat ambient[] = { 0.3f, 0.3f, 0.3f, 1.0f };  
	GLfloat diffuse[] = { 0.7f, 0.7f, 0.7f, 0.7f }; 
	GLfloat light_pos[] = { 0.0f, 1.0f, 1.0f, 1.0f };
	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);                          
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse); 
	glLightfv(GL_LIGHT1, GL_POSITION, light_pos);
	glEnable(GL_LIGHT1); 

	// fog
	GLfloat fogColor[4]= {0.01f, 0.01f, 0.01f, 1.0f};

	glFogi(GL_FOG_MODE, GL_LINEAR);
	glFogfv(GL_FOG_COLOR, fogColor);
	glFogf(GL_FOG_DENSITY, 0.35f);
	glHint(GL_FOG_HINT, GL_DONT_CARE);
	glFogf(GL_FOG_START, 0.0f);
	glFogf(GL_FOG_END, 5000.0f);
	glEnable(GL_FOG);

	glLineWidth(2);
 
	
	// INITIALIZE HERE!!!

	InitializeBitmaps();

	camera_pos->y = 25.0f;
	camera_rot->x = -3.14159f / 4.0f;

	for (int i=0; i<1000; i++)
	{	
		rain_pos_x[i] = 0.0f;
		rain_pos_y[i] = -10.0f;
		rain_pos_z[i] = 0.0f;
	}

	return;
};

void OpenGLDisplayFunction()
{
	return;
};

void MainGameLoop()
{
	int temp_actor, temp_number, temp_total;
	
	char action_message[32];

	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])
	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;

			if (keyboard['d']) 
			{
				compute_cycles_total--;
			
				if (compute_cycles_total < 1)
				{
					compute_unlimited = true;
					compute_cycles_total = 1;
				}
			}
			if (keyboard['c'])
			{
				if (compute_unlimited == true)
				{
					compute_unlimited = false;
					compute_cycles_total = 1;
				}
				else
				{
					compute_cycles_total++;
					compute_unlimited = false;
				}
			}
		}
	}
	else frame_change_button_down = false;	
*/

	if (compute_cycles_left <= 0 || compute_unlimited == true)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		
		glColor3f(1,1,1);
		glRasterPos3f(-0.49f, 0.36f, -0.9f);
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'F');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'P');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'S');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, '=');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second1 % 10000) - (frames_per_second1 % 1000)) / 1000 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second1 % 1000) - (frames_per_second1 % 100)) / 100 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second1 % 100) - (frames_per_second1 % 10)) / 10 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((frames_per_second1 % 10) + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, '/');
		if (compute_unlimited == true)
		{
			glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'I');
			glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'N');
			glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'F');
		}
		else
		{	
			glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((60 / compute_cycles_total) / 10) + '0');
			glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((60 / compute_cycles_total) % 10) + '0');
		}
	
		glEnable(GL_LIGHTING);
	
		if (control_menu_on)
		{
			if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
			else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

			menu_system_active = 3;
			
			menu_position = 0;
		
			return;
		}
		
		//if (keyboard[27] || joystick_button[9]) exit(1);

		
		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];


		// DRAW HERE!!!
	
		if (stats->dialog_up == -1) 
		{
			if (time(0) != last_time)
			{
				last_time = time(0);
		
				SecondLoop(field, inventory, cast, stats);
		
				if (stats->hour < 18) // stop at 6pm
				{
					if (stats->current_field == 0 || stats->current_field == 3 || 
						stats->current_field == 4 || stats->current_field == 5 ||
						stats->current_field == 6 || stats->current_field == 9) // only outside and in the mines and fishery!
					{
						stats->minute += 5;
			
						if (stats->minute >= 60)
						{
							stats->minute = 0;
				
							stats->hour++;
				
							if (stats->hour >= 18)
							{
								stats->hour = 18;
							}

							if (stats->hour >= 17 && stats->current_field == 5) // exit mines immediately, too late!
							{
								stats->fx = 21.5f;
								stats->fy = 50.5f;
								stats->px = 21;
								stats->py = 50;
								stats->dx = 21;
								stats->dy = 51;

								stats->move_priority[1] = 1;
							}

							if (stats->hour >= 17 && stats->current_field == 9) // exit fishery immediately, too late!
							{
								stats->fx = 20.5f;
								stats->fy = 30.5f;
								stats->px = 20;
								stats->py = 30;
								stats->dx = 20;
								stats->dy = 31;

								stats->move_priority[1] = 1;

								for (int i=21; i<=26; i++)
								{
									for (int j=22; j<=26; j++)
									{
										if (field[9]->tile[i][j]->type != TILE_TYPE_FISHERY) // just incase
										{
											field[9]->tile[i][j]->type = TILE_TYPE_FISHERY;
											field[9]->tile[i][j]->growth = 1;
										}
									}
								}
							}
						}				
					}
				}

				if (stats->hour >= 17) // send off the exchanger rover
				{
					cast->actor[24]->rx1 = 0.5f;
					cast->actor[24]->ry1 = 27.5f;
					cast->actor[24]->rx2 = 20.5f;
					cast->actor[24]->ry2 = 27.5f;
					cast->actor[24]->tx = 0.5f;
					cast->actor[24]->ty = 27.5f;
				}
			}

			if (stats->hour >= 18)
			{
				stats->hour = 18;
				stats->minute = 0;
			}

			glDisable(GL_LIGHTING);

			glLineWidth(6);

			glColor3f(0.1f,0.1f,0.1f);

			glPushMatrix();
			glTranslatef(-0.375f, -0.3f, -0.8f);
			glScalef(0.00025f, 0.00025f, 0.00025f);
			
			if (stats->countdown >= 0)
			{
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((abs(stats->countdown) % 1000) - (abs(stats->countdown) % 100)) / 100 + 48));
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((abs(stats->countdown) % 100) - (abs(stats->countdown) % 10)) / 10 + 48));
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((abs(stats->countdown) % 10) + 48));
			}
			else if (stats->countdown > -5 && stats->countdown < 0)
			{
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'W');
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'A');
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'I');
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'T');
			}
			else if (stats->countdown <= -5)
			{
				
			}
	
			glPopMatrix();

			glLineWidth(2);

			glColor3f(1,1,1);

			glPushMatrix();
			glTranslatef(-0.375f, -0.3f, -0.8f);
			glScalef(0.00025f, 0.00025f, 0.00025f);
			
			if (stats->countdown >= 0)
			{
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((abs(stats->countdown) % 1000) - (abs(stats->countdown) % 100)) / 100 + 48));
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((abs(stats->countdown) % 100) - (abs(stats->countdown) % 10)) / 10 + 48));
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((abs(stats->countdown) % 10) + 48));
			}
			else if (stats->countdown > -5 && stats->countdown < 0)
			{
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'W');
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'A');
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'I');
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'T');
			}
			else if (stats->countdown <= -5)
			{
				
			}
	
			glPopMatrix();
	
			for (int i=0; i<32; i++) action_message[i] = 0;
	
			sprintf(action_message, "%s", ActivateMessage(field, inventory, cast, stats));
	
			glColor3f(1,1,1);
	
			glLineWidth(6);
	
			glPushMatrix();	
			glTranslatef(0.225f, -0.3f, -0.8f);
			glScalef(0.00025f, 0.00025f, 0.00025f);
	
			for (int i=0; i<32; i++)
			{
				glColor3f(0.1f,0.1f,0.1f);
	
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, action_message[i]);
			}
	
			glPopMatrix();
	
			glLineWidth(2);
	
			glPushMatrix();	
			glTranslatef(0.225f, -0.3f, -0.8f);
			glScalef(0.00025f, 0.00025f, 0.00025f);
	
			for (int i=0; i<32; i++)
			{
				glColor3f(1,1,1);
	
				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, action_message[i]);
			}
	
			glPopMatrix();	

			glEnable(GL_LIGHTING);


			if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE)
			{
				inventory->tool[stats->current_tool]->quantity = 0;
			}

			random_dialog = rand() % 31832; // 4 * 7958 verses in NT.  Just for randomization.
	
			EveryLoop(field, inventory, cast, stats, compute_cycles_total);
	
			Controls(field, 30, inventory, cast, stats, compute_cycles_total);
	
			if (control_tool_left_on == true || control_tool_right_on == true)
			{
				inventory_hang_time = 1.0f;
			}
	
			inventory_hang_time -= 0.01f * compute_cycles_total;

			if (inventory_hang_time < 0.0f) inventory_hang_time = 0.0f;
			else DrawInventory(inventory, stats->current_tool, constant_inventory_rotation);
	
			constant_inventory_rotation += 0.05f * compute_cycles_total;
			if (constant_inventory_rotation >= 6.28f) constant_inventory_rotation -= 6.28f;
		}
		else if (stats->dialog_up == -2)
		{
			if (stats->dialog_selection == -1 && control_left_on == false && control_right_on == false)
			{
				stats->dialog_selection = 0;
			}
	
			if (stats->dialog_selection == 0 || stats->dialog_selection == 1)
			{
				if (control_left_on == true) stats->dialog_selection = 0;
				if (control_right_on == true) stats->dialog_selection = 1;
			}

			DrawDialog(field, inventory, cast, stats, -2, stats->dialog_up, random_dialog, (control_activate_on || control_status_on));
/*	
			if (stats->dialog_up == -1 && stats->dialog_selection == 1)
			{
				stats->px = 25;
				stats->py = 22;
				stats->fx = 25.5f;
				stats->fy = 22.5f;
				stats->dx = 25;
				stats->dy = 23;
				stats->rot = 3.0f * 3.14149f / 2.0f;
				stats->current_field = 1;
	
				stats->hour = 18;
				stats->minute = 0;
	
				stats->animation_timer = -5.0f;

				stats->move_priority[1] = 1;
			}
*/
		}
		else if (stats->dialog_up == -3) // prayer
		{
			if (stats->dialog_selection == -1 && control_left_on == false && control_right_on == false)
			{
				stats->dialog_selection = 0;
			}
	
			if (stats->dialog_selection == 0 || stats->dialog_selection == 1)
			{
				if (control_left_on == true) stats->dialog_selection = 0;
				if (control_right_on == true) stats->dialog_selection = 1;
			}

			DrawDialog(field, inventory, cast, stats, -3, stats->dialog_up, random_dialog, (control_activate_on || control_pray_on));

			if (stats->dialog_up == -1)
			{
				stats->animation_type = 0;
				stats->animation_timer = 0.0f;
			}
		}
		else
		{
			if (stats->dialog_selection == -1 && control_left_on == false && control_right_on == false)
			{
				stats->dialog_selection = 0;
			}
	
			if (stats->dialog_selection == 0 || stats->dialog_selection == 1)
			{
				if (control_left_on == true) stats->dialog_selection = 0;
				if (control_right_on == true) stats->dialog_selection = 1;
			}

			temp_actor = cast->actor[stats->dialog_up]->type;
			temp_number = stats->dialog_up;

			if (temp_actor == ACTOR_TYPE_TELEVISION)
			{
				cast->actor[stats->dialog_up]->affection = 1;

				stats->animation_type = 1; // sitting down
			}

			DrawDialog(field, inventory, cast, stats, cast->actor[stats->dialog_up]->type, stats->dialog_up, random_dialog, control_activate_on);

			if (temp_actor == ACTOR_TYPE_BUY_ROVER && stats->dialog_up == -1 && stats->dialog_selection == 0)
			{
				if (stats->credits >= 2000 && stats->materials >= 250)
				{
					temp_total = 0;

					for (int i=0; i<4; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_ROVER && cast->actor[i]->present_field == 2) temp_total++;
					}
	
					if (temp_total < 4)
					{
						stats->dialog_up = 4; // BUY_ACCEPTED
						stats->dialog_place = 0;
						stats->dialog_selection = -1;

						stats->credits -= 2000;
						stats->materials -= 250;

						if (temp_total >= 0)
						{
							cast->actor[0]->type = ACTOR_TYPE_ROVER;
							cast->actor[0]->fx = 21.5f;
							cast->actor[0]->fy = 24.5f;
							cast->actor[0]->px = 21;
							cast->actor[0]->py = 24;
							cast->actor[0]->present_field = 2;
							cast->actor[0]->rx1 = 21.0f;
							cast->actor[0]->ry1 = 24.0f;
							cast->actor[0]->rx2 = 25.0f;
							cast->actor[0]->ry2 = 28.0f;
							cast->actor[0]->tx = 21.5f;
							cast->actor[0]->ty = 24.5f;

							cast->actor[0]->primary_color[0] = 1.0f;
							cast->actor[0]->primary_color[1] = 1.0f;
							cast->actor[0]->primary_color[2] = 0.0f;
							cast->actor[0]->secondary_color[0] = 0.3f;
							cast->actor[0]->secondary_color[1] = 0.3f;
							cast->actor[0]->secondary_color[2] = 0.3f;
						}

						if (temp_total >= 1)
						{
							cast->actor[1]->type = ACTOR_TYPE_ROVER;
							cast->actor[1]->fx = 22.5f;
							cast->actor[1]->fy = 25.5f;
							cast->actor[1]->px = 22;
							cast->actor[1]->py = 25;
							cast->actor[1]->present_field = 2;
							cast->actor[1]->rx1 = 21.0f;
							cast->actor[1]->ry1 = 24.0f;
							cast->actor[1]->rx2 = 25.0f;
							cast->actor[1]->ry2 = 28.0f;
							cast->actor[1]->tx = 22.5f;
							cast->actor[1]->ty = 25.5f;

							cast->actor[1]->primary_color[0] = 1.0f;
							cast->actor[1]->primary_color[1] = 0.0f;
							cast->actor[1]->primary_color[2] = 1.0f;
							cast->actor[1]->secondary_color[0] = 0.3f;
							cast->actor[1]->secondary_color[1] = 0.3f;
							cast->actor[1]->secondary_color[2] = 0.3f;
						}

						if (temp_total >= 2)
						{
							cast->actor[2]->type = ACTOR_TYPE_ROVER;
							cast->actor[2]->fx = 23.5f;
							cast->actor[2]->fy = 26.5f;
							cast->actor[2]->px = 23;
							cast->actor[2]->py = 26;
							cast->actor[2]->present_field = 2;
							cast->actor[2]->rx1 = 21.0f;
							cast->actor[2]->ry1 = 24.0f;
							cast->actor[2]->rx2 = 25.0f;
							cast->actor[2]->ry2 = 28.0f;
							cast->actor[2]->tx = 23.5f;
							cast->actor[2]->ty = 26.5f;

							cast->actor[2]->primary_color[0] = 0.0f;
							cast->actor[2]->primary_color[1] = 1.0f;
							cast->actor[2]->primary_color[2] = 1.0f;
							cast->actor[2]->secondary_color[0] = 0.3f;
							cast->actor[2]->secondary_color[1] = 0.3f;
							cast->actor[2]->secondary_color[2] = 0.3f;
						}

						if (temp_total >= 3)
						{
							cast->actor[3]->type = ACTOR_TYPE_ROVER;
							cast->actor[3]->fx = 24.5f;
							cast->actor[3]->fy = 27.5f;
							cast->actor[3]->px = 24;
							cast->actor[3]->py = 27;
							cast->actor[3]->present_field = 2;
							cast->actor[3]->rx1 = 21.0f;
							cast->actor[3]->ry1 = 24.0f;
							cast->actor[3]->rx2 = 25.0f;
							cast->actor[3]->ry2 = 28.0f;
							cast->actor[3]->tx = 24.5f;
							cast->actor[3]->ty = 27.5f;

							cast->actor[3]->primary_color[0] = 0.5f;
							cast->actor[3]->primary_color[1] = 0.5f;
							cast->actor[3]->primary_color[2] = 1.0f;
							cast->actor[3]->secondary_color[0] = 0.3f;
							cast->actor[3]->secondary_color[1] = 0.3f;
							cast->actor[3]->secondary_color[2] = 0.3f;
						}
					}
					else
					{
						stats->dialog_up = 5; // BUY_REJECTED
						stats->dialog_place = 0;
						stats->dialog_selection = -1;
					}
				}
				else
				{
					stats->dialog_up = 5; // BUY_REJECTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				}
			}
			else if (temp_actor == ACTOR_TYPE_SELL_ROVER && stats->dialog_up == -1 && stats->dialog_selection == 0)
			{
				temp_total = 0;

				for (int i=0; i<4; i++)
				{
					if (cast->actor[i]->type == ACTOR_TYPE_ROVER && cast->actor[i]->present_field == 2) temp_total++;
				}
	
				if (temp_total > 0)
				{
					stats->dialog_up = 4; // BUY_ACCEPTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;

					stats->credits += 500;
					stats->materials += 100;

					cast->actor[temp_total-1]->type = ACTOR_TYPE_NONE;
					cast->actor[temp_total-1]->fx = 0.0f;
					cast->actor[temp_total-1]->fy = 0.0f;

					cast->actor[temp_total-1]->px = 0;
					cast->actor[temp_total-1]->py = 0;
					cast->actor[temp_total-1]->present_field = 0;
				}
				else
				{
					stats->dialog_up = 5; // BUY_REJECTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				}
			}
			else if (temp_actor == ACTOR_TYPE_BUY_WATER_GENERATOR && stats->dialog_up == -1 && stats->dialog_selection == 0)
			{
				if (stats->credits >= 1000 && stats->materials >= 50)
				{
					temp_total = 0;

					for (int i=0; i<100; i++)	
					{
						for (int j=0; j<100; j++)
						{
							if (field[0]->tile[i][j]->type == TILE_TYPE_WATER_GENERATOR) temp_total++;
						}
					}
	
					if (temp_total < 8)
					{
						stats->dialog_up = 4; // BUY_ACCEPTED
						stats->dialog_place = 0;
						stats->dialog_selection = -1;

						stats->credits -= 1000;
						stats->materials -= 50;

						field[0]->tile[44-temp_total][24]->type = TILE_TYPE_WATER_GENERATOR;
						field[0]->tile[44-temp_total][24]->growth = 100;
					}
					else
					{
						stats->dialog_up = 5; // BUY_REJECTED
						stats->dialog_place = 0;
						stats->dialog_selection = -1;
					}
				}
				else
				{
					stats->dialog_up = 5; // BUY_REJECTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				}
			}
			else if (temp_actor == ACTOR_TYPE_BUY_GIFT_BASKET && stats->dialog_up == -1 && stats->dialog_selection == 0)
			{
				if (stats->credits >= 100)
				{	
					temp_total = -1;

					for (int i=0; i<12; i++)	
					{
						if (inventory->tool[i]->type == TOOL_TYPE_NONE)
						{
							temp_total = i;

							i = 13;
						}
					}
					
					if (temp_total >= 0)
					{
						stats->credits -= 100;
	
						inventory->tool[temp_total]->type = TOOL_TYPE_GIFT_BASKET;
						inventory->tool[temp_total]->quantity = 1;

						stats->dialog_up = 4; // BUY_ACCEPTED
						stats->dialog_place = 0;
						stats->dialog_selection = -1;
					}
					else
					{
						stats->dialog_up = 5; // BUY_REJECTED
						stats->dialog_place = 0;
						stats->dialog_selection = -1;
					}
				}
				else
				{
					stats->dialog_up = 5; // BUY_REJECTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				}
			}
			else if (temp_actor == ACTOR_TYPE_BUY_ORE && stats->dialog_up == -1 && stats->dialog_selection == 0)
			{
				if (stats->credits >= 100)
				{		
					stats->dialog_up = 4; // BUY_ACCEPTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;

					stats->credits -= 100;
					stats->materials += 5;
				}
				else
				{
					stats->dialog_up = 5; // BUY_REJECTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				}
			}
			else if (temp_actor == ACTOR_TYPE_BUY_NANOTUBE && stats->dialog_up == -1 && stats->dialog_selection == 0)
			{
				if (stats->credits >= 500)
				{		
					stats->dialog_up = 4; // BUY_ACCEPTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;

					stats->credits -= 500;
					stats->feed += 20;
				}
				else
				{
					stats->dialog_up = 5; // BUY_REJECTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				}
			}
			else if ((temp_actor == ACTOR_TYPE_BUY_RADISH_SEEDS ||
				temp_actor == ACTOR_TYPE_BUY_CABBAGE_SEEDS ||
				temp_actor == ACTOR_TYPE_BUY_CUCUMBER_SEEDS ||
				temp_actor == ACTOR_TYPE_BUY_BEANS_SEEDS ||
				temp_actor == ACTOR_TYPE_BUY_MELON_SEEDS ||
				temp_actor == ACTOR_TYPE_BUY_TURNIP_SEEDS ||
				temp_actor == ACTOR_TYPE_BUY_ONION_SEEDS ||
				temp_actor == ACTOR_TYPE_BUY_RYE_SEEDS ||
				temp_actor == ACTOR_TYPE_BUY_NANOTUBE_SEEDS) && stats->dialog_up == -1 && stats->dialog_selection == 0)
			{
				if ((temp_actor == ACTOR_TYPE_BUY_RADISH_SEEDS && stats->credits >= 200) ||
					(temp_actor == ACTOR_TYPE_BUY_CABBAGE_SEEDS && stats->credits >= 200) ||
					(temp_actor == ACTOR_TYPE_BUY_CUCUMBER_SEEDS && stats->credits >= 300) ||
					(temp_actor == ACTOR_TYPE_BUY_BEANS_SEEDS && stats->credits >= 300) ||
					(temp_actor == ACTOR_TYPE_BUY_MELON_SEEDS && stats->credits >= 300) ||
					(temp_actor == ACTOR_TYPE_BUY_TURNIP_SEEDS && stats->credits >= 200) ||
					(temp_actor == ACTOR_TYPE_BUY_ONION_SEEDS && stats->credits >= 200) ||
					(temp_actor == ACTOR_TYPE_BUY_RYE_SEEDS && stats->credits >= 80) ||
					(temp_actor == ACTOR_TYPE_BUY_NANOTUBE_SEEDS && stats->credits >= 500))
				{
					temp_total = -1;

					for (int i=0; i<12; i++)	
					{
						if (inventory->tool[i]->type == temp_actor - ACTOR_TYPE_BUY_RADISH_SEEDS + TOOL_TYPE_RADISH_SEED)
						{
							temp_total = i;

							i = 13;
						}
					}
					
					if (temp_total >= 0)
					{
						if (temp_actor == ACTOR_TYPE_BUY_RADISH_SEEDS ||
							temp_actor == ACTOR_TYPE_BUY_CABBAGE_SEEDS ||
							temp_actor == ACTOR_TYPE_BUY_TURNIP_SEEDS ||
							temp_actor == ACTOR_TYPE_BUY_ONION_SEEDS)
						{		
							stats->credits -= 200;

							inventory->tool[temp_total]->quantity++;
						}
						else if (temp_actor == ACTOR_TYPE_BUY_CUCUMBER_SEEDS ||
							temp_actor == ACTOR_TYPE_BUY_BEANS_SEEDS ||
							temp_actor == ACTOR_TYPE_BUY_MELON_SEEDS)
						{
							stats->credits -= 300;

							inventory->tool[temp_total]->quantity++;
						}
						else if (temp_actor == ACTOR_TYPE_BUY_RYE_SEEDS)
						{
							stats->credits -= 80;

							inventory->tool[temp_total]->quantity++;
						}
						else if (temp_actor == ACTOR_TYPE_BUY_NANOTUBE_SEEDS)
						{
							stats->credits -= 500;

							inventory->tool[temp_total]->quantity++;
						}

						stats->dialog_up = 4; // BUY_ACCEPTED
						stats->dialog_place = 0;
						stats->dialog_selection = -1;
					}
					else
					{	
						for (int i=0; i<12; i++)	
						{
							if (inventory->tool[i]->type == TOOL_TYPE_NONE)
							{
								temp_total = i;

								i = 13;
							}
						}

						if (temp_total >= 0)
						{
							if (temp_actor == ACTOR_TYPE_BUY_RADISH_SEEDS ||
								temp_actor == ACTOR_TYPE_BUY_CABBAGE_SEEDS ||
								temp_actor == ACTOR_TYPE_BUY_TURNIP_SEEDS ||
								temp_actor == ACTOR_TYPE_BUY_ONION_SEEDS)
							{		
								stats->credits -= 200;
	
								inventory->tool[temp_total]->type = temp_actor - ACTOR_TYPE_BUY_RADISH_SEEDS + TOOL_TYPE_RADISH_SEED;
								inventory->tool[temp_total]->quantity = 1;
							}
							else if (temp_actor == ACTOR_TYPE_BUY_CUCUMBER_SEEDS ||
								temp_actor == ACTOR_TYPE_BUY_BEANS_SEEDS ||
								temp_actor == ACTOR_TYPE_BUY_MELON_SEEDS)
							{
								stats->credits -= 300;
	
								inventory->tool[temp_total]->type = temp_actor - ACTOR_TYPE_BUY_RADISH_SEEDS + TOOL_TYPE_RADISH_SEED;
								inventory->tool[temp_total]->quantity = 1;
							}
							else if (temp_actor == ACTOR_TYPE_BUY_RYE_SEEDS)
							{
								stats->credits -= 80;
	
								inventory->tool[temp_total]->type = temp_actor - ACTOR_TYPE_BUY_RADISH_SEEDS + TOOL_TYPE_RADISH_SEED;
								inventory->tool[temp_total]->quantity = 1;
							}
							else if (temp_actor == ACTOR_TYPE_BUY_NANOTUBE_SEEDS)
							{
								stats->credits -= 500;
	
								inventory->tool[temp_total]->type = temp_actor - ACTOR_TYPE_BUY_RADISH_SEEDS + TOOL_TYPE_RADISH_SEED;
								inventory->tool[temp_total]->quantity = 1;
							}

							stats->dialog_up = 4; // BUY_ACCEPTED
							stats->dialog_place = 0;
							stats->dialog_selection = -1;
						}
						else
						{
							stats->dialog_up = 5; // BUY_REJECTED
							stats->dialog_place = 0;
							stats->dialog_selection = -1;
						}

					}
				}
				else
				{
					stats->dialog_up = 5; // BUY_REJECTED
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				}
			}
			else if (temp_actor == ACTOR_TYPE_DAVID && stats->sex == 1 && stats->dialog_up == -1 && stats->dialog_selection == 0 && stats->hour >= 18 && stats->current_field == 6 &&
				((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || stats->day == stats->days_in_a_season)) ||
				(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || stats->day == stats->days_in_a_season)))) // festivals 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Dance.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Dance.wav"), NULL, SND_FILENAME | SND_ASYNC);

				// move everyone else out of the way?
				
				stats->px = 56;
				stats->py = 45;
				stats->fx = 56.5f;
				stats->fy = 45.5f;
				stats->dx = 57;
				stats->dy = 45;
				stats->rot = 0.0f;
				stats->current_field = 6;

				stats->animation_type = 17; // dancing!
				stats->animation_timer = -5.0f;

				cast->actor[temp_number]->px = 57;
				cast->actor[temp_number]->py = 45;
				cast->actor[temp_number]->fx = 57.5f;
				cast->actor[temp_number]->fy = 45.5f;
				cast->actor[temp_number]->rot = 3.14159f;
				cast->actor[temp_number]->present_field = 6;

				cast->actor[temp_number]->animation_type = 17; // dancing!
				cast->actor[temp_number]->animation_timer = -5.0f;

				cast->actor[temp_number]->affection += 10;

				if (rand() % 2 == 0)
				{
					for (int i=0; i<30; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_CLARA)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 42;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 42.5f;
							cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 18; // playing instrument
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_ANDREW)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 0.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_EMILY)
						{
							cast->actor[i]->px = 58;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 58.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 3.14159f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
					}
				}
				else
				{
					for (int i=0; i<30; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_EMILY)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 42;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 42.5f;
							cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 18; // playing instrument
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_ANDREW)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 0.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_CLARA)
						{
							cast->actor[i]->px = 58;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 58.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 3.14159f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
					}
				}
			}
			else if (temp_actor == ACTOR_TYPE_CLARA && stats->sex == 0 && stats->dialog_up == -1 && stats->dialog_selection == 0 && stats->hour >= 18 && stats->current_field == 6 &&
				((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || stats->day == stats->days_in_a_season)) ||
				(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || stats->day == stats->days_in_a_season)))) // festivals 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Dance.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Dance.wav"), NULL, SND_FILENAME | SND_ASYNC);

				// move everyone else out of the way?
				
				stats->px = 56;
				stats->py = 45;
				stats->fx = 56.5f;
				stats->fy = 45.5f;
				stats->dx = 57;
				stats->dy = 45;
				stats->rot = 0.0f;
				stats->current_field = 6;

				stats->animation_type = 17; // dancing!
				stats->animation_timer = -5.0f;

				cast->actor[temp_number]->px = 57;
				cast->actor[temp_number]->py = 45;
				cast->actor[temp_number]->fx = 57.5f;
				cast->actor[temp_number]->fy = 45.5f;
				cast->actor[temp_number]->rot = 3.14159f;
				cast->actor[temp_number]->present_field = 6;

				cast->actor[temp_number]->animation_type = 17; // dancing!
				cast->actor[temp_number]->animation_timer = -5.0f;

				cast->actor[temp_number]->affection += 10;

				if (rand() % 2 == 0)
				{
					for (int i=0; i<30; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_DAVID)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 42;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 42.5f;
							cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 18; // playing instrument
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_EMILY)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 0.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_ANDREW)
						{
							cast->actor[i]->px = 58;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 58.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 3.14159f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
					}
				}
				else
				{
					for (int i=0; i<30; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_ANDREW)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 42;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 42.5f;
							cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 18; // playing instrument
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_EMILY)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 0.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_DAVID)
						{
							cast->actor[i]->px = 58;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 58.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 3.14159f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
					}
				}
			}
			else if (temp_actor == ACTOR_TYPE_ANDREW && stats->sex == 1 && stats->dialog_up == -1 && stats->dialog_selection == 0 && stats->hour >= 18 && stats->current_field == 6 &&
				((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || stats->day == stats->days_in_a_season)) ||
				(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || stats->day == stats->days_in_a_season)))) // festivals 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Dance.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Dance.wav"), NULL, SND_FILENAME | SND_ASYNC);

				// move everyone else out of the way?
				
				stats->px = 56;
				stats->py = 45;
				stats->fx = 56.5f;
				stats->fy = 45.5f;
				stats->dx = 57;
				stats->dy = 45;
				stats->rot = 0.0f;
				stats->current_field = 6;

				stats->animation_type = 17; // dancing!
				stats->animation_timer = -5.0f;

				cast->actor[temp_number]->px = 57;
				cast->actor[temp_number]->py = 45;
				cast->actor[temp_number]->fx = 57.5f;
				cast->actor[temp_number]->fy = 45.5f;
				cast->actor[temp_number]->rot = 3.14159f;
				cast->actor[temp_number]->present_field = 6;

				cast->actor[temp_number]->animation_type = 17; // dancing!
				cast->actor[temp_number]->animation_timer = -5.0f;

				cast->actor[temp_number]->affection += 10;

				if (rand() % 2 == 0)
				{
					for (int i=0; i<30; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_CLARA)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 42;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 42.5f;
							cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 18; // playing instrument
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_DAVID)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 0.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_EMILY)
						{
							cast->actor[i]->px = 58;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 58.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 3.14159f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
					}
				}
				else
				{
					for (int i=0; i<30; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_EMILY)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 42;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 42.5f;
							cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 18; // playing instrument
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_DAVID)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 0.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_CLARA)
						{
							cast->actor[i]->px = 58;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 58.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 3.14159f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
					}
				}
			}
			else if (temp_actor == ACTOR_TYPE_EMILY && stats->sex == 0 && stats->dialog_up == -1 && stats->dialog_selection == 0 && stats->hour >= 18 && stats->current_field == 6 &&
				((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || stats->day == stats->days_in_a_season)) ||
				(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || stats->day == stats->days_in_a_season)))) // festivals 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Dance.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Dance.wav"), NULL, SND_FILENAME | SND_ASYNC);

				// move everyone else out of the way?
				
				stats->px = 56;
				stats->py = 45;
				stats->fx = 56.5f;
				stats->fy = 45.5f;
				stats->dx = 57;
				stats->dy = 45;
				stats->rot = 0.0f;
				stats->current_field = 6;

				stats->animation_type = 17; // dancing!
				stats->animation_timer = -5.0f;

				cast->actor[temp_number]->px = 57;
				cast->actor[temp_number]->py = 45;
				cast->actor[temp_number]->fx = 57.5f;
				cast->actor[temp_number]->fy = 45.5f;
				cast->actor[temp_number]->rot = 3.14159f;
				cast->actor[temp_number]->present_field = 6;

				cast->actor[temp_number]->animation_type = 17; // dancing!
				cast->actor[temp_number]->animation_timer = -5.0f;

				cast->actor[temp_number]->affection += 10;

				if (rand() % 2 == 0)
				{
					for (int i=0; i<30; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_DAVID)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 42;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 42.5f;
							cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 18; // playing instrument
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_CLARA)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 0.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_ANDREW)
						{
							cast->actor[i]->px = 58;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 58.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 3.14159f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
					}
				}
				else
				{
					for (int i=0; i<30; i++)
					{
						if (cast->actor[i]->type == ACTOR_TYPE_ANDREW)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 42;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 42.5f;
							cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 18; // playing instrument
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_CLARA)
						{
							cast->actor[i]->px = 57;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 57.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 0.0f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
						else if (cast->actor[i]->type == ACTOR_TYPE_DAVID)
						{
							cast->actor[i]->px = 58;
							cast->actor[i]->py = 47;
							cast->actor[i]->fx = 58.5f;
							cast->actor[i]->fy = 47.5f;
							cast->actor[i]->rot = 3.14159f;
							cast->actor[i]->present_field = 6;
		
							cast->actor[i]->animation_type = 17; // dancing
							cast->actor[i]->animation_timer = -5.0f;
						}
					}
				}
			}
			else if (temp_actor == ACTOR_TYPE_DAVID && stats->dialog_up == -1 && stats->dialog_selection == 0 &&
				cast->actor[temp_number]->affection >= 50 && stats->upgrade[0] == 0 && inventory->tool[stats->current_tool]->type == TOOL_TYPE_HOE)
			{
				inventory->tool[stats->current_tool]->type = TOOL_TYPE_ADAMANTINE_HOE;
				stats->upgrade[0] = 1;
			}
			else if (temp_actor == ACTOR_TYPE_CLARA && stats->dialog_up == -1 && stats->dialog_selection == 0 &&
				cast->actor[temp_number]->affection >= 50 && stats->upgrade[1] == 0 && inventory->tool[stats->current_tool]->type == TOOL_TYPE_WATERING_CAN)
			{
				inventory->tool[stats->current_tool]->type = TOOL_TYPE_ADAMANTINE_WATERING_CAN;
				stats->upgrade[1] = 1;
			}
			else if (temp_actor == ACTOR_TYPE_ANDREW && stats->dialog_up == -1 && stats->dialog_selection == 0 &&
				cast->actor[temp_number]->affection >= 50 && stats->upgrade[2] == 0 && inventory->tool[stats->current_tool]->type == TOOL_TYPE_HAMMER)
			{
				inventory->tool[stats->current_tool]->type = TOOL_TYPE_ADAMANTINE_HAMMER;
				stats->upgrade[2] = 1;
			}
			else if (temp_actor == ACTOR_TYPE_EMILY && stats->dialog_up == -1 && stats->dialog_selection == 0 &&
				cast->actor[temp_number]->affection >= 50 && stats->upgrade[3] == 0 && inventory->tool[stats->current_tool]->type == TOOL_TYPE_SCYTHE)
			{
				inventory->tool[stats->current_tool]->type = TOOL_TYPE_ADAMANTINE_SCYTHE;
				stats->upgrade[3] = 1;
			}
		}

		if (stats->animation_type == 11 && stats->animation_timer < 0.0f) // charging
		{	
			glFogf(GL_FOG_START, 0.0f);
			glFogf(GL_FOG_END, 50.0f - 49.0f * sin(-stats->animation_timer / 10.0f * 3.14159f));
		}
		else if (stats->animation_type != 8 && stats->animation_timer < 0.0f) // running between fields
		{
			glFogf(GL_FOG_START, 0.0f);
			glFogf(GL_FOG_END, 50.0f - 49.0f * sin(-stats->animation_timer / 10.0f * 3.14159f));
		}
		else if (stats->weather == 0 && (stats->current_field == 0 || stats->current_field == 3 ||
			stats->current_field == 4 || stats->current_field == 6 || stats->current_field == 9)) // outside places, really
		{
			glFogf(GL_FOG_START, 250.0f * sin(((float)stats->hour * 60.0f + (float)stats->minute - 360.0f) / 720.0f * 3.14159f));
			glFogf(GL_FOG_END, 1000.0f * sin(((float)stats->hour * 60.0f + (float)stats->minute - 360.0f) / 720.0f * 3.14159f) + 75.0f);
		}
		else if (stats->weather == 1 && (stats->current_field == 0 || stats->current_field == 3 ||
			stats->current_field == 4 || stats->current_field == 6 || stats->current_field == 9)) // outside places, really
		{
			glFogf(GL_FOG_START, 20.0f * sin(((float)stats->hour * 60.0f + (float)stats->minute - 360.0f) / 720.0f * 3.14159f));
			glFogf(GL_FOG_END, 50.0f * sin(((float)stats->hour * 60.0f + (float)stats->minute - 360.0f) / 720.0f * 3.14159f) + 50.0f);
		}
		else 
		{
			glFogf(GL_FOG_START, 250.0f);
			glFogf(GL_FOG_END, 1000.0f);
		}
	
		camera_pos->x = stats->fx*3.0f;
		camera_pos->y = camera_distance + (camera_distance==20.0f?1.0f:0.0f) + (camera_distance==15.0f?2.0f:0.0f) + (camera_distance==10.0f?4.0f:0.0f);
		camera_pos->z = stats->fy*3.0f + camera_distance;	

		if (stats->weather == 1) // raining
		{
			for (int i=0; i<10000; i++)
			{
				if (rain_pos_y[i] <= 0.0f)
				{
					rain_pos_x[i] = 3.0f * (float)(rand() % 10000) / 100.0f;
					rain_pos_y[i] = (float)(rand() % 10000) / 100.0f;
					rain_pos_z[i] = 3.0f * (float)(rand() % 10000) / 100.0f;
				}

				if (stats->season != 4) rain_pos_y[i] -= 0.5f * compute_cycles_total;
				else if (stats->season == 4) rain_pos_y[i] -= 0.1f * compute_cycles_total;
			}
		}
	
		glRotatef(-camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
		glRotatef(-camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(-camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glTranslatef(-camera_pos->x, -camera_pos->y, -camera_pos->z);
		
		if (stats->weather == 1 &&
			(stats->current_field == 0 || stats->current_field == 3 ||
			stats->current_field == 4 || stats->current_field == 6)) // raining
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

			glDisable(GL_LIGHTING);

			if (stats->season != 4) glColor3f(0.0f, 0.0f, 1.0f);
			else if (stats->season == 4) glColor3f(0.9f, 0.9f, 1.0f);

			for (int i=0; i<10000; i++)
			{
				glBegin(GL_LINES);
	
				if (stats->season != 4)
				{
					glVertex3f(rain_pos_x[i], rain_pos_y[i], rain_pos_z[i]);
					glVertex3f(rain_pos_x[i], rain_pos_y[i]+0.5f, rain_pos_z[i]);
				}
				else if (stats->season == 4)
				{
					glVertex3f(rain_pos_x[i], rain_pos_y[i], rain_pos_z[i]);
					glVertex3f(rain_pos_x[i], rain_pos_y[i]+0.25f, rain_pos_z[i]);
				}
			

				glEnd();
			}

			glEnable(GL_LIGHTING);
		}		
	
		for (int i=stats->px-25; i<=stats->px+25; i++)
		{
			for (int j=stats->py-30; j<=stats->py+20; j++)
			{
				if (i >= 0 && i < 100 && j >= 0 && j < 100)
				{
					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

					glDisable(GL_LIGHTING);
	
					if (i == stats->dx && j == stats->dy)
					{
						glColor3f(0,0,1);
		
						glBegin(GL_LINES);
		
						glVertex3f((float)(i)*3.0f, 0.5f, (float)(j)*3.0f);
						glVertex3f((float)(i)*3.0f, 0.5f, (float)(j+1)*3.0f);
		
						glVertex3f((float)(i)*3.0f, 0.5f, (float)(j+1)*3.0f);
						glVertex3f((float)(i+1)*3.0f, 0.5f, (float)(j+1)*3.0f);
		
						glVertex3f((float)(i+1)*3.0f, 0.5f, (float)(j+1)*3.0f);
						glVertex3f((float)(i+1)*3.0f, 0.5f, (float)(j)*3.0f);
		
						glVertex3f((float)(i+1)*3.0f, 0.5f, (float)(j)*3.0f);
						glVertex3f((float)(i)*3.0f, 0.5f, (float)(j)*3.0f);
						
						glEnd();
					}

					glEnable(GL_LIGHTING);
		
					DrawSprite(i, j, field[stats->current_field]->tile[i][j]->type, field[stats->current_field]->tile[i][j]->water,
						field[stats->current_field]->tile[i][j]->growth, field[stats->current_field]->tile[i][j]->style, stats->season);
				
					if ((stats->current_field == 0 || stats->current_field == 3 ||
						stats->current_field == 4 || stats->current_field == 6 ||
						stats->current_field == 9) && 
						!(stats->hour == 18 && stats->minute == 0)) // or others
					{
						DrawShadow((float)i, (float)j, field[stats->current_field]->tile[i][j]->type, field[stats->current_field]->tile[i][j]->growth,
							field[stats->current_field]->tile[i][j]->style, stats->hour, stats->minute);
					}
				}
			}
		}
	
		DrawFieldStructures(stats->current_field);
		
		glColor3f(1,1,1);
		
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
	
		for (int i=0; i<30; i++)
		{
			if (cast->actor[i]->type != ACTOR_TYPE_NONE && cast->actor[i]->present_field == stats->current_field)
			{
				if (cast->actor[i]->type == ACTOR_TYPE_ROVER)
				{
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glRotatef(cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					DrawRover(cast->actor[i]->affection, cast->actor[i]->rot, cast->actor[i]->primary_color, 
						cast->actor[i]->secondary_color, cast->actor[i]->tertiary_color, cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
					glRotatef(-cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					glTranslatef(-cast->actor[i]->fx*3.0f, 0.0f, -cast->actor[i]->fy*3.0f);
	
					if ((stats->current_field == 0 || stats->current_field == 3 ||
						stats->current_field == 4 || stats->current_field == 6 ||
						stats->current_field == 9) && !(stats->hour == 18 && stats->minute == 0)) // or others
					{
						DrawShadow(cast->actor[i]->fx-0.5f, cast->actor[i]->fy-0.5f, 0, 1, 0, stats->hour, stats->minute);
					}
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_PARROT)
				{
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glRotatef(cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					DrawParrot(cast->actor[i]->affection, cast->actor[i]->rot, cast->actor[i]->primary_color, 
						cast->actor[i]->secondary_color, cast->actor[i]->tertiary_color, cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
					glRotatef(-cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					glTranslatef(-cast->actor[i]->fx*3.0f, 0.0f, -cast->actor[i]->fy*3.0f);
	
					if ((stats->current_field == 0 || stats->current_field == 3 ||
						stats->current_field == 4 || stats->current_field == 6 ||
						stats->current_field == 9) && !(stats->hour == 18 && stats->minute == 0)) // or others
					{
						DrawShadow(cast->actor[i]->fx-0.5f, cast->actor[i]->fy-0.5f, 0, 1, 0, stats->hour, stats->minute);
					}
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_BUY_ROVER)
				{
					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glColor3f(0.5f, 0.5f, 0.5f);
					DrawComponent(container_point, container_indice, 12);
					glTranslatef(0.0f, 3.0f, 0.0f);
					glScalef(0.75f, 0.75f, 0.75f);
					DrawRover(cast->actor[i]->affection, cast->actor[i]->rot, cast->actor[i]->primary_color, 
						cast->actor[i]->secondary_color, cast->actor[i]->tertiary_color, cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
					glScalef(4.0f / 3.0f, 4.0f / 3.0f, 4.0f / 3.0f);
					glTranslatef(-cast->actor[i]->fx*3.0f, -3.0f, -cast->actor[i]->fy*3.0f);
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_SELL_ROVER)
				{
					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glColor3f(0.5f, 0.5f, 0.5f);
					DrawComponent(container_point, container_indice, 12);
					glTranslatef(0.0f, 3.0f, 0.0f);
					glScalef(0.75f, 0.75f, 0.75f);
					DrawRover(cast->actor[i]->affection, cast->actor[i]->rot, cast->actor[i]->primary_color, 
						cast->actor[i]->secondary_color, cast->actor[i]->tertiary_color, cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
					glScalef(4.0f / 3.0f, 4.0f / 3.0f, 4.0f / 3.0f);
					glTranslatef(-cast->actor[i]->fx*3.0f, -3.0f, -cast->actor[i]->fy*3.0f);
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_BUY_WATER_GENERATOR)
				{
					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

					glPushMatrix();
					
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);

					glColor3f(0.5f, 0.5f, 0.5f);
					DrawComponent(container_point, container_indice, 12);
					glTranslatef(0.0f, 3.0f, 0.0f);

					glScalef(0.5f, 0.5f, 0.5f);

					DrawComponent(water_generator_point, water_generator_indice, 10);

					glColor3f(1,1,1);

					glTranslatef(0.0f, 4.0f, 0.0f);
		
					glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
					glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
					//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		
					glBegin(GL_QUADS);
		
					glColor3f(0.25f, 0.25f, 1.0f);
					glNormal3f(0.0f, 0.0f, 1.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-0.75f, 3.0f, 0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-0.75f, 0.0f, 0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(0.75f, 0.0f, 0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(0.75f, 3.0f, 0.5f);

					glColor3f(0.25f, 0.25f, 1.0f);
					glNormal3f(0.0f, 1.0f, 0.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-0.8f, 3.0f, -0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-0.8f, 3.0f, 0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(0.8f, 3.0f, 0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(0.8f, 3.0f, -0.5f);

					glEnd();

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);
		
					glBegin(GL_QUADS);

					glColor3f(0.5f, 0.5f, 0.5f);
					glNormal3f(0.0f, 0.0f, 1.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-0.8f, 3.0f, 0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-0.8f, 0.0f, 0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(-0.75f, 0.0f, 0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(-0.75f, 3.0f, 0.5f);

					glColor3f(0.5f, 0.5f, 0.5f);
					glNormal3f(0.0f, 0.0f, 1.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(0.75f, 3.0f, 0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(0.75f, 0.0f, 0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(0.8f, 0.0f, 0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(0.8f, 3.0f, 0.5f);

					glColor3f(0.5f, 0.5f, 0.5f);
					glNormal3f(0.0f, 0.0f, 1.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-0.8f, 3.2f, 0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-0.8f, 3.0f, 0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(0.8f, 3.0f, 0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(0.8f, 3.2f, 0.5f);

					glColor3f(0.5f, 0.5f, 0.5f);
					glNormal3f(-1.0f, 0.0f, 0.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-0.8f, 3.2f, -0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-0.8f, 0.0f, -0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(-0.8f, 0.0f, 0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(-0.8f, 3.2f, 0.5f);

					glColor3f(0.5f, 0.5f, 0.5f);
					glNormal3f(1.0f, 0.0f, 0.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(0.8f, 3.2f, 0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(0.8f, 0.0f, 0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(0.8f, 0.0f, -0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(0.8f, 3.2f, -0.5f);

					glColor3f(0.5f, 0.5f, 0.5f);
					glNormal3f(0.0f, 1.0f, 0.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-0.8f, 3.2f, -0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-0.8f, 3.2f, 0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(0.8f, 3.2f, 0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(0.8f, 3.2f, -0.5f);
/*
					glColor3f(0.5f, 0.5f, 0.5f);
					glNormal3f(0.0f, 0.0f, 1.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-0.8f, 3.2f, -0.5f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-0.8f, 0.0f, -0.5f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(0.8f, 0.0f, -0.5f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(0.8f, 3.2f, -0.5f);
*/
					glEnd();
			
					glPopMatrix();
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_BUY_GIFT_BASKET)
				{
					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

					glPushMatrix();
					
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);

					glColor3f(0.5f, 0.5f, 0.5f);

					DrawComponent(container_point, container_indice, 12);

					glTranslatef(0.0f, 3.0f, 0.45f);

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BASKET_HERB]);

					glColor3f(1,1,1);
			

					glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
					glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
					glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

					glBegin(GL_QUADS);
			
					glNormal3f(0.0f, 0.707f, 0.707f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-1.25f, 2.5f, 0.1f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-1.25f, 0.0f, 0.1f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(1.25f, 0.0f, 0.1f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(1.25f, 2.5f, 0.1f);
				
					glEnd();

					glPopMatrix();
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_BUY_ORE)
				{
					glPushMatrix();

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glColor3f(0.5f, 0.5f, 0.5f);
					DrawComponent(container_point, container_indice, 12);

					glTranslatef(0.0f, 3.0f, 0.35f);

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE]);

					glColor3f(1,1,1);
			
					glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
					glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
					glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

					glBegin(GL_QUADS);
			
					glNormal3f(0.0f, 0.707f, 0.707f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-1.0f, 2.0f, 0.1f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-1.0f, 0.0f, 0.1f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(1.0f, 0.0f, 0.1f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(1.0f, 2.0f, 0.1f);
				
					glEnd();

					glPopMatrix();
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_BUY_NANOTUBE)
				{
					glPushMatrix();

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glColor3f(0.5f, 0.5f, 0.5f);
					DrawComponent(container_point, container_indice, 12);

					glTranslatef(0.0f, 3.0f, 0.35f);

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE]);

					glColor3f(1,1,1);
			
					glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
					glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
					glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

					glBegin(GL_QUADS);
			
					glNormal3f(0.0f, 0.707f, 0.707f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-1.0f, 2.0f, 0.1f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-1.0f, 0.0f, 0.1f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(1.0f, 0.0f, 0.1f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(1.0f, 2.0f, 0.1f);
				
					glEnd();

					glPopMatrix();
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_BUY_RADISH_SEEDS ||
					cast->actor[i]->type == ACTOR_TYPE_BUY_CABBAGE_SEEDS ||
					cast->actor[i]->type == ACTOR_TYPE_BUY_CUCUMBER_SEEDS ||
					cast->actor[i]->type == ACTOR_TYPE_BUY_BEANS_SEEDS ||
					cast->actor[i]->type == ACTOR_TYPE_BUY_MELON_SEEDS ||
					cast->actor[i]->type == ACTOR_TYPE_BUY_TURNIP_SEEDS ||
					cast->actor[i]->type == ACTOR_TYPE_BUY_ONION_SEEDS ||
					cast->actor[i]->type == ACTOR_TYPE_BUY_RYE_SEEDS ||
					cast->actor[i]->type == ACTOR_TYPE_BUY_NANOTUBE_SEEDS)
				{
					glPushMatrix();

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glColor3f(0.5f, 0.5f, 0.5f);
					DrawComponent(container_point, container_indice, 12);

					glTranslatef(0.0f, 3.0f, 0.35f);

					if (cast->actor[i]->type == ACTOR_TYPE_BUY_RADISH_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH_SEED]);
					else if (cast->actor[i]->type == ACTOR_TYPE_BUY_CABBAGE_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE_SEED]);
					else if (cast->actor[i]->type == ACTOR_TYPE_BUY_CUCUMBER_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER_SEED]);
					else if (cast->actor[i]->type == ACTOR_TYPE_BUY_BEANS_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS_SEED]);
					else if (cast->actor[i]->type == ACTOR_TYPE_BUY_MELON_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON_SEED]);
					else if (cast->actor[i]->type == ACTOR_TYPE_BUY_TURNIP_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP_SEED]);
					else if (cast->actor[i]->type == ACTOR_TYPE_BUY_ONION_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION_SEED]);
					else if (cast->actor[i]->type == ACTOR_TYPE_BUY_RYE_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE_SEED]);
					else if (cast->actor[i]->type == ACTOR_TYPE_BUY_NANOTUBE_SEEDS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE_SEED]);

					glColor3f(1,1,1);
			
					glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
					glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
					glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

					glBegin(GL_QUADS);
			
					glNormal3f(0.0f, 0.707f, 0.707f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-1.0f, 2.0f, 0.1f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-1.0f, 0.0f, 0.1f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(1.0f, 0.0f, 0.1f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(1.0f, 2.0f, 0.1f);
				
					glEnd();

					glPopMatrix();
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_BUY_NOTHING)
				{
					glPushMatrix();

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glColor3f(0.5f, 0.5f, 0.5f);
					DrawComponent(container_point, container_indice, 12);

					glPopMatrix();
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_DAVID)
				{
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glRotatef(cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					DrawRobot(0, 0, 0, cast->actor[i]->rot, cast->actor[i]->primary_color, 
						cast->actor[i]->secondary_color, cast->actor[i]->tertiary_color, cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
					glRotatef(-cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					glTranslatef(-cast->actor[i]->fx*3.0f, 0.0f, -cast->actor[i]->fy*3.0f);
	
					if ((stats->current_field == 0 || stats->current_field == 3 ||
						stats->current_field == 4 || stats->current_field == 6 ||
						stats->current_field == 9) && !(stats->hour == 18 && stats->minute == 0)) // or others
					{
						DrawShadow(cast->actor[i]->fx-0.5f, cast->actor[i]->fy-0.5f, 0, 1, 0, stats->hour, stats->minute);
					}
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_CLARA)
				{
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glRotatef(cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					DrawRobot(1, 0, 0, cast->actor[i]->rot, cast->actor[i]->primary_color, 
						cast->actor[i]->secondary_color, cast->actor[i]->tertiary_color, cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
					glRotatef(-cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					glTranslatef(-cast->actor[i]->fx*3.0f, 0.0f, -cast->actor[i]->fy*3.0f);
	
					if ((stats->current_field == 0 || stats->current_field == 3 ||
						stats->current_field == 4 || stats->current_field == 6 ||
						stats->current_field == 9) && !(stats->hour == 18 && stats->minute == 0)) // or others
					{
						DrawShadow(cast->actor[i]->fx-0.5f, cast->actor[i]->fy-0.5f, 0, 1, 0, stats->hour, stats->minute);
					}
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_ANDREW)
				{
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glRotatef(cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					DrawRobot(0, 0, 0, cast->actor[i]->rot, cast->actor[i]->primary_color, 
						cast->actor[i]->secondary_color, cast->actor[i]->tertiary_color, cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
					glRotatef(-cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					glTranslatef(-cast->actor[i]->fx*3.0f, 0.0f, -cast->actor[i]->fy*3.0f);
	
					if ((stats->current_field == 0 || stats->current_field == 3 ||
						stats->current_field == 4 || stats->current_field == 6 ||
						stats->current_field == 9) && !(stats->hour == 18 && stats->minute == 0)) // or others
					{
						DrawShadow(cast->actor[i]->fx-0.5f, cast->actor[i]->fy-0.5f, 0, 1, 0, stats->hour, stats->minute);
					}
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_EMILY)
				{
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					glRotatef(cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					DrawRobot(1, 0, 0, cast->actor[i]->rot, cast->actor[i]->primary_color, 
						cast->actor[i]->secondary_color, cast->actor[i]->tertiary_color, cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
					glRotatef(-cast->actor[i]->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
					glTranslatef(-cast->actor[i]->fx*3.0f, 0.0f, -cast->actor[i]->fy*3.0f);
	
					if ((stats->current_field == 0 || stats->current_field == 3 ||
						stats->current_field == 4 || stats->current_field == 6 ||
						stats->current_field == 9) && !(stats->hour == 18 && stats->minute == 0)) // or others
					{
						DrawShadow(cast->actor[i]->fx-0.5f, cast->actor[i]->fy-0.5f, 0, 1, 0, stats->hour, stats->minute);
					}
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_BIBLE_STATION)
				{
					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

					glPushMatrix();
					
					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);

					glColor3f(1,1,1);

					DrawComponent(arcade_point, arcade_indice, 8);

					cast->actor[i]->affection += 1 * compute_cycles_total;

					if (cast->actor[i]->affection > 101) cast->actor[i]->affection -= 100;

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

					glColor3f((float)cast->actor[i]->affection / 200.0f + 0.25f, 
						(float)cast->actor[i]->affection / 200.0f + 0.5f, 
						(float)cast->actor[i]->affection / 200.0f + 0.5f);
					
					glBegin(GL_QUADS);

					glNormal3f(0.0f, 1.0f, 0.0f);
					glTexCoord2f(0,1);
					glVertex3f(-1.6f, 3.55f, -1.6f);
					glTexCoord2f(0,0);
					glVertex3f(-1.6f, 3.55f, 1.6f);
					glTexCoord2f(1,0);
					glVertex3f(1.6f, 3.55f, 1.6f);
					glTexCoord2f(1,1);
					glVertex3f(1.6f, 3.55f, -1.6f);
	
					glEnd();
		
					glPopMatrix();
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_WEATHER_GAUGE)
				{
					glPushMatrix();

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					
					glColor3f(0.5f, 0.5f, 0.5f);
					DrawComponent(weather_gauge_lower_point, weather_gauge_lower_indice, 10);

					cast->actor[i]->affection += 1 * compute_cycles_total;

					if (cast->actor[i]->affection > 101) cast->actor[i]->affection -= 100;

					glRotatef(360.0f * (float)cast->actor[i]->affection / 100.0f, 0.0f, 1.0f, 0.0f);

					glColor3f(0.75f, 0.75f, 0.75f);
					DrawComponent(weather_gauge_upper_point, weather_gauge_upper_indice, 18);

					glPopMatrix();

					if ((stats->current_field == 0 || stats->current_field == 3 ||
						stats->current_field == 4 || stats->current_field == 6 ||
						stats->current_field == 9) && !(stats->hour == 18 && stats->minute == 0)) // or others
					{
						DrawShadow(cast->actor[i]->fx-0.5f, cast->actor[i]->fy-0.5f, 0, 1, 0, stats->hour, stats->minute);
					}
				}
				else if (cast->actor[i]->type == ACTOR_TYPE_TELEVISION)
				{
					glPushMatrix();

					glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

					glTranslatef(cast->actor[i]->fx*3.0f, 0.0f, cast->actor[i]->fy*3.0f);
					
					glColor3f(1.0f, 1.0f, 1.0f);
					DrawComponent(television_point, television_indice, 10);

					if (cast->actor[i]->affection > 0)
					{
						glColor3f(1,1,1);

						glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TELEVISION]);
					}
					else
					{
						glColor3f(0.1f, 0.1f, 0.1f);

						glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
					}
		
					glTranslatef(0.0f, 0.0f, 1.5f);
			
					glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
					glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
					//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

					glBegin(GL_QUADS);
			
					glNormal3f(0.0f, 0.0f, 1.0f);
					glTexCoord2f(0.0f, 1.0f);
					glVertex3f(-1.0f, 5.0f, 0.1f);
					glTexCoord2f(0.0f, 0.0f);
					glVertex3f(-1.0f, 3.0f, 0.1f);
					glTexCoord2f(1.0f, 0.0f);
					glVertex3f(1.0f, 3.0f, 0.1f);
					glTexCoord2f(1.0f, 1.0f);
					glVertex3f(1.0f, 5.0f, 0.1f);
					
					glEnd();

					cast->actor[i]->affection = 0;

					glPopMatrix();
				}
			}
		}	
	
		glTranslatef(stats->fx*3.0f, 0.0f, stats->fy*3.0f);
		glRotatef(stats->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		//if (stats->success == 1) glScalef(1.1f, 1.1f, 1.1f);
		DrawRobot(stats->sex, 3 * (stats->success > 0 ? 1 : 0), inventory->tool[stats->current_tool]->type, stats->rot, stats->primary_color, stats->secondary_color, stats->tertiary_color,
			stats->animation_type, stats->animation_timer);
		//if (stats->success == 1) glScalef(1.0f / 1.1f, 1.0f / 1.1f, 1.0f / 1.1f);
		glRotatef(-stats->rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glTranslatef(-stats->fx*3.0f, 0.0f, -stats->fy*3.0f);
	
		if ((stats->current_field == 0 || stats->current_field == 3 ||
			stats->current_field == 4 || stats->current_field == 6 ||
			stats->current_field == 9) && !(stats->hour == 18 && stats->minute == 0)) // or others
		{
			DrawShadow(stats->fx-0.5f, stats->fy-0.5f, 0, 1, 0, stats->hour, stats->minute);
		}
		
		glutSwapBuffers();
	}	


	return;
};

void MiniGameLoop()
{
	float left_bound = -0.49f, right_bound = 0.49f, upper_bound = 0.35f, lower_bound = -0.35f; 

	float prev_x, prev_y;

	float craft_speed;

	int bullets_fired;

	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])
	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;

			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}
	}
	else frame_change_button_down = false;
*/

	craft_speed = 0.01f * (float)compute_cycles_total;

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		
		glColor3f(1,1,1);
		glRasterPos3f(-0.49f, 0.36f, -0.9f);
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'F');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'P');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'S');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, '=');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second1 % 10000) - (frames_per_second1 % 1000)) / 1000 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second1 % 1000) - (frames_per_second1 % 100)) / 100 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second1 % 100) - (frames_per_second1 % 10)) / 10 + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((frames_per_second1 % 10) + 48));
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, '/');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((60 / compute_cycles_total) / 10) + '0');
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((60 / compute_cycles_total) % 10) + '0');


		glColor3f(1,1,1);

		glPushMatrix();	
		glTranslatef(0.3f, 0.3f, -0.8f);
		glScalef(0.0001f, 0.00015f, 0.00015f);
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'C');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'O');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'E');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((minigame_score % 1000000) - (minigame_score % 100000)) / 100000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((minigame_score % 100000) - (minigame_score % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((minigame_score % 10000) - (minigame_score % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((minigame_score % 1000) - (minigame_score % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((minigame_score % 100) - (minigame_score % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((minigame_score % 10) + 48));
		glPopMatrix();

		glPushMatrix();	
		glTranslatef(0.3f, 0.275f, -0.8f);
		glScalef(0.0001f, 0.00015f, 0.00015f);
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'H');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'I');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'G');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'H');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_high_score % 1000000) - (stats->minigame_high_score % 100000)) / 100000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_high_score % 100000) - (stats->minigame_high_score % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_high_score % 10000) - (stats->minigame_high_score % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_high_score % 1000) - (stats->minigame_high_score % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_high_score % 100) - (stats->minigame_high_score % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->minigame_high_score % 10) + 48));
		glPopMatrix();

		glPushMatrix();	
		glTranslatef(0.3f, 0.25f, -0.8f);
		glScalef(0.0001f, 0.00015f, 0.00015f);
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'E');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'V');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_prev_score % 1000000) - (stats->minigame_prev_score % 100000)) / 100000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_prev_score % 100000) - (stats->minigame_prev_score % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_prev_score % 10000) - (stats->minigame_prev_score % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_prev_score % 1000) - (stats->minigame_prev_score % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_prev_score % 100) - (stats->minigame_prev_score % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->minigame_prev_score % 10) + 48));
		glPopMatrix();	

		//glEnable(GL_LIGHTING);

	
		
		//if (keyboard[27] || joystick_button[9]) exit(1);

		
		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		prev_x = minigame_pos_x;
		prev_y = minigame_pos_y;

		if (control_down_on) { minigame_pos_y -= craft_speed; if (minigame_pos_y < lower_bound) minigame_pos_y = lower_bound; }
		if (control_up_on) { minigame_pos_y += craft_speed; if (minigame_pos_y > upper_bound) minigame_pos_y = upper_bound; }
		if (control_left_on) { minigame_pos_x -= craft_speed; if (minigame_pos_x < left_bound) minigame_pos_x = left_bound; }
		if (control_right_on) { minigame_pos_x += craft_speed; if (minigame_pos_x > right_bound) minigame_pos_x = right_bound; }

		bullets_fired = 0;

		minigame_fire_delay += 0.01f * (float)compute_cycles_total;
		if (minigame_fire_delay > 1.0f) minigame_fire_delay = 1.0f;

		if (control_activate_on)
		{
			if (linux_box == true && sound_on == true) if (minigame_sound_delay == 0) system("play -q -v 1.0 ./Sounds/Laser.wav &");
			else if (linux_box == false && sound_on == true) if (minigame_sound_delay == 0) PlaySound(TEXT("Sounds\\Laser.wav"), NULL, SND_FILENAME | SND_ASYNC);
		
			minigame_sound_delay++;

			if (minigame_sound_delay > 6 / compute_cycles_total) minigame_sound_delay = 0;
		}

		if (control_activate_on && minigame_fire_delay > 0.0f)
		{
			for (int i=0; i<50; i++)
			{
				if (minigame_bullet_pos_y[i] > upper_bound)
				{
					minigame_bullet_pos_x[i] = prev_x + (minigame_pos_x - prev_x) * (float)bullets_fired / (float)compute_cycles_total;

					minigame_bullet_pos_y[i] = prev_y + (minigame_pos_y - prev_y) * (float)bullets_fired / (float)compute_cycles_total - 
						(float)bullets_fired * craft_speed / (float)compute_cycles_total;
				
					minigame_fire_delay -= 0.05f;

					bullets_fired++;

					if (bullets_fired >= compute_cycles_total) i = 51;
				}
			}
		}

		if (control_status_on || control_menu_on) 
		{
			if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Bomb.wav &");
			else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Bomb.wav"), NULL, SND_FILENAME | SND_ASYNC);

			minigame_active = false; // quit

			if (minigame_score > stats->minigame_high_score) stats->minigame_high_score = minigame_score;
			stats->minigame_prev_score = minigame_score;
		}


		if (time(0) != last_time)
		{
			last_time = time(0);

			minigame_speed += 0.0001f * (float)compute_cycles_total;

			minigame_score += (int)(minigame_speed * 1000.0f);
		}

		for (int i=0; i<50; i++)
		{
			minigame_enemy_pos_y[i] -= minigame_speed * (float)compute_cycles_total;

			if (minigame_enemy_pos_y[i] < lower_bound)
			{
				minigame_enemy_pos_x[i] = left_bound + (right_bound - left_bound) * (float)(rand() % 100) / 100.0f;
				minigame_enemy_pos_y[i] = upper_bound + 3.0f * upper_bound * (float)(rand() % 100) / 100.0f;
			}

			minigame_star_pos_y[i] -= minigame_speed * (float)compute_cycles_total;

			if (minigame_star_pos_y[i] < lower_bound)
			{
				minigame_star_pos_x[i] = left_bound + (right_bound - left_bound) * (float)(rand() % 100) / 100.0f;
				minigame_star_pos_y[i] = upper_bound + 3.0f * upper_bound * (float)(rand() % 100) / 100.0f;
			}

			minigame_bullet_pos_y[i] += craft_speed;// / (float)compute_cycles_total;

			if (fabs(minigame_pos_x - minigame_enemy_pos_x[i]) <= 0.025f &&
				fabs(minigame_pos_y - minigame_enemy_pos_y[i]) <= 0.025f)
			{
				// game over
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Bomb.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Bomb.wav"), NULL, SND_FILENAME | SND_ASYNC);

				minigame_active = false;

				if (minigame_score > stats->minigame_high_score) stats->minigame_high_score = minigame_score;
				stats->minigame_prev_score = minigame_score;
			}

			for (int j=0; j<50; j++)
			{
				for (float k=0.0f; k<=1.0f; k+=0.001f)
				{
					if (fabs(minigame_bullet_pos_x[j] - minigame_enemy_pos_x[i]) <= 0.016f &&
						fabs((minigame_bullet_pos_y[j]-k*craft_speed) - (minigame_enemy_pos_y[i]+k*minigame_speed*(float)compute_cycles_total)) <= 0.016f)
					{
						minigame_enemy_pos_x[i] = left_bound + (right_bound - left_bound) * (float)(rand() % 100) / 100.0f;
						minigame_enemy_pos_y[i] = upper_bound + 3.0f * upper_bound * (float)(rand() % 100) / 100.0f;
	
						minigame_bullet_pos_y[i] = 100.0f;
		
						minigame_score++;

						k = 1.1f;
					}
				}
			}
		}
					

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(0.01f, 0.01f, 0.01f);

		glScalef(4.0f, 4.0f, 1.0f);

		glBegin(GL_QUADS);

		glVertex3f(left_bound, upper_bound, -1.0f);
		glVertex3f(left_bound, lower_bound, -1.0f);
		glVertex3f(right_bound, lower_bound, -1.0f);
		glVertex3f(right_bound, upper_bound, -1.0f);

		glEnd();

		glScalef(0.25f, 0.25f, 1.0f);

		glColor3f(1,1,1);

		for (int i=0; i<50; i++)
		{
			glBegin(GL_POINTS);

			glVertex3f(minigame_star_pos_x[i], minigame_star_pos_y[i], -0.902f);

			glEnd();
		}

		glColor3f(0,1,0);
		
		for (int i=0; i<50; i++)
		{
			glBegin(GL_QUADS);

			glVertex3f(minigame_bullet_pos_x[i]-0.002f, minigame_bullet_pos_y[i]-0.002f, -0.901f);
			glVertex3f(minigame_bullet_pos_x[i]-0.002f, minigame_bullet_pos_y[i]+0.002f, -0.901f);
			glVertex3f(minigame_bullet_pos_x[i]+0.002f, minigame_bullet_pos_y[i]+0.002f, -0.901f);
			glVertex3f(minigame_bullet_pos_x[i]+0.002f, minigame_bullet_pos_y[i]-0.002f, -0.901f);

			glEnd();
		}

		glColor3f(0,0,1);
		
		for (int i=0; i<50; i++)
		{
			glTranslatef(minigame_enemy_pos_x[i], minigame_enemy_pos_y[i], -0.901f);

			glRotatef((minigame_enemy_pos_x[i] * 7.0f + minigame_enemy_pos_y[i] * 5.0f) * 360.0f, 0.0f, 0.0f, 1.0f);

			glBegin(GL_QUADS);

			glVertex3f(-0.01f, -0.01f, 0.0f);
			glVertex3f(-0.01f, 0.01f, 0.0f);
			glVertex3f(0.01f, 0.01f, 0.0f);
			glVertex3f(0.01f, -0.01f, 0.0f);

			glEnd();

			glRotatef(-(minigame_enemy_pos_x[i] * 7.0f + minigame_enemy_pos_y[i] * 5.0f) * 360.0f, 0.0f, 0.0f, 1.0f);

			glTranslatef(-minigame_enemy_pos_x[i], -minigame_enemy_pos_y[i], 0.901f);
		}

		glColor3f(1,0,0);
		
		glBegin(GL_TRIANGLES);

		glVertex3f(minigame_pos_x-0.015f, minigame_pos_y+0.01f, -0.8999f);
		glVertex3f(minigame_pos_x-0.015f, minigame_pos_y-0.015f, -0.8999f);
		glVertex3f(minigame_pos_x-0.005f, minigame_pos_y-0.015f, -0.8999f);

		glVertex3f(minigame_pos_x+0.015f, minigame_pos_y+0.01f, -0.8999f);
		glVertex3f(minigame_pos_x+0.005f, minigame_pos_y-0.015f, -0.8999f);
		glVertex3f(minigame_pos_x+0.015f, minigame_pos_y-0.015f, -0.8999f);

		glEnd();

		glColor3f(1,1,1);
		
		glBegin(GL_TRIANGLES);

		glVertex3f(minigame_pos_x, minigame_pos_y+0.015f, -0.9f);
		glVertex3f(minigame_pos_x-0.015f, minigame_pos_y-0.0125f, -0.9f);
		glVertex3f(minigame_pos_x+0.015f, minigame_pos_y-0.0125f, -0.9f);

		glEnd();
		
		glutSwapBuffers();
	}
	
	return;
};

void IntroScreenLoop()
{
	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])
	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;

			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}
	}
	else frame_change_button_down = false;
*/

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_INTRO_SCREEN]);

		glBegin(GL_QUADS);

		glTexCoord2f(0,1);
		glVertex3f(-0.575f, 0.42f, -1.0f);
		glTexCoord2f(0,0);
		glVertex3f(-0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.575f, 0.42f, -1.0f);

		glEnd();

		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		if (control_activate_on)
		{
			if (menu_button_down == false) 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

				if (menu_position == 0)
				{
					menu_system_active = 0;

					// Load saved game!
					if (!Load(field, inventory, cast, stats, "SaveFile.txt"))
					{
						// Starting new game!

						InitializeFields(field, inventory, cast, stats);

						menu_system_active = 5;

						menu_position = 0;

						menu_name_length = 0;
					}
					else
					{
						Sleep(field, inventory, cast, stats);
					}
				}
				else if (menu_position == 1) 
				{
					// Making sure now...

					menu_system_active = 6;
					menu_position = 0;
				}
				else if (menu_position == 2) { menu_system_active = 2; menu_position = 0; }
				else if (menu_position == 3) exit(1);
			}

			menu_button_down = true;

			for (int i=0; i<256; i++) { keyboard[i] = 0; }
		}
		else if (control_up_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { menu_position--; if (menu_position < 0) menu_position = 0; }
		
			menu_button_down = true;
		}
		else if (control_down_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { menu_position++; if (menu_position > 3) menu_position = 3; }
	
			menu_button_down = true;
		}
		else menu_button_down = false;		

		//if (keyboard[27] || joystick_button[9]) exit(1);

		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,0,0);

		glLineWidth(4);
		
		glBegin(GL_LINES);

		glVertex3f(-0.2f, 0.1f - 0.105f * (float)menu_position, -0.95f);
		glVertex3f(-0.2f, 0.0f - 0.105f * (float)menu_position, -0.95f);

		glVertex3f(0.2f, 0.1f - 0.105f * (float)menu_position, -0.95f);
		glVertex3f(0.2f, 0.0f - 0.105f * (float)menu_position, -0.95f);

		glVertex3f(0.2f, 0.1f - 0.105f * (float)menu_position, -0.95f);
		glVertex3f(-0.2f, 0.1f - 0.105f * (float)menu_position, -0.95f);

		glVertex3f(0.2f, 0.0f - 0.105f * (float)menu_position, -0.95f);
		glVertex3f(-0.2f, 0.0f - 0.105f * (float)menu_position, -0.95f);

		glEnd();
		
		glLineWidth(2);	

		glutSwapBuffers();
	}

	return;
};

void OptionsScreenLoop()
{
	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])
	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;

			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}
	}
	else frame_change_button_down = false;
*/

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_OPTIONS_SCREEN]);

		glBegin(GL_QUADS);

		glTexCoord2f(0,1);
		glVertex3f(-0.575f, 0.42f, -1.0f);
		glTexCoord2f(0,0);
		glVertex3f(-0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.575f, 0.42f, -1.0f);

		glEnd();

		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		if (control_activate_on)
		{
			if (menu_button_down == false) 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

				if (menu_position == 0) { compute_cycles_total = 1; compute_unlimited = true; }
				else if (menu_position == 1) { compute_cycles_total = 1; compute_unlimited = false; }
				else if (menu_position == 2) { compute_cycles_total = 2; compute_unlimited = false; }
				else if (menu_position == 3) { compute_cycles_total = 3; compute_unlimited = false; }
				else if (menu_position == 4) { compute_cycles_total = 4; compute_unlimited = false; }

				else if (menu_position == 10) { camera_distance = 50.0f; }
				else if (menu_position == 11) { camera_distance = 40.0f; }
				else if (menu_position == 12) { camera_distance = 35.0f; }
				else if (menu_position == 13) { camera_distance = 30.0f; }
				else if (menu_position == 14) { camera_distance = 25.0f; }
				else if (menu_position == 15) { camera_distance = 20.0f; }
				else if (menu_position == 16) { camera_distance = 15.0f; }
				else if (menu_position == 17) { camera_distance = 10.0f; }
	
				else if (menu_position == 20) { sound_on = true; }
				else if (menu_position == 21) { sound_on = false; }
				
				else if (menu_position == 30)
				{
					if (menu_system_active == 2)
					{
						menu_system_active = 1;
						menu_position = 0;
					}
					else if (menu_system_active == 4)
					{
						menu_system_active = 3;
						menu_position = 0;
					}
				}
			}

			menu_button_down = true;

			for (int i=0; i<256; i++) { keyboard[i] = 0; }
		}
		else if (control_up_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false)
			{
				menu_position -= 10;

				menu_position /= 10;
		
				menu_position *= 10;
				
				if (menu_position < 0) menu_position = 0;
			}
		
			menu_button_down = true;
		}
		else if (control_down_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false)
			{
				menu_position += 10;

				menu_position /= 10;
		
				menu_position *= 10;
			
				if (menu_position > 30) menu_position = 30;
			}
	
			menu_button_down = true;
		}
		else if (control_left_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { if (menu_position % 10 > 0) menu_position--; }
		
			menu_button_down = true;
		}
		else if (control_right_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false)
			{
				if (menu_position / 10 == 0)
				{
					if (menu_position % 10 < 4) menu_position++;
				}
				else if (menu_position / 10 == 1)
				{
					if (menu_position % 10 < 7) menu_position++;
				}
				else if (menu_position / 10 == 2)
				{
					if (menu_position % 10 < 1) menu_position++;
				}
				else if (menu_position / 10 == 3)
				{
					menu_position = 30;
				}
			}
		
			menu_button_down = true;
		}
		else menu_button_down = false;		

		//if (keyboard[27] || joystick_button[9]) exit(1);

		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,0,0);

		glLineWidth(4);

		if (menu_position / 10 == 0)
		{
			if (menu_position % 10 == 0)
			{
				glBegin(GL_LINES);

				glVertex3f(-0.45f + 0.2f * (float)menu_position, 0.085f, -0.95f);
				glVertex3f(-0.45f + 0.2f * (float)menu_position, 0.015f, -0.95f);
	
				glVertex3f(-0.45f + 0.2f * (float)(menu_position+1), 0.085f, -0.95f);
				glVertex3f(-0.45f + 0.2f * (float)(menu_position+1), 0.015f, -0.95f);
	
				glVertex3f(-0.45f + 0.2f * (float)(menu_position+1), 0.015f, -0.95f);
				glVertex3f(-0.45f + 0.2f * (float)menu_position, 0.015f, -0.95f);
	
				glVertex3f(-0.45f + 0.2f * (float)(menu_position+1), 0.085f, -0.95f);
				glVertex3f(-0.45f + 0.2f * (float)menu_position, 0.085f, -0.95f);

				glEnd();
			}
			else
			{
				glBegin(GL_LINES);

				glVertex3f(-0.39f - 0.03f + 0.17f * (float)menu_position, 0.085f, -0.95f);
				glVertex3f(-0.39f - 0.03f + 0.17f * (float)menu_position, 0.015f, -0.95f);
	
				glVertex3f(-0.39f - 0.03f + 0.17f * (float)(menu_position+1), 0.085f, -0.95f);
				glVertex3f(-0.39f - 0.03f + 0.17f * (float)(menu_position+1), 0.015f, -0.95f);
	
				glVertex3f(-0.39f - 0.03f + 0.17f * (float)(menu_position+1), 0.015f, -0.95f);
				glVertex3f(-0.39f - 0.03f + 0.17f * (float)menu_position, 0.015f, -0.95f);
	
				glVertex3f(-0.39f - 0.03f + 0.17f * (float)(menu_position+1), 0.085f, -0.95f);
				glVertex3f(-0.39f - 0.03f + 0.17f * (float)menu_position, 0.085f, -0.95f);

				glEnd();
			}	
		}
		else if (menu_position / 10 == 1)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(menu_position%10), 0.085f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(menu_position%10), 0.015f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)((menu_position%10)+1), 0.085f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)((menu_position%10)+1), 0.015f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)((menu_position%10)+1), 0.015f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(menu_position%10), 0.015f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)((menu_position%10)+1), 0.085f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(menu_position%10), 0.085f - 0.15f, -0.95f);

			glEnd();
		}
		else if (menu_position / 10 == 2)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.15f - 0.03f + 0.1175f * (float)(menu_position%10), 0.085f - 0.24f, -0.95f);
			glVertex3f(-0.15f - 0.03f + 0.1175f * (float)(menu_position%10), 0.015f - 0.24f, -0.95f);

			glVertex3f(-0.15f - 0.03f + 0.1175f * (float)((menu_position%10)+1), 0.085f - 0.24f, -0.95f);
			glVertex3f(-0.15f - 0.03f + 0.1175f * (float)((menu_position%10)+1), 0.015f - 0.24f, -0.95f);
	
			glVertex3f(-0.15f - 0.03f + 0.1175f * (float)((menu_position%10)+1), 0.015f - 0.24f, -0.95f);
			glVertex3f(-0.15f - 0.03f + 0.1175f * (float)(menu_position%10), 0.015f - 0.24f, -0.95f);
	
			glVertex3f(-0.15f - 0.03f + 0.1175f * (float)((menu_position%10)+1), 0.085f - 0.24f, -0.95f);
			glVertex3f(-0.15f - 0.03f + 0.1175f * (float)(menu_position%10), 0.085f - 0.24f, -0.95f);

			glEnd();
		}
		else if (menu_position / 10 == 3)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.1f, 0.085f - 0.125f * 3.0f, -0.95f);
			glVertex3f(-0.1f, 0.015f - 0.125f * 3.0f, -0.95f);

			glVertex3f(0.1f, 0.085f - 0.125f * 3.0f, -0.95f);
			glVertex3f(0.1f, 0.015f - 0.125f * 3.0f, -0.95f);

			glVertex3f(0.1f, 0.085f - 0.125f * 3.0f, -0.95f);
			glVertex3f(-0.1f, 0.085f - 0.125f * 3.0f, -0.95f);

			glVertex3f(0.1f, 0.015f - 0.125f * 3.0f, -0.95f);
			glVertex3f(-0.1f, 0.015f - 0.125f * 3.0f, -0.95f);
	
			glEnd();
		}

		glColor3f(0,0,1);

		if (compute_cycles_total == 1 && compute_unlimited == true)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.45f + 0.2f * (float)(compute_cycles_total-1), 0.075f, -0.95f);
			glVertex3f(-0.45f + 0.2f * (float)(compute_cycles_total-1), 0.025f, -0.95f);
	
			glVertex3f(-0.45f + 0.2f * (float)(compute_cycles_total), 0.075f, -0.95f);
			glVertex3f(-0.45f + 0.2f * (float)(compute_cycles_total), 0.025f, -0.95f);
	
			glVertex3f(-0.45f + 0.2f * (float)(compute_cycles_total), 0.025f, -0.95f);
			glVertex3f(-0.45f + 0.2f * (float)(compute_cycles_total-1), 0.025f, -0.95f);
	
			glVertex3f(-0.45f + 0.2f * (float)(compute_cycles_total), 0.075f, -0.95f);
			glVertex3f(-0.45f + 0.2f * (float)(compute_cycles_total-1), 0.075f, -0.95f);

			glEnd();
		}
		else if (compute_unlimited == false)
		{	
			glBegin(GL_LINES);

			glVertex3f(-0.39f - 0.03f + 0.17f * (float)compute_cycles_total, 0.075f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.17f * (float)compute_cycles_total, 0.025f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.17f * (float)(compute_cycles_total+1), 0.075f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.17f * (float)(compute_cycles_total+1), 0.025f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.17f * (float)(compute_cycles_total+1), 0.025f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.17f * (float)compute_cycles_total, 0.025f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.17f * (float)(compute_cycles_total+1), 0.075f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.17f * (float)compute_cycles_total, 0.075f, -0.95f);

			glEnd();	
		}

		if (camera_distance == 50.0f)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.39f - 0.03f, 0.075f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f, 0.025f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f, 0.075f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f, 0.025f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f, 0.025f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f, 0.025f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f, 0.075f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f, 0.075f - 0.15f, -0.95f);

			glEnd();
		}
		else
		{
			glBegin(GL_LINES);

			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(-6.0f/30.0f * camera_distance + 240.0f/30.0f + 1.0f), 0.075f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(-6.0f/30.0f * camera_distance + 240.0f/30.0f + 1.0f), 0.025f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(-6.0f/30.0f * camera_distance + 240.0f/30.0f + 1.0f + 1.0f), 0.075f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(-6.0f/30.0f * camera_distance + 240.0f/30.0f + 1.0f + 1.0f), 0.025f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(-6.0f/30.0f * camera_distance + 240.0f/30.0f + 1.0f + 1.0f), 0.025f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(-6.0f/30.0f * camera_distance + 240.0f/30.0f + 1.0f), 0.025f - 0.15f, -0.95f);
	
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(-6.0f/30.0f * camera_distance + 240.0f/30.0f + 1.0f + 1.0f), 0.075f - 0.15f, -0.95f);
			glVertex3f(-0.39f - 0.03f + 0.1075f * (float)(-6.0f/30.0f * camera_distance + 240.0f/30.0f + 1.0f), 0.075f - 0.15f, -0.95f);

			glEnd();
		}

		glBegin(GL_LINES);

		glVertex3f(-0.15f - 0.03f + 0.1175f * (float)(!sound_on), 0.075f - 0.24f, -0.95f);
		glVertex3f(-0.15f - 0.03f + 0.1175f * (float)(!sound_on), 0.025f - 0.24f, -0.95f);

		glVertex3f(-0.15f - 0.03f + 0.1175f * ((float)(!sound_on)+1.0f), 0.075f - 0.24f, -0.95f);
		glVertex3f(-0.15f - 0.03f + 0.1175f * ((float)(!sound_on)+1.0f), 0.025f - 0.24f, -0.95f);
	
		glVertex3f(-0.15f - 0.03f + 0.1175f * ((float)(!sound_on)+1.0f), 0.025f - 0.24f, -0.95f);
		glVertex3f(-0.15f - 0.03f + 0.1175f * (float)(!sound_on), 0.025f - 0.24f, -0.95f);
	
		glVertex3f(-0.15f - 0.03f + 0.1175f * ((float)(!sound_on)+1.0f), 0.075f - 0.24f, -0.95f);
		glVertex3f(-0.15f - 0.03f + 0.1175f * (float)(!sound_on), 0.075f - 0.24f, -0.95f);

		glEnd();
		
		glLineWidth(2);	

		glutSwapBuffers();
	}

	return;
};

void MenuScreenLoop()
{
	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])
	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;

			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}
	}
	else frame_change_button_down = false;
*/

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MENU_SCREEN]);

		glBegin(GL_QUADS);

		glTexCoord2f(0,1);
		glVertex3f(-0.575f, 0.42f, -1.0f);
		glTexCoord2f(0,0);
		glVertex3f(-0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.575f, 0.42f, -1.0f);

		glEnd();

		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		if (control_activate_on)
		{
			if (menu_button_down == false) 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

				if (menu_position == 0) menu_system_active = 0;
				else if (menu_position == 1) 
				{
					menu_system_active = 0;

					stats->px = 24;
					stats->py = 22;
					stats->fx = 24.5f;
					stats->fy = 22.5f;
					stats->dx = 24;
					stats->dy = 23;
					stats->rot = 3.0f * 3.14149f / 2.0f;
					stats->current_field = 0;
	
					stats->hour = 18;
					stats->minute = 0;
	
					stats->animation_timer = -5.0f;
	
					stats->move_priority[1] = 1;
				}
				else if (menu_position == 2) { menu_system_active = 4; menu_position = 0; }
				else if (menu_position == 3) exit(1);
			}

			menu_button_down = true;

			for (int i=0; i<256; i++) { keyboard[i] = 0; }
		}
		else if (control_up_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { menu_position--; if (menu_position < 0) menu_position = 0; }
		
			menu_button_down = true;
		}
		else if (control_down_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { menu_position++; if (menu_position > 3) menu_position = 3; }
	
			menu_button_down = true;
		}
		else menu_button_down = false;		

		//if (keyboard[27] || joystick_button[9]) exit(1);

		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,0,0);

		glLineWidth(4);
		
		glBegin(GL_LINES);


		glVertex3f(-0.2f, 0.1f - 0.105f * (float)menu_position, -0.95f);
		glVertex3f(-0.2f, 0.0f - 0.105f * (float)menu_position, -0.95f);

		glVertex3f(0.2f, 0.1f - 0.105f * (float)menu_position, -0.95f);
		glVertex3f(0.2f, 0.0f - 0.105f * (float)menu_position, -0.95f);

		glVertex3f(0.2f, 0.1f - 0.105f * (float)menu_position, -0.95f);
		glVertex3f(-0.2f, 0.1f - 0.105f * (float)menu_position, -0.95f);

		glVertex3f(0.2f, 0.0f - 0.105f * (float)menu_position, -0.95f);
		glVertex3f(-0.2f, 0.0f - 0.105f * (float)menu_position, -0.95f);

		glEnd();
		
		glLineWidth(2);	

		glutSwapBuffers();
	}

	return;
};

void CreationScreenLoop()
{
	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])
	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;

			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}
	}
	else frame_change_button_down = false;
*/

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CREATION_SCREEN]);

		glBegin(GL_QUADS);

		glTexCoord2f(0,1);
		glVertex3f(-0.575f, 0.42f, -1.0f);
		glTexCoord2f(0,0);
		glVertex3f(-0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.575f, 0.42f, -1.0f);

		glEnd();

		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		if (control_activate_on)
		{
			if (menu_button_down == false) 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

				if (menu_position == 0) { stats->sex = 0; }
				else if (menu_position == 1) { stats->sex = 1; }

				else if (menu_position == 100) { stats->primary_color[0] -= 0.1f; if (stats->primary_color[0] < 0.0f) stats->primary_color[0] = 0.0f; }
				else if (menu_position == 101) { stats->primary_color[0] += 0.1f; if (stats->primary_color[0] > 1.0f) stats->primary_color[0] = 1.0f; }
				else if (menu_position == 102) { stats->primary_color[1] -= 0.1f; if (stats->primary_color[1] < 0.0f) stats->primary_color[1] = 0.0f; }
				else if (menu_position == 103) { stats->primary_color[1] += 0.1f; if (stats->primary_color[1] > 1.0f) stats->primary_color[1] = 1.0f; }
				else if (menu_position == 104) { stats->primary_color[2] -= 0.1f; if (stats->primary_color[2] < 0.0f) stats->primary_color[2] = 0.0f; }
				else if (menu_position == 105) { stats->primary_color[2] += 0.1f; if (stats->primary_color[2] > 1.0f) stats->primary_color[2] = 1.0f; }

				else if (menu_position == 200) { stats->days_in_a_season = 30; }
				else if (menu_position == 201) { stats->days_in_a_season = 15; }
				else if (menu_position == 202) { stats->days_in_a_season = 6; }
				
				else if (menu_position >= 300 && menu_position <= 325)
				{
					stats->name[menu_name_length] = (char)(menu_position-300 + 'A');
					menu_name_length++; 

					if (menu_name_length >= 32) menu_name_length = 31;
				}
				else if (menu_position >= 400 && menu_position <= 425)
				{
					stats->name[menu_name_length] = (char)(menu_position-400 + 'a');
					menu_name_length++;

					if (menu_name_length >= 32) menu_name_length = 31;
				}
				else if (menu_position >= 500 && menu_position <= 508)
				{
					stats->name[menu_name_length] = (char)(menu_position-500 + '1');
					menu_name_length++;

					if (menu_name_length >= 32) menu_name_length = 31;
				}
				else if (menu_position == 509)
				{
					stats->name[menu_name_length] = '0';
					menu_name_length++;

					if (menu_name_length >= 32) menu_name_length = 31;
				}
				else if (menu_position == 510)
				{
					stats->name[menu_name_length] = '\'';
					menu_name_length++;

					if (menu_name_length >= 32) menu_name_length = 31;
				}
				else if (menu_position == 511)
				{
					stats->name[menu_name_length] = '_';
					menu_name_length++;
	
					if (menu_name_length >= 32) menu_name_length = 31;
				}
				else if (menu_position == 512)
				{
					stats->name[menu_name_length] = 0;

					menu_name_length--;

					if (menu_name_length < 0) menu_name_length = 0;

					stats->name[menu_name_length] = 0;
				}	
				else if (menu_position == 600)
				{
					menu_system_active = 0;
					
					stats->animation_type = 0;
					stats->animation_timer = -5.0f;

					Sleep(field, inventory, cast, stats);
				}
			}

			menu_button_down = true;

			for (int i=0; i<256; i++) { keyboard[i] = 0; }
		}
		else if (control_up_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false)
			{
				if (menu_position == 512) menu_position = 425;
				else
				{
					menu_position -= 100;

					if (menu_position < 300)
					{
						menu_position /= 100;
			
						menu_position *= 100;
					}
					
					if (menu_position < 0) menu_position = 0;
				}
			}
		
			menu_button_down = true;
		}
		else if (control_down_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false)
			{
				menu_position += 100;

				if (menu_position < 400)
				{
					menu_position /= 100;
		
					menu_position *= 100;
				}		
	
				if (menu_position > 600) menu_position = 600;
			}
	
			menu_button_down = true;
		}
		else if (control_left_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { if (menu_position % 100 > 0) menu_position--; }
		
			menu_button_down = true;
		}
		else if (control_right_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false)
			{
				if (menu_position / 100 == 0)
				{
					if (menu_position % 100 < 1) menu_position++;
				}
				else if (menu_position / 100 == 1)
				{
					if (menu_position % 100 < 5) menu_position++;
				}
				else if (menu_position / 100 == 2)
				{
					if (menu_position % 100 < 2) menu_position++;
				}
				else if (menu_position / 100 == 3)
				{
					if (menu_position % 100 < 25) menu_position++;
				}
				else if (menu_position / 100 == 4)
				{
					if (menu_position % 100 < 25) menu_position++;
				}
				else if (menu_position / 100 == 5)
				{
					if (menu_position % 100 < 12) menu_position++;
				}
				else if (menu_position / 100 == 6)
				{
					menu_position = 600;
				}
			}
		
			menu_button_down = true;
		}
		else menu_button_down = false;	

		if (menu_position/100 == 5 && menu_position%500 > 12) menu_position = 512;

		stats->secondary_color[0] = 1.0f;
		stats->secondary_color[1] = 1.0f;
		stats->secondary_color[2] = 1.0f;

		stats->tertiary_color[0] = (stats->primary_color[0] + stats->secondary_color[0]) / 2.0f;
		stats->tertiary_color[1] = (stats->primary_color[1] + stats->secondary_color[1]) / 2.0f;
		stats->tertiary_color[2] = (stats->primary_color[2] + stats->secondary_color[2]) / 2.0f;	

		//if (keyboard[27] || joystick_button[9]) exit(1);

		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,0,0);

		glLineWidth(4);

		if (menu_position / 100 == 0)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.33f + 0.125f * (float)menu_position, 0.085f + 0.205f, -0.95f);
			glVertex3f(-0.33f + 0.125f * (float)menu_position, 0.015f + 0.205f, -0.95f);
	
			glVertex3f(-0.33f + 0.125f * (float)(menu_position+1), 0.085f + 0.205f, -0.95f);
			glVertex3f(-0.33f + 0.125f * (float)(menu_position+1), 0.015f + 0.205f, -0.95f);
	
			glVertex3f(-0.33f + 0.125f * (float)(menu_position+1), 0.015f + 0.205f, -0.95f);

			glVertex3f(-0.33f + 0.125f * (float)menu_position, 0.015f + 0.205f, -0.95f);
	
			glVertex3f(-0.33f + 0.125f * (float)(menu_position+1), 0.085f + 0.205f, -0.95f);
			glVertex3f(-0.33f + 0.125f * (float)menu_position, 0.085f + 0.205f, -0.95f);

			glEnd();
		}
		else if (menu_position / 100 == 1)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.39f + ((menu_position%100)%6>=5?0.01f:0.0f) + ((menu_position%100)%6>=3?0.035f:0.0f) + 0.1075f * (float)((menu_position%100)%2) + 0.185f * (float)((menu_position%100)/2), 0.085f + 0.125f, -0.95f);
			glVertex3f(-0.39f + ((menu_position%100)%6>=5?0.01f:0.0f) + ((menu_position%100)%6>=3?0.035f:0.0f) + 0.1075f * (float)((menu_position%100)%2) + 0.185f * (float)((menu_position%100)/2), 0.015f + 0.125f, -0.95f);
	
			glVertex3f(-0.39f + ((menu_position%100)%6>=5?0.01f:0.0f) + ((menu_position%100)%6>=3?0.035f:0.0f) + 0.045f + 0.1075f * (float)((menu_position%100)%2) + 0.185f * (float)((menu_position%100)/2), 0.085f + 0.125f, -0.95f);
			glVertex3f(-0.39f + ((menu_position%100)%6>=5?0.01f:0.0f) + ((menu_position%100)%6>=3?0.035f:0.0f) + 0.045f + 0.1075f * (float)((menu_position%100)%2) + 0.185f * (float)((menu_position%100)/2), 0.015f + 0.125f, -0.95f);
	
			glVertex3f(-0.39f + ((menu_position%100)%6>=5?0.01f:0.0f) + ((menu_position%100)%6>=3?0.035f:0.0f) + 0.045f + 0.1075f * (float)((menu_position%100)%2) + 0.185f * (float)((menu_position%100)/2), 0.015f + 0.125f, -0.95f);
			glVertex3f(-0.39f + ((menu_position%100)%6>=5?0.01f:0.0f) + ((menu_position%100)%6>=3?0.035f:0.0f) + 0.1075f * (float)((menu_position%100)%2) + 0.185f * (float)((menu_position%100)/2), 0.015f + 0.125f, -0.95f);
	
			glVertex3f(-0.39f + ((menu_position%100)%6>=5?0.01f:0.0f) + ((menu_position%100)%6>=3?0.035f:0.0f) + 0.045f + 0.1075f * (float)((menu_position%100)%2) + 0.185f * (float)((menu_position%100)/2), 0.085f + 0.125f, -0.95f);
			glVertex3f(-0.39f + ((menu_position%100)%6>=5?0.01f:0.0f) + ((menu_position%100)%6>=3?0.035f:0.0f) + 0.1075f * (float)((menu_position%100)%2) + 0.185f * (float)((menu_position%100)/2), 0.085f + 0.125f, -0.95f);

			glEnd();
		}
		else if (menu_position / 100 == 2)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.445f + 0.2f * (float)(menu_position%200), 0.085f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(menu_position%200), 0.015f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((menu_position%200)+1), 0.085f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)((menu_position%200)+1), 0.015f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((menu_position%200)+1), 0.015f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(menu_position%200), 0.015f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((menu_position%200)+1), 0.085f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(menu_position%200), 0.085f - 0.02f, -0.95f);

			glEnd();
		}
		else if (menu_position / 100 == 3)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%300), 0.08f - 0.22f, -0.95f);
			glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%300), 0.035f - 0.22f, -0.95f);
	
			glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%300)+1), 0.08f - 0.22f, -0.95f);
			glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%300)+1), 0.035f - 0.22f, -0.95f);
	
			glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%300)+1), 0.035f - 0.22f, -0.95f);
			glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%300), 0.035f - 0.22f, -0.95f);
	
			glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%300)+1), 0.08f - 0.22f, -0.95f);
			glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%300), 0.08f - 0.22f, -0.95f);

			glEnd();
		}
		else if (menu_position / 100 == 4)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%400), 0.08f - 0.26f, -0.95f);
			glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%400), 0.035f - 0.26f, -0.95f);
	
			glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%400)+1), 0.08f - 0.26f, -0.95f);
			glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%400)+1), 0.035f - 0.26f, -0.95f);
	
			glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%400)+1), 0.035f - 0.26f, -0.95f);
			glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%400), 0.035f - 0.26f, -0.95f);
	
			glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%400)+1), 0.08f - 0.26f, -0.95f);
			glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%400), 0.08f - 0.26f, -0.95f);

			glEnd();
		}
		else if (menu_position / 100 == 5)
		{
			if (menu_position%500 < 12)
			{
				glBegin(GL_LINES);

				glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%500), 0.08f - 0.305f, -0.95f);
				glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%500), 0.035f - 0.305f, -0.95f);
		
				glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%500)+1), 0.08f - 0.305f, -0.95f);
				glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%500)+1), 0.035f - 0.305f, -0.95f);
		
				glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%500)+1), 0.035f - 0.305f, -0.95f);
				glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%500), 0.035f - 0.305f, -0.95f);
		
				glVertex3f(-0.4925f + 0.0345f * (float)((menu_position%500)+1), 0.08f - 0.305f, -0.95f);
				glVertex3f(-0.4925f + 0.0345f * (float)(menu_position%500), 0.08f - 0.305f, -0.95f);

				glEnd();
			}
			else
			{
				glBegin(GL_LINES);

				glVertex3f(-0.4925f + 0.0345f * (float)(22), 0.08f - 0.305f, -0.95f);
				glVertex3f(-0.4925f + 0.0345f * (float)(22), 0.035f - 0.305f, -0.95f);
		
				glVertex3f(-0.4925f + 0.0345f * (float)(26), 0.08f - 0.305f, -0.95f);
				glVertex3f(-0.4925f + 0.0345f * (float)(26), 0.035f - 0.305f, -0.95f);
		
				glVertex3f(-0.4925f + 0.0345f * (float)(26), 0.035f - 0.305f, -0.95f);
				glVertex3f(-0.4925f + 0.0345f * (float)(22), 0.035f - 0.305f, -0.95f);
		
				glVertex3f(-0.4925f + 0.0345f * (float)(26), 0.08f - 0.305f, -0.95f);
				glVertex3f(-0.4925f + 0.0345f * (float)(22), 0.08f - 0.305f, -0.95f);

				glEnd();
			}
		}
		
		else if (menu_position / 100 == 6)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.1f, 0.085f - 0.125f * 3.0f, -0.95f);
			glVertex3f(-0.1f, 0.015f - 0.125f * 3.0f, -0.95f);

			glVertex3f(0.1f, 0.085f - 0.125f * 3.0f, -0.95f);
			glVertex3f(0.1f, 0.015f - 0.125f * 3.0f, -0.95f);

			glVertex3f(0.1f, 0.085f - 0.125f * 3.0f, -0.95f);
			glVertex3f(-0.1f, 0.085f - 0.125f * 3.0f, -0.95f);

			glVertex3f(0.1f, 0.015f - 0.125f * 3.0f, -0.95f);
			glVertex3f(-0.1f, 0.015f - 0.125f * 3.0f, -0.95f);
	
			glEnd();
		}

		glColor3f(0,0,1);

		glBegin(GL_LINES);

		glVertex3f(-0.33f + 0.125f * (float)stats->sex, 0.075f + 0.205f, -0.95f);
		glVertex3f(-0.33f + 0.125f * (float)stats->sex, 0.025f + 0.205f, -0.95f);
	
		glVertex3f(-0.33f + 0.125f * (float)(stats->sex+1), 0.075f + 0.205f, -0.95f);
		glVertex3f(-0.33f + 0.125f * (float)(stats->sex+1), 0.025f + 0.205f, -0.95f);
	
		glVertex3f(-0.33f + 0.125f * (float)(stats->sex+1), 0.025f + 0.205f, -0.95f);
		glVertex3f(-0.33f + 0.125f * (float)stats->sex, 0.025f + 0.205f, -0.95f);
	
		glVertex3f(-0.33f + 0.125f * (float)(stats->sex+1), 0.075f + 0.205f, -0.95f);
		glVertex3f(-0.33f + 0.125f * (float)stats->sex, 0.075f + 0.205f, -0.95f);

		glEnd();
	

		if (stats->days_in_a_season == 30)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.445f + 0.2f * (float)(0), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(0), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((0)+1), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)((0)+1), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((0)+1), 0.025f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(0), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((0)+1), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(0), 0.075f - 0.02f, -0.95f);

			glEnd();
		}
		else if (stats->days_in_a_season == 15)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.445f + 0.2f * (float)(1), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(1), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((1)+1), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)((1)+1), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((1)+1), 0.025f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(1), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((1)+1), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(1), 0.075f - 0.02f, -0.95f);

			glEnd();
		}
		else if (stats->days_in_a_season == 6)
		{
			glBegin(GL_LINES);

			glVertex3f(-0.445f + 0.2f * (float)(2), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(2), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((2)+1), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)((2)+1), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((2)+1), 0.025f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(2), 0.025f - 0.02f, -0.95f);
	
			glVertex3f(-0.445f + 0.2f * (float)((2)+1), 0.075f - 0.02f, -0.95f);
			glVertex3f(-0.445f + 0.2f * (float)(2), 0.075f - 0.02f, -0.95f);

			glEnd();
		}

		glLineWidth(2);	

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);

		glVertex3f(0.2f, 0.5f, -0.85f);
		glVertex3f(0.2f, -0.1f, -0.85f);
		glVertex3f(0.5f, -0.1f, -0.85f);
		glVertex3f(0.5f, 0.5f, -0.85f);

		glEnd();

		stats->animation_type = 3;
		stats->animation_timer += 0.05f;
		if (stats->animation_timer > 4.0f * 6.28f) stats->animation_timer -= 4.0f * 6.28f;

		glEnable(GL_LIGHTING); 

		glTranslatef(0.2f, 0.0f, -0.5f);
		glRotatef(stats->animation_timer / 4.0f * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		
		glScalef(0.02f, 0.02f, 0.02f);
		DrawRobot(stats->sex, 0, inventory->tool[stats->current_tool]->type, stats->rot, stats->primary_color, stats->secondary_color, stats->tertiary_color,
			stats->animation_type, stats->animation_timer);
		glScalef(50.0f, 50.0f, 50.0f);
		glRotatef(-stats->animation_timer / 4.0f * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glTranslatef(-0.2f, -0.0f, 0.5f);

		glDisable(GL_LIGHTING);

		glPushMatrix();	
		glTranslatef(-0.35f, -0.075f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);

		for (int i=0; i<32; i++)
		{
			if (i == menu_name_length)
			{
				glColor3f(1.0f,0.0f,0.0f);

				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '_');
			}
			else
			{
				glColor3f(0.0f,0.0f,1.0f);

				glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, stats->name[i]);
			}
		}

		glPopMatrix();

		glutSwapBuffers();
	}

	return;
};

void NewSureScreenLoop()
{
	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])
	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;


			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}
	}
	else frame_change_button_down = false;
*/

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NEW_SURE_SCREEN]);

		glBegin(GL_QUADS);

		glTexCoord2f(0,1);
		glVertex3f(-0.575f, 0.42f, -1.0f);
		glTexCoord2f(0,0);
		glVertex3f(-0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.575f, 0.42f, -1.0f);

		glEnd();

		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		if (control_activate_on)
		{
			if (menu_button_down == false) 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

				if (menu_position == 0)
				{
					menu_system_active = 1;

					menu_position = 0;
				}
				else if (menu_position == 1) 
				{
					// Starting new game!

					InitializeFields(field, inventory, cast, stats);

					menu_system_active = 7;
		
					menu_position = 0;

					menu_name_length = 0;

					for (int i=0; i<32; i++)
					{
						stats->name[i] = 0;
					}
				}
			}

			menu_button_down = true;

			for (int i=0; i<256; i++) { keyboard[i] = 0; }
		}
		else if (control_up_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { menu_position--; if (menu_position < 0) menu_position = 0; }
		
			menu_button_down = true;
		}
		else if (control_down_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { menu_position++; if (menu_position > 1) menu_position = 1; }
	
			menu_button_down = true;
		}
		else menu_button_down = false;		

		//if (keyboard[27] || joystick_button[9]) exit(1);

		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,0,0);

		glLineWidth(4);
		
		glBegin(GL_LINES);

		glVertex3f(-0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glEnd();
		
		glLineWidth(2);	

		glutSwapBuffers();
	}

	return;
};

void StoryScreenLoop()
{
	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])

	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;



			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}

	}
	else frame_change_button_down = false;
*/

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_STORY_SCREEN]);

		glBegin(GL_QUADS);

		glTexCoord2f(0,1);
		glVertex3f(-0.575f, 0.42f, -1.0f);
		glTexCoord2f(0,0);
		glVertex3f(-0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.575f, 0.42f, -1.0f);

		glEnd();

		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		if (control_activate_on)
		{
			if (menu_button_down == false) 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

				menu_system_active = 5;

				menu_position = 0;
			}

			menu_button_down = true;

			for (int i=0; i<256; i++) { keyboard[i] = 0; }
		}
		else menu_button_down = false;		

		//if (keyboard[27] || joystick_button[9]) exit(1);
/*
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,0,0);

		glLineWidth(4);
		
		glBegin(GL_LINES);

		glVertex3f(-0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glEnd();
		
		glLineWidth(2);	
*/

		glutSwapBuffers();
	}

	return;
};

void EndGameScreenLoop()
{
	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();
	}
/*
	if (keyboard['d'] || keyboard['c'])

	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;



			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}

	}
	else frame_change_button_down = false;
*/

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_END_GAME_SCREEN]);

		glBegin(GL_QUADS);

		glTexCoord2f(0,1);
		glVertex3f(-0.575f, 0.42f, -1.0f);
		glTexCoord2f(0,0);
		glVertex3f(-0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.575f, 0.42f, -1.0f);

		glEnd();

		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		if (control_activate_on)
		{
			if (menu_button_down == false) 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

				if (menu_position == 0) // show the scores
				{
					menu_system_active = 9;

					menu_position = 0;

					stats->countdown = 15 * 60; // show for 15 seconds!
				}
				else if (menu_position == 1) // back to the game
				{
					menu_system_active = 0;
		
					menu_position = 0;
				}
			}

			menu_button_down = true;

			for (int i=0; i<256; i++) { keyboard[i] = 0; }
		}
		else if (control_up_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { menu_position--; if (menu_position < 0) menu_position = 0; }
		
			menu_button_down = true;
		}
		else if (control_down_on)
		{
			if (linux_box == true && sound_on == true) if (menu_button_down == false) system("play -q -v 1.0 ./Sounds/Tick.wav &");
			else if (linux_box == false && sound_on == true) if (menu_button_down == false) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);

			if (menu_button_down == false) { menu_position++; if (menu_position > 1) menu_position = 1; }
	
			menu_button_down = true;
		}
		else menu_button_down = false;		

		//if (keyboard[27] || joystick_button[9]) exit(1);

		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,0,0);

		glLineWidth(4);
		
		glBegin(GL_LINES);

		glVertex3f(-0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.0f - 0.16f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(0.35f, -0.1f + 0.0f - 0.16f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.0f - 0.16f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.0f - 0.16f * (float)menu_position, -0.95f);

		glEnd();
		
		glLineWidth(2);	

		glutSwapBuffers();
	}

	return;
};

void ShowScoreScreenLoop()
{
	int avg_affection = 0;
	int max_affection = 0;
	unsigned long grand_total = 0;

	// time to compute!
	if (fabs((float)(compute_milli_timer) - (float)(clock())) >= CLOCKS_PER_SEC / 60.0f) // checks 60 times a second!
	{	
		compute_cycles_left--;

		compute_milli_timer = clock();

		stats->countdown--;

		if (stats->countdown <= 0) stats->countdown = 0;
	}
/*
	if (keyboard['d'] || keyboard['c'])
	{
		if (frame_change_button_down == false)
		{
			frame_change_button_down = true;


			if (keyboard['d']) { compute_cycles_total--; if (compute_cycles_total < 1) compute_cycles_total = 1; }
			if (keyboard['c']) { compute_cycles_total++; }
		}
	}
	else frame_change_button_down = false;
*/

	if (compute_cycles_left <= 0)
	{
		compute_cycles_left = compute_cycles_total;

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();

		frames_per_second_counter1++;
	
		if (frames_per_second_timer1 != time(0))
		{
			frames_per_second1 = frames_per_second_counter1;
			frames_per_second_counter1 = 0;
			frames_per_second_timer1 = time(0);
		}
		
		glDisable(GL_LIGHTING);
		
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_SHOW_SCORE_SCREEN]);

		glBegin(GL_QUADS);

		glTexCoord2f(0,1);
		glVertex3f(-0.575f, 0.42f, -1.0f);
		glTexCoord2f(0,0);
		glVertex3f(-0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.575f, -0.42f, -1.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.575f, 0.42f, -1.0f);

		glEnd();

		// used for keyboard, not controller
		//keyboard['i'] = special_keyboard[GLUT_KEY_UP];
		//keyboard['k'] = special_keyboard[GLUT_KEY_DOWN];
		//keyboard['j'] = special_keyboard[GLUT_KEY_LEFT];
		//keyboard['l'] = special_keyboard[GLUT_KEY_RIGHT];

		if (control_activate_on && stats->countdown <= 0)
		{
			if (menu_button_down == false) 
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);

				menu_system_active = 1;

				menu_position = 0;
			}

			menu_button_down = true;

			for (int i=0; i<256; i++) { keyboard[i] = 0; }
		}
		else menu_button_down = false;		

		//if (keyboard[27] || joystick_button[9]) exit(1);
/*
		// Blank texture.
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(1,0,0);

		glLineWidth(4);
		
		glBegin(GL_LINES);

		glVertex3f(-0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.1f - 0.13f * (float)menu_position, -0.95f);

		glVertex3f(0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);
		glVertex3f(-0.35f, -0.1f + 0.0f - 0.13f * (float)menu_position, -0.95f);

		glEnd();
		
		glLineWidth(2);	
*/

		for (int i=0; i<30; i++)
		{
			if (cast->actor[i]->type == ACTOR_TYPE_DAVID ||
				cast->actor[i]->type == ACTOR_TYPE_CLARA ||
				cast->actor[i]->type == ACTOR_TYPE_ANDREW ||
				cast->actor[i]->type == ACTOR_TYPE_EMILY)
			{
				avg_affection += cast->actor[i]->affection;
				
				if (cast->actor[i]->affection > max_affection)
				{
					max_affection = cast->actor[i]->affection;
				}
			}
		}

		avg_affection /= 4;

		glPushMatrix();	
		glTranslatef(0.375f, 0.325f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);
		
		if (stats->countdown > 0)
		{
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->countdown/60) % 100) - ((stats->countdown/60) % 10)) / 10 + 48));
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->countdown/60) % 10) + 48);
		}
		else
		{
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'X');
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'I');
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'T');
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '?');
		}

		glPopMatrix();

		
		glPushMatrix();	
		glTranslatef(-0.375f, 0.105f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'N');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');

		for (int i=0; i<32; i++)
		{
			glColor3f(0.05f,0.05f,0.05f);

			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, stats->name[i]);
		}

		glPopMatrix();

	
		glPushMatrix();	
		glTranslatef(-0.375f, 0.005f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'Y');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->year-1) % 100) - ((stats->year-1) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->year-1) % 10) + 48);

		glPopMatrix();


		glPushMatrix();	
		glTranslatef(-0.375f, -0.035f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'A');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'A');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'f');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'f');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((avg_affection % 10000) - (avg_affection % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((avg_affection % 1000) - (avg_affection % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((avg_affection % 100) - (avg_affection % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((avg_affection % 10) + 48));

		glPopMatrix();

		
		glPushMatrix();	
		glTranslatef(-0.375f, -0.075f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'M');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'x');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'A');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'f');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'f');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((max_affection % 10000) - (max_affection % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((max_affection % 1000) - (max_affection % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((max_affection % 100) - (max_affection % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((max_affection % 10) + 48));

		glPopMatrix();
	
		
		glPushMatrix();	
		glTranslatef(-0.375f, -0.115f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'C');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'p');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_crops % 10000) - (stats->total_crops % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_crops % 1000) - (stats->total_crops % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_crops % 100) - (stats->total_crops % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->total_crops % 10) + 48));

		glPopMatrix();


		glPushMatrix();	
		glTranslatef(-0.375f, -0.155f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_rye % 10000) - (stats->total_rye % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_rye % 1000) - (stats->total_rye % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_rye % 100) - (stats->total_rye % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->total_rye % 10) + 48));

		glPopMatrix();

		
		glPushMatrix();	
		glTranslatef(-0.375f, -0.195f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'G');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_gathered % 10000) - (stats->total_gathered % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_gathered % 1000) - (stats->total_gathered % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_gathered % 100) - (stats->total_gathered % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->total_gathered % 10) + 48));

		glPopMatrix();

		glPushMatrix();	
		glTranslatef(-0.375f, -0.235f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'C');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_crystal % 10000) - (stats->total_crystal % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_crystal % 1000) - (stats->total_crystal % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_crystal % 100) - (stats->total_crystal % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->total_crystal % 10) + 48));

		glPopMatrix();

		
		glPushMatrix();
		glTranslatef(-0.375f, -0.275f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'E');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'x');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_extract % 10000) - (stats->total_extract % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_extract % 1000) - (stats->total_extract % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_extract % 100) - (stats->total_extract % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->total_extract % 10) + 48));

		glPopMatrix();


		glPushMatrix();	
		glTranslatef(-0.375f, -0.315f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'F');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_fish % 10000) - (stats->total_fish % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_fish % 1000) - (stats->total_fish % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->total_fish % 100) - (stats->total_fish % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((stats->total_fish % 10) + 48));

		glPopMatrix();


		glPushMatrix();	
		glTranslatef(0.125f, 0.035f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'C');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->credits+stats->held_credits) % 100000000) - ((stats->credits+stats->held_credits) % 10000000)) / 10000000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->credits+stats->held_credits) % 10000000) - ((stats->credits+stats->held_credits) % 1000000)) / 1000000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->credits+stats->held_credits) % 1000000) - ((stats->credits+stats->held_credits) % 100000)) / 100000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->credits+stats->held_credits) % 100000) - ((stats->credits+stats->held_credits) % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->credits+stats->held_credits) % 10000) - ((stats->credits+stats->held_credits) % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->credits+stats->held_credits) % 1000) - ((stats->credits+stats->held_credits) % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->credits+stats->held_credits) % 100) - ((stats->credits+stats->held_credits) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->credits+stats->held_credits) % 10) + 48));

		glPopMatrix();

		
		glPushMatrix();	
		glTranslatef(0.125f, -0.005f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'O');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->materials+stats->held_materials) % 10000) - ((stats->materials+stats->held_materials) % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->materials+stats->held_materials) % 1000) - ((stats->materials+stats->held_materials) % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->materials+stats->held_materials) % 100) - ((stats->materials+stats->held_materials) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->materials+stats->held_materials) % 10) + 48));

		glPopMatrix();

		
		glPushMatrix();	
		glTranslatef(0.125f, -0.045f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'N');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->feed) % 10000) - ((stats->feed) % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->feed) % 1000) - ((stats->feed) % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->feed) % 100) - ((stats->feed) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->feed) % 10) + 48));

		glPopMatrix();


		glPushMatrix();	
		glTranslatef(0.125f, -0.085f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'D');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->donated) % 100000000) - ((stats->donated) % 10000000)) / 10000000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->donated) % 10000000) - ((stats->donated) % 1000000)) / 1000000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->donated) % 1000000) - ((stats->donated) % 100000)) / 100000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->donated) % 100000) - ((stats->donated) % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->donated) % 10000) - ((stats->donated) % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->donated) % 1000) - ((stats->donated) % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->donated) % 100) - ((stats->donated) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->donated) % 10) + 48));

		glPopMatrix();


		glPushMatrix();	
		glTranslatef(0.125f, -0.125f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '/');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'd');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->prayed) % 1000000) - ((stats->prayed) % 100000)) / 100000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->prayed) % 100000) - ((stats->prayed) % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->prayed) % 10000) - ((stats->prayed) % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->prayed) % 1000) - ((stats->prayed) % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->prayed) % 100) - ((stats->prayed) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->prayed) % 10) + 48));

		glPopMatrix();


		glPushMatrix();	
		glTranslatef(0.125f, -0.165f, -0.9f);
		glScalef(0.00015f, 0.00025f, 0.00025f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'M');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'g');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->minigame_high_score) % 1000000) - ((stats->minigame_high_score) % 100000)) / 100000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->minigame_high_score) % 100000) - ((stats->minigame_high_score) % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->minigame_high_score) % 10000) - ((stats->minigame_high_score) % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->minigame_high_score) % 1000) - ((stats->minigame_high_score) % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((((stats->minigame_high_score) % 100) - ((stats->minigame_high_score) % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((stats->minigame_high_score) % 10) + 48));

		glPopMatrix();

	
		grand_total = (unsigned long)((avg_affection * 2 + max_affection * 2 + stats->total_crops + stats->total_rye + stats->total_gathered + 
			stats->total_crystal + stats->total_extract * 5 + stats->total_fish * 2 +
			(stats->credits+stats->held_credits) / 10 + (stats->materials+stats->held_materials) / 10 + stats->feed / 100 +
			stats->donated / 5 + stats->prayed / 10 + stats->minigame_high_score / 10) / stats->year);
			

		glPushMatrix();	
		glTranslatef(0.005f, -0.265f, -0.9f);
		glScalef(0.00025f, 0.00035f, 0.00035f);
		glColor3f(0.05f,0.05f,0.05f);

		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((grand_total % 100000000) - (grand_total % 10000000)) / 10000000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((grand_total % 10000000) - (grand_total % 1000000)) / 1000000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((grand_total % 1000000) - (grand_total % 100000)) / 100000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((grand_total % 100000) - (grand_total % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((grand_total % 10000) - (grand_total % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((grand_total % 1000) - (grand_total % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)(((grand_total % 100) - (grand_total % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, (char)((grand_total % 10) + 48));

		glPopMatrix();


		glutSwapBuffers();
	}


	return;
};

void OpenGLIdleFunction()
{
	control_up_on = false;	
	for (int i=0; i<control_up_length; i++)
	{
		if (control_up_key[i] >= 0)
		{
			if (keyboard[control_up_key[i]] == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_up_on = true;
		}
		else if (control_up_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_up_on = true;
		}
	}

	control_down_on = false;	
	for (int i=0; i<control_down_length; i++)
	{
		if (control_down_key[i] >= 0)
		{
			if (keyboard[control_down_key[i]] == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_down_on = true;
		}
		else if (control_down_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_down_on = true;
		}
	}

	control_left_on = false;	
	for (int i=0; i<control_left_length; i++)
	{
		if (control_left_key[i] >= 0)
		{
			if (keyboard[control_left_key[i]] == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_left_on = true;
		}
		else if (control_left_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_left_on = true;
		}
	}

	control_right_on = false;	
	for (int i=0; i<control_right_length; i++)
	{
		if (control_right_key[i] >= 0)
		{
			if (keyboard[control_right_key[i]] == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_right_on = true;
		}
		else if (control_right_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_right_on = true;
		}
	}

	control_activate_on = false;	
	for (int i=0; i<control_activate_length; i++)
	{
		if (control_activate_key[i] >= 0)
		{
			if (keyboard[control_activate_key[i]] == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_activate_on = true;
		}
		else if (control_activate_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_activate_on = true;
		}
	}

	control_run_on = false;	
	for (int i=0; i<control_run_length; i++)
	{
		if (control_run_key[i] >= 0)
		{
			if (keyboard[control_run_key[i]] == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_run_on = true;
		}
		else if (control_run_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_run_on = true;
		}
	}

	control_tool_left_on = false;	
	for (int i=0; i<control_tool_left_length; i++)
	{
		if (control_tool_left_key[i] >= 0)
		{
			if (keyboard[control_tool_left_key[i]] == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_tool_left_on = true;
		}
		else if (control_tool_left_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_tool_left_on = true;
		}
	}

	control_tool_right_on = false;	
	for (int i=0; i<control_tool_right_length; i++)
	{
		if (control_tool_right_key[i] >= 0)
		{
			if (keyboard[control_tool_right_key[i]] == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_tool_right_on = true;
		}
		else if (control_tool_right_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_tool_right_on = true;
		}
	}

	control_pray_on = false;	
	for (int i=0; i<control_pray_length; i++)
	{
		if (control_pray_key[i] >= 0)
		{
			if (keyboard[control_pray_key[i]] == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_pray_on = true;
		}
		else if (control_pray_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_pray_on = true;
		}
	}

	control_status_on = false;	
	for (int i=0; i<control_status_length; i++)
	{
		if (control_status_key[i] >= 0)
		{
			if (keyboard[control_status_key[i]] == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_status_on = true;
		}
		else if (control_status_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_status_on = true;
		}
	}

	control_menu_on = false;	
	for (int i=0; i<control_menu_length; i++)
	{
		if (control_menu_key[i] >= 0)
		{
			if (keyboard[control_menu_key[i]] == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'w')
		{
			if (special_keyboard[GLUT_KEY_UP] == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'s')
		{
			if (special_keyboard[GLUT_KEY_DOWN] == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'a')
		{
			if (special_keyboard[GLUT_KEY_LEFT] == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'d')
		{
			if (special_keyboard[GLUT_KEY_RIGHT] == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'b')
		{
			if (keyboard[32] == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'r')
		{
			if (keyboard[10] == true || keyboard[13] == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'x')
		{
			if (keyboard[27] == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'h')
		{
			if (shift_key_active == true) control_menu_on = true;
		}
		else if (control_menu_key[i] == -1 * (int)'c')
		{
			if (ctrl_key_active == true) control_menu_on = true;
		}
	}


	if (menu_system_active == 0)
	{
		if (minigame_active == false)
		{
			MainGameLoop();
		}
		else
		{
			MiniGameLoop();
		}
	}
	else if (menu_system_active == 1)
	{
		IntroScreenLoop();
	}
	else if (menu_system_active == 2 || menu_system_active == 4)
	{
		OptionsScreenLoop();
	}
	else if (menu_system_active == 3)
	{
		MenuScreenLoop();
	}
	else if (menu_system_active == 5)
	{
		CreationScreenLoop();
	}
	else if (menu_system_active == 6)
	{
		NewSureScreenLoop();
	}
	else if (menu_system_active == 7)
	{
		StoryScreenLoop();
	}
	else if (menu_system_active == 8)
	{
		EndGameScreenLoop();
	}
	else if (menu_system_active == 9)
	{
		ShowScoreScreenLoop();
	}

	return;
};

void OpenGLKeyboardUpFunction(unsigned char key, int x, int y)
{
	keyboard[key] = false;

	if (glutGetModifiers() == GLUT_ACTIVE_SHIFT) shift_key_active = true;
	else shift_key_active = false;

	if (glutGetModifiers() == GLUT_ACTIVE_CTRL) ctrl_key_active = true;
	else ctrl_key_active = false;

	return;
};

void OpenGLKeyboardFunction(unsigned char key, int x, int y)
{
	keyboard[key] = true;

	if (glutGetModifiers() == GLUT_ACTIVE_SHIFT) shift_key_active = true;
	else shift_key_active = false;

	if (glutGetModifiers() == GLUT_ACTIVE_CTRL) ctrl_key_active = true;
	else ctrl_key_active = false;

	return;
};

void OpenGLSpecialKeyboardFunction(int key, int x, int y)
{
	special_keyboard[key] = true;

	if (glutGetModifiers() == GLUT_ACTIVE_SHIFT) shift_key_active = true;
	else shift_key_active = false;

	if (glutGetModifiers() == GLUT_ACTIVE_CTRL) ctrl_key_active = true;
	else ctrl_key_active = false;

	return;
};	

void OpenGLSpecialKeyboardUpFunction(int key, int x, int y)
{
	special_keyboard[key] = false;

	if (glutGetModifiers() == GLUT_ACTIVE_SHIFT) shift_key_active = true;
	else shift_key_active = false;

	if (glutGetModifiers() == GLUT_ACTIVE_CTRL) ctrl_key_active = true;
	else ctrl_key_active = false;

	return;
};

void OpenGLMouseFunction(int button, int state, int x, int y)
{
	mouse->button = button;
	mouse->state = state;
	mouse->x = x;
	mouse->y = y;

	if (glutGetModifiers() == GLUT_ACTIVE_SHIFT) shift_key_active = true;
	else shift_key_active = false;

	if (glutGetModifiers() == GLUT_ACTIVE_CTRL) ctrl_key_active = true;
	else ctrl_key_active = false;

	return;
};

void OpenGLPassiveMotionFunction(int x, int y)
{
	mouse->x = x;
	mouse->y = y;

	if (glutGetModifiers() == GLUT_ACTIVE_SHIFT) shift_key_active = true;
	else shift_key_active = false;

	if (glutGetModifiers() == GLUT_ACTIVE_CTRL) ctrl_key_active = true;
	else ctrl_key_active = false;

	return;
};

// GLUT in Linux does support joystick detection but not input.
// GLUT in Windows supports both
void OpenGLJoystickFunction(unsigned int button, int x, int y, int z)
{
	joystick_axis->x = x;
	joystick_axis->y = y;
	joystick_axis->z = z;

	// Bitwise AND
	joystick_button[0] = button & 0x0001;
	joystick_button[1] = button & 0x0002;
	joystick_button[2] = button & 0x0004;
	joystick_button[3] = button & 0x0008;
	joystick_button[4] = button & 0x0010;
	joystick_button[5] = button & 0x0020;
	joystick_button[6] = button & 0x0040;
	joystick_button[7] = button & 0x0080;
	joystick_button[8] = button & 0x0100;
	joystick_button[9] = button & 0x0200;
	joystick_button[10] = button & 0x0400;
	joystick_button[11] = button & 0x0800;

	return;
};


void my_randomize()
{
	int stime = 0;
	long ltime = 0;
	ltime = time(NULL);
	stime = (unsigned)ltime/2;
	srand(stime);
};

int main(int argc, char **argv)
{
	my_randomize();

	camera_pos = new _Point();
	camera_rot = new _Point();

	mouse = new _Mouse();
	joystick_axis = new _Joystick();



	for (int k=0; k<MAX_FIELDS; k++) field[k] = new _Field();

	inventory = new _Inventory();

	cast = new _Cast();
	
	stats = new _Stats();

	
	compute_milli_timer = clock();
	draw_milli_timer = clock();


	LoadControls();
	

	glutInit(&argc, argv);

	glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);

	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

	glutCreateWindow("SowingSun");

	glutDisplayFunc(OpenGLDisplayFunction);
	glutIdleFunc(OpenGLIdleFunction);
	glutKeyboardFunc(OpenGLKeyboardFunction);
	glutKeyboardUpFunc(OpenGLKeyboardUpFunction);
	glutSpecialFunc(OpenGLSpecialKeyboardFunction);
	glutSpecialUpFunc(OpenGLSpecialKeyboardUpFunction);
	glutMouseFunc(OpenGLMouseFunction);
	glutPassiveMotionFunc(OpenGLPassiveMotionFunction);
	glutJoystickFunc(OpenGLJoystickFunction, 50);

	OpenGLSetupFunction(WINDOW_WIDTH, WINDOW_HEIGHT);

	//glutFullScreen();

   	glutMainLoop();


	for (int k=0; k<MAX_FIELDS; k++) delete field[k];
	
	delete inventory;

	delete cast;

	delete stats;	



	delete camera_pos;
	delete camera_rot;

	delete mouse;
	delete joystick_axis;


	return 0;
}

