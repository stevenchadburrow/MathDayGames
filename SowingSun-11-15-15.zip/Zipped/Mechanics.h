// Grub Hoe
// Double Headed Pick
// Austrian Scythe
// Watering Can

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>


clock_t compute_milli_timer, draw_milli_timer;
int compute_cycles_total = 1; // multiplier
int compute_cycles_left = compute_cycles_total;
bool compute_unlimited = false; // better have v-sync turned on if this is left unlimited! should then have 'compute_cycles_total' = 1 here.

float camera_distance = 25.0f;
bool sound_on = true;


const int MAX_FIELDS = 12;

const int TILE_TYPE_NONE = 0;

const int TILE_TYPE_DIRT = 1;
const int TILE_TYPE_TILLED = 2;
const int TILE_TYPE_ROCK = 3;
const int TILE_TYPE_WEED = 4;

const int TILE_TYPE_RADISH = 5;
const int TILE_TYPE_CABBAGE = 6;
const int TILE_TYPE_CUCUMBER = 7;
const int TILE_TYPE_BEANS = 8;
const int TILE_TYPE_MELON = 9;
const int TILE_TYPE_TURNIP = 10;
const int TILE_TYPE_ONION = 11;

const int TILE_TYPE_RYE = 12;
const int TILE_TYPE_CUT_RYE = 13;
const int TILE_TYPE_NANOTUBE = 14;

const int TILE_TYPE_ORE = 15;
const int TILE_TYPE_BROKEN_ORE = 16;
const int TILE_TYPE_EMPTY_ORE = 17;
const int TILE_TYPE_BERRY_BUSH = 18;
const int TILE_TYPE_EMPTY_BERRY_BUSH = 19;
const int TILE_TYPE_APPLE_TREE = 20;
const int TILE_TYPE_EMPTY_APPLE_TREE = 21;
const int TILE_TYPE_MUSHROOM_BED = 22;
const int TILE_TYPE_EMPTY_MUSHROOM_BED = 23;
const int TILE_TYPE_CRYSTAL = 24;
const int TILE_TYPE_EXPOSED_CRYSTAL = 25;
const int TILE_TYPE_BROKEN_CRYSTAL = 26;
const int TILE_TYPE_EMPTY_CRYSTAL = 27;

const int TILE_TYPE_WATER_GENERATOR = 28;
const int TILE_TYPE_EXCHANGER = 29;
const int TILE_TYPE_CHARGING_STATION = 30;
const int TILE_TYPE_DYNAMO_CHARGER = 31;
const int TILE_TYPE_NANOTUBE_DISTRIBUTOR = 32;
const int TILE_TYPE_EMPTY_ROVER_STATION = 33;
const int TILE_TYPE_FULL_ROVER_STATION = 34;
const int TILE_TYPE_ROVER_DEPOSIT = 35;
const int TILE_TYPE_EMPTY_ROVER_DEPOSIT = 36;

const int TILE_TYPE_FISHERY = 37;
const int TILE_TYPE_FISHERY_WAITING = 38;
const int TILE_TYPE_FISHERY_HOOKED = 39;
const int TILE_TYPE_FISHERY_CAUGHT = 40;

const int TILE_TYPE_EXTRACTOR = 41; // only for berry, apple, and rye. (spring, summer, fall)
const int TILE_TYPE_EXTRACTOR_FULL = 42;
const int TILE_TYPE_EXTRACTOR_READY = 43;

const int TILE_TYPE_ARCADE = 44;

const int TILE_TYPE_WALL = 45;
const int TILE_TYPE_BOUNDED = 46;

const int TILE_TYPE_OPEN_DOOR = 47;
const int TILE_TYPE_CLOSED_DOOR = 48;

const int TILE_TYPE_PATH = 49;

const int TILE_TYPE_OBELISK = 50;

const int TILE_TYPE_CONTAINER = 51;

const int TILE_TYPE_BLOCKING_SIGN = 52;

const int TILE_TYPE_PORTABLE_EXCHANGER = 53;

const int TILE_TYPE_MINI_SPEED_CHALLENGE = 54;
const int TILE_TYPE_MINI_TIMING_CHALLENGE = 55;

const int TILE_TYPE_MATCHING_CHALLENGE = 56;

const int TILE_TYPE_POTTED_HERB = 57;

const int TILE_TYPE_DONATION_BOX = 58;


class _Tile {
public:
	_Tile()
	{
		type = 0;
		growth = 0;
		water = 0;
		style = 0;
	}

	~_Tile()
	{
		type = 0;
		growth = 0;
		water = 0;
		style = 0;
	}

	int type;
	int growth;
	int water;
	int style;
};

class _Field {
public:
	_Field()
	{
		for (int i=0; i<100; i++)
		{
			for (int j=0; j<100; j++)
			{
				tile[i][j] = new _Tile();
			}
		}
	}

	~_Field()
	{
		for (int i=0; i<100; i++)
		{
			for (int j=0; j<100; j++)
			{
				delete tile[i][j];
			}
		}
	}

	_Tile *tile[100][100];
};

const int TOOL_TYPE_NONE = 0;

const int TOOL_TYPE_HOE = 1;
const int TOOL_TYPE_HAMMER = 2;
const int TOOL_TYPE_SCYTHE = 3;
const int TOOL_TYPE_WATERING_CAN = 4;

const int TOOL_TYPE_ADAMANTINE_HOE = 5;
const int TOOL_TYPE_ADAMANTINE_HAMMER = 6;
const int TOOL_TYPE_ADAMANTINE_SCYTHE = 7;
const int TOOL_TYPE_ADAMANTINE_WATERING_CAN = 8;

const int TOOL_TYPE_RADISH = 9;
const int TOOL_TYPE_CABBAGE = 10;
const int TOOL_TYPE_CUCUMBER = 11;
const int TOOL_TYPE_BEANS = 12;
const int TOOL_TYPE_MELON = 13;
const int TOOL_TYPE_TURNIP = 14;
const int TOOL_TYPE_ONION = 15;

const int TOOL_TYPE_RYE = 16;
const int TOOL_TYPE_NANOTUBE = 17;

const int TOOL_TYPE_ORE = 18;
const int TOOL_TYPE_BERRY = 19;
const int TOOL_TYPE_APPLE = 20;
const int TOOL_TYPE_MUSHROOM = 21;
const int TOOL_TYPE_CRYSTAL = 22;

const int TOOL_TYPE_RADISH_SEED = 23; // do not separate this group!
const int TOOL_TYPE_CABBAGE_SEED = 24;
const int TOOL_TYPE_CUCUMBER_SEED = 25;
const int TOOL_TYPE_BEANS_SEED = 26;
const int TOOL_TYPE_MELON_SEED = 27;
const int TOOL_TYPE_TURNIP_SEED = 28;
const int TOOL_TYPE_ONION_SEED = 29;
const int TOOL_TYPE_RYE_SEED = 30;
const int TOOL_TYPE_NANOTUBE_SEED = 31;

const int TOOL_TYPE_FISH = 32;
const int TOOL_TYPE_EXTRACT = 33;

const int TOOL_TYPE_PORTABLE_EXCHANGER = 34;

const int TOOL_TYPE_GIFT_BASKET = 35;

class _Tool {
public:
	_Tool()
	{
		type = 0;
		quantity = 0;
	}

	~_Tool()
	{
		type = 0;
		quantity = 0;
	}

	int type;
	int quantity;
};

class _Inventory {
public:
	_Inventory()
	{
		for (int i=0; i<12; i++)
		{
			tool[i] = new _Tool();
		}
	}

	~_Inventory()
	{
		for (int i=0; i<12; i++)
		{
			delete tool[i];
		}
	}

	_Tool *tool[12];
};

const int ACTOR_TYPE_NONE = 0;
const int ACTOR_TYPE_ROVER = 1;
const int ACTOR_TYPE_PARROT = 2;

const int ACTOR_TYPE_BUY_ACCEPTED = 3;
const int ACTOR_TYPE_BUY_REJECTED = 4;

const int ACTOR_TYPE_BUY_ROVER = 5;
const int ACTOR_TYPE_SELL_ROVER = 6;
const int ACTOR_TYPE_BUY_WATER_GENERATOR = 7;
const int ACTOR_TYPE_BUY_GIFT_BASKET = 8;
const int ACTOR_TYPE_BUY_ORE = 9; 
const int ACTOR_TYPE_BUY_NANOTUBE = 10;

const int ACTOR_TYPE_BUY_RADISH_SEEDS = 11; // do not break up this group!
const int ACTOR_TYPE_BUY_CABBAGE_SEEDS = 12;
const int ACTOR_TYPE_BUY_CUCUMBER_SEEDS = 13;
const int ACTOR_TYPE_BUY_BEANS_SEEDS = 14;
const int ACTOR_TYPE_BUY_MELON_SEEDS = 15;
const int ACTOR_TYPE_BUY_TURNIP_SEEDS = 16;
const int ACTOR_TYPE_BUY_ONION_SEEDS = 17;
const int ACTOR_TYPE_BUY_RYE_SEEDS = 18;
const int ACTOR_TYPE_BUY_NANOTUBE_SEEDS = 19;

const int ACTOR_TYPE_BUY_NOTHING = 20;

const int ACTOR_TYPE_DAVID = 21;
const int ACTOR_TYPE_CLARA = 22;
const int ACTOR_TYPE_ANDREW = 23;
const int ACTOR_TYPE_EMILY = 24;

const int ACTOR_TYPE_BIBLE_STATION = 25;
const int ACTOR_TYPE_WEATHER_GAUGE = 26;
const int ACTOR_TYPE_TELEVISION = 27;


class _Actor {
public:
	_Actor()
	{
		type = 0;
		fx = 0.0f;
		fy = 0.0f;
		rot = 0.0f;
		pitch = 0.0f;
		px = 0;
		py = 0;
		present_field = -1;

		rx1 = 0.0f;
		ry1 = 0.0f;
		rx2 = 0.0f;
		ry2 = 0.0f;
		tx = 0.0f;
		ty = 0.0f;

		affection = 0;
		affection_lifted_today = 0;

		for (int i=0; i<3; i++)
		{
			primary_color[i] = 0.0f;
			secondary_color[i] = 0.0f;
			tertiary_color[i] = 0.0f;
		}

		animation_type = 0;
		animation_timer = 0.0f;
	}
	
	~_Actor()
	{
		type = 0;
		fx = 0.0f;
		fy = 0.0f;
		rot = 0.0f;
		pitch = 0.0f;
		px = 0;
		py = 0;
		present_field = -1;

		rx1 = 0.0f;
		ry1 = 0.0f;
		rx2 = 0.0f;
		ry2 = 0.0f;
		tx = 0.0f;
		ty = 0.0f;

		affection = 0;
		affection_lifted_today = 0;

		for (int i=0; i<3; i++)
		{
			primary_color[i] = 0.0f;
			secondary_color[i] = 0.0f;
			tertiary_color[i] = 0.0f;
		}

		animation_type = 0;
		animation_timer = 0.0f;
	}

	int type;
	float fx, fy;
	float rot, pitch;
	int px, py;
	int present_field;
	
	float rx1, ry1;
	float rx2, ry2;
	float tx, ty;

	int affection;
	int affection_lifted_today;

	float primary_color[3];
	float secondary_color[3];
	float tertiary_color[3];

	int animation_type;
	float animation_timer;
};

class _Cast {
public:
	_Cast()
	{
		for (int i=0; i<30; i++)
		{
			actor[i] = new _Actor();
		}
	}

	~_Cast()
	{
		for (int i=0; i<30; i++)
		{
			delete actor[i];
		}
	}

	_Actor *actor[30];
};

class _Stats {
public:
	_Stats()
	{
		fx = 5.5f;
		fy = 5.5f;
		rot = 3.0f * 3.14159f / 2.0f;
		pitch = 0.0f;
		px = 5;
		py = 5;
		dx = 5;
		dy = 6;
		sex = 0;
		current_tool = 0;
		credits = 0;
		held_credits = 0;
		materials = 0;
		held_materials = 0;
		feed = 0;
		minute = 0;
		hour = 6;
		day = 1;
		season = 1;
		year = 1;
		day_of_week = 2;
		days_in_a_season = 30;
		weather = 0;
		future_weather = 0;
		current_field = 0;
		other_field = 0;
		activate_on = false;
		dialog_up = -1;
		dialog_place = 0;
		dialog_selection = 0;
		countdown = -5;
		success = 0;
		donated = 0;
		prayed = 0;

		for (int i=0; i<4; i++)
		{
			upgrade[i] = 0;
		}

		for (int i=0; i<4; i++)
		{
			move_priority[i] = 0;
		}

		for (int i=0; i<3; i++)
		{
			primary_color[i] = 0.0f;
			secondary_color[i] = 0.0f;
			tertiary_color[i] = 0.0f;
		}
	
		animation_type = 0;
		animation_timer = 0.0f;

		minigame_high_score = 0;
		minigame_prev_score = 0;

		total_crops = 0;
		total_rye = 0;
		total_gathered = 0;
		total_crystal = 0;
		total_ore = 0;
		total_extract = 0;
		total_fish = 0;

		for (int i=0; i<32; i++)
		{
			name[i] = 0;
		}
	}

	~_Stats()
	{
		fx = 5.5f;
		fy = 5.5f;
		rot = 3.0f * 3.14159f / 2.0f;
		pitch = 0.0f;
		px = 5;
		py = 5;
		dx = 5;
		dy = 6;
		sex = 0;
		current_tool = 0;
		credits = 0;
		held_credits = 0;
		materials = 0;
		held_materials = 0;
		feed = 0;
		minute = 0;
		hour = 6;
		day = 0;
		season = 0;
		year = 1;
		day_of_week = 2;
		days_in_a_season = 30;
		weather = 0;
		future_weather = 0;
		current_field = 0;
		other_field = 0;
		activate_on = false;
		dialog_up = -1;
		dialog_place = 0;
		dialog_selection = 0;
		countdown = -5;
		success = 0;
		donated = 0;
		prayed = 0;

		for (int i=0; i<4; i++)
		{
			upgrade[i] = 0;
		}

		for (int i=0; i<4; i++)
		{
			move_priority[i] = 0;
		}

		for (int i=0; i<3; i++)
		{
			primary_color[i] = 0.0f;
			secondary_color[i] = 0.0f;
			tertiary_color[i] = 0.0f;
		}

		animation_type = 0;
		animation_timer = 0.0f;

		minigame_high_score = 0;
		minigame_prev_score = 0;

		total_crops = 0;
		total_rye = 0;
		total_gathered = 0;
		total_crystal = 0;
		total_ore = 0;
		total_extract = 0;
		total_fish = 0;

		for (int i=0; i<32; i++)
		{
			name[i] = 0;
		}
	}

	float fx, fy;
	float rot, pitch;
	int px, py;
	int dx, dy;
	int sex;

	int current_tool;
	int energy;
	unsigned long credits;
	int held_credits;
	int materials, held_materials;
	int feed;
	int minute, hour, day, season, year;
	int day_of_week;
	int days_in_a_season;
	int weather, future_weather;
	int current_field, other_field;
	bool activate_on;
	int dialog_up;
	int dialog_place;
	int dialog_selection;
	int countdown, success;
	unsigned long donated;
	unsigned long prayed;
	int upgrade[4];

	int move_priority[4];

	float primary_color[3];
	float secondary_color[3];
	float tertiary_color[3];

	int animation_type;
	float animation_timer;

	unsigned long minigame_high_score, minigame_prev_score;

	unsigned long total_crops, total_rye, total_gathered, total_crystal, total_ore, total_extract, total_fish;

	char name[32];
};

bool Save(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats, const char *filename)
{
	FILE *output = NULL;

	output = fopen(filename, "wt");
	if (!output) return false;

	fprintf(output, "# Save File for Sowing Sun\n\n");

	for (int f=0; f<MAX_FIELDS; f++)
	{
		fprintf(output, "# Field %d Tiles 100x100 - Type, Growth, Water, Style\n", f);

		for (int i=0; i<100; i++)
		{
			for (int j=0; j<100; j++)
			{
				fprintf(output, "$ %d %d %d %d\n", field[f]->tile[i][j]->type, field[f]->tile[i][j]->growth,
					field[f]->tile[i][j]->water, field[f]->tile[i][j]->style);
			}
		
			fprintf(output, "\n");
		}

		fprintf(output, "\n");
	} 

	fprintf(output, "# Inventory - ToolType, ToolQuantity\n");

	for (int i=0; i<12; i++)
	{
		fprintf(output, "$ %d %d\n", inventory->tool[i]->type, inventory->tool[i]->quantity);
	}

	fprintf(output, "\n");

	fprintf(output, "# Cast Actors - Type, FloatX, FloatY, Rotation, Pitch, PosX, PosY, PresentField, RectX1, RectY1, RectX2, RectY2, TargetX, TargetY, Affection, AffectionLiftedToday, ");
	fprintf(output, "PrimaryColorRed, PrimaryColorGreen, PrimaryColorBlue, SecondaryColorRed, SecondaryColorGreen, SecondaryColorBlue, ");
	fprintf(output, "TertiaryColorRed, TertiaryColorGreen, TertiaryColorBlue, AnimationType, AnimationTimer\n");
	
	for (int i=0; i<30; i++)
	{
		fprintf(output, "$ %d %f %f %f %f %d %d %d %f %f %f %f %f %f %d %d ", cast->actor[i]->type, cast->actor[i]->fx, cast->actor[i]->fy, cast->actor[i]->rot,
			cast->actor[i]->pitch, cast->actor[i]->px, cast->actor[i]->py, cast->actor[i]->present_field, cast->actor[i]->rx1, cast->actor[i]->ry1,
			cast->actor[i]->rx2, cast->actor[i]->ry2, cast->actor[i]->tx, cast->actor[i]->ty, cast->actor[i]->affection, cast->actor[i]->affection_lifted_today);
		
		fprintf(output, "%f %f %f %f %f %f %f %f %f %d %f\n", cast->actor[i]->primary_color[0], cast->actor[i]->primary_color[1], cast->actor[i]->primary_color[2],
			cast->actor[i]->secondary_color[0], cast->actor[i]->secondary_color[1], cast->actor[i]->secondary_color[2], cast->actor[i]->tertiary_color[0],
			cast->actor[i]->tertiary_color[1], cast->actor[i]->tertiary_color[2], cast->actor[i]->animation_type, cast->actor[i]->animation_timer);
	}

	fprintf(output, "\n");

	fprintf(output, "# Stats - FloatX, FloatY, Rotation, Pitch, PosX, PosY, DirX, DirY, Sex, CurrentTool, Energy, Credits, HeldCredits, Materials, HeldMaterials, ");
	fprintf(output, "Feed, Minute, Hour, Day, Season, Year, DayOfWeek, DaysInASeason, Weather, FutureWeather, CurrentField, OtherField, ActivateOn, ");
	fprintf(output, "DialogUp, DialogPlace, DialogSelection, Countdown, Success, Donated, Prayed, Upgrade1, Upgrade2, Upgrade3, Upgrade4, ");
	fprintf(output, "MovePriority1, MovePriority2, MovePriority3, MovePriority4, ");
	fprintf(output, "PrimaryColorRed, PrimaryColorGreen, PrimaryColorBlue, SecondaryColorRed, SecondaryColorGreen, SecondaryColorBlue, ");
	fprintf(output, "TertiaryColorRed, TertiaryColorGreen, TertiaryColorBlue, AnimationType, AnimationTimer, MiniGameHighScore, MiniGamePrevScore, ");
	fprintf(output, "TotalCrops, TotalRye, TotalGathered, TotalCrystal, TotalOre, TotalExtract, TotalFish, ;Name;\n");

	fprintf(output, "$ %f %f %f %f %d %d %d %d %d %d %d %lu %d %d %d ", stats->fx, stats->fy, stats->rot, stats->pitch, stats->px, stats->py, stats->dx, stats->dy,
		stats->sex, stats->current_tool, stats->energy, stats->credits, stats->held_credits, stats->materials, stats->held_materials);

	fprintf(output, "%d %d %d %d %d %d %d %d %d %d %d %d %d ", stats->feed, stats->minute, stats->hour, stats->day, stats->season, stats->year, stats->day_of_week,
		stats->days_in_a_season, stats->weather, stats->future_weather, stats->current_field, stats->other_field, stats->activate_on);

	fprintf(output, "%d %d %d %d %d %lu %lu %d %d %d %d %d %d %d %d ", stats->dialog_up, stats->dialog_place, stats->dialog_selection, stats->countdown, stats->success, stats->donated,
		stats->prayed, stats->upgrade[0], stats->upgrade[1], stats->upgrade[2], stats->upgrade[3],
		stats->move_priority[0], stats->move_priority[1], stats->move_priority[2], stats->move_priority[3]);

	fprintf(output, "%f %f %f %f %f %f %f %f %f %d %f ", stats->primary_color[0], stats->primary_color[1], stats->primary_color[2],
			stats->secondary_color[0], stats->secondary_color[1], stats->secondary_color[2], stats->tertiary_color[0],
			stats->tertiary_color[1], stats->tertiary_color[2], stats->animation_type, stats->animation_timer);
	
	fprintf(output, "%lu %lu %lu %lu %lu %lu %lu %lu %lu ", stats->minigame_high_score, stats->minigame_prev_score,
		stats->total_crops, stats->total_rye, stats->total_gathered, stats->total_crystal, stats->total_ore, stats->total_extract, stats->total_fish);

	fprintf(output, ";");

	for (int i=0; i<32; i++)
	{
		fprintf(output, "%c", stats->name[i]);
	}

	fprintf(output, ";\n");

	fprintf(output, "\n");

	fprintf(output, "# Options - FramesDivider, CameraDistance, SoundOn\n");

	fprintf(output, "$ %d %f %d\n", (compute_unlimited==true && compute_cycles_total==1?0:compute_cycles_total), camera_distance, sound_on);

	fprintf(output, "\n");

	fclose(output);

	return true;
};

bool Load(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats, const char *filename)
{
	FILE *input = NULL;

	input = fopen(filename, "rt");
	if (!input) return false;

	char buffer;

	int temp_number;

	buffer = 0;
	temp_number = 0;

	while (buffer != '#' && temp_number < 1000)
	{
		fscanf(input, "%c", &buffer);

		temp_number++;
	}

	if (temp_number == 1000)
	{
		//printf("Blank Save File Found!\n");

		return false;
	}

	for (int f=0; f<MAX_FIELDS; f++)
	{
		//printf("Loading Field %d\n", f);

		for (int i=0; i<100; i++)
		{
			for (int j=0; j<100; j++)
			{
				buffer = 0;

				while (buffer != '$')
				{
					fscanf(input, "%c", &buffer);
				}

				fscanf(input, "%d %d %d %d", &field[f]->tile[i][j]->type, &field[f]->tile[i][j]->growth,
					&field[f]->tile[i][j]->water, &field[f]->tile[i][j]->style);
			}
		}
	} 

	//printf("Loading Inventory\n");

	for (int i=0; i<12; i++)
	{
		buffer = 0;

		while (buffer != '$')
		{
			fscanf(input, "%c", &buffer);
		}

		fscanf(input, "%d %d", &inventory->tool[i]->type, &inventory->tool[i]->quantity);
	}

	//printf("Loading Cast\n");
	
	for (int i=0; i<30; i++)
	{
		buffer = 0;

		while (buffer != '$')
		{
			fscanf(input, "%c", &buffer);
		}

		fscanf(input, "%d %f %f %f %f %d %d %d %f %f %f %f %f %f %d %d ", &cast->actor[i]->type, &cast->actor[i]->fx, &cast->actor[i]->fy, &cast->actor[i]->rot,
			&cast->actor[i]->pitch, &cast->actor[i]->px, &cast->actor[i]->py, &cast->actor[i]->present_field, &cast->actor[i]->rx1, &cast->actor[i]->ry1,
			&cast->actor[i]->rx2, &cast->actor[i]->ry2, &cast->actor[i]->tx, &cast->actor[i]->ty, &cast->actor[i]->affection, &cast->actor[i]->affection_lifted_today);
		
		fscanf(input, "%f %f %f %f %f %f %f %f %f %d %f\n", &cast->actor[i]->primary_color[0], &cast->actor[i]->primary_color[1], &cast->actor[i]->primary_color[2],
			&cast->actor[i]->secondary_color[0], &cast->actor[i]->secondary_color[1], &cast->actor[i]->secondary_color[2], &cast->actor[i]->tertiary_color[0],
			&cast->actor[i]->tertiary_color[1], &cast->actor[i]->tertiary_color[2], &cast->actor[i]->animation_type, &cast->actor[i]->animation_timer);
	}

	//printf("Loading Stats\n");

	buffer = 0;

	while (buffer != '$')
	{
		fscanf(input, "%c", &buffer);
	}

	fscanf(input, "%f %f %f %f %d %d %d %d %d %d %d %lu %d %d %d ", &stats->fx, &stats->fy, &stats->rot, &stats->pitch, &stats->px, &stats->py, &stats->dx, &stats->dy,
		&stats->sex, &stats->current_tool, &stats->energy, &stats->credits, &stats->held_credits, &stats->materials, &stats->held_materials);

	fscanf(input, "%d %d %d %d %d %d %d %d %d %d %d %d %d ", &stats->feed, &stats->minute, &stats->hour, &stats->day, &stats->season, &stats->year, &stats->day_of_week,
		&stats->days_in_a_season, &stats->weather, &stats->future_weather, &stats->current_field, &stats->other_field, &temp_number);

	stats->activate_on = (bool)temp_number;

	fscanf(input, "%d %d %d %d %d %lu %lu %d %d %d %d %d %d %d %d ", &stats->dialog_up, &stats->dialog_place, &stats->dialog_selection, &stats->countdown, &stats->success, &stats->donated,
		&stats->prayed, &stats->upgrade[0], &stats->upgrade[1], &stats->upgrade[2], &stats->upgrade[3],
		&stats->move_priority[0], &stats->move_priority[1], &stats->move_priority[2], &stats->move_priority[3]);

	fscanf(input, "%f %f %f %f %f %f %f %f %f %d %f ", &stats->primary_color[0], &stats->primary_color[1], &stats->primary_color[2],
			&stats->secondary_color[0], &stats->secondary_color[1], &stats->secondary_color[2], &stats->tertiary_color[0],
			&stats->tertiary_color[1], &stats->tertiary_color[2], &stats->animation_type, &stats->animation_timer);
	
	fscanf(input, "%lu %lu %lu %lu %lu %lu %lu %lu %lu", &stats->minigame_high_score, &stats->minigame_prev_score,
		&stats->total_crops, &stats->total_rye, &stats->total_gathered, &stats->total_crystal, &stats->total_ore, &stats->total_extract, &stats->total_fish);

	buffer = 0;

	while (buffer != ';')
	{
		fscanf(input, "%c", &buffer);
	}

	for (int i=0; i<33; i++)
	{
		fscanf(input, "%c", &buffer);

		if (buffer == ';')
		{
			for (int j=i; j<32; j++) stats->name[j] = 0;

			i = 34;
		}
		else if (i < 32) stats->name[i] = buffer;
	}

	//printf("Loading Options\n");

	buffer = 0;

	while (buffer != '$')
	{
		fscanf(input, "%c", &buffer);
	}

	fscanf(input, "%d %f %d", &compute_cycles_total, &camera_distance, &temp_number);

	sound_on = (bool)temp_number;

	if (compute_cycles_total == 0)
	{
		compute_cycles_total = 1;

		compute_unlimited = true;
	}
	else
	{
		compute_unlimited = false;
	}

	fclose(input);

	return true;
};

void Sleep(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats)
{
/*
	// This temporary code draws a map of the tiles for each field, very handy!
	FILE *temp_file = NULL;

	temp_file = fopen("TempMaps.txt", "wt");
	if (!temp_file) return;

	for (int f=0; f<MAX_FIELDS; f++)
	{
		fprintf(temp_file, "Field %d\n   ", f);

		for (int i=0; i<100; i++)
		{
			if (i % 10 == 0) { fprintf(temp_file, "|%02d", i); i += 2; }
			else fprintf(temp_file, " ");
		}

		fprintf(temp_file, "\n");

		for (int j=0; j<100; j++)
		{
			if (j % 10 == 0) fprintf(temp_file, "%02d-", j);
			else fprintf(temp_file, "   ");

			for (int i=0; i<100; i++)
			{
				bool temp_test = false;

				for (int a=0; a<30; a++)
				{
					if (cast->actor[a]->present_field == f && 
						cast->actor[a]->type != ACTOR_TYPE_NONE &&
						cast->actor[a]->px == i && 
						cast->actor[a]->py == j) { fprintf(temp_file, "1"); temp_test = true; }
				}
				
				if (temp_test == false)
				{
					if (field[f]->tile[i][j]->growth == 0 || 
						field[f]->tile[i][j]->type == TILE_TYPE_WEED || 
						field[f]->tile[i][j]->type == TILE_TYPE_ROCK) fprintf(temp_file, "0");
					else if (field[f]->tile[i][j]->type == TILE_TYPE_CLOSED_DOOR || 
						field[f]->tile[i][j]->type == TILE_TYPE_OPEN_DOOR) fprintf(temp_file, "*");
					else fprintf(temp_file, "1");
				}
			}

			fprintf(temp_file, "\n");
		}

		fprintf(temp_file, "\n");
	}
	
	fclose(temp_file);
*/	

	Save(field, inventory, cast, stats, "SaveFile.txt");

	int number_of_rovers = 0;

	bool next_season = false;

	stats->day++;
		
	stats->minute = 0;
	stats->hour = 6;
			
	if (stats->day > stats->days_in_a_season)
	{
		stats->day = 1;
			
		stats->season++;

		next_season = true;
				
		if (stats->season > 4)
		{
			stats->season = 1;
			
			stats->year++;

			if (stats->year == 2) // give the Portable XChanger
			{
				field[0]->tile[22][27]->type = TILE_TYPE_PORTABLE_EXCHANGER;
				field[0]->tile[22][27]->growth = 1;
			}

			menu_system_active = 8; // end of year, show score?	

			menu_position = 0;
		}
	}

	stats->day_of_week++;
	if (stats->day_of_week > 7) stats->day_of_week = 1; // Sunday

	stats->weather = stats->future_weather;

	if (rand() % 100 < 25) stats->future_weather = 1;
	else stats->future_weather = 0;

	if ((stats->season == 1 && stats->day_of_week == 7 && stats->day >= stats->days_in_a_season-7 && stats->day <= stats->days_in_a_season-1) ||
		(stats->season == 2 && ((stats->day == 3 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season-1 && stats->days_in_a_season < 4))) ||
		(stats->season == 3 && stats->day_of_week == 4 && stats->day >= stats->days_in_a_season-7 && stats->day <= stats->days_in_a_season-1) ||
		(stats->season == 4 && ((stats->day == 24 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season-1 && stats->days_in_a_season < 25)))) // day before festivals
	{
		stats->future_weather = 0;
	}
	
	if (stats->season == 4)
	{
		field[5]->tile[21][46]->type = TILE_TYPE_PATH;
		field[5]->tile[21][46]->growth = 0;
		field[5]->tile[21][46]->style = 0;
	}
	else
	{
		field[5]->tile[21][46]->type = TILE_TYPE_BLOCKING_SIGN;
		field[5]->tile[21][46]->growth = 1;
		field[5]->tile[21][46]->style = 0;
	}
			
	if (stats->success > 0) stats->success -= (int)(30.0f / (float)stats->days_in_a_season);

	if (stats->prayed > 2 * ((stats->year-1)*stats->days_in_a_season*4 + (stats->season-1)*stats->days_in_a_season + stats->day))
	{
		if (rand() % 4 == 0) stats->success++;
	}

	if (stats->success > 0) stats->energy = 300;
	else stats->energy = 200;
	
	stats->credits += stats->held_credits;
	stats->held_credits = 0;

	stats->materials += stats->held_materials;
	stats->held_materials = 0;

	cast->actor[24]->type = ACTOR_TYPE_ROVER;
	cast->actor[24]->fx = 20.5f;
	cast->actor[24]->fy = 27.5f;
	cast->actor[24]->px = 20;
	cast->actor[24]->py = 27;
	cast->actor[24]->present_field = 0;
	cast->actor[24]->rx1 = 20.5f;
	cast->actor[24]->ry1 = 27.5f;
	cast->actor[24]->rx2 = 20.5f;
	cast->actor[24]->ry2 = 27.5f;
	cast->actor[24]->tx = 20.5f;
	cast->actor[24]->ty = 27.5f;
	cast->actor[24]->rot = 0.0f;
	cast->actor[24]->primary_color[0] = 0.75f;
	cast->actor[24]->primary_color[1] = 0.75f;
	cast->actor[24]->primary_color[2] = 0.75f;
	cast->actor[24]->secondary_color[0] = 0.3f;
	cast->actor[24]->secondary_color[1] = 0.3f;
	cast->actor[24]->secondary_color[2] = 0.3f;
	cast->actor[24]->tertiary_color[0] = 0.75f;
	cast->actor[24]->tertiary_color[1] = 0.75f;
	cast->actor[24]->tertiary_color[2] = 0.75f;
	cast->actor[24]->affection = 1;
	
	number_of_rovers = 0;
	
	for (int k=0; k<30; k++)
	{
		cast->actor[k]->affection_lifted_today = 0;

		if (cast->actor[k]->type == ACTOR_TYPE_ROVER && cast->actor[k]->present_field == 2)
		{
			if (cast->actor[k]->affection > 0) number_of_rovers++;
							
			cast->actor[k]->affection = 0;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_RADISH_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_TURNIP_SEEDS ||
			(cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 0)) && stats->season == 2)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_CUCUMBER_SEEDS;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_CABBAGE_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_ONION_SEEDS ||
			(cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 1)) && stats->season == 2)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_BEANS_SEEDS;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_RYE_SEEDS ||
			(cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 2)) && stats->season == 2)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_MELON_SEEDS;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_RADISH_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_CUCUMBER_SEEDS ||
			(cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 0)) && stats->season == 3)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_TURNIP_SEEDS;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_CABBAGE_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_BEANS_SEEDS ||
			(cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 1)) && stats->season == 3)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_ONION_SEEDS;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_RYE_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_MELON_SEEDS) && (stats->season == 3 || stats->season == 4))
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_NOTHING;
			cast->actor[k]->affection = 2;
		}
		else if (cast->actor[k]->type == ACTOR_TYPE_BUY_NANOTUBE_SEEDS && (stats->season == 3 || stats->season == 4))
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_NOTHING;
			cast->actor[k]->affection = 3;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_RADISH_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_CUCUMBER_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_TURNIP_SEEDS) && stats->season == 4)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_NOTHING;
			cast->actor[k]->affection = 0;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_CABBAGE_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_BEANS_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_ONION_SEEDS) && stats->season == 4)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_NOTHING;
			cast->actor[k]->affection = 1;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_CUCUMBER_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_TURNIP_SEEDS ||
			(cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 0)) && stats->season == 1)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_RADISH_SEEDS;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_BEANS_SEEDS ||
			cast->actor[k]->type == ACTOR_TYPE_BUY_ONION_SEEDS ||
			(cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 1)) && stats->season == 1)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_CABBAGE_SEEDS;
		}
		else if ((cast->actor[k]->type == ACTOR_TYPE_BUY_MELON_SEEDS ||
			(cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 2)) && stats->season == 1)
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_RYE_SEEDS;
		}
		else if (cast->actor[k]->type == ACTOR_TYPE_BUY_NOTHING && cast->actor[k]->affection == 3 && (stats->season == 1 || stats->season == 2))
		{
			cast->actor[k]->type = ACTOR_TYPE_BUY_NANOTUBE_SEEDS;
		}
	}

	// 12 fields to look through!
	for (int f=0; f<MAX_FIELDS; f++)
	{	
		for (int i=0; i<100; i++)
		{
			for (int j=0; j<100; j++)
			{
				if (field[f]->tile[i][j]->type == TILE_TYPE_CUT_RYE)
				{
					field[f]->tile[i][j]->type = TILE_TYPE_DIRT; // blows away?
		
					field[f]->tile[i][j]->growth = 0;
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_RYE)
				{
					if (f == 0 && stats->season != 4)
					{
						field[f]->tile[i][j]->growth += (int)(30.0f / (float)stats->days_in_a_season);

						if (field[f]->tile[i][j]->growth > 30) field[f]->tile[i][j]->growth = 30;
					}
					else 
					{
						field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
	
						field[f]->tile[i][j]->growth = 0;
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_NANOTUBE)
				{
					if (f == 0)
					{
						if (stats->season != 4)
						{
							field[f]->tile[i][j]->growth -= (int)(30.0f / (float)stats->days_in_a_season);

							if (field[f]->tile[i][j]->growth < -9) field[f]->tile[i][j]->growth = -9;
						}
						else field[f]->tile[i][j]->growth = 0;
					}
					else
					{
						field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
	
						field[f]->tile[i][j]->growth = 0;
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_BROKEN_ORE ||
					field[f]->tile[i][j]->type == TILE_TYPE_EMPTY_ORE)
				{
					field[f]->tile[i][j]->type = TILE_TYPE_ORE;
								
					field[f]->tile[i][j]->growth = 5;
					field[f]->tile[i][j]->style = rand() % 3;
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_EMPTY_BERRY_BUSH)
				{
					if (stats->season == 1)
					{
						field[f]->tile[i][j]->type = TILE_TYPE_BERRY_BUSH;
								
						field[f]->tile[i][j]->growth = 1;
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_BERRY_BUSH)
				{
					if (stats->season != 1)
					{
						field[f]->tile[i][j]->type = TILE_TYPE_EMPTY_BERRY_BUSH;
								
						field[f]->tile[i][j]->growth = 1;
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_EMPTY_APPLE_TREE)
				{
					if (stats->season == 2)
					{
						field[f]->tile[i][j]->type = TILE_TYPE_APPLE_TREE;
								
						field[f]->tile[i][j]->growth = 1;
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_APPLE_TREE)
				{
					if (stats->season != 2)
					{
						field[f]->tile[i][j]->type = TILE_TYPE_EMPTY_APPLE_TREE;
								
						field[f]->tile[i][j]->growth = 1;
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_EMPTY_MUSHROOM_BED)
				{
					if (stats->season == 3)
					{				
						field[f]->tile[i][j]->type = TILE_TYPE_MUSHROOM_BED;
								
						field[f]->tile[i][j]->growth = 1;
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_MUSHROOM_BED)
				{
					if (stats->season != 3)
					{				
						field[f]->tile[i][j]->type = TILE_TYPE_EMPTY_MUSHROOM_BED;
								
						field[f]->tile[i][j]->growth = 1;
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_EXPOSED_CRYSTAL ||
					field[f]->tile[i][j]->type == TILE_TYPE_EMPTY_CRYSTAL ||
					field[f]->tile[i][j]->type == TILE_TYPE_BROKEN_CRYSTAL ||
					field[f]->tile[i][j]->type == TILE_TYPE_CRYSTAL)
				{
					field[f]->tile[i][j]->type = TILE_TYPE_CRYSTAL;
								
					field[f]->tile[i][j]->growth = -(rand() % 10) - 1;
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_WATER_GENERATOR)
				{
					field[f]->tile[i][j]->growth = 100;
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_FULL_ROVER_STATION)
				{
					if (f == 2)
					{
						if (number_of_rovers > 0)
						{
							field[f]->tile[i][j]->type = TILE_TYPE_EMPTY_ROVER_STATION;
								
							for (int x=0; x<100; x++)
							{
								for (int y=0; y<100; y++)
								{
									if (field[f]->tile[x][y]->type == TILE_TYPE_EMPTY_ROVER_DEPOSIT)
									{
										field[f]->tile[x][y]->type = TILE_TYPE_ROVER_DEPOSIT;
										
										x = 101;
										y = 101;
									}
								}
							}
								
							number_of_rovers--;
						}
					}
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_EXTRACTOR_FULL)
				{
					field[f]->tile[i][j]->growth = 1;
								
					field[f]->tile[i][j]->type = TILE_TYPE_EXTRACTOR_READY;
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_RADISH ||
					field[f]->tile[i][j]->type == TILE_TYPE_CABBAGE)
				{
					if (f == 0 && (stats->season == 1 || 
						(stats->season == 2 && field[f]->tile[i][j]->growth > 0 && field[f]->tile[i][j]->type == TILE_TYPE_RADISH)))
					{
						if (field[f]->tile[i][j]->water == 1) field[f]->tile[i][j]->growth += (int)(30.0f / (float)stats->days_in_a_season);
	
						if (field[f]->tile[i][j]->type == TILE_TYPE_RADISH && 
							field[f]->tile[i][j]->growth > 4) field[f]->tile[i][j]->growth = 4;
			
						if (field[f]->tile[i][j]->type == TILE_TYPE_RADISH && 
							field[f]->tile[i][j]->growth > 7) field[f]->tile[i][j]->growth = 7;
					}
					else 
					{
						field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
		
						field[f]->tile[i][j]->growth = 0;
					}

					field[f]->tile[i][j]->water = 0;
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_CUCUMBER ||
					field[f]->tile[i][j]->type == TILE_TYPE_BEANS ||
					field[f]->tile[i][j]->type == TILE_TYPE_MELON)
				{	
					if (f == 0 && stats->season == 2)
					{
						if (field[f]->tile[i][j]->water == 1) field[f]->tile[i][j]->growth += (int)(30.0f / (float)stats->days_in_a_season);
	
						if (field[f]->tile[i][j]->type == TILE_TYPE_CUCUMBER && 
							field[f]->tile[i][j]->growth > 9) field[f]->tile[i][j]->growth = 9;

						if (field[f]->tile[i][j]->type == TILE_TYPE_BEANS && 
							field[f]->tile[i][j]->growth > 12) field[f]->tile[i][j]->growth = 12;

						if (field[f]->tile[i][j]->type == TILE_TYPE_MELON && 
							field[f]->tile[i][j]->growth > 15) field[f]->tile[i][j]->growth = 15;
					}
					else 
					{
						field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
		
						field[f]->tile[i][j]->growth = 0;
					}

					field[f]->tile[i][j]->water = 0;
				}
				else if (field[f]->tile[i][j]->type == TILE_TYPE_TURNIP ||
					field[f]->tile[i][j]->type == TILE_TYPE_ONION)
				{
					if (f == 0 && (stats->season == 3 || (stats->season == 4 && field[f]->tile[i][j]->growth >= 0)))
					{
						if (field[f]->tile[i][j]->water == 1 && stats->season == 3) field[f]->tile[i][j]->growth += (int)(30.0f / (float)stats->days_in_a_season); // only lay dormant in the winter
	
						if (field[f]->tile[i][j]->type == TILE_TYPE_TURNIP && 
							field[f]->tile[i][j]->growth > 6) field[f]->tile[i][j]->growth = 6;

						if (field[f]->tile[i][j]->type == TILE_TYPE_ONION && 
							field[f]->tile[i][j]->growth > 11) field[f]->tile[i][j]->growth = 11;
					}
					else 
					{
						field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
		
						field[f]->tile[i][j]->growth = 0;
					}

					field[f]->tile[i][j]->water = 0;
				}
				else if (field[f]->tile[i][j]->water == 1)
				{						
					if (field[f]->tile[i][j]->type == TILE_TYPE_WEED)
					{
						if (stats->season == 4)
						{
							if (rand() % 100 < 5)
							{
								field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
		
								field[f]->tile[i][j]->growth = 0;
							}
						}
					}
					else if (field[f]->tile[i][j]->type == TILE_TYPE_DIRT)
					{
						if (f == 0)
						{
							if (rand() % 100 < 1)
							{
								field[f]->tile[i][j]->type = TILE_TYPE_WEED;
											
								field[f]->tile[i][j]->growth = 1;
								field[f]->tile[i][j]->style = rand() % 3;
							}
						}
						else
						{
							if (rand() % 1000 < 1)
							{
								field[f]->tile[i][j]->type = TILE_TYPE_WEED;
											
								field[f]->tile[i][j]->growth = 1;
								field[f]->tile[i][j]->style = rand() % 3;
							}
						}
					}
					else if (field[f]->tile[i][j]->type == TILE_TYPE_TILLED)
					{
						if (rand() % 100 < 10)
						{
							field[f]->tile[i][j]->type = TILE_TYPE_WEED;
						
							field[f]->tile[i][j]->growth = 1;
							field[f]->tile[i][j]->style = rand() % 3;
						}
						else if (rand() % 100 < 25)
						{
							field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
		
							field[f]->tile[i][j]->growth = 0;
						}
					}
			
					field[f]->tile[i][j]->water = 0;
				}
				else if (field[f]->tile[i][j]->water == 0)
				{
					if (field[f]->tile[i][j]->type == TILE_TYPE_WEED)
					{
						if (stats->season == 4)
						{
							if (rand() % 100 < 5)
							{
								field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
		
								field[f]->tile[i][j]->growth = 0;
							}
						}
					}
					else if (field[f]->tile[i][j]->type == TILE_TYPE_DIRT)
					{
						if (rand() % 100 < 1)
						{
							field[f]->tile[i][j]->type = TILE_TYPE_WEED;
										
							field[f]->tile[i][j]->growth = 1;
							field[f]->tile[i][j]->style = rand() % 3;
						}
					}
					else if (field[f]->tile[i][j]->type == TILE_TYPE_TILLED)
					{
						if (rand() % 100 < 5)
						{
							field[f]->tile[i][j]->type = TILE_TYPE_WEED;
						
							field[f]->tile[i][j]->growth = 1;
							field[f]->tile[i][j]->style = rand() % 3;
						}
						else if (rand() % 100 < 25)
						{
							field[f]->tile[i][j]->type = TILE_TYPE_DIRT;
		
							field[f]->tile[i][j]->growth = 0;
						}
					}
				}

				if (stats->weather == 1)
				{
					field[f]->tile[i][j]->water = 1;
				}
			}
		}
	}

	// clear the mountainside
	for (int i=20; i<=40; i++)
	{
		for (int j=31; j<=60; j++)
		{
			if (field[4]->tile[i][j]->type == TILE_TYPE_WEED || 
				field[4]->tile[i][j]->type == TILE_TYPE_ROCK) 
			{
				field[4]->tile[i][j]->type = TILE_TYPE_DIRT;
				field[4]->tile[i][j]->growth = 0;
				field[4]->tile[i][j]->style = 0;
			}
		}
	}

/*
	Town Square (6):
	x = 53 to 62, y = 40 to 49

	Church (10):
	x = 20 to 36, y = 21 to 39
*/

	if (stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
	{
		stats->success = 0;

		field[6]->tile[52][42]->type = TILE_TYPE_MINI_SPEED_CHALLENGE;
		field[6]->tile[52][42]->growth = 1;

		field[6]->tile[63][42]->type = TILE_TYPE_MINI_TIMING_CHALLENGE;
		field[6]->tile[63][42]->growth = 1;

		
		field[6]->tile[77][29]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[77][29]->growth = 1;
		field[6]->tile[77][29]->style = 0;

		field[6]->tile[77][33]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[77][33]->growth = 1;
		field[6]->tile[77][33]->style = 0;

		field[6]->tile[75][29]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[75][29]->growth = 1;
		field[6]->tile[75][29]->style = 3;

		field[6]->tile[75][33]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[75][33]->growth = 1;
		field[6]->tile[75][33]->style = 3;

	
		cast->actor[25]->type = ACTOR_TYPE_PARROT;
		cast->actor[25]->fx = 23.5f;
		cast->actor[25]->fy = 25.5f;
		cast->actor[25]->px = 23;
		cast->actor[25]->py = 25;
		cast->actor[25]->present_field = 0;
		cast->actor[25]->rx1 = 23.5f;
		cast->actor[25]->ry1 = 25.5f;
		cast->actor[25]->rx2 = 23.5f;
		cast->actor[25]->ry2 = 25.5f;
		cast->actor[25]->tx = 23.5f;
		cast->actor[25]->ty = 25.5f;
		cast->actor[25]->affection = 1;
		cast->actor[25]->rot = 0.0f;
		cast->actor[25]->primary_color[0] = 1.0f;
		cast->actor[25]->primary_color[1] = 1.0f;
		cast->actor[25]->primary_color[2] = 1.0f;
		cast->actor[25]->secondary_color[0] = 0.3f;
		cast->actor[25]->secondary_color[1] = 0.3f;
		cast->actor[25]->secondary_color[2] = 0.3f;
	}
	else if (stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) // festivals
	{
		stats->success = 0;

		field[6]->tile[77][29]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[77][29]->growth = 1;
		field[6]->tile[77][29]->style = 1;

		field[6]->tile[77][33]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[77][33]->growth = 1;
		field[6]->tile[77][33]->style = 1;

		field[6]->tile[75][29]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[75][29]->growth = 1;
		field[6]->tile[75][29]->style = 6;

		field[6]->tile[75][33]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[75][33]->growth = 1;
		field[6]->tile[75][33]->style = 6;		

		
		field[10]->tile[21][28]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[21][28]->growth = 1;
		
		field[10]->tile[23][28]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[23][28]->growth = 1;
		
		field[10]->tile[25][28]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[25][28]->growth = 1;

		field[10]->tile[27][28]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[27][28]->growth = 1;

		field[10]->tile[29][28]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[29][28]->growth = 1;

		field[10]->tile[31][28]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[31][28]->growth = 1;

		field[10]->tile[33][28]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[33][28]->growth = 1;
		
		field[10]->tile[35][28]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[35][28]->growth = 1;

		
		field[10]->tile[21][30]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[21][30]->growth = 1;
		
		field[10]->tile[23][30]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[23][30]->growth = 1;
		
		field[10]->tile[25][30]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[25][30]->growth = 1;

		field[10]->tile[27][30]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[27][30]->growth = 1;

		field[10]->tile[29][30]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[29][30]->growth = 1;

		field[10]->tile[31][30]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[31][30]->growth = 1;

		field[10]->tile[33][30]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[33][30]->growth = 1;
		
		field[10]->tile[35][30]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[35][30]->growth = 1;


		field[10]->tile[21][32]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[21][32]->growth = 1;
		
		field[10]->tile[23][32]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[23][32]->growth = 1;
		
		field[10]->tile[25][32]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[25][32]->growth = 1;

		field[10]->tile[27][32]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[27][32]->growth = 1;

		field[10]->tile[29][32]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[29][32]->growth = 1;

		field[10]->tile[31][32]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[31][32]->growth = 1;

		field[10]->tile[33][32]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[33][32]->growth = 1;
		
		field[10]->tile[35][32]->type = TILE_TYPE_MATCHING_CHALLENGE;
		field[10]->tile[35][32]->growth = 1;


		int very_temp_count = 0;
		int very_temp_x1, very_temp_x2, very_temp_y1, very_temp_y2;
		
		for (int i=0; i<100; i++)
		{
			for (int j=0; j<100; j++)
			{
				if (field[10]->tile[i][j]->type == TILE_TYPE_MATCHING_CHALLENGE)
				{
					field[10]->tile[i][j]->style = very_temp_count;

					very_temp_count++;

					if (very_temp_count >= 6) very_temp_count = 0;
				}
			}
		}

		for (int loop=0; loop<100; loop++) // might take a bit?
		{
			very_temp_x1 = rand() % 100;
			very_temp_y1 = rand() % 100;
			
			while (field[10]->tile[very_temp_x1][very_temp_y1]->type != TILE_TYPE_MATCHING_CHALLENGE)
			{
				very_temp_x1 = rand() % 100;
				very_temp_y1 = rand() % 100;
			}

			very_temp_x2 = rand() % 100;
			very_temp_y2 = rand() % 100;
			
			while (field[10]->tile[very_temp_x2][very_temp_y2]->type != TILE_TYPE_MATCHING_CHALLENGE)
			{
				very_temp_x2 = rand() % 100;
				very_temp_y2 = rand() % 100;
			}
					
			very_temp_count = field[10]->tile[very_temp_x1][very_temp_y1]->style;

			field[10]->tile[very_temp_x1][very_temp_y1]->style = field[10]->tile[very_temp_x2][very_temp_y2]->style;
								
			field[10]->tile[very_temp_x2][very_temp_y2]->style = very_temp_count;
		}


		cast->actor[25]->type = ACTOR_TYPE_PARROT;
		cast->actor[25]->fx = 23.5f;
		cast->actor[25]->fy = 25.5f;
		cast->actor[25]->px = 23;
		cast->actor[25]->py = 25;
		cast->actor[25]->present_field = 0;
		cast->actor[25]->rx1 = 23.5f;
		cast->actor[25]->ry1 = 25.5f;
		cast->actor[25]->rx2 = 23.5f;
		cast->actor[25]->ry2 = 25.5f;
		cast->actor[25]->tx = 23.5f;
		cast->actor[25]->ty = 25.5f;
		cast->actor[25]->affection = 1;
		cast->actor[25]->rot = 0.0f;
		cast->actor[25]->primary_color[0] = 1.0f;
		cast->actor[25]->primary_color[1] = 1.0f;
		cast->actor[25]->primary_color[2] = 1.0f;
		cast->actor[25]->secondary_color[0] = 0.3f;
		cast->actor[25]->secondary_color[1] = 0.3f;
		cast->actor[25]->secondary_color[2] = 0.3f;
	}
	else if (stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
	{
		stats->success = 0;

		field[6]->tile[77][29]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[77][29]->growth = 1;
		field[6]->tile[77][29]->style = 4;

		field[6]->tile[77][33]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[77][33]->growth = 1;
		field[6]->tile[77][33]->style = 4;

		field[6]->tile[75][29]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[75][29]->growth = 1;
		field[6]->tile[75][29]->style = 5;

		field[6]->tile[75][33]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[75][33]->growth = 1;
		field[6]->tile[75][33]->style = 5;	


		field[10]->tile[26][32]->type = TILE_TYPE_DONATION_BOX;
		field[10]->tile[26][32]->growth = 1;
		field[10]->tile[29][32]->type = TILE_TYPE_DONATION_BOX;
		field[10]->tile[29][32]->growth = 1;


		cast->actor[25]->type = ACTOR_TYPE_PARROT;
		cast->actor[25]->fx = 23.5f;
		cast->actor[25]->fy = 25.5f;
		cast->actor[25]->px = 23;
		cast->actor[25]->py = 25;
		cast->actor[25]->present_field = 0;
		cast->actor[25]->rx1 = 23.5f;
		cast->actor[25]->ry1 = 25.5f;
		cast->actor[25]->rx2 = 23.5f;
		cast->actor[25]->ry2 = 25.5f;
		cast->actor[25]->tx = 23.5f;
		cast->actor[25]->ty = 25.5f;
		cast->actor[25]->affection = 1;
		cast->actor[25]->rot = 0.0f;
		cast->actor[25]->primary_color[0] = 1.0f;
		cast->actor[25]->primary_color[1] = 1.0f;
		cast->actor[25]->primary_color[2] = 1.0f;
		cast->actor[25]->secondary_color[0] = 0.3f;
		cast->actor[25]->secondary_color[1] = 0.3f;
		cast->actor[25]->secondary_color[2] = 0.3f;
	}
	else if (stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25))) // festivals
	{
		stats->success = 0;

		field[6]->tile[52][42]->type = TILE_TYPE_MINI_SPEED_CHALLENGE;
		field[6]->tile[52][42]->growth = 1;

		field[6]->tile[63][42]->type = TILE_TYPE_MINI_TIMING_CHALLENGE;
		field[6]->tile[63][42]->growth = 1;


		field[6]->tile[77][29]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[77][29]->growth = 1;
		field[6]->tile[77][29]->style = 2;

		field[6]->tile[77][33]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[77][33]->growth = 1;
		field[6]->tile[77][33]->style = 2;

		field[6]->tile[75][29]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[75][29]->growth = 1;
		field[6]->tile[75][29]->style = 7;

		field[6]->tile[75][33]->type = TILE_TYPE_POTTED_HERB;
		field[6]->tile[75][33]->growth = 1;
		field[6]->tile[75][33]->style = 7;


		cast->actor[25]->type = ACTOR_TYPE_PARROT;
		cast->actor[25]->fx = 23.5f;
		cast->actor[25]->fy = 25.5f;
		cast->actor[25]->px = 23;
		cast->actor[25]->py = 25;
		cast->actor[25]->present_field = 0;
		cast->actor[25]->rx1 = 23.5f;
		cast->actor[25]->ry1 = 25.5f;
		cast->actor[25]->rx2 = 23.5f;
		cast->actor[25]->ry2 = 25.5f;
		cast->actor[25]->tx = 23.5f;
		cast->actor[25]->ty = 25.5f;
		cast->actor[25]->affection = 1;
		cast->actor[25]->rot = 0.0f;
		cast->actor[25]->primary_color[0] = 1.0f;
		cast->actor[25]->primary_color[1] = 1.0f;
		cast->actor[25]->primary_color[2] = 1.0f;
		cast->actor[25]->secondary_color[0] = 0.3f;
		cast->actor[25]->secondary_color[1] = 0.3f;
		cast->actor[25]->secondary_color[2] = 0.3f;
	}
	else
	{
		field[10]->tile[21][28]->type = TILE_TYPE_PATH;
		field[10]->tile[21][28]->growth = 0;
		field[10]->tile[21][28]->style = 1;
		
		field[10]->tile[23][28]->type = TILE_TYPE_PATH;
		field[10]->tile[23][28]->growth = 0;
		field[10]->tile[23][28]->style = 1;
		
		field[10]->tile[25][28]->type = TILE_TYPE_PATH;
		field[10]->tile[25][28]->growth = 0;
		field[10]->tile[25][28]->style = 1;

		field[10]->tile[27][28]->type = TILE_TYPE_PATH;
		field[10]->tile[27][28]->growth = 0;
		field[10]->tile[27][28]->style = 1;

		field[10]->tile[29][28]->type = TILE_TYPE_PATH;
		field[10]->tile[29][28]->growth = 0;
		field[10]->tile[29][28]->style = 1;

		field[10]->tile[31][28]->type = TILE_TYPE_PATH;
		field[10]->tile[31][28]->growth = 0;
		field[10]->tile[31][28]->style = 1;

		field[10]->tile[33][28]->type = TILE_TYPE_PATH;
		field[10]->tile[33][28]->growth = 0;
		field[10]->tile[33][28]->style = 1;
		
		field[10]->tile[35][28]->type = TILE_TYPE_PATH;
		field[10]->tile[35][28]->growth = 0;
		field[10]->tile[35][28]->style = 1;

		
		field[10]->tile[21][30]->type = TILE_TYPE_PATH;
		field[10]->tile[21][30]->growth = 0;
		field[10]->tile[21][30]->style = 1;
		
		field[10]->tile[23][30]->type = TILE_TYPE_PATH;
		field[10]->tile[23][30]->growth = 0;
		field[10]->tile[23][30]->style = 1;
		
		field[10]->tile[25][30]->type = TILE_TYPE_PATH;
		field[10]->tile[25][30]->growth = 0;
		field[10]->tile[25][30]->style = 1;

		field[10]->tile[27][30]->type = TILE_TYPE_PATH;
		field[10]->tile[27][30]->growth = 0;
		field[10]->tile[27][30]->style = 1;

		field[10]->tile[29][30]->type = TILE_TYPE_PATH;
		field[10]->tile[29][30]->growth = 0;
		field[10]->tile[29][30]->style = 1;

		field[10]->tile[31][30]->type = TILE_TYPE_PATH;
		field[10]->tile[31][30]->growth = 0;
		field[10]->tile[31][30]->style = 1;

		field[10]->tile[33][30]->type = TILE_TYPE_PATH;
		field[10]->tile[33][30]->growth = 0;
		field[10]->tile[33][30]->style = 1;
		
		field[10]->tile[35][30]->type = TILE_TYPE_PATH;
		field[10]->tile[35][30]->growth = 0;
		field[10]->tile[35][30]->style = 1;


		field[10]->tile[21][32]->type = TILE_TYPE_PATH;
		field[10]->tile[21][32]->growth = 0;
		field[10]->tile[21][32]->style = 1;
		
		field[10]->tile[23][32]->type = TILE_TYPE_PATH;
		field[10]->tile[23][32]->growth = 0;
		field[10]->tile[23][32]->style = 1;
		
		field[10]->tile[25][32]->type = TILE_TYPE_PATH;
		field[10]->tile[25][32]->growth = 0;
		field[10]->tile[25][32]->style = 1;

		field[10]->tile[27][32]->type = TILE_TYPE_PATH;
		field[10]->tile[27][32]->growth = 0;
		field[10]->tile[27][32]->style = 1;

		field[10]->tile[29][32]->type = TILE_TYPE_PATH;
		field[10]->tile[29][32]->growth = 0;
		field[10]->tile[29][32]->style = 1;

		field[10]->tile[31][32]->type = TILE_TYPE_PATH;
		field[10]->tile[31][32]->growth = 0;
		field[10]->tile[31][32]->style = 1;

		field[10]->tile[33][32]->type = TILE_TYPE_PATH;
		field[10]->tile[33][32]->growth = 0;
		field[10]->tile[33][32]->style = 1;
		
		field[10]->tile[35][32]->type = TILE_TYPE_PATH;
		field[10]->tile[35][32]->growth = 0;
		field[10]->tile[35][32]->style = 1;


		field[6]->tile[52][42]->type = TILE_TYPE_PATH;
		field[6]->tile[52][42]->growth = 0;
		field[6]->tile[52][42]->style = 0;		

		field[6]->tile[63][42]->type = TILE_TYPE_PATH;
		field[6]->tile[63][42]->growth = 0;
		field[6]->tile[63][42]->style = 0;

		
		field[10]->tile[26][32]->type = TILE_TYPE_PATH;
		field[10]->tile[26][32]->growth = 0;
		field[10]->tile[26][32]->style = 1;
		field[10]->tile[29][32]->type = TILE_TYPE_PATH;
		field[10]->tile[29][32]->growth = 0;
		field[10]->tile[29][32]->style = 1;

		
		field[6]->tile[77][29]->type = TILE_TYPE_PATH;
		field[6]->tile[77][29]->growth = 0;
		field[6]->tile[77][29]->style = 0;

		field[6]->tile[77][33]->type = TILE_TYPE_PATH;
		field[6]->tile[77][33]->growth = 0;
		field[6]->tile[77][33]->style = 0;

		field[6]->tile[75][29]->type = TILE_TYPE_PATH;
		field[6]->tile[75][29]->growth = 0;
		field[6]->tile[75][29]->style = 0;

		field[6]->tile[75][33]->type = TILE_TYPE_PATH;
		field[6]->tile[75][33]->growth = 0;
		field[6]->tile[75][33]->style = 0;


		cast->actor[25]->type = ACTOR_TYPE_PARROT;
		cast->actor[25]->present_field = -1;
	}

	if ((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
		(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25)))) // festivals
	{
		cast->actor[26]->type = ACTOR_TYPE_DAVID;
		cast->actor[26]->fx = 25.5f;
		cast->actor[26]->fy = 27.5f;
		cast->actor[26]->px = 25;
		cast->actor[26]->py = 27;
		cast->actor[26]->present_field = 10;
		cast->actor[26]->rx1 = 25.5f;
		cast->actor[26]->ry1 = 27.5f;
		cast->actor[26]->rx2 = 25.5f;
		cast->actor[26]->ry2 = 27.5f;
		cast->actor[26]->tx = 25.5f;
		cast->actor[26]->ty = 27.5f;
		cast->actor[26]->rot = 3.14159f / 2.0f;
		cast->actor[26]->animation_type = 19; // prayer

		cast->actor[26]->primary_color[1] = 0.5f;
		cast->actor[26]->secondary_color[0] = 1.0f;
		cast->actor[26]->secondary_color[1] = 1.0f;
		cast->actor[26]->secondary_color[2] = 1.0f;
		
		cast->actor[27]->type = ACTOR_TYPE_CLARA;
		cast->actor[27]->fx = 31.5f;
		cast->actor[27]->fy = 26.5f;
		cast->actor[27]->px = 31;
		cast->actor[27]->py = 26;
		cast->actor[27]->present_field = 10;
		cast->actor[27]->rx1 = 31.5f;
		cast->actor[27]->ry1 = 26.5f;
		cast->actor[27]->rx2 = 31.5f;
		cast->actor[27]->ry2 = 26.5f;
		cast->actor[27]->tx = 31.5f;
		cast->actor[27]->ty = 26.5f;
		cast->actor[27]->rot = 3.14159f / 2.0f;
		cast->actor[27]->animation_type = 19; // prayer

		cast->actor[27]->primary_color[0] = 0.5f;
		cast->actor[27]->secondary_color[0] = 1.0f;
		cast->actor[27]->secondary_color[1] = 1.0f;
		cast->actor[27]->secondary_color[2] = 1.0f;

		cast->actor[28]->type = ACTOR_TYPE_ANDREW;
		cast->actor[28]->fx = 22.5f;
		cast->actor[28]->fy = 34.5f;
		cast->actor[28]->px = 22;
		cast->actor[28]->py = 34;
		cast->actor[28]->present_field = 10;
		cast->actor[28]->rx1 = 22.5f;
		cast->actor[28]->ry1 = 34.5f;
		cast->actor[28]->rx2 = 22.5f;
		cast->actor[28]->ry2 = 34.5f;
		cast->actor[28]->tx = 22.5f;
		cast->actor[28]->ty = 34.5f;
		cast->actor[28]->rot = 3.14159f / 2.0f;
		cast->actor[28]->animation_type = 19; // prayer

		cast->actor[28]->primary_color[2] = 0.5f;
		cast->actor[28]->secondary_color[0] = 1.0f;
		cast->actor[28]->secondary_color[1] = 1.0f;
		cast->actor[28]->secondary_color[2] = 1.0f;
	
		cast->actor[29]->type = ACTOR_TYPE_EMILY;
		cast->actor[29]->fx = 29.5f;
		cast->actor[29]->fy = 30.5f;
		cast->actor[29]->px = 29;
		cast->actor[29]->py = 30;
		cast->actor[29]->present_field = 10;
		cast->actor[29]->rx1 = 29.5f;
		cast->actor[29]->ry1 = 30.5f;
		cast->actor[29]->rx2 = 29.5f;
		cast->actor[29]->ry2 = 30.5f;
		cast->actor[29]->tx = 29.5f;
		cast->actor[29]->ty = 30.5f;
		cast->actor[29]->rot = 3.14159f / 2.0f;
		cast->actor[29]->animation_type = 19; // prayer

		cast->actor[29]->primary_color[0] = 0.5f;
		cast->actor[29]->primary_color[2] = 0.5f;
		cast->actor[29]->secondary_color[0] = 1.0f;
		cast->actor[29]->secondary_color[1] = 1.0f;
		cast->actor[29]->secondary_color[2] = 1.0f;
	}
	else if ((stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) ||
		(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season)) // festivals
	{
		cast->actor[26]->type = ACTOR_TYPE_DAVID;
		cast->actor[26]->fx = 54.5f;
		cast->actor[26]->fy = 41.5f;
		cast->actor[26]->px = 54;
		cast->actor[26]->py = 41;
		cast->actor[26]->present_field = 6;
		cast->actor[26]->rx1 = 53.0f;
		cast->actor[26]->ry1 = 40.0f;
		cast->actor[26]->rx2 = 62.0f;
		cast->actor[26]->ry2 = 49.0f;
		cast->actor[26]->tx = 54.5f;
		cast->actor[26]->ty = 41.5f;
		cast->actor[26]->animation_type = 0;

		cast->actor[26]->primary_color[1] = 0.5f;
		cast->actor[26]->secondary_color[0] = 1.0f;
		cast->actor[26]->secondary_color[1] = 1.0f;
		cast->actor[26]->secondary_color[2] = 1.0f;
	
		cast->actor[27]->type = ACTOR_TYPE_CLARA;
		cast->actor[27]->fx = 61.5f;
		cast->actor[27]->fy = 41.5f;
		cast->actor[27]->px = 61;
		cast->actor[27]->py = 41;
		cast->actor[27]->present_field = 6;
		cast->actor[27]->rx1 = 53.0f;
		cast->actor[27]->ry1 = 40.0f;
		cast->actor[27]->rx2 = 62.0f;
		cast->actor[27]->ry2 = 49.0f;
		cast->actor[27]->tx = 54.5f;
		cast->actor[27]->ty = 41.5f;
		cast->actor[27]->animation_type = 0;

		cast->actor[27]->primary_color[0] = 0.5f;
		cast->actor[27]->secondary_color[0] = 1.0f;
		cast->actor[27]->secondary_color[1] = 1.0f;
		cast->actor[27]->secondary_color[2] = 1.0f;


		cast->actor[28]->type = ACTOR_TYPE_ANDREW;
		cast->actor[28]->fx = 54.5f;
		cast->actor[28]->fy = 48.5f;
		cast->actor[28]->px = 54;
		cast->actor[28]->py = 48;
		cast->actor[28]->present_field = 6;
		cast->actor[28]->rx1 = 53.0f;
		cast->actor[28]->ry1 = 40.0f;
		cast->actor[28]->rx2 = 62.0f;
		cast->actor[28]->ry2 = 49.0f;
		cast->actor[28]->tx = 54.5f;
		cast->actor[28]->ty = 48.5f;
		cast->actor[28]->animation_type = 0;

		cast->actor[28]->primary_color[2] = 0.5f;
		cast->actor[28]->secondary_color[0] = 1.0f;
		cast->actor[28]->secondary_color[1] = 1.0f;
		cast->actor[28]->secondary_color[2] = 1.0f;
	
		cast->actor[29]->type = ACTOR_TYPE_EMILY;
		cast->actor[29]->fx = 61.5f;
		cast->actor[29]->fy = 48.5f;
		cast->actor[29]->px = 61;
		cast->actor[29]->py = 48;
		cast->actor[29]->present_field = 6;
		cast->actor[29]->rx1 = 53.0f;
		cast->actor[29]->ry1 = 40.0f;
		cast->actor[29]->rx2 = 62.0f;
		cast->actor[29]->ry2 = 49.0f;
		cast->actor[29]->tx = 54.5f;
		cast->actor[29]->ty = 48.5f;
		cast->actor[29]->animation_type = 0;

		cast->actor[29]->primary_color[0] = 0.5f;
		cast->actor[29]->primary_color[2] = 0.5f;
		cast->actor[29]->secondary_color[0] = 1.0f;
		cast->actor[29]->secondary_color[1] = 1.0f;
		cast->actor[29]->secondary_color[2] = 1.0f;
	}
	else // normal days
	{
		if (stats->day_of_week == 1) // Sunday
		{
			cast->actor[26]->type = ACTOR_TYPE_DAVID;
			cast->actor[26]->fx = 25.5f;
			cast->actor[26]->fy = 27.5f;
			cast->actor[26]->px = 25;
			cast->actor[26]->py = 27;
			cast->actor[26]->present_field = 10;
			cast->actor[26]->rx1 = 25.5f;
			cast->actor[26]->ry1 = 27.5f;
			cast->actor[26]->rx2 = 25.5f;
			cast->actor[26]->ry2 = 27.5f;
			cast->actor[26]->tx = 25.5f;
			cast->actor[26]->ty = 27.5f;
			cast->actor[26]->rot = 3.14159f / 2.0f;
			cast->actor[26]->animation_type = 19; // prayer

			cast->actor[26]->primary_color[1] = 0.5f;
			cast->actor[26]->secondary_color[0] = 1.0f;
			cast->actor[26]->secondary_color[1] = 1.0f;
			cast->actor[26]->secondary_color[2] = 1.0f;
		
			cast->actor[27]->type = ACTOR_TYPE_CLARA;
			cast->actor[27]->fx = 31.5f;
			cast->actor[27]->fy = 26.5f;
			cast->actor[27]->px = 31;
			cast->actor[27]->py = 26;
			cast->actor[27]->present_field = 10;
			cast->actor[27]->rx1 = 31.5f;
			cast->actor[27]->ry1 = 26.5f;
			cast->actor[27]->rx2 = 31.5f;
			cast->actor[27]->ry2 = 26.5f;
			cast->actor[27]->tx = 31.5f;
			cast->actor[27]->ty = 26.5f;
			cast->actor[27]->rot = 3.14159f / 2.0f;
			cast->actor[27]->animation_type = 19; // prayer

			cast->actor[27]->primary_color[0] = 0.5f;
			cast->actor[27]->secondary_color[0] = 1.0f;
			cast->actor[27]->secondary_color[1] = 1.0f;
			cast->actor[27]->secondary_color[2] = 1.0f;

			cast->actor[28]->type = ACTOR_TYPE_ANDREW;
			cast->actor[28]->fx = 22.5f;
			cast->actor[28]->fy = 34.5f;
			cast->actor[28]->px = 22;
			cast->actor[28]->py = 34;
			cast->actor[28]->present_field = 10;
			cast->actor[28]->rx1 = 22.5f;
			cast->actor[28]->ry1 = 34.5f;
			cast->actor[28]->rx2 = 22.5f;
			cast->actor[28]->ry2 = 34.5f;
			cast->actor[28]->tx = 22.5f;
			cast->actor[28]->ty = 34.5f;
			cast->actor[28]->rot = 3.14159f / 2.0f;
			cast->actor[28]->animation_type = 19; // prayer

			cast->actor[28]->primary_color[2] = 0.5f;
			cast->actor[28]->secondary_color[0] = 1.0f;
			cast->actor[28]->secondary_color[1] = 1.0f;
			cast->actor[28]->secondary_color[2] = 1.0f;
	
			cast->actor[29]->type = ACTOR_TYPE_EMILY;
			cast->actor[29]->fx = 29.5f;
			cast->actor[29]->fy = 30.5f;
			cast->actor[29]->px = 29;
			cast->actor[29]->py = 30;
			cast->actor[29]->present_field = 10;
			cast->actor[29]->rx1 = 29.5f;
			cast->actor[29]->ry1 = 30.5f;
			cast->actor[29]->rx2 = 29.5f;
			cast->actor[29]->ry2 = 30.5f;
			cast->actor[29]->tx = 29.5f;
			cast->actor[29]->ty = 30.5f;
			cast->actor[29]->rot = 3.14159f / 2.0f;
			cast->actor[29]->animation_type = 19; // prayer

			cast->actor[29]->primary_color[0] = 0.5f;
			cast->actor[29]->primary_color[2] = 0.5f;
			cast->actor[29]->secondary_color[0] = 1.0f;
			cast->actor[29]->secondary_color[1] = 1.0f;
			cast->actor[29]->secondary_color[2] = 1.0f;
		}
		else if (stats->weather == 1) // Rainy
		{
			cast->actor[26]->type = ACTOR_TYPE_DAVID;
			cast->actor[26]->fx = 24.5f;
			cast->actor[26]->fy = 30.5f;
			cast->actor[26]->px = 24;
			cast->actor[26]->py = 30;
			cast->actor[26]->present_field = 10;
			cast->actor[26]->rx1 = 24.5f;
			cast->actor[26]->ry1 = 30.5f;
			cast->actor[26]->rx2 = 24.5f;
			cast->actor[26]->ry2 = 30.5f;
			cast->actor[26]->tx = 24.5f;
			cast->actor[26]->ty = 30.5f;
			cast->actor[26]->rot = 0.0f;
			cast->actor[26]->animation_type = 1; // sitting

			cast->actor[26]->primary_color[1] = 0.5f;
			cast->actor[26]->secondary_color[0] = 1.0f;
			cast->actor[26]->secondary_color[1] = 1.0f;
			cast->actor[26]->secondary_color[2] = 1.0f;
		
			cast->actor[27]->type = ACTOR_TYPE_CLARA;
			cast->actor[27]->fx = 35.5f;
			cast->actor[27]->fy = 26.5f;
			cast->actor[27]->px = 35;
			cast->actor[27]->py = 26;
			cast->actor[27]->present_field = 10;
			cast->actor[27]->rx1 = 35.5f;
			cast->actor[27]->ry1 = 26.5f;
			cast->actor[27]->rx2 = 35.5f;
			cast->actor[27]->ry2 = 26.5f;
			cast->actor[27]->tx = 35.5f;
			cast->actor[27]->ty = 26.5f;
			cast->actor[27]->rot = 3.14159f;
			cast->actor[27]->animation_type = 1; // sitting

			cast->actor[27]->primary_color[0] = 0.5f;
			cast->actor[27]->secondary_color[0] = 1.0f;
			cast->actor[27]->secondary_color[1] = 1.0f;
			cast->actor[27]->secondary_color[2] = 1.0f;

			cast->actor[28]->type = ACTOR_TYPE_ANDREW;
			cast->actor[28]->fx = 25.5f;
			cast->actor[28]->fy = 29.5f;
			cast->actor[28]->px = 25;
			cast->actor[28]->py = 29;
			cast->actor[28]->present_field = 10;
			cast->actor[28]->rx1 = 25.5f;
			cast->actor[28]->ry1 = 29.5f;
			cast->actor[28]->rx2 = 25.5f;
			cast->actor[28]->ry2 = 29.5f;
			cast->actor[28]->tx = 25.5f;
			cast->actor[28]->ty = 29.5f;
			cast->actor[28]->rot = 3.0f * 3.14159f / 2.0f;
			cast->actor[28]->animation_type = 1; // sitting

			cast->actor[28]->primary_color[2] = 0.5f;
			cast->actor[28]->secondary_color[0] = 1.0f;
			cast->actor[28]->secondary_color[1] = 1.0f;
			cast->actor[28]->secondary_color[2] = 1.0f;
	
			cast->actor[29]->type = ACTOR_TYPE_EMILY;
			cast->actor[29]->fx = 34.5f;
			cast->actor[29]->fy = 25.5f;
			cast->actor[29]->px = 34;
			cast->actor[29]->py = 25;
			cast->actor[29]->present_field = 10;
			cast->actor[29]->rx1 = 34.5f;
			cast->actor[29]->ry1 = 25.5f;
			cast->actor[29]->rx2 = 34.5f;
			cast->actor[29]->ry2 = 25.5f;
			cast->actor[29]->tx = 34.5f;
			cast->actor[29]->ty = 25.5f;
			cast->actor[29]->rot = 3.0f * 3.14159f / 2.0f;
			cast->actor[29]->animation_type = 1; // sitting

			cast->actor[29]->primary_color[0] = 0.5f;
			cast->actor[29]->primary_color[2] = 0.5f;
			cast->actor[29]->secondary_color[0] = 1.0f;
			cast->actor[29]->secondary_color[1] = 1.0f;
			cast->actor[29]->secondary_color[2] = 1.0f;
		}
		else
		{
			// David
			//	Saturday - Town Square
			//	Spring - Tool Shop
			//	Summer - Town outside Tool Shop
			//	Fall - Church
			//	Winter - Cave
			
			// Clara
			//	Saturday - Mountainside
			//	Spring - Plant Shop
			//	Summer - Mountainside
			//	Fall - Town outside Plant Shop
			//	Winter - Church
		
			// Andrew
			//	Saturday - Town Square
			//	Spring - Mountainside
			//	Summer - Church
			//	Fall - Intersection
			//	Winter - Town Entrance
			
			// Emily
			//	Saturday - Mountainside
			//	Spring - Church
			//	Summer - Town outside Church
			//	Fall - Town Square
			//	Winter - Fishery

			if (stats->day_of_week == 7) // Saturday
			{
				cast->actor[26]->type = ACTOR_TYPE_DAVID;
				cast->actor[26]->fx = 54.5f;
				cast->actor[26]->fy = 41.5f;
				cast->actor[26]->px = 54;
				cast->actor[26]->py = 41;
				cast->actor[26]->present_field = 6;
				cast->actor[26]->rx1 = 53.0f;
				cast->actor[26]->ry1 = 40.0f;
				cast->actor[26]->rx2 = 62.0f;
				cast->actor[26]->ry2 = 49.0f;
				cast->actor[26]->tx = 54.5f;
				cast->actor[26]->ty = 41.5f;
				cast->actor[26]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[26]->animation_type = 0; // walking

				cast->actor[26]->primary_color[1] = 0.5f;
				cast->actor[26]->secondary_color[0] = 1.0f;
				cast->actor[26]->secondary_color[1] = 1.0f;
				cast->actor[26]->secondary_color[2] = 1.0f;

				cast->actor[27]->type = ACTOR_TYPE_CLARA;
				cast->actor[27]->fx = 30.5f;
				cast->actor[27]->fy = 40.5f;
				cast->actor[27]->px = 30;
				cast->actor[27]->py = 40;
				cast->actor[27]->present_field = 4;
				cast->actor[27]->rx1 = 20.5f;
				cast->actor[27]->ry1 = 32.5f;
				cast->actor[27]->rx2 = 40.5f;
				cast->actor[27]->ry2 = 59.5f;
				cast->actor[27]->tx = 30.5f;
				cast->actor[27]->ty = 40.5f;
				cast->actor[27]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[27]->animation_type = 0; // walking
	
				cast->actor[27]->primary_color[0] = 0.5f;
				cast->actor[27]->secondary_color[0] = 1.0f;
				cast->actor[27]->secondary_color[1] = 1.0f;
				cast->actor[27]->secondary_color[2] = 1.0f;
	
				cast->actor[28]->type = ACTOR_TYPE_ANDREW;
				cast->actor[28]->fx = 54.5f;
				cast->actor[28]->fy = 48.5f;
				cast->actor[28]->px = 54;
				cast->actor[28]->py = 48;
				cast->actor[28]->present_field = 6;
				cast->actor[28]->rx1 = 53.0f;
				cast->actor[28]->ry1 = 40.0f;
				cast->actor[28]->rx2 = 62.0f;
				cast->actor[28]->ry2 = 49.0f;
				cast->actor[28]->tx = 54.5f;
				cast->actor[28]->ty = 48.5f;
				cast->actor[28]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[28]->animation_type = 0; // walking
		
				cast->actor[28]->primary_color[2] = 0.5f;
				cast->actor[28]->secondary_color[0] = 1.0f;
				cast->actor[28]->secondary_color[1] = 1.0f;
				cast->actor[28]->secondary_color[2] = 1.0f;

				cast->actor[29]->type = ACTOR_TYPE_EMILY;
				cast->actor[29]->fx = 25.5f;
				cast->actor[29]->fy = 40.5f;
				cast->actor[29]->px = 25;
				cast->actor[29]->py = 40;
				cast->actor[29]->present_field = 4;
				cast->actor[29]->rx1 = 20.5f;
				cast->actor[29]->ry1 = 32.5f;
				cast->actor[29]->rx2 = 40.5f;
				cast->actor[29]->ry2 = 59.5f;
				cast->actor[29]->tx = 25.5f;
				cast->actor[29]->ty = 40.5f;
				cast->actor[29]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[29]->animation_type = 0; // walking
	
				cast->actor[29]->primary_color[0] = 0.5f;
				cast->actor[29]->secondary_color[0] = 1.0f;
				cast->actor[29]->secondary_color[1] = 1.0f;
				cast->actor[29]->secondary_color[2] = 1.0f;
			}
			else if (stats->season == 1) // Spring weekdays
			{
				cast->actor[26]->type = ACTOR_TYPE_DAVID;
				cast->actor[26]->fx = 27.5f;
				cast->actor[26]->fy = 28.5f;
				cast->actor[26]->px = 27;
				cast->actor[26]->py = 28;
				cast->actor[26]->present_field = 8;
				cast->actor[26]->rx1 = 27.5f;
				cast->actor[26]->ry1 = 28.5f;
				cast->actor[26]->rx2 = 27.5f;
				cast->actor[26]->ry2 = 28.5f;
				cast->actor[26]->tx = 27.5f;
				cast->actor[26]->ty = 28.5f;
				cast->actor[26]->rot = 3.14159f;
				cast->actor[26]->animation_type = 0; // standing
	
				cast->actor[26]->primary_color[1] = 0.5f;
				cast->actor[26]->secondary_color[0] = 1.0f;
				cast->actor[26]->secondary_color[1] = 1.0f;
				cast->actor[26]->secondary_color[2] = 1.0f;
			
				cast->actor[27]->type = ACTOR_TYPE_CLARA;
				cast->actor[27]->fx = 20.5f;
				cast->actor[27]->fy = 25.5f;
				cast->actor[27]->px = 20;
				cast->actor[27]->py = 25;
				cast->actor[27]->present_field = 7;
				cast->actor[27]->rx1 = 20.5f;
				cast->actor[27]->ry1 = 25.5f;
				cast->actor[27]->rx2 = 25.5f;
				cast->actor[27]->ry2 = 29.5f;
				cast->actor[27]->tx = 20.5f;
				cast->actor[27]->ty = 25.5f;
				cast->actor[27]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[27]->animation_type = 0; // walking
	
				cast->actor[27]->primary_color[0] = 0.5f;
				cast->actor[27]->secondary_color[0] = 1.0f;
				cast->actor[27]->secondary_color[1] = 1.0f;
				cast->actor[27]->secondary_color[2] = 1.0f;
	
				cast->actor[28]->type = ACTOR_TYPE_ANDREW;
				cast->actor[28]->fx = 30.5f;
				cast->actor[28]->fy = 31.5f;
				cast->actor[28]->px = 30;
				cast->actor[28]->py = 31;
				cast->actor[28]->present_field = 4;
				cast->actor[28]->rx1 = 30.5f;
				cast->actor[28]->ry1 = 31.5f;
				cast->actor[28]->rx2 = 30.5f;
				cast->actor[28]->ry2 = 31.5f;
				cast->actor[28]->tx = 30.5f;
				cast->actor[28]->ty = 31.5f;
				cast->actor[28]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[28]->animation_type = 1; // sitting
	
				cast->actor[28]->primary_color[2] = 0.5f;
				cast->actor[28]->secondary_color[0] = 1.0f;
				cast->actor[28]->secondary_color[1] = 1.0f;
				cast->actor[28]->secondary_color[2] = 1.0f;
		
				cast->actor[29]->type = ACTOR_TYPE_EMILY;
				cast->actor[29]->fx = 20.5f;
				cast->actor[29]->fy = 24.5f;
				cast->actor[29]->px = 20;
				cast->actor[29]->py = 24;
				cast->actor[29]->present_field = 10;
				cast->actor[29]->rx1 = 20.5f;
				cast->actor[29]->ry1 = 24.5f;
				cast->actor[29]->rx2 = 20.5f;
				cast->actor[29]->ry2 = 24.5f;
				cast->actor[29]->tx = 20.5f;
				cast->actor[29]->ty = 24.5f;
				cast->actor[29]->rot = 0.0f;
				cast->actor[29]->animation_type = 1; // sitting
	
				cast->actor[29]->primary_color[0] = 0.5f;
				cast->actor[29]->primary_color[2] = 0.5f;
				cast->actor[29]->secondary_color[0] = 1.0f;
				cast->actor[29]->secondary_color[1] = 1.0f;
				cast->actor[29]->secondary_color[2] = 1.0f;
			}
			else if (stats->season == 2) // Summer weekdays
			{
				cast->actor[26]->type = ACTOR_TYPE_DAVID;
				cast->actor[26]->fx = 70.5f;
				cast->actor[26]->fy = 47.5f;
				cast->actor[26]->px = 70;
				cast->actor[26]->py = 47;
				cast->actor[26]->present_field = 6;
				cast->actor[26]->rx1 = 70.5f;
				cast->actor[26]->ry1 = 47.5f;
				cast->actor[26]->rx2 = 79.5f;
				cast->actor[26]->ry2 = 49.5f;
				cast->actor[26]->tx = 70.5f;
				cast->actor[26]->ty = 47.5f;
				cast->actor[26]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[26]->animation_type = 0; // walking
	
				cast->actor[26]->primary_color[1] = 0.5f;
				cast->actor[26]->secondary_color[0] = 1.0f;
				cast->actor[26]->secondary_color[1] = 1.0f;
				cast->actor[26]->secondary_color[2] = 1.0f;
			
				cast->actor[27]->type = ACTOR_TYPE_CLARA;
				cast->actor[27]->fx = 30.5f;
				cast->actor[27]->fy = 40.5f;
				cast->actor[27]->px = 30;
				cast->actor[27]->py = 40;
				cast->actor[27]->present_field = 4;
				cast->actor[27]->rx1 = 20.5f;
				cast->actor[27]->ry1 = 32.5f;
				cast->actor[27]->rx2 = 40.5f;
				cast->actor[27]->ry2 = 59.5f;
				cast->actor[27]->tx = 30.5f;
				cast->actor[27]->ty = 40.5f;
				cast->actor[27]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[27]->animation_type = 0; // walking
	
				cast->actor[27]->primary_color[0] = 0.5f;
				cast->actor[27]->secondary_color[0] = 1.0f;
				cast->actor[27]->secondary_color[1] = 1.0f;
				cast->actor[27]->secondary_color[2] = 1.0f;

				cast->actor[28]->type = ACTOR_TYPE_ANDREW;
				cast->actor[28]->fx = 30.5f;
				cast->actor[28]->fy = 26.5f;
				cast->actor[28]->px = 20;
				cast->actor[28]->py = 26;
				cast->actor[28]->present_field = 10;
				cast->actor[28]->rx1 = 20.5f;
				cast->actor[28]->ry1 = 26.5f;
				cast->actor[28]->rx2 = 36.5f;
				cast->actor[28]->ry2 = 47.5f;
				cast->actor[28]->tx = 30.5f;
				cast->actor[28]->ty = 26.5f;
				cast->actor[28]->rot = 3.14159f / 2.0f;
				cast->actor[28]->animation_type = 0; // walking

				cast->actor[28]->primary_color[2] = 0.5f;
				cast->actor[28]->secondary_color[0] = 1.0f;
				cast->actor[28]->secondary_color[1] = 1.0f;
				cast->actor[28]->secondary_color[2] = 1.0f;

				cast->actor[29]->type = ACTOR_TYPE_EMILY;
				cast->actor[29]->fx = 25.5f;
				cast->actor[29]->fy = 40.5f;
				cast->actor[29]->px = 25;
				cast->actor[29]->py = 40;
				cast->actor[29]->present_field = 6;
				cast->actor[29]->rx1 = 25.5f;
				cast->actor[29]->ry1 = 40.5f;
				cast->actor[29]->rx2 = 45.5f;
				cast->actor[29]->ry2 = 49.5f;
				cast->actor[29]->tx = 25.5f;
				cast->actor[29]->ty = 40.5f;
				cast->actor[29]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[29]->animation_type = 0; // walking
	
				cast->actor[29]->primary_color[0] = 0.5f;
				cast->actor[29]->primary_color[2] = 0.5f;
				cast->actor[29]->secondary_color[0] = 1.0f;
				cast->actor[29]->secondary_color[1] = 1.0f;
				cast->actor[29]->secondary_color[2] = 1.0f;
			}
			else if (stats->season == 3) // Fall weekdays
			{
				cast->actor[26]->type = ACTOR_TYPE_DAVID;
				cast->actor[26]->fx = 30.5f;
				cast->actor[26]->fy = 24.5f;
				cast->actor[26]->px = 30;
				cast->actor[26]->py = 24;
				cast->actor[26]->present_field = 10;
				cast->actor[26]->rx1 = 30.5f;
				cast->actor[26]->ry1 = 24.5f;
				cast->actor[26]->rx2 = 30.5f;
				cast->actor[26]->ry2 = 24.5f;
				cast->actor[26]->tx = 30.5f;
				cast->actor[26]->ty = 24.5f;
				cast->actor[26]->rot = 3.14159f / 2.0f;
				cast->actor[26]->animation_type = 0; // standing

				cast->actor[26]->primary_color[1] = 0.5f;
				cast->actor[26]->secondary_color[0] = 1.0f;
				cast->actor[26]->secondary_color[1] = 1.0f;
				cast->actor[26]->secondary_color[2] = 1.0f;
			
				cast->actor[27]->type = ACTOR_TYPE_CLARA;
				cast->actor[27]->fx = 60.5f;
				cast->actor[27]->fy = 26.5f;
				cast->actor[27]->px = 60;
				cast->actor[27]->py = 26;
				cast->actor[27]->present_field = 6;
				cast->actor[27]->rx1 = 60.5f;
				cast->actor[27]->ry1 = 26.5f;
				cast->actor[27]->rx2 = 74.5f;
				cast->actor[27]->ry2 = 28.5f;
				cast->actor[27]->tx = 60.5f;
				cast->actor[27]->ty = 26.5f;
				cast->actor[27]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[27]->animation_type = 0; // walking
	
				cast->actor[27]->primary_color[0] = 0.5f;
				cast->actor[27]->secondary_color[0] = 1.0f;
				cast->actor[27]->secondary_color[1] = 1.0f;
				cast->actor[27]->secondary_color[2] = 1.0f;
	
				cast->actor[28]->type = ACTOR_TYPE_ANDREW;
				cast->actor[28]->fx = 22.5f;
				cast->actor[28]->fy = 26.5f;
				cast->actor[28]->px = 22;
				cast->actor[28]->py = 26;
				cast->actor[28]->present_field = 3;
				cast->actor[28]->rx1 = 22.5f;
				cast->actor[28]->ry1 = 26.5f;
				cast->actor[28]->rx2 = 28.5f;
				cast->actor[28]->ry2 = 29.5f;
				cast->actor[28]->tx = 22.5f;
				cast->actor[28]->ty = 26.5f;
				cast->actor[28]->rot = 0.0f;
				cast->actor[28]->animation_type = 0; // walking

				cast->actor[28]->primary_color[2] = 0.5f;
				cast->actor[28]->secondary_color[0] = 1.0f;
				cast->actor[28]->secondary_color[1] = 1.0f;
				cast->actor[28]->secondary_color[2] = 1.0f;
		
				cast->actor[29]->type = ACTOR_TYPE_EMILY;	
				cast->actor[29]->fx = 61.5f;
				cast->actor[29]->fy = 48.5f;
				cast->actor[29]->px = 61;
				cast->actor[29]->py = 48;
				cast->actor[29]->present_field = 6;
				cast->actor[29]->rx1 = 53.0f;
				cast->actor[29]->ry1 = 40.0f;
				cast->actor[29]->rx2 = 62.0f;
				cast->actor[29]->ry2 = 49.0f;
				cast->actor[29]->tx = 54.5f;
				cast->actor[29]->ty = 48.5f;
				cast->actor[29]->rot = 3.0f * 3.14159f / 2.0f;
				cast->actor[29]->animation_type = 0; // walking

				cast->actor[29]->primary_color[0] = 0.5f;
				cast->actor[29]->primary_color[2] = 0.5f;
				cast->actor[29]->secondary_color[0] = 1.0f;
				cast->actor[29]->secondary_color[1] = 1.0f;
				cast->actor[29]->secondary_color[2] = 1.0f;
			}
			else if (stats->season == 4) // Winter weekdays
			{
				cast->actor[26]->type = ACTOR_TYPE_DAVID;
				cast->actor[26]->fx = 25.5f;
				cast->actor[26]->fy = 47.5f;
				cast->actor[26]->px = 25;
				cast->actor[26]->py = 47;
				cast->actor[26]->present_field = 5;
				cast->actor[26]->rx1 = 25.5f;
				cast->actor[26]->ry1 = 47.5f;
				cast->actor[26]->rx2 = 25.5f;
				cast->actor[26]->ry2 = 47.5f;
				cast->actor[26]->tx = 25.5f;
				cast->actor[26]->ty = 47.5f;
				cast->actor[26]->rot = 3.14159f / 2.0f;
				cast->actor[26]->animation_type = 0; // standing

				cast->actor[26]->primary_color[1] = 0.5f;
				cast->actor[26]->secondary_color[0] = 1.0f;
				cast->actor[26]->secondary_color[1] = 1.0f;
				cast->actor[26]->secondary_color[2] = 1.0f;

				cast->actor[27]->type = ACTOR_TYPE_CLARA;
				cast->actor[27]->fx = 30.5f;
				cast->actor[27]->fy = 24.5f;
				cast->actor[27]->px = 30;
				cast->actor[27]->py = 24;
				cast->actor[27]->present_field = 10;
				cast->actor[27]->rx1 = 30.5f;
				cast->actor[27]->ry1 = 24.5f;
				cast->actor[27]->rx2 = 30.5f;
				cast->actor[27]->ry2 = 24.5f;
				cast->actor[27]->tx = 30.5f;
				cast->actor[27]->ty = 24.5f;
				cast->actor[27]->rot = 3.14159f / 2.0f;
				cast->actor[27]->animation_type = 0; // standing
	
				cast->actor[27]->primary_color[0] = 0.5f;
				cast->actor[27]->secondary_color[0] = 1.0f;
				cast->actor[27]->secondary_color[1] = 1.0f;
				cast->actor[27]->secondary_color[2] = 1.0f;
	
				cast->actor[28]->type = ACTOR_TYPE_ANDREW;
				cast->actor[28]->fx = 70.5f;
				cast->actor[28]->fy = 30.5f;
				cast->actor[28]->px = 70;
				cast->actor[28]->py = 30;
				cast->actor[28]->present_field = 6;
				cast->actor[28]->rx1 = 70.5f;
				cast->actor[28]->ry1 = 30.5f;
				cast->actor[28]->rx2 = 73.5f;
				cast->actor[28]->ry2 = 33.5f;
				cast->actor[28]->tx = 70.5f;
				cast->actor[28]->ty = 30.5f;
				cast->actor[28]->rot = 3.14159f / 2.0f;
				cast->actor[28]->animation_type = 0; // walking
	
				cast->actor[28]->primary_color[2] = 0.5f;
				cast->actor[28]->secondary_color[0] = 1.0f;
				cast->actor[28]->secondary_color[1] = 1.0f;
				cast->actor[28]->secondary_color[2] = 1.0f;
		
				cast->actor[29]->type = ACTOR_TYPE_EMILY;
				cast->actor[29]->fx = 25.5f;
				cast->actor[29]->fy = 28.5f;
				cast->actor[29]->px = 25;
				cast->actor[29]->py = 28;
				cast->actor[29]->present_field = 9;
				cast->actor[29]->rx1 = 25.5f;
				cast->actor[29]->ry1 = 28.5f;
				cast->actor[29]->rx2 = 25.5f;
				cast->actor[29]->ry2 = 28.5f;
				cast->actor[29]->tx = 25.5f;
				cast->actor[29]->ty = 28.5f;
				cast->actor[29]->rot = 3.14159f / 2.0f;
				cast->actor[29]->animation_type = 0; // standing
	
				cast->actor[29]->primary_color[0] = 0.5f;
				cast->actor[29]->primary_color[2] = 0.5f;
				cast->actor[29]->secondary_color[0] = 1.0f;
				cast->actor[29]->secondary_color[1] = 1.0f;
				cast->actor[29]->secondary_color[2] = 1.0f;
			}
		}
	}

	return;
};

void Controls(_Field **field, int total_fields, _Inventory *inventory, _Cast *cast, _Stats *stats, int frames_multiplier)
{
	float character_speed = 0.05f * (float)frames_multiplier;
	float character_radius = 0.35f;

	float mx = 0.0f, my = 0.0f;

	int tx, ty;

	bool test;

	int min_place, min_value;

	if (stats->animation_type >= 4 && stats->animation_type != 12)
	{
		if (stats->animation_type < 17) stats->animation_timer += 0.2f * (float)frames_multiplier;
		else if (stats->animation_type == 17) stats->animation_timer += 0.1f * (float)frames_multiplier;

		if ((stats->animation_type != 8 && stats->animation_type < 17 && stats->animation_timer >= 3.0f * 3.14159f / 2.0f) ||
			(stats->animation_type == 8 && stats->animation_timer >= 3.14159f) ||
			(stats->animation_type == 17 && stats->animation_timer >= 32.0f * 3.14159f))
		{
			if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_HOE && stats->animation_type == 4)
			{
				if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
				{
					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DIRT ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TILLED ||
						(field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 30) ||
						(field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 9) ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH ||					
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUT_RYE)
					{
						if (rand() % 100 < 5) 
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_ROCK;
			
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 5;
							field[stats->current_field]->tile[stats->dx][stats->dy]->style = rand() % 3;
						}
						else
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_TILLED;
			
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CRYSTAL)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth += 1;
	
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 0)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXPOSED_CRYSTAL;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 5;
							field[stats->current_field]->tile[stats->dx][stats->dy]->style = rand() % 3;
						}
					}
				}
			}
			else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_HAMMER && stats->animation_type == 5) 
			{
				if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
				{
					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ROCK)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth -= 1;
		
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= 0)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
						}
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ORE)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth -= 1;
		
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= 0)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_BROKEN_ORE;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;
						}
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXPOSED_CRYSTAL)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth -= 1;
		
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= 0)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_BROKEN_CRYSTAL;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;
						}
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TILLED)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
		
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
					}
				}
			}
			else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_SCYTHE && stats->animation_type == 6)
			{
				if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
				{
					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 30)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_CUT_RYE;
						
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE && 
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= -9)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;

						stats->feed++;
					}
					else if ((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 30) ||
						((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WEED ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION) &&
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth > 0))
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;

						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
					}
				}
			}
			else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_WATERING_CAN && stats->animation_type == 7)
			{
				if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
				{
					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WATER_GENERATOR) 
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth > (25 - inventory->tool[stats->current_tool]->quantity))
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth -= (25 - inventory->tool[stats->current_tool]->quantity);
					
							inventory->tool[stats->current_tool]->quantity = 25;
						}
						else
						{
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth == 1)
							{
								if (inventory->tool[stats->current_tool]->quantity == 0) inventory->tool[stats->current_tool]->quantity = 1;
							}
							else
							{
								inventory->tool[stats->current_tool]->quantity += field[stats->current_field]->tile[stats->dx][stats->dy]->growth;

								field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;
							}
						}
					}
					else if (inventory->tool[stats->current_tool]->quantity > 0)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->water = 1;
						
						inventory->tool[stats->current_tool]->quantity--;
					}	
				}
			}
			else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_HOE && stats->animation_type == 13)
			{
				if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
				{
					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DIRT ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TILLED ||
						(field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 30) ||
						(field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 9) ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH ||					
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUT_RYE)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_TILLED;
			
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CRYSTAL)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXPOSED_CRYSTAL;

						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 5;
						field[stats->current_field]->tile[stats->dx][stats->dy]->style = rand() % 3;
					}
				}
			}
			else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_HAMMER && stats->animation_type == 14) 
			{
				if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
				{
					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ROCK)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
		
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ORE)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;
		
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_BROKEN_ORE;
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXPOSED_CRYSTAL)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;
		
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_BROKEN_CRYSTAL;
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TILLED)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
		
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
					}
				}
			}
			else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_SCYTHE && stats->animation_type == 15)
			{
				if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
				{
					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 30)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_CUT_RYE;
						
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
					}
					else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE && 
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= -9)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;

						stats->feed++;
					}
					else if ((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 30) ||
						((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WEED ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP ||
						field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION) &&
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth > 0))
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;

						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
					}
				}
				
				if (stats->dx == stats->px)
				{
					stats->dx -= 1;

					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 30)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_CUT_RYE;
						
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= -9)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
	
							stats->feed++;
						}
						else if ((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 30) ||
							((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WEED ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION) &&
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth > 0))
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
					}

					stats->dx += 2;

					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 30)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_CUT_RYE;
						
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= -9)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
	
							stats->feed++;
						}
						else if ((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 30) ||
							((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WEED ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION) &&
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth > 0))
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
					}

					stats->dx -= 1;
				}
				else if (stats->dy == stats->py)
				{
					stats->dy -= 1;

					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 30)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_CUT_RYE;
						
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= -9)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
	
							stats->feed++;
						}
						else if ((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 30) ||
							((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WEED ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION) &&
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth > 0))
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
					}

					stats->dy += 2;

					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 30)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_CUT_RYE;
						
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= -9)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
	
							stats->feed++;
						}
						else if ((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RYE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth < 30) ||
							((field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WEED ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP ||
							field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION) &&
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth > 0))
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
						}
					}

					stats->dy -= 1;
				}
			}
			else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_WATERING_CAN && stats->animation_type == 16)
			{
				tx = stats->dx;
				ty = stats->dy;

				for (int i=-1; i<=1; i++)	
				{
					for (int j=-1; j<=1; j++)
					{
						stats->dx = stats->px+i;
						stats->dy = stats->py+j;

						if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
						{
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WATER_GENERATOR) 
							{
								if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth > (45 - inventory->tool[stats->current_tool]->quantity))
								{
									field[stats->current_field]->tile[stats->dx][stats->dy]->growth -= (45 - inventory->tool[stats->current_tool]->quantity);
						
									inventory->tool[stats->current_tool]->quantity = 45;
								}
								else
								{
									if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth == 1)
									{
										if (inventory->tool[stats->current_tool]->quantity == 0) inventory->tool[stats->current_tool]->quantity = 1;
									}
									else
									{
										inventory->tool[stats->current_tool]->quantity += field[stats->current_field]->tile[stats->dx][stats->dy]->growth;
		
										field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;
									}
								}
							}
							else if (inventory->tool[stats->current_tool]->quantity > 0)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->water = 1;
						
								inventory->tool[stats->current_tool]->quantity--;
							}	
						}
					}
				}

				stats->dx = tx;
				stats->dy = ty;
			}
			else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH_SEED ||
				inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE_SEED ||
				inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER_SEED ||
				inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS_SEED ||
				inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON_SEED ||
				inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP_SEED ||
				inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION_SEED ||
				inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE_SEED ||
				inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE_SEED)
			{			
				if (inventory->tool[stats->current_tool]->quantity > 0 && stats->animation_type == 8)
				{
					for (int i=stats->px-1; i<=stats->px+1; i++)
					{
						for (int j=stats->py-1; j<=stats->py+1; j++)
						{
							if (i >= 0 && i < 100 && j >= 0 && j < 100)
							{
								if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_TILLED)
								{
									if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_RADISH;
									else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_CABBAGE;
									else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_CUCUMBER;
									else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_BEANS;
									else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_MELON;
									else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_TURNIP;
									else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_ONION;
									else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_RYE;
									else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE_SEED) 
										field[stats->current_field]->tile[i][j]->type = TILE_TYPE_NANOTUBE;
		
									field[stats->current_field]->tile[i][j]->growth = 0;
								}
							}
						}
					}
		
					inventory->tool[stats->current_tool]->quantity--;
		
					if (inventory->tool[stats->current_tool]->quantity <= 0)
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					}
				}
			}

			if (stats->animation_type == 17) // after the dance, go home and sleep!
			{
				stats->px = 25;
				stats->py = 22;
				stats->fx = 25.5f;
				stats->fy = 22.5f;
				stats->dx = 25;
				stats->dy = 23;
				stats->rot = 3.0f * 3.14159f / 2.0f;
				stats->current_field = 1;

				stats->animation_type = 11;
				stats->animation_timer = -10.0f;
	
				Sleep(field, inventory, cast, stats);

				stats->move_priority[1] = 1;

				return;
			}
			else
			{
				stats->animation_type = 0;
				stats->animation_timer = 0.0f;
			}
		}
		else return;
	}
	else if (stats->animation_timer < 0.0f) // for going between fields
	{
		stats->animation_timer += 0.2f * (float)frames_multiplier;

		return;
	}

	if (stats->animation_type != 12) stats->animation_type = 0;
	else 
	{
		stats->animation_timer -= 0.8f * (float)frames_multiplier;
		
		if (stats->animation_timer <= 0.0f) stats->animation_timer = 0.0f;
	}
	
	if ((control_up_on || control_down_on || control_left_on || control_right_on || control_run_on) && stats->activate_on == false)
	{
		if (control_run_on == true) 
		{
			character_speed *= 2.5f;

			stats->animation_type = 3;
		}
		else stats->animation_type = 2;

		if (control_up_on == true) { stats->move_priority[0]++; if (stats->move_priority[0] > 10000) stats->move_priority[0] = 10000; }
		else stats->move_priority[0] = 0;

		if (control_down_on == true) { stats->move_priority[1]++; if (stats->move_priority[1] > 10000) stats->move_priority[1] = 10000; }
		else stats->move_priority[1] = 0;

		if (control_left_on == true) { stats->move_priority[2]++; if (stats->move_priority[2] > 10000) stats->move_priority[2] = 10000; }
		else stats->move_priority[2] = 0;

		if (control_right_on == true) { stats->move_priority[3]++; if (stats->move_priority[3] > 10000) stats->move_priority[3] = 10000; }
		else stats->move_priority[3] = 0;

		min_value = 10001;
		min_place = -1;

		for (int i=0; i<4; i++)
		{
			if (stats->move_priority[i] > 0 && stats->move_priority[i] < min_value)
			{
				min_value = stats->move_priority[i];
				min_place = i;
			}
		}

		if (min_place == -1) // only '0' key
		{
			if (stats->rot == 3.14159f / 2.0f) min_place = 0;
			else if (stats->rot == 3.0f * 3.14159f / 2.0f) min_place = 1;
			else if (stats->rot == 3.14159f) min_place = 2;
			else if (stats->rot == 0.0f) min_place = 3;
		}

		// min_place MUST not be -1 at this point (hopefully?)	
	
		mx = 0.0f;
		my = 0.0f;

		if (min_place == 0)
		{
			my = -character_speed;
			stats->rot = 3.14159f / 2.0f;
		}
		else if (min_place == 1)
		{
			my = character_speed;
			stats->rot = 3.0f * 3.14159f / 2.0f;
		}
		else if (min_place == 2)
		{
			mx = -character_speed;
			stats->rot = 3.14159f;
		}
		else if (min_place == 3)
		{
			mx = character_speed;
			stats->rot = 0.0f;
		}

		if (stats->animation_timer < 3.14f - 3.14f / 4.0f)
		{
			if (stats->animation_type == 2) stats->animation_timer += 0.1f * (float)frames_multiplier;
			else if (stats->animation_type == 3) stats->animation_timer += 0.1f * (float)frames_multiplier;

			if (stats->animation_timer >= 3.14f - 3.14f / 4.0f)
			{
				if (linux_box == true && sound_on == true) if (stats->animation_type == 3) system("play -q -v 1.0 ./Sounds/Step.wav &");
				else if (linux_box == false && sound_on == true) if (stats->animation_type == 3) PlaySound(TEXT("Sounds\\Step.wav"), NULL, SND_FILENAME | SND_ASYNC);
			}
		}
		else if (stats->animation_timer < 6.28f - 3.14f / 4.0f)
		{
			if (stats->animation_type == 2) stats->animation_timer += 0.1f * (float)frames_multiplier;
			else if (stats->animation_type == 3) stats->animation_timer += 0.1f * (float)frames_multiplier;

			if (stats->animation_timer >= 6.28f - 3.14f / 4.0f)
			{
				if (linux_box == true && sound_on == true) if (stats->animation_type == 3) system("play -q -v 1.0 ./Sounds/Step.wav &");
				else if (linux_box == false && sound_on == true) if (stats->animation_type == 3) PlaySound(TEXT("Sounds\\Step.wav"), NULL, SND_FILENAME | SND_ASYNC);
			}
		}
		else
		{
			if (stats->animation_type == 2) stats->animation_timer += 0.1f * (float)frames_multiplier;
			else if (stats->animation_type == 3) stats->animation_timer += 0.1f * (float)frames_multiplier;
		}

		if (stats->animation_timer >= 6.28f) 
		{
			stats->animation_timer -= 6.28f;
		}

		if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
		{
			if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_WAITING ||
				field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_HOOKED ||
				field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_CAUGHT)
			{
				field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_FISHERY;
			}
		}

		stats->fx += mx;
		stats->fy += my;

		test = false;

		for (int k=0; k<30; k++)
		{
			if (cast->actor[k]->type != ACTOR_TYPE_NONE && cast->actor[k]->present_field == stats->current_field)
			{
				if (fabs(stats->fx - cast->actor[k]->fx) < 2.0f * character_radius &&
					fabs(stats->fy - cast->actor[k]->fy) < 2.0f * character_radius)
				{
					test = true;
				}
			}
		}

		if (test == true) 
		{
			stats->fx -= mx;
			stats->fy -= my;
		}

		test = false;

		for (int i=-1; i<=1; i++)
		{
			for (int j=-1; j<=1; j++)
			{
				if (stats->px+i >= 0 && stats->px+i < 100 && stats->py+j >= 0 && stats->py+j < 100)
				{
					if ((field[stats->current_field]->tile[stats->px+i][stats->py+j]->type != TILE_TYPE_NONE &&
						field[stats->current_field]->tile[stats->px+i][stats->py+j]->growth > 0) ||
						field[stats->current_field]->tile[stats->px+i][stats->py+j]->type == TILE_TYPE_CLOSED_DOOR)
					{
						if (stats->fx-character_radius >= (float)(stats->px+i) &&
							stats->fx-character_radius <= (float)(stats->px+i+1) &&
							stats->fy-character_radius >= (float)(stats->py+j) &&
							stats->fy-character_radius <= (float)(stats->py+j+1))
						{
							test = true;

							if (sqrt(pow(stats->fx - (float)(stats->px+i) - 0.5f, 2.0f) + pow(stats->fy - (float)(stats->py+j) - 0.5f, 2.0f)) > 0.9f)
							{
								if (mx == 0.0f && stats->fx > (float)(stats->px+i) + 0.5f) stats->fx += character_speed / 4.0f;
								else if (mx == 0.0f && stats->fx < (float)(stats->px+i) + 0.5f) stats->fx -= character_speed / 4.0f;
								else if (my == 0.0f && stats->fy > (float)(stats->py+j) + 0.5f) stats->fy += character_speed / 4.0f;
								else if (my == 0.0f && stats->fy < (float)(stats->py+j) + 0.5f) stats->fy -= character_speed / 4.0f;
							}
						}
						
						if (stats->fx+character_radius >= (float)(stats->px+i) &&
							stats->fx+character_radius <= (float)(stats->px+i+1) &&
							stats->fy-character_radius >= (float)(stats->py+j) &&
							stats->fy-character_radius <= (float)(stats->py+j+1))
						{
							test = true;

							if (sqrt(pow(stats->fx - (float)(stats->px+i) - 0.5f, 2.0f) + pow(stats->fy - (float)(stats->py+j) - 0.5f, 2.0f)) > 0.9f)
							{
								if (mx == 0.0f && stats->fx > (float)(stats->px+i) + 0.5f) stats->fx += character_speed / 4.0f;
								else if (mx == 0.0f && stats->fx < (float)(stats->px+i) + 0.5f) stats->fx -= character_speed / 4.0f;
								else if (my == 0.0f && stats->fy > (float)(stats->py+j) + 0.5f) stats->fy += character_speed / 4.0f;
								else if (my == 0.0f && stats->fy < (float)(stats->py+j) + 0.5f) stats->fy -= character_speed / 4.0f;
							}
						}

						if (stats->fx-character_radius >= (float)(stats->px+i) &&
							stats->fx-character_radius <= (float)(stats->px+i+1) &&
							stats->fy+character_radius >= (float)(stats->py+j) &&
							stats->fy+character_radius <= (float)(stats->py+j+1))
						{
							test = true;

							if (sqrt(pow(stats->fx - (float)(stats->px+i) - 0.5f, 2.0f) + pow(stats->fy - (float)(stats->py+j) - 0.5f, 2.0f)) > 0.9f)
							{
								if (mx == 0.0f && stats->fx > (float)(stats->px+i) + 0.5f) stats->fx += character_speed / 4.0f;
								else if (mx == 0.0f && stats->fx < (float)(stats->px+i) + 0.5f) stats->fx -= character_speed / 4.0f;
								else if (my == 0.0f && stats->fy > (float)(stats->py+j) + 0.5f) stats->fy += character_speed / 4.0f;
								else if (my == 0.0f && stats->fy < (float)(stats->py+j) + 0.5f) stats->fy -= character_speed / 4.0f;
							}
						}

						if (stats->fx+character_radius >= (float)(stats->px+i) &&
							stats->fx+character_radius <= (float)(stats->px+i+1) &&
							stats->fy+character_radius >= (float)(stats->py+j) &&
							stats->fy+character_radius <= (float)(stats->py+j+1))
						{
							test = true;

							if (sqrt(pow(stats->fx - (float)(stats->px+i) - 0.5f, 2.0f) + pow(stats->fy - (float)(stats->py+j) - 0.5f, 2.0f)) > 0.9f)
							{
								if (mx == 0.0f && stats->fx > (float)(stats->px+i) + 0.5f) stats->fx += character_speed / 4.0f;
								else if (mx == 0.0f && stats->fx < (float)(stats->px+i) + 0.5f) stats->fx -= character_speed / 4.0f;
								else if (my == 0.0f && stats->fy > (float)(stats->py+j) + 0.5f) stats->fy += character_speed / 4.0f;
								else if (my == 0.0f && stats->fy < (float)(stats->py+j) + 0.5f) stats->fy -= character_speed / 4.0f;
							}
						}
					}
				}
			}
		}

		if (test == true) 
		{
			stats->fx -= mx;
			stats->fy -= my;
		}

		stats->px = (int)(stats->fx);
		stats->py = (int)(stats->fy);

		test = false;

		for (int i=-1; i<=1; i++)
		{
			for (int j=-1; j<=1; j++)
			{
				if (stats->px+i >= 0 && stats->px+i < 100 && stats->py+j >= 0 && stats->py+j < 100)
				{
					if ((field[stats->current_field]->tile[stats->px+i][stats->py+j]->type != TILE_TYPE_NONE &&
						field[stats->current_field]->tile[stats->px+i][stats->py+j]->growth > 0) ||
						field[stats->current_field]->tile[stats->px+i][stats->py+j]->type == TILE_TYPE_CLOSED_DOOR)
					{
						if (stats->fx-character_radius >= (float)(stats->px+i) &&
							stats->fx-character_radius <= (float)(stats->px+i+1) &&
							stats->fy-character_radius >= (float)(stats->py+j) &&
							stats->fy-character_radius <= (float)(stats->py+j+1))
						{
							test = true;
						}
						
						if (stats->fx+character_radius >= (float)(stats->px+i) &&
							stats->fx+character_radius <= (float)(stats->px+i+1) &&
							stats->fy-character_radius >= (float)(stats->py+j) &&
							stats->fy-character_radius <= (float)(stats->py+j+1))
						{
							test = true;
						}

						if (stats->fx-character_radius >= (float)(stats->px+i) &&
							stats->fx-character_radius <= (float)(stats->px+i+1) &&
							stats->fy+character_radius >= (float)(stats->py+j) &&
							stats->fy+character_radius <= (float)(stats->py+j+1))
						{
							test = true;
						}

						if (stats->fx+character_radius >= (float)(stats->px+i) &&
							stats->fx+character_radius <= (float)(stats->px+i+1) &&
							stats->fy+character_radius >= (float)(stats->py+j) &&
							stats->fy+character_radius <= (float)(stats->py+j+1))
						{
							test = true;
						}
					}
				}
			}
		}

		// Apparently last time it didn't work...
		if (test == true) 
		{
			stats->fx = (float)(stats->px + 0.5f);
			stats->fy = (float)(stats->py + 0.5f);
		}

		stats->px = (int)(stats->fx);
		stats->py = (int)(stats->fy);

		if (stats->px < 0 || stats->py < 0 || stats->px >= 100 || stats->py >= 100)
		{
			stats->fx -= mx;
			stats->fy -= my;
				
			stats->px = (int)(stats->fx);
			stats->py = (int)(stats->fy);
		}
	
		if (field[stats->current_field]->tile[stats->px][stats->py]->growth > 0 ||
			field[stats->current_field]->tile[stats->px][stats->py]->type == TILE_TYPE_CLOSED_DOOR) 
		{
			stats->fx -= mx;
			stats->fy -= my;
				
			stats->px = (int)(stats->fx);
			stats->py = (int)(stats->fy);
		}

		if (min_place == 0)
		{
			stats->dy = stats->py - 1;
			stats->dx = stats->px;
		}
		else if (min_place == 1)
		{
			stats->dy = stats->py + 1;
			stats->dx = stats->px;
		}
		else if (min_place == 2)
		{
			stats->dx = stats->px - 1;
			stats->dy = stats->py;
		}
		else if (min_place == 3)
		{
			stats->dx = stats->px + 1;
			stats->dy = stats->py;
		}
	}
	
	if (control_tool_left_on && stats->activate_on == false) // change tool
	{
		stats->activate_on = true;

		stats->current_tool -= 1;

		if (stats->current_tool < 0) stats->current_tool = 11;

		if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Switch.wav &");
		else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Switch.wav"), NULL, SND_FILENAME | SND_ASYNC);
	}
	
	if (control_tool_right_on && stats->activate_on == false) // change tool
	{
		stats->activate_on = true;

		stats->current_tool += 1;

		if (stats->current_tool >= 12) stats->current_tool = 0;

		if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Switch.wav &");
		else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Switch.wav"), NULL, SND_FILENAME | SND_ASYNC);
	}

	if (control_pray_on && stats->activate_on == false) // prayer button!
	{
		stats->activate_on = true;

		stats->dialog_up = -3;
		stats->dialog_place = 0;
		stats->dialog_selection = -1;

		stats->animation_type = 19; // prayer
		stats->animation_timer = 0.0f;

		stats->prayed++;

		if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Chat.wav &");
		else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Chat.wav"), NULL, SND_FILENAME | SND_ASYNC);
	}
	
	if (control_status_on && stats->activate_on == false) // check status, pause
	{
		stats->activate_on = true;

		stats->dialog_up = -2;
		stats->dialog_place = 0;
		stats->dialog_selection = -1;

		if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
		else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Step.wav"), NULL, SND_FILENAME | SND_ASYNC);
	}
	
	if (control_activate_on && stats->activate_on == false) // enter, activate
	{
		stats->activate_on = true;

		test = false;

		for (int k=0; k<30; k++)
		{
			if (cast->actor[k]->type != ACTOR_TYPE_NONE &&
				cast->actor[k]->present_field == stats->current_field &&
				fabs((stats->fx + 1.5f * character_radius * (float)(stats->dx - stats->px)) - cast->actor[k]->fx) < character_radius &&
				fabs((stats->fy + 1.5f * character_radius * (float)(stats->dy - stats->py)) - cast->actor[k]->fy) < character_radius)
			{
				test = true;

				if (cast->actor[k]->type == ACTOR_TYPE_ROVER || cast->actor[k]->type == ACTOR_TYPE_PARROT)
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Chat.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Chat.wav"), NULL, SND_FILENAME | SND_ASYNC);

					cast->actor[k]->affection = 1;
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_DAVID)
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Chat.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Chat.wav"), NULL, SND_FILENAME | SND_ASYNC);

					if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH) // best
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 3;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 103; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL) // good
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 1;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 102; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE) // meh
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 0;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 101; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET) // bad
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += -2;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 100; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += -2;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 100; // still bad
						}
					}
					else // talking
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 2) 
						{
							cast->actor[k]->affection += 1;// * (int)(30.0f / (float)stats->days_in_a_season);

							cast->actor[k]->affection_lifted_today += 1;
						}
						else if (cast->actor[k]->affection_lifted_today == 1 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
						}
					}
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_CLARA)
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Chat.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Chat.wav"), NULL, SND_FILENAME | SND_ASYNC);

					if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY) // best
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 3;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 103; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET) // good
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 1;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 102; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT) // meh
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 0;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 101; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH) // bad
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += -2;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 100; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += -2;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 100; // still bad
						}
					}
					else // talking
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 2) 
						{
							cast->actor[k]->affection += 1;// * (int)(30.0f / (float)stats->days_in_a_season);

							cast->actor[k]->affection_lifted_today += 1;
						}
						else if (cast->actor[k]->affection_lifted_today == 1 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
						}
					}
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_ANDREW)
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Chat.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Chat.wav"), NULL, SND_FILENAME | SND_ASYNC);

					if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON) // best
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 3;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 103; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET) // good
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 1;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 102; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT) // meh
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 0;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 101; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE) // bad
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += -2;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 100; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += -2;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 100; // still bad
						}
					}
					else // talking
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 2) 
						{
							cast->actor[k]->affection += 1;// * (int)(30.0f / (float)stats->days_in_a_season);

							cast->actor[k]->affection_lifted_today += 1;
						}
						else if (cast->actor[k]->affection_lifted_today == 1 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
						}
					}
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_EMILY)
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Chat.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Chat.wav"), NULL, SND_FILENAME | SND_ASYNC);

					if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET) // best
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 3;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 103; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT) // good
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 1;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 102; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE) // meh
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += 0;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 101; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 99; // indicates gift was already given
						}
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM) // bad
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 1) 
						{
							cast->actor[k]->affection += -2;// * (int)(30.0f / (float)stats->days_in_a_season);
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 100; // indicates it was a gift

							cast->actor[k]->affection_lifted_today += 2;
						}
						else if (cast->actor[k]->affection_lifted_today == 2 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += -2;
					
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
							inventory->tool[stats->current_tool]->quantity = 100; // still bad
						}
					}
					else // talking
					{
						if (cast->actor[k]->affection_lifted_today == 0 || cast->actor[k]->affection_lifted_today == 2) 
						{
							cast->actor[k]->affection += 1;// * (int)(30.0f / (float)stats->days_in_a_season);

							cast->actor[k]->affection_lifted_today += 1;
						}
						else if (cast->actor[k]->affection_lifted_today == 1 || cast->actor[k]->affection_lifted_today == 3) 
						{
							cast->actor[k]->affection += 0;
						}
					}
				}
				else
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}

				if (cast->actor[k]->animation_type == 19) // praying
				{
					cast->actor[k]->animation_type = 0;
				}
				
				if (cast->actor[k]->animation_type != 1) // not sitting
				{
					if (stats->dx > stats->px) cast->actor[k]->rot = 3.14159f;
					else if (stats->dx < stats->px) cast->actor[k]->rot = 0.0f;
					else if (stats->dy > stats->py) cast->actor[k]->rot = 3.14159f / 2.0f;
					else if (stats->dy < stats->py) cast->actor[k]->rot = 3.0f * 3.14159f / 2.0f;
				}
			
				cast->actor[k]->tx = cast->actor[k]->fx;
				cast->actor[k]->ty = cast->actor[k]->fy;

				if (cast->actor[k]->type == ACTOR_TYPE_TELEVISION)
				{
					if (stats->py > cast->actor[k]->py && stats->px == cast->actor[k]->px)
					{
						stats->dialog_up = k;
						stats->dialog_place = 0;
						stats->dialog_selection = -1;
					}
					else
					{
						// nothing
					}
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_BIBLE_STATION)
				{
					stats->dialog_up = k;
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				
					stats->prayed++; // counts I suppose?
				}
				else
				{
					stats->dialog_up = k;
					stats->dialog_place = 0;
					stats->dialog_selection = -1;
				}
			}
		}

		if (test == false)
		{
			if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
			{
				if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CHARGING_STATION)
				{
					stats->animation_type = 11;
					stats->animation_timer = -10.0f;
	
					Sleep(field, inventory, cast, stats);

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Sleep.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Sleep.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY)
				{
					field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_FISHERY_WAITING;

					stats->animation_type = 12;
					stats->animation_timer = 0.0f;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_WAITING)
				{
					//field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_FISHERY;

					//stats->animation_type = 0;
					//stats->animation_timer = 0.0f;
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_HOOKED)
				{
					if (rand() % 100 < 10) field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_FISHERY_CAUGHT;
			
					stats->animation_type = 12;
					stats->animation_timer = 1.0f;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DYNAMO_CHARGER)
				{
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth += 1;

					if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth % 2 == 0)
					{
						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Tick.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Tick.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MINI_SPEED_CHALLENGE)
				{
					if (stats->countdown > 0)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth += 1;

						if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 50)
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 50;

							if (stats->success == 0) stats->success = 4;
							else if (stats->success == 3) stats->success = 7;

							stats->countdown = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else if (stats->countdown <= -5) stats->countdown = 10;
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MINI_TIMING_CHALLENGE)
				{
					if (stats->countdown > 0)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 23 &&
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth <= 37)
						{
							if (stats->success == 0) stats->success = 3;
							else if (stats->success == 4) stats->success = 7;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else
						{
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;
						}

						stats->countdown = 0;
					}
					else if (stats->countdown <= -5) 
					{
						stats->countdown = 10;	

						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 50;
					}
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MATCHING_CHALLENGE)
				{
					if (stats->countdown <= -5)
					{
						stats->countdown = 90;
					}

					if (stats->countdown > 0 && field[stats->current_field]->tile[stats->dx][stats->dy]->growth == 1)
					{
						field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 2;
					}
					
					test = false;

					for (int i=0; i<100; i++)
					{
						for (int j=0; j<100; j++)
						{
							if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_MATCHING_CHALLENGE &&
								field[stats->current_field]->tile[i][j]->growth == 1) // basically, if none unfilled, good to go
							{
								test = true;
							}
						}
					}

					if (test == false) 
					{
						stats->success = 21;

						stats->countdown = 0;
					}
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DONATION_BOX && stats->credits >= 100)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;	

					stats->credits -= 100;
					stats->donated += 100;

					if (rand() % 2 == 0) stats->success++;

					field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}			
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ARCADE)
				{
					minigame_active = true;

					minigame_score = 0;
					minigame_pos_x = 0.0f, minigame_pos_y = -0.25f;

					for (int i=0; i<50; i++)
					{
						minigame_enemy_pos_x[i] = 0.0f;
						minigame_enemy_pos_y[i] = -100.0f;
						minigame_bullet_pos_x[i] = 0.0f;
						minigame_bullet_pos_y[i] = 100.0f;
						minigame_star_pos_x[i] = 0.0f; 
						minigame_star_pos_y[i] = -100.0f;
						minigame_speed = 0.001f;
					}

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CONTAINER &&
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_NONE+1 &&
					inventory->tool[stats->current_tool]->type != TOOL_TYPE_NONE &&
					inventory->tool[stats->current_tool]->type != TOOL_TYPE_PORTABLE_EXCHANGER)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;

					field[stats->current_field]->tile[stats->dx][stats->dy]->growth = inventory->tool[stats->current_tool]->type + 1;

					field[stats->current_field]->tile[stats->dx][stats->dy]->style = inventory->tool[stats->current_tool]->quantity;

					inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
					inventory->tool[stats->current_tool]->quantity = 0;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CONTAINER &&
					(field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_RADISH_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_CABBAGE_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_CUCUMBER_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_BEANS_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_MELON_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_TURNIP_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_ONION_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_RYE_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_NANOTUBE_SEED+1) &&
					inventory->tool[stats->current_tool]->type == field[stats->current_field]->tile[stats->dx][stats->dy]->growth-1 &&
					inventory->tool[stats->current_tool]->type != TOOL_TYPE_NONE &&
					inventory->tool[stats->current_tool]->type != TOOL_TYPE_PORTABLE_EXCHANGER)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;

					field[stats->current_field]->tile[stats->dx][stats->dy]->growth = inventory->tool[stats->current_tool]->type + 1;

					field[stats->current_field]->tile[stats->dx][stats->dy]->style += inventory->tool[stats->current_tool]->quantity;

					inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
					inventory->tool[stats->current_tool]->quantity = 0;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_HOE && stats->energy > 1 && stats->animation_type != 4)
				{
					stats->animation_type = 4;
					stats->animation_timer = 0.0f;
	
					stats->energy -= 2;
		
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Dig.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Dig.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_HAMMER && stats->energy > 1 && stats->animation_type != 5) 
				{
					stats->animation_type = 5;
					stats->animation_timer = 0.0f;
	
					stats->energy -= 2;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Smash.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Smash.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_SCYTHE && stats->energy > 1 && stats->animation_type != 6)
				{
					stats->animation_type = 6;
					stats->animation_timer = 0.0f;
	
					stats->energy -= 2;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Cut.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Cut.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_WATERING_CAN && stats->energy > 0 && stats->animation_type != 7)
				{
					stats->animation_type = 7;
					stats->animation_timer = 0.0f;
	
					stats->energy -= 1;

					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WATER_GENERATOR)
					{
						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fill.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fill.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
					else if (inventory->tool[stats->current_tool]->quantity > 0)
					{
						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Water.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Water.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_HOE && stats->energy > 2 && stats->animation_type != 13)
				{
					stats->animation_type = 13;
					stats->animation_timer = 0.0f;

					stats->energy -= 3;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Dig.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Dig.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_HAMMER && stats->energy > 2 && stats->animation_type != 14) 
				{
					stats->animation_type = 14;
					stats->animation_timer = 0.0f;
	
					stats->energy -= 3;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Smash.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Smash.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_SCYTHE && stats->energy > 2 && stats->animation_type != 15)
				{
					stats->animation_type = 15;
					stats->animation_timer = 0.0f;
	
					stats->energy -= 3;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Cut.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Cut.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_WATERING_CAN && stats->energy > 1 && stats->animation_type != 16)
				{
					stats->animation_type = 16;
					stats->animation_timer = 0.0f;
	
					stats->energy -= 2;

					if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WATER_GENERATOR)
					{
						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fill.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fill.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
					else if (inventory->tool[stats->current_tool]->quantity > 0)
					{
						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Water.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Water.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE_SEED)
				{			
					if (inventory->tool[stats->current_tool]->quantity > 0 && stats->energy > 0 && stats->animation_type != 8)
					{
						stats->animation_type = 8;
						stats->animation_timer = -3.14159f / 2.0f;
	
						stats->energy -= 1;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Sow.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Sow.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 60;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 60;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 80;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 80;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 100;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 100;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 120;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 120;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 150;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 150;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 70;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 70;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 90;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 90;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crops++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 20;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_rye++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 20;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_rye++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_materials += 5;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_materials += 5;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;
						}
*/
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EMPTY_ROVER_STATION)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_FULL_ROVER_STATION;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE_DISTRIBUTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							stats->feed++;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;		
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_materials += 5;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_ore++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_materials += 5;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_ore++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 30;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_gathered++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 30;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_gathered++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 40;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_gathered++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 40;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_gathered++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 30;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_gathered++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 30;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_gathered++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth++;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 50;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crystal++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 50;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_crystal++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
				
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 200;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_fish++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 200;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_fish++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type != TILE_TYPE_FISHERY_CAUGHT) // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;
	
						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;
	
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 300;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_extract++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;
	
							stats->held_credits += 300;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

							stats->total_extract++;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
			
							inventory->tool[stats->current_tool]->quantity = 0;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth += 3;
	
							if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
							{
								field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR_FULL;
							}

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Splash.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Splash.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else // destroyed?
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
							inventory->tool[stats->current_tool]->quantity = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
					else
					{
						inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
						inventory->tool[stats->current_tool]->quantity = 0;

						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET)
				{
					stats->animation_type = 9;
					stats->animation_timer = 0.0f;

					inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;
					
					inventory->tool[stats->current_tool]->quantity = 0;

					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Fail.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Fail.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_PORTABLE_EXCHANGER)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DIRT &&
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth == 0)
						{
							stats->animation_type = 9;
							stats->animation_timer = 0.0f;

							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_PORTABLE_EXCHANGER;
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;

							inventory->tool[stats->current_tool]->type = TOOL_TYPE_NONE;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}	
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 4)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 7)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_CABBAGE;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 9)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_CUCUMBER;
	
							//field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 6;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 12)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_BEANS;
	
							//field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 8;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 15)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_MELON;
	
							//field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 10;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_TURNIP;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 11)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_ONION;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUT_RYE)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RYE;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BROKEN_ORE)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_ORE;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EMPTY_ORE;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BERRY_BUSH)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_BERRY;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EMPTY_BERRY_BUSH;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_APPLE_TREE)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;						
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_APPLE;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EMPTY_APPLE_TREE;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MUSHROOM_BED)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_MUSHROOM;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EMPTY_MUSHROOM_BED;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BROKEN_CRYSTAL)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_CRYSTAL;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EMPTY_CRYSTAL;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE_DISTRIBUTOR)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							if (stats->feed > 0)
							{
								inventory->tool[stats->current_tool]->type = TOOL_TYPE_NANOTUBE;
	
								stats->feed--;

								field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 100;

								if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
								else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
							}
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ROVER_DEPOSIT)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_CRYSTAL;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EMPTY_ROVER_DEPOSIT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_CAUGHT)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_FISH;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_FISHERY;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR_READY)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_EXTRACT;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_EXTRACTOR;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 1;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CONTAINER)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = field[stats->current_field]->tile[stats->dx][stats->dy]->growth-1;

							inventory->tool[stats->current_tool]->quantity = field[stats->current_field]->tile[stats->dx][stats->dy]->style;

							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = TOOL_TYPE_NONE+1;
	
							field[stats->current_field]->tile[stats->dx][stats->dy]->style = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER)
						{
							stats->animation_type = 10;
							stats->animation_timer = 0.0f;
	
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_PORTABLE_EXCHANGER;

							field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_DIRT;
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth = 0;
							field[stats->current_field]->tile[stats->dx][stats->dy]->style = 0;

							if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Grab.wav &");
							else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Grab.wav"), NULL, SND_FILENAME | SND_ASYNC);
						}
					}
				}
				else
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Error.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Error.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
			}
		}
	}
	
	if (!(control_activate_on || control_pray_on || control_status_on || control_tool_left_on || control_tool_right_on))
	{
		stats->activate_on = false;
	}

	if (stats->animation_type == 0)
	{
		stats->animation_timer = 0.0f;
	}

	return;
};

void SecondLoop(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats)
{
	bool test;

	stats->countdown--;

	if (linux_box == true && sound_on == true) if (stats->countdown >= 0) system("play -q -v 1.0 ./Sounds/Clock.wav &");
	else if (linux_box == false && sound_on == true) if (stats->countdown >= 0) PlaySound(TEXT("Sounds\\Clock.wav"), NULL, SND_FILENAME | SND_ASYNC);

	if (stats->countdown < -5) stats->countdown = -5;

	if (stats->weather == 0) // sunny
	{
		if ((stats->current_field == 0 || stats->current_field == 3 || stats->current_field == 4 || stats->current_field == 6) && rand() % 10 == 0)
		{
			//if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Wind.wav &");
			//else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Wind.wav"), NULL, SND_FILENAME | SND_ASYNC);
		}
		else
		{
			// nothing
		}
	}
	else if (stats->weather == 1) // raining
	{
		if (stats->current_field == 0 || stats->current_field == 3 || stats->current_field == 4 || stats->current_field == 6)
		{
			if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/RainLoud.wav &");
			else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\RainLoud.wav"), NULL, SND_FILENAME | SND_ASYNC);
		}
		else
		{
			if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/RainSoft.wav &");
			else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\RainSoft.wav"), NULL, SND_FILENAME | SND_ASYNC);
		}
	}

	if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
	{
		if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_WAITING)
		{
			if (rand() % 100 < 10)
			{
				field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_FISHERY_HOOKED;
			}
		}
		else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DYNAMO_CHARGER)
		{
			if (field[stats->current_field]->tile[stats->dx][stats->dy]->growth > 1)
			{
				if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Charge.wav &");
				else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Charge.wav"), NULL, SND_FILENAME | SND_ASYNC);

				stats->energy += field[stats->current_field]->tile[stats->dx][stats->dy]->growth-1;

				if (stats->success > 0)
				{
					if (stats->energy > 300) stats->energy = 300;
				}
				else
				{
					if (stats->energy > 200) stats->energy = 200;
				}
			}
		}
	}

	for (int i=0; i<100; i++)
	{
		for (int j=0; j<100; j++)
		{
			if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_FISHERY_HOOKED)
			{
				if (i == stats->dx && j == stats->dy)
				{
					if (rand() % 100 < 50)
					{
						field[stats->current_field]->tile[i][j]->type = TILE_TYPE_FISHERY_WAITING;
					}
				}
				else field[stats->current_field]->tile[i][j]->type = TILE_TYPE_FISHERY;
			}
			else if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_DYNAMO_CHARGER)
			{
				field[stats->current_field]->tile[i][j]->growth -= 5;

				if (field[stats->current_field]->tile[i][j]->growth < 1)
				{
					field[stats->current_field]->tile[i][j]->growth = 1;
				}
			}
			else if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_MINI_SPEED_CHALLENGE)
			{
				if (stats->countdown > 0)
				{
					field[stats->current_field]->tile[i][j]->growth -= 2;

					if (field[stats->current_field]->tile[i][j]->growth < 1)
					{
						field[stats->current_field]->tile[i][j]->growth = 1;
					}
				}
				else field[stats->current_field]->tile[i][j]->growth = 1;
			}
			else if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_MINI_TIMING_CHALLENGE)
			{
				if (stats->countdown > 2)
				{
					if (rand() % 3 == 0 && field[stats->current_field]->tile[i][j]->growth == 50)
					{
						field[stats->current_field]->tile[i][j]->growth = 49;
					}
				}
				else if (stats->countdown <= 2 && stats->countdown >= 0)
				{
					if (field[stats->current_field]->tile[i][j]->growth == 50)
					{
						field[stats->current_field]->tile[i][j]->growth = 49;
					}
				}
				else field[stats->current_field]->tile[i][j]->growth = 1;
			}
			else if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_MATCHING_CHALLENGE)
			{
				if (stats->countdown == -4)
				{
					field[stats->current_field]->tile[i][j]->growth = 1; // SOMETHING ELSE ABOUT CHANGING STYLES AROUND? RANDOM!

					int very_temp_count = 0;
					int very_temp_x1, very_temp_x2, very_temp_y1, very_temp_y2;
		
					for (int i=0; i<100; i++)
					{
						for (int j=0; j<100; j++)
						{
							if (field[10]->tile[i][j]->type == TILE_TYPE_MATCHING_CHALLENGE)
							{
								field[10]->tile[i][j]->style = very_temp_count;
	
								very_temp_count++;
			
								if (very_temp_count >= 6) very_temp_count = 0;
							}
						}
					}

					for (int loop=0; loop<100; loop++) // might take a bit?
					{
						very_temp_x1 = rand() % 100;
						very_temp_y1 = rand() % 100;
			
						while (field[10]->tile[very_temp_x1][very_temp_y1]->type != TILE_TYPE_MATCHING_CHALLENGE)
						{
							very_temp_x1 = rand() % 100;
							very_temp_y1 = rand() % 100;
						}

						very_temp_x2 = rand() % 100;
						very_temp_y2 = rand() % 100;
			
						while (field[10]->tile[very_temp_x2][very_temp_y2]->type != TILE_TYPE_MATCHING_CHALLENGE)
						{
							very_temp_x2 = rand() % 100;
							very_temp_y2 = rand() % 100;
						}
					
						very_temp_count = field[10]->tile[very_temp_x1][very_temp_y1]->style;
	
						field[10]->tile[very_temp_x1][very_temp_y1]->style = field[10]->tile[very_temp_x2][very_temp_y2]->style;
										
						field[10]->tile[very_temp_x2][very_temp_y2]->style = very_temp_count;
					}
				}
			}
			else if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_OPEN_DOOR)
			{
				test = true;

				for (int a=-1; a<=1; a++)
				{
					for (int b=-1; b<=1; b++)
					{
						if (stats->px == i+a && stats->py == j+b)
						{
							test = false;
						}
					}
				}

				if (test == true)
				{
					field[stats->current_field]->tile[i][j]->type = TILE_TYPE_CLOSED_DOOR;

					if ((field[stats->current_field]->tile[i][j]->style == 1 ||
						field[stats->current_field]->tile[i][j]->style == 2) && stats->current_field != 5)
					{
						if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Door.wav &");
						else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Door.wav"), NULL, SND_FILENAME | SND_ASYNC);
					}
				}
			}
		}
	}

	for (int i=0; i<30; i++)
	{
		if (cast->actor[i]->type != ACTOR_TYPE_NONE && cast->actor[i]->fx == cast->actor[i]->tx && cast->actor[i]->fy == cast->actor[i]->ty)
		{
			if (rand() % 100 < 25)
			{
				if (rand() % 100 < 50) // left/right
				{
					cast->actor[i]->tx = (cast->actor[i]->rx1<=cast->actor[i]->rx2 ? cast->actor[i]->rx1 : cast->actor[i]->rx2) + 
						fabs(cast->actor[i]->rx2 - cast->actor[i]->rx1) * ((float)(rand() % 1000) / 1000.0f);
				}
				else // up/down
				{
					cast->actor[i]->ty =  (cast->actor[i]->ry1<=cast->actor[i]->ry2 ? cast->actor[i]->ry1 : cast->actor[i]->ry2) + 
						fabs(cast->actor[i]->ry2 - cast->actor[i]->ry1) * ((float)(rand() % 1000) / 1000.0f);
				}
			}
		}

		if ((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
			(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25))) || stats->day_of_week == 1) // festivals
		{
			if (stats->current_field == 10 && cast->actor[i]->present_field == 10) // church
			{	
				if (cast->actor[i]->type == ACTOR_TYPE_DAVID || cast->actor[i]->type == ACTOR_TYPE_CLARA ||
					cast->actor[i]->type == ACTOR_TYPE_ANDREW || cast->actor[i]->type == ACTOR_TYPE_EMILY)
				{
					if (cast->actor[i]->animation_type == 0)
					{
						cast->actor[i]->animation_type = 19; // praying
						
						cast->actor[i]->rot = 3.14159f / 2.0f;
					}
				}
			}
		}
	}					

	return;
};

void EveryLoop(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats, int frames_multiplier)
{
	float actor_speed = 0.05f * (float)frames_multiplier; // somehow manage a better speed?
	float actor_radius = 0.35f;

	float mx = 0.0f, my = 0.0f;

	bool test;

	for (int i=0; i<30; i++)
	{
		if (cast->actor[i]->animation_type == 17 || cast->actor[i]->animation_type == 18) // dancing or playing instruments
		{
			cast->actor[i]->animation_timer += 0.1f * (float)frames_multiplier;
			
			if (cast->actor[i]->animation_timer >= 32.0f * 3.14159f)
			{
				cast->actor[i]->animation_type = 0;
			}
		}
		else if (cast->actor[i]->animation_type == 1 || cast->actor[i]->animation_type == 19) // sitting or praying
		{
			// do nothing
		}	
		else
		{
			cast->actor[i]->animation_type = 0;

			if (cast->actor[i]->type != ACTOR_TYPE_NONE && cast->actor[i]->present_field == stats->current_field && 
				(cast->actor[i]->fx != cast->actor[i]->tx || cast->actor[i]->fy != cast->actor[i]->ty))
			{
				if (cast->actor[i]->fx != cast->actor[i]->tx || cast->actor[i]->fy != cast->actor[i]->ty)
				{
					if (cast->actor[i]->type == ACTOR_TYPE_ROVER && cast->actor[i]->affection == 0) actor_speed /= 2.0f;
	
					mx = 0.0f;
					my = 0.0f;
	
					if (cast->actor[i]->fx > cast->actor[i]->tx)
					{
						mx = -actor_speed;
						cast->actor[i]->rot = 3.14159f;
					}
					else if (cast->actor[i]->fx < cast->actor[i]->tx)
					{
						mx = actor_speed;
						cast->actor[i]->rot = 0.0f;
					}
					else if (cast->actor[i]->fy > cast->actor[i]->ty)
					{
						my = -actor_speed;
						cast->actor[i]->rot = 3.14159f / 2.0f;
					}
					else if (cast->actor[i]->fy < cast->actor[i]->ty)
					{
						my = actor_speed;
						cast->actor[i]->rot = 3.0f * 3.14159f / 2.0f;
					}
	
					cast->actor[i]->animation_type = 2;
					cast->actor[i]->animation_timer += 0.1f * (float)frames_multiplier;
					if (cast->actor[i]->animation_timer >= 6.28f) cast->actor[i]->animation_timer -= 6.28f;
	
					cast->actor[i]->fx += mx;
					cast->actor[i]->fy += my;
	
					test = false;
	
					if (fabs(stats->fx - cast->actor[i]->fx) < 2.0f * actor_radius &&
						fabs(stats->fy - cast->actor[i]->fy) < 2.0f * actor_radius)
					{
						test = true;
					}
	
					for (int k=0; k<30; k++)
					{
						if (cast->actor[k]->type != ACTOR_TYPE_NONE && cast->actor[k]->present_field == cast->actor[i]->present_field && k != i)
						{
							if (fabs(cast->actor[i]->fx - cast->actor[k]->fx) < 2.0f * actor_radius &&
								fabs(cast->actor[i]->fy - cast->actor[k]->fy) < 2.0f * actor_radius)
							{
								test = true;
							}
						}
					}
	
					if (test == true) 
					{
						cast->actor[i]->fx -= mx;
						cast->actor[i]->fy -= my;
	
						cast->actor[i]->tx = cast->actor[i]->fx;
						cast->actor[i]->ty = cast->actor[i]->fy;
					}
	
					test = false;
	
					for (int m=-1; m<=1; m++)
					{
						for (int n=-1; n<=1; n++)
						{
							if (cast->actor[i]->px+m >= 0 && cast->actor[i]->px+m < 100 && cast->actor[i]->py+n >= 0 && cast->actor[i]->py+n < 100)
							{
								if (field[stats->current_field]->tile[cast->actor[i]->px+m][cast->actor[i]->py+n]->type != TILE_TYPE_NONE &&
									field[stats->current_field]->tile[cast->actor[i]->px+m][cast->actor[i]->py+n]->growth > 0)
								{
									if (cast->actor[i]->fx-actor_radius >= (float)(cast->actor[i]->px+m) &&
										cast->actor[i]->fx-actor_radius <= (float)(cast->actor[i]->px+m+1) &&
										cast->actor[i]->fy-actor_radius >= (float)(cast->actor[i]->py+n) &&
										cast->actor[i]->fy-actor_radius <= (float)(cast->actor[i]->py+n+1))
									{
										test = true;
									}
									
									if (cast->actor[i]->fx+actor_radius >= (float)(cast->actor[i]->px+m) &&
										cast->actor[i]->fx+actor_radius <= (float)(cast->actor[i]->px+m+1) &&
										cast->actor[i]->fy-actor_radius >= (float)(cast->actor[i]->py+n) &&
										cast->actor[i]->fy-actor_radius <= (float)(cast->actor[i]->py+n+1))
									{
										test = true;
									}
			
									if (cast->actor[i]->fx-actor_radius >= (float)(cast->actor[i]->px+m) &&
										cast->actor[i]->fx-actor_radius <= (float)(cast->actor[i]->px+m+1) &&
										cast->actor[i]->fy+actor_radius >= (float)(cast->actor[i]->py+n) &&
										cast->actor[i]->fy+actor_radius <= (float)(cast->actor[i]->py+n+1))
									{
										test = true;
									}
			
									if (cast->actor[i]->fx+actor_radius >= (float)(cast->actor[i]->px+m) &&
										cast->actor[i]->fx+actor_radius <= (float)(cast->actor[i]->px+m+1) &&
										cast->actor[i]->fy+actor_radius >= (float)(cast->actor[i]->py+n) &&
										cast->actor[i]->fy+actor_radius <= (float)(cast->actor[i]->py+n+1))
									{
										test = true;
									}
								}
							}
						}
					}
	
					if (test == true)
					{
						cast->actor[i]->fx -= mx;
						cast->actor[i]->fy -= my;
	
						cast->actor[i]->tx = cast->actor[i]->fx;
						cast->actor[i]->ty = cast->actor[i]->fy;
					}
	
					cast->actor[i]->px = (int)cast->actor[i]->fx;
					cast->actor[i]->py = (int)(cast->actor[i]->fy);
	
					if (cast->actor[i]->px < 0 || cast->actor[i]->py < 0 || cast->actor[i]->px >= 100 || cast->actor[i]->py >= 100)
					{
						cast->actor[i]->fx -= mx;
						cast->actor[i]->fy -= my;
					
						cast->actor[i]->px = (int)(cast->actor[i]->fx);
						cast->actor[i]->py = (int)(cast->actor[i]->fy);
	
						cast->actor[i]->tx = cast->actor[i]->fx;
						cast->actor[i]->ty = cast->actor[i]->fy;
					}
		
					if (field[stats->current_field]->tile[cast->actor[i]->px][cast->actor[i]->py]->growth > 0) 
					{
						cast->actor[i]->fx -= mx;
						cast->actor[i]->fy -= my;
					
						cast->actor[i]->px = (int)(cast->actor[i]->fx);
						cast->actor[i]->py = (int)(cast->actor[i]->fy);
	
						cast->actor[i]->tx = cast->actor[i]->fx;
						cast->actor[i]->ty = cast->actor[i]->fy;
					}
	
					if (fabs(cast->actor[i]->fx - cast->actor[i]->tx) <= actor_speed) cast->actor[i]->tx = cast->actor[i]->fx;
					if (fabs(cast->actor[i]->fy - cast->actor[i]->ty) <= actor_speed) cast->actor[i]->ty = cast->actor[i]->fy;
	
					if (cast->actor[i]->type == ACTOR_TYPE_ROVER && cast->actor[i]->affection == 0) actor_speed *= 2.0f;
				}
	
				if (cast->actor[i]->animation_type == 0)
				{
					cast->actor[i]->animation_timer = 0.0f;
				}
			}
		}
	}

	if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100 &&
		stats->px >= 0 && stats->px < 100 && stats->py >= 0 && stats->py < 100)
	{
		if (field[stats->current_field]->tile[stats->px][stats->py]->type == TILE_TYPE_CLOSED_DOOR)
		{
			if ((field[stats->current_field]->tile[stats->px][stats->py]->growth == -3 ||
				field[stats->current_field]->tile[stats->px][stats->py]->growth == -6 ||
				field[stats->current_field]->tile[stats->px][stats->py]->growth == -10) && stats->hour >= 17) // rover building and mine
			{
				// keep it closed
			}
			else if ((field[stats->current_field]->tile[stats->px][stats->py]->growth == -8 ||
				field[stats->current_field]->tile[stats->px][stats->py]->growth == -9) && 
				(stats->hour >= 17 || stats->day_of_week == 1 || stats->day_of_week == 7 ||
				((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) ||
				(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25)))))) // shops, festivals and weekends
			{
				// keep it closed
			}
			else
			{
				field[stats->current_field]->tile[stats->px][stats->py]->type = TILE_TYPE_OPEN_DOOR;

				if ((field[stats->current_field]->tile[stats->px][stats->py]->style == 1 ||
					field[stats->current_field]->tile[stats->px][stats->py]->style == 2) &&
					stats->current_field != 5)
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Door.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Door.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
			}
		}

		if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CLOSED_DOOR)
		{
			if ((field[stats->current_field]->tile[stats->dx][stats->dy]->growth == -3 ||
				field[stats->current_field]->tile[stats->dx][stats->dy]->growth == -6 ||
				field[stats->current_field]->tile[stats->dx][stats->dy]->growth == -10) && stats->hour >= 17) // rover building and mine 
			{
				// keep it closed
			}
			else if ((field[stats->current_field]->tile[stats->dx][stats->dy]->growth == -8 ||
				field[stats->current_field]->tile[stats->dx][stats->dy]->growth == -9) && 
				(stats->hour >= 17 || stats->day_of_week == 1 || stats->day_of_week == 7 ||
				((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) ||
				(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
				(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25)))))) // shops, festivals and weekends
			{
				// keep it closed
			}
			else
			{
				field[stats->current_field]->tile[stats->dx][stats->dy]->type = TILE_TYPE_OPEN_DOOR;

				if ((field[stats->current_field]->tile[stats->dx][stats->dy]->style == 1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->style == 2) &&
					stats->current_field != 5)
				{
					if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Door.wav &");
					else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Door.wav"), NULL, SND_FILENAME | SND_ASYNC);
				}
			}
		}

		for (int i=-1; i<=1; i++)
		{
			for (int j=-1; j<=1; j++)
			{
				if (stats->px+i >= 0 && stats->px+i < 100 && stats->py+j >= 0 && stats->py+j < 100)
				{
					if (field[stats->current_field]->tile[stats->px+i][stats->py+j]->type == TILE_TYPE_CLOSED_DOOR) //&&
						//field[stats->current_field]->tile[stats->px+i][stats->py+j]->style == 0)
					{
						if ((field[stats->current_field]->tile[stats->px+i][stats->py+j]->growth == -3 ||
							field[stats->current_field]->tile[stats->px+i][stats->py+j]->growth == -6 ||
							field[stats->current_field]->tile[stats->px+i][stats->py+j]->growth == -10) && stats->hour >= 17) // rover building and mine
						{
							// keep it closed
						}
						else if ((field[stats->current_field]->tile[stats->px+i][stats->py+j]->growth == -8 ||
							field[stats->current_field]->tile[stats->px+i][stats->py+j]->growth == -9) &&
							(stats->hour >= 17 || stats->day_of_week == 1 || stats->day_of_week == 7 ||
							((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
							(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) ||
							(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
							(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25)))))) // shops, festivals and weekends
						{
							// keep it closed
						}
						else
						{
							field[stats->current_field]->tile[stats->px+i][stats->py+j]->type = TILE_TYPE_OPEN_DOOR;

							if ((field[stats->current_field]->tile[stats->px+i][stats->py+j]->style == 1 ||
								field[stats->current_field]->tile[stats->px+i][stats->py+j]->style == 2) &&
								stats->current_field != 5)
							{
								if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Door.wav &");
								else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Door.wav"), NULL, SND_FILENAME | SND_ASYNC);
							}
						}
					}
				}
			}
		}
	}

	if (field[stats->current_field]->tile[stats->px][stats->py]->type == TILE_TYPE_OPEN_DOOR)
	{
		stats->other_field = -field[stats->current_field]->tile[stats->px][stats->py]->growth - 1;

		if ((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
			(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25)))) // festivals
		{
			if (stats->current_field == 10 && stats->other_field == 6) // leaving church for first time
			{
				if (cast->actor[26]->present_field == 10)
				{
					cast->actor[26]->type = ACTOR_TYPE_DAVID;
					cast->actor[26]->fx = 54.5f;
					cast->actor[26]->fy = 41.5f;
					cast->actor[26]->px = 54;
					cast->actor[26]->py = 41;
					cast->actor[26]->present_field = 6;
					cast->actor[26]->rx1 = 53.0f;
					cast->actor[26]->ry1 = 40.0f;
					cast->actor[26]->rx2 = 62.0f;
					cast->actor[26]->ry2 = 49.0f;
					cast->actor[26]->tx = 54.5f;
					cast->actor[26]->ty = 41.5f;
					cast->actor[26]->animation_type = 0;
	
					cast->actor[26]->primary_color[1] = 0.5f;
					cast->actor[26]->secondary_color[0] = 1.0f;
					cast->actor[26]->secondary_color[1] = 1.0f;
					cast->actor[26]->secondary_color[2] = 1.0f;
				}
		
				if (cast->actor[27]->present_field == 10)
				{
					cast->actor[27]->type = ACTOR_TYPE_CLARA;
					cast->actor[27]->fx = 61.5f;
					cast->actor[27]->fy = 41.5f;
					cast->actor[27]->px = 61;
					cast->actor[27]->py = 41;
					cast->actor[27]->present_field = 6;
					cast->actor[27]->rx1 = 53.0f;
					cast->actor[27]->ry1 = 40.0f;
					cast->actor[27]->rx2 = 62.0f;
					cast->actor[27]->ry2 = 49.0f;
					cast->actor[27]->tx = 54.5f;
					cast->actor[27]->ty = 41.5f;
					cast->actor[27]->animation_type = 0;

					cast->actor[27]->primary_color[0] = 0.5f;
					cast->actor[27]->secondary_color[0] = 1.0f;
					cast->actor[27]->secondary_color[1] = 1.0f;
					cast->actor[27]->secondary_color[2] = 1.0f;
				}

				if (cast->actor[28]->present_field == 10)
				{
					cast->actor[28]->type = ACTOR_TYPE_ANDREW;
					cast->actor[28]->fx = 54.5f;
					cast->actor[28]->fy = 48.5f;
					cast->actor[28]->px = 54;
					cast->actor[28]->py = 48;
					cast->actor[28]->present_field = 6;
					cast->actor[28]->rx1 = 53.0f;
					cast->actor[28]->ry1 = 40.0f;
					cast->actor[28]->rx2 = 62.0f;
					cast->actor[28]->ry2 = 49.0f;
					cast->actor[28]->tx = 54.5f;
					cast->actor[28]->ty = 48.5f;
					cast->actor[28]->animation_type = 0;

					cast->actor[28]->primary_color[2] = 0.5f;
					cast->actor[28]->secondary_color[0] = 1.0f;
					cast->actor[28]->secondary_color[1] = 1.0f;
					cast->actor[28]->secondary_color[2] = 1.0f;
				}
	
				if (cast->actor[29]->present_field == 10)
				{
					cast->actor[29]->type = ACTOR_TYPE_EMILY;
					cast->actor[29]->fx = 61.5f;
					cast->actor[29]->fy = 48.5f;
					cast->actor[29]->px = 61;
					cast->actor[29]->py = 48;
					cast->actor[29]->present_field = 6;
					cast->actor[29]->rx1 = 53.0f;
					cast->actor[29]->ry1 = 40.0f;
					cast->actor[29]->rx2 = 62.0f;
					cast->actor[29]->ry2 = 49.0f;
					cast->actor[29]->tx = 54.5f;
					cast->actor[29]->ty = 48.5f;
					cast->actor[29]->animation_type = 0;

					cast->actor[29]->primary_color[0] = 0.5f;
					cast->actor[29]->primary_color[2] = 0.5f;
					cast->actor[29]->secondary_color[0] = 1.0f;
					cast->actor[29]->secondary_color[1] = 1.0f;
					cast->actor[29]->secondary_color[2] = 1.0f;
				}
			}
		}

		for (int i=0; i<100; i++)
		{
			for (int j=0; j<100; j++)
			{
				if ((field[stats->other_field]->tile[i][j]->type == TILE_TYPE_OPEN_DOOR ||
					field[stats->other_field]->tile[i][j]->type == TILE_TYPE_CLOSED_DOOR) &&
					-field[stats->other_field]->tile[i][j]->growth - 1 == stats->current_field)
				{
					if (i+1 < 100 && field[stats->other_field]->tile[i+1][j]->type != TILE_TYPE_NONE &&
						field[stats->other_field]->tile[i+1][j]->type != TILE_TYPE_OPEN_DOOR &&
						field[stats->other_field]->tile[i+1][j]->type != TILE_TYPE_CLOSED_DOOR &&
						field[stats->other_field]->tile[i+1][j]->growth <= 0)
					{
						if (stats->animation_timer >= 0.0f)
						{
							stats->animation_timer = -10.0f;

							if ((stats->current_field == 3 && stats->other_field == 0) ||
								(stats->current_field == 0 && stats->other_field == 3) ||
								(stats->current_field == 3 && stats->other_field == 4) ||
								(stats->current_field == 4 && stats->other_field == 3) ||
								(stats->current_field == 3 && stats->other_field == 6) ||
								(stats->current_field == 6 && stats->other_field == 3))
							{
								stats->minute += 25;

								if (stats->minute > 60)
								{
									stats->minute = 0;
				
									stats->hour++;
				
									if (stats->hour >= 18)
									{
										stats->hour = 18;
									}
								}
							}

							if (stats->hour >= 18 && 
								!((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
								(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) ||
								(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
								(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season-1 && stats->days_in_a_season < 25))))) // festivals
							{
								cast->actor[26]->type = ACTOR_TYPE_DAVID;
								cast->actor[26]->fx = 0.5f;
								cast->actor[26]->fy = 0.5f;
								cast->actor[26]->px = 0;
								cast->actor[26]->py = 0;
								cast->actor[26]->present_field = -1;

								cast->actor[27]->type = ACTOR_TYPE_CLARA;
								cast->actor[27]->fx = 0.5f;
								cast->actor[27]->fy = 0.5f;
								cast->actor[27]->px = 0;
								cast->actor[27]->py = 0;
								cast->actor[27]->present_field = -1;

								cast->actor[28]->type = ACTOR_TYPE_ANDREW;
								cast->actor[28]->fx = 0.5f;
								cast->actor[28]->fy = 0.5f;
								cast->actor[28]->px = 0;
								cast->actor[28]->py = 0;
								cast->actor[28]->present_field = -1;

								cast->actor[29]->type = ACTOR_TYPE_EMILY;
								cast->actor[29]->fx = 0.5f;
								cast->actor[29]->fy = 0.5f;
								cast->actor[29]->px = 0;
								cast->actor[29]->py = 0;
								cast->actor[29]->present_field = -1;
							}
						}
						else if (stats->animation_timer < 0.0f && stats->animation_timer > -5.0f)
						{
							stats->px = i + 1;
							stats->py = j;
	
							stats->fx = (float)i + 1.0f + 0.5f;
							stats->fy = (float)j + 0.5f;
	
							stats->rot = 0.0f;
							stats->dx = stats->px + 1;
							stats->dy = stats->py;

							if (stats->current_field == 0 && stats->other_field == 3)
							{
								cast->actor[25]->type = ACTOR_TYPE_PARROT; // festivals
								cast->actor[25]->present_field = -1;
							}

							stats->current_field = stats->other_field;
						}
	
						i = 101;
						j = 101;
					}
					else if (i-1 >= 0 && field[stats->other_field]->tile[i-1][j]->type != TILE_TYPE_NONE &&
						field[stats->other_field]->tile[i-1][j]->type != TILE_TYPE_OPEN_DOOR &&
						field[stats->other_field]->tile[i-1][j]->type != TILE_TYPE_CLOSED_DOOR &&
						field[stats->other_field]->tile[i-1][j]->growth <= 0)
					{
						if (stats->animation_timer >= 0.0f)
						{
							stats->animation_timer = -10.0f;

							if ((stats->current_field == 3 && stats->other_field == 0) ||
								(stats->current_field == 0 && stats->other_field == 3) ||
								(stats->current_field == 3 && stats->other_field == 4) ||
								(stats->current_field == 4 && stats->other_field == 3) ||
								(stats->current_field == 3 && stats->other_field == 6) ||
								(stats->current_field == 6 && stats->other_field == 3))
							{
								stats->minute += 25;

								if (stats->minute > 60)
								{
									stats->minute = 0;
				
									stats->hour++;
				
									if (stats->hour >= 18)
									{
										stats->hour = 18;
									}
								}
							}

							if (stats->hour >= 18 && 
								!((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
								(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) ||
								(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
								(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season-1 && stats->days_in_a_season < 25))))) // festivals
							{
								cast->actor[26]->type = ACTOR_TYPE_DAVID;
								cast->actor[26]->fx = 0.5f;
								cast->actor[26]->fy = 0.5f;
								cast->actor[26]->px = 0;
								cast->actor[26]->py = 0;
								cast->actor[26]->present_field = -1;

								cast->actor[27]->type = ACTOR_TYPE_CLARA;
								cast->actor[27]->fx = 0.5f;
								cast->actor[27]->fy = 0.5f;
								cast->actor[27]->px = 0;
								cast->actor[27]->py = 0;
								cast->actor[27]->present_field = -1;

								cast->actor[28]->type = ACTOR_TYPE_ANDREW;
								cast->actor[28]->fx = 0.5f;
								cast->actor[28]->fy = 0.5f;
								cast->actor[28]->px = 0;
								cast->actor[28]->py = 0;
								cast->actor[28]->present_field = -1;

								cast->actor[29]->type = ACTOR_TYPE_EMILY;
								cast->actor[29]->fx = 0.5f;
								cast->actor[29]->fy = 0.5f;
								cast->actor[29]->px = 0;
								cast->actor[29]->py = 0;
								cast->actor[29]->present_field = -1;
							}
						}
						else if (stats->animation_timer < 0.0f && stats->animation_timer > -5.0f)
						{
							stats->px = i - 1;
							stats->py = j;

							stats->fx = (float)i - 1.0f + 0.5f;
							stats->fy = (float)j + 0.5f;
	
							stats->rot = 3.14159f;
							stats->dx = stats->px - 1;
							stats->dy = stats->py;

							if (stats->current_field == 0 && stats->other_field == 3)
							{
								cast->actor[25]->type = ACTOR_TYPE_PARROT; // festivals
								cast->actor[25]->present_field = -1;
							}

							stats->current_field = stats->other_field;
						}

						i = 101;
						j = 101;
					}
					else if (j+1 < 100 && field[stats->other_field]->tile[i][j+1]->type != TILE_TYPE_NONE &&
						field[stats->other_field]->tile[i][j+1]->type != TILE_TYPE_OPEN_DOOR &&
						field[stats->other_field]->tile[i][j+1]->type != TILE_TYPE_CLOSED_DOOR &&
						field[stats->other_field]->tile[i][j+1]->growth <= 0)
					{
						if (stats->animation_timer >= 0.0f)
						{
							stats->animation_timer = -10.0f;

							if ((stats->current_field == 3 && stats->other_field == 0) ||
								(stats->current_field == 0 && stats->other_field == 3) ||
								(stats->current_field == 3 && stats->other_field == 4) ||
								(stats->current_field == 4 && stats->other_field == 3) ||
								(stats->current_field == 3 && stats->other_field == 6) ||
								(stats->current_field == 6 && stats->other_field == 3))
							{
								stats->minute += 25;

								if (stats->minute > 60)
								{
									stats->minute = 0;
				
									stats->hour++;
				
									if (stats->hour >= 18)
									{
										stats->hour = 18;
									}
								}
							}

							if (stats->hour >= 18 && 
								!((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
								(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) ||
								(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
								(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season-1 && stats->days_in_a_season < 25))))) // festivals
							{
								cast->actor[26]->type = ACTOR_TYPE_DAVID;
								cast->actor[26]->fx = 0.5f;
								cast->actor[26]->fy = 0.5f;
								cast->actor[26]->px = 0;
								cast->actor[26]->py = 0;
								cast->actor[26]->present_field = -1;

								cast->actor[27]->type = ACTOR_TYPE_CLARA;
								cast->actor[27]->fx = 0.5f;
								cast->actor[27]->fy = 0.5f;
								cast->actor[27]->px = 0;
								cast->actor[27]->py = 0;
								cast->actor[27]->present_field = -1;

								cast->actor[28]->type = ACTOR_TYPE_ANDREW;
								cast->actor[28]->fx = 0.5f;
								cast->actor[28]->fy = 0.5f;
								cast->actor[28]->px = 0;
								cast->actor[28]->py = 0;
								cast->actor[28]->present_field = -1;

								cast->actor[29]->type = ACTOR_TYPE_EMILY;
								cast->actor[29]->fx = 0.5f;
								cast->actor[29]->fy = 0.5f;
								cast->actor[29]->px = 0;
								cast->actor[29]->py = 0;
								cast->actor[29]->present_field = -1;
							}
						}
						else if (stats->animation_timer < 0.0f && stats->animation_timer > -5.0f)
						{
							stats->px = i;
							stats->py = j + 1;

							stats->fx = (float)i + 0.5f;
							stats->fy = (float)j + 1.0f + 0.5f;
	
							stats->rot = 3.0f * 3.14159f / 2.0f;
							stats->dx = stats->px;
							stats->dy = stats->py + 1;

							if (stats->current_field == 0 && stats->other_field == 3)
							{
								cast->actor[25]->type = ACTOR_TYPE_PARROT; // festivals
								cast->actor[25]->present_field = -1;
							}

							stats->current_field = stats->other_field;
						}

						i = 101;
						j = 101;
					}
					else if (j+1 >= 0 && field[stats->other_field]->tile[i][j-1]->type != TILE_TYPE_NONE &&
						field[stats->other_field]->tile[i][j-1]->type != TILE_TYPE_OPEN_DOOR &&
						field[stats->other_field]->tile[i][j-1]->type != TILE_TYPE_CLOSED_DOOR &&
						field[stats->other_field]->tile[i][j-1]->growth <= 0)
					{
						if (stats->animation_timer >= 0.0f)
						{
							stats->animation_timer = -10.0f;

							if ((stats->current_field == 3 && stats->other_field == 0) ||
								(stats->current_field == 0 && stats->other_field == 3) ||
								(stats->current_field == 3 && stats->other_field == 4) ||
								(stats->current_field == 4 && stats->other_field == 3) ||
								(stats->current_field == 3 && stats->other_field == 6) ||
								(stats->current_field == 6 && stats->other_field == 3))
							{
								stats->minute += 25;

								if (stats->minute >= 60)
								{
									stats->minute = 0;
				
									stats->hour++;
				
									if (stats->hour >= 18)
									{
										stats->hour = 18;
									}
								}
							}

							if (stats->hour >= 18 && 
								!((stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
								(stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) ||
								(stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) ||
								(stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season-1 && stats->days_in_a_season < 25))))) // festivals
							{
								cast->actor[26]->type = ACTOR_TYPE_DAVID;
								cast->actor[26]->fx = 0.5f;
								cast->actor[26]->fy = 0.5f;
								cast->actor[26]->px = 0;
								cast->actor[26]->py = 0;
								cast->actor[26]->present_field = -1;

								cast->actor[27]->type = ACTOR_TYPE_CLARA;
								cast->actor[27]->fx = 0.5f;
								cast->actor[27]->fy = 0.5f;
								cast->actor[27]->px = 0;
								cast->actor[27]->py = 0;
								cast->actor[27]->present_field = -1;

								cast->actor[28]->type = ACTOR_TYPE_ANDREW;
								cast->actor[28]->fx = 0.5f;
								cast->actor[28]->fy = 0.5f;
								cast->actor[28]->px = 0;
								cast->actor[28]->py = 0;
								cast->actor[28]->present_field = -1;

								cast->actor[29]->type = ACTOR_TYPE_EMILY;
								cast->actor[29]->fx = 0.5f;
								cast->actor[29]->fy = 0.5f;
								cast->actor[29]->px = 0;
								cast->actor[29]->py = 0;
								cast->actor[29]->present_field = -1;
							}
						}
						else if (stats->animation_timer < 0.0f && stats->animation_timer > -5.0f)
						{
							stats->px = i;
							stats->py = j - 1;

							stats->fx = (float)i + 0.5f;
							stats->fy = (float)j - 1.0f + 0.5f;

							stats->rot = 3.14159f / 2.0f;
							stats->dx = stats->px;
							stats->dy = stats->py - 1;

							if (stats->current_field == 0 && stats->other_field == 3)
							{
								cast->actor[25]->type = ACTOR_TYPE_PARROT; // festivals
								cast->actor[25]->present_field = -1;
							}

							stats->current_field = stats->other_field;
						}

						i = 101;
						j = 101;
					}
				}
			}
		}			
	}

	if (stats->countdown >= 0)
	{
		for (int i=0; i<100; i++)	
		{
			for (int j=0; j<100; j++)
			{
				if (field[stats->current_field]->tile[i][j]->type == TILE_TYPE_MATCHING_CHALLENGE &&
					field[stats->current_field]->tile[i][j]->growth == 99)
				{
					for (int a=0; a<100; a++)
					{
						for (int b=0; b<100; b++)
						{
							if (field[stats->current_field]->tile[a][b]->type == TILE_TYPE_MATCHING_CHALLENGE &&
								field[stats->current_field]->tile[a][b]->growth == 99 && (a != i || b != j))
							{
								if (field[stats->current_field]->tile[i][j]->style == field[stats->current_field]->tile[a][b]->style)
								{
									field[stats->current_field]->tile[i][j]->growth = 100;
									field[stats->current_field]->tile[a][b]->growth = 100;

									if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Credits.wav &");
									else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Credits.wav"), NULL, SND_FILENAME | SND_ASYNC);
								}
								else
								{
									field[stats->current_field]->tile[i][j]->growth = 1;
									field[stats->current_field]->tile[a][b]->growth = 1;
								}
							}
						}
					}
				}
			}
		}
	}

	return;
};

void InitializeFields(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats)
{
	for (int f=0; f<=10; f++)
	{
		for (int i=0; i<100; i++)
		{
			for (int j=0; j<100; j++)
			{
				field[f]->tile[i][j]->growth = 0; // just incase
			}
		}
	}

	// player's field	

	for (int i=0; i<100; i++)
	{
		for (int j=0; j<100; j++)
		{
			field[0]->tile[i][j]->type = TILE_TYPE_DIRT;

			if (((i >= 23 && i <= 32) || (i >= 35 && i <= 44)) && j <= 20)
			{
				// nothing
			}
			else if ((j >= 20 && j <= 26) && i <= 20)
			{
				// nothing
			}
			else
			{
				if (rand() % 100 < 1)
				{
					field[0]->tile[i][j]->type = TILE_TYPE_ROCK;
	
					field[0]->tile[i][j]->growth = 5;
					field[0]->tile[i][j]->style = rand() % 3;
				}
				else if (rand() % 100 < 2)
				{
					field[0]->tile[i][j]->type = TILE_TYPE_WEED;
			
					field[0]->tile[i][j]->growth = 1;
					field[0]->tile[i][j]->style = rand() % 3;
				}
				else if (rand() % 100 < 10)
				{
					if (i < 20 || j < 20 || i >= 80 || j >= 80)
					{
						field[0]->tile[i][j]->type = TILE_TYPE_WALL;
						
						field[0]->tile[i][j]->growth = 1;
						field[0]->tile[i][j]->style = rand() % 5;
					}
				}
			}
		}
	}

	for (int i=20; i<80; i++)
	{
		if (!((i >= 23 && i <= 32) || (i >= 35 && i <= 44)))
		{
			field[0]->tile[i][20]->type = TILE_TYPE_WALL;
			field[0]->tile[i][20]->growth = 1;
			field[0]->tile[i][20]->style = rand() % 5;
		}

		field[0]->tile[i][79]->type = TILE_TYPE_WALL;
		field[0]->tile[i][79]->growth = 1;
		field[0]->tile[i][79]->style = rand() % 5;

		if (!(i >= 22 && i <= 24))
		{
			field[0]->tile[20][i]->type = TILE_TYPE_WALL;
			field[0]->tile[20][i]->growth = 1;
			field[0]->tile[20][i]->style = rand() % 5;
		}

		field[0]->tile[79][i]->type = TILE_TYPE_WALL;
		field[0]->tile[79][i]->growth = 1;
		field[0]->tile[79][i]->style = rand() % 5;
	}

	field[0]->tile[21][26]->type = TILE_TYPE_PATH;
	field[0]->tile[21][26]->growth = 0;
	field[0]->tile[21][26]->style = 0;
	field[0]->tile[22][26]->type = TILE_TYPE_PATH;
	field[0]->tile[22][26]->growth = 0;
	field[0]->tile[22][26]->style = 0;
	field[0]->tile[22][24]->type = TILE_TYPE_PATH;
	field[0]->tile[22][24]->growth = 0;
	field[0]->tile[22][24]->style = 0;
	field[0]->tile[22][25]->type = TILE_TYPE_PATH;
	field[0]->tile[22][25]->growth = 0;
	field[0]->tile[22][25]->style = 0;
	field[0]->tile[23][25]->type = TILE_TYPE_PATH;
	field[0]->tile[23][25]->growth = 0;
	field[0]->tile[23][25]->style = 0;
	field[0]->tile[23][23]->type = TILE_TYPE_PATH;
	field[0]->tile[23][23]->growth = 0;
	field[0]->tile[23][23]->style = 0;
	field[0]->tile[23][24]->type = TILE_TYPE_PATH;
	field[0]->tile[23][24]->growth = 0;
	field[0]->tile[23][24]->style = 0;
	field[0]->tile[24][24]->type = TILE_TYPE_PATH;
	field[0]->tile[24][24]->growth = 0;
	field[0]->tile[24][24]->style = 0;
	field[0]->tile[24][23]->type = TILE_TYPE_PATH;
	field[0]->tile[24][23]->growth = 0;
	field[0]->tile[24][23]->style = 0;
	field[0]->tile[25][23]->type = TILE_TYPE_PATH;
	field[0]->tile[25][23]->growth = 0;
	field[0]->tile[25][23]->style = 0;

	field[0]->tile[23][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[23][21]->growth = 1;
	field[0]->tile[23][21]->style = 0;
	field[0]->tile[24][21]->type = TILE_TYPE_CLOSED_DOOR;
	field[0]->tile[24][21]->growth = -2;
	field[0]->tile[24][21]->style = 1;
	field[0]->tile[25][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[25][21]->growth = 1;
	field[0]->tile[25][21]->style = 0;
	field[0]->tile[26][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[26][21]->growth = 1;
	field[0]->tile[26][21]->style = 0;
	field[0]->tile[27][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[27][21]->growth = 1;
	field[0]->tile[27][21]->style = 0;
	field[0]->tile[28][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[28][21]->growth = 1;
	field[0]->tile[28][21]->style = 0;
	field[0]->tile[29][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[29][21]->growth = 1;
	field[0]->tile[29][21]->style = 0;
	field[0]->tile[30][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[30][21]->growth = 1;
	field[0]->tile[30][21]->style = 0;
	field[0]->tile[31][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[31][21]->growth = 1;
	field[0]->tile[31][21]->style = 0;
	field[0]->tile[32][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[32][21]->growth = 1;
	field[0]->tile[32][21]->style = 0;

	for (int i=23; i<=32; i++)
	{
		for (int j=11; j<=20; j++)
		{
			field[0]->tile[i][j]->type = TILE_TYPE_BOUNDED;
			field[0]->tile[i][j]->growth = 1;
			field[0]->tile[i][j]->style = 0;
		}
	}

	field[0]->tile[35][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[35][21]->growth = 1;
	field[0]->tile[35][21]->style = 0;
	field[0]->tile[36][21]->type = TILE_TYPE_CLOSED_DOOR;
	field[0]->tile[36][21]->growth = -3;
	field[0]->tile[36][21]->style = 1;
	field[0]->tile[37][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[37][21]->growth = 1;
	field[0]->tile[37][21]->style = 0;
	field[0]->tile[38][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[38][21]->growth = 1;
	field[0]->tile[38][21]->style = 0;
	field[0]->tile[39][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[39][21]->growth = 1;
	field[0]->tile[39][21]->style = 0;
	field[0]->tile[40][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[40][21]->growth = 1;
	field[0]->tile[40][21]->style = 0;
	field[0]->tile[41][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[41][21]->growth = 1;
	field[0]->tile[41][21]->style = 0;
	field[0]->tile[42][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[42][21]->growth = 1;
	field[0]->tile[42][21]->style = 0;
	field[0]->tile[43][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[43][21]->growth = 1;
	field[0]->tile[43][21]->style = 0;
	field[0]->tile[44][21]->type = TILE_TYPE_BOUNDED;
	field[0]->tile[44][21]->growth = 1;
	field[0]->tile[44][21]->style = 0;

	for (int i=35; i<=44; i++)
	{
		for (int j=11; j<=20; j++)
		{
			field[0]->tile[i][j]->type = TILE_TYPE_BOUNDED;
			field[0]->tile[i][j]->growth = 1;
			field[0]->tile[i][j]->style = 0;
		}
	}

	for (int i=0; i<=19; i++)
	{
		field[0]->tile[i][22]->type = TILE_TYPE_PATH;
		field[0]->tile[i][22]->growth = 1;
		field[0]->tile[i][22]->style = 0;
		field[0]->tile[i][23]->type = TILE_TYPE_PATH;
		field[0]->tile[i][23]->growth = 1;
		field[0]->tile[i][23]->style = 0;
		field[0]->tile[i][24]->type = TILE_TYPE_PATH;
		field[0]->tile[i][24]->growth = 1;
		field[0]->tile[i][24]->style = 0;
	}

	field[0]->tile[21][21]->type = TILE_TYPE_PATH;
	field[0]->tile[21][21]->growth = 0;
	field[0]->tile[21][21]->style = 0;
	field[0]->tile[22][21]->type = TILE_TYPE_PATH;
	field[0]->tile[22][21]->growth = 0;
	field[0]->tile[22][21]->style = 0;
	field[0]->tile[20][22]->type = TILE_TYPE_CLOSED_DOOR;
	field[0]->tile[20][22]->growth = -4;
	field[0]->tile[20][22]->style = 0;
	field[0]->tile[20][23]->type = TILE_TYPE_CLOSED_DOOR;
	field[0]->tile[20][23]->growth = -4;
	field[0]->tile[20][23]->style = 0;
	field[0]->tile[20][24]->type = TILE_TYPE_CLOSED_DOOR;
	field[0]->tile[20][24]->growth = -4;
	field[0]->tile[20][24]->style = 0;
	field[0]->tile[21][22]->type = TILE_TYPE_PATH;
	field[0]->tile[21][22]->growth = 0;
	field[0]->tile[21][22]->style = 0;
	field[0]->tile[21][23]->type = TILE_TYPE_PATH;
	field[0]->tile[21][23]->growth = 0;
	field[0]->tile[21][23]->style = 0;
	field[0]->tile[21][24]->type = TILE_TYPE_PATH;
	field[0]->tile[21][24]->growth = 0;
	field[0]->tile[21][24]->style = 0;
	field[0]->tile[21][25]->type = TILE_TYPE_PATH;
	field[0]->tile[21][25]->growth = 0;
	field[0]->tile[21][25]->style = 0;
	field[0]->tile[22][22]->type = TILE_TYPE_PATH;
	field[0]->tile[22][22]->growth = 0;
	field[0]->tile[22][22]->style = 0;
	field[0]->tile[22][23]->type = TILE_TYPE_PATH;
	field[0]->tile[22][23]->growth = 0;
	field[0]->tile[22][23]->style = 0;
	field[0]->tile[23][22]->type = TILE_TYPE_PATH;
	field[0]->tile[23][22]->growth = 0;
	field[0]->tile[23][22]->style = 0;

	for (int i=24; i<=36; i++)
	{
		field[0]->tile[i][22]->type = TILE_TYPE_PATH;
		field[0]->tile[i][22]->growth = 0;
		field[0]->tile[i][22]->style = 0;
		field[0]->tile[i][23]->type = TILE_TYPE_PATH;
		field[0]->tile[i][23]->growth = 0;
		field[0]->tile[i][23]->style = 0;
	}

	field[0]->tile[36][24]->type = TILE_TYPE_PATH;
	field[0]->tile[36][24]->growth = 0;
	field[0]->tile[36][24]->style = 0;
	field[0]->tile[36][25]->type = TILE_TYPE_PATH;
	field[0]->tile[36][25]->growth = 0;
	field[0]->tile[36][25]->style = 0;
	
	for (int i=36; i<=44; i++)
	{
		field[0]->tile[i][25]->type = TILE_TYPE_PATH;
		field[0]->tile[i][25]->growth = 0;
		field[0]->tile[i][25]->style = 0;
	}

	for (int i=0; i<=20; i++)
	{
		field[0]->tile[i][27]->type = TILE_TYPE_PATH;
		field[0]->tile[i][27]->growth = 0;
		field[0]->tile[i][27]->style = 0;
	}

	field[0]->tile[21][27]->type = TILE_TYPE_EXCHANGER;
	field[0]->tile[21][27]->growth = 1;

	field[0]->tile[44][24]->type = TILE_TYPE_WATER_GENERATOR;
	field[0]->tile[44][24]->growth = 100;

	field[0]->tile[33][21]->type = TILE_TYPE_EXTRACTOR;
	field[0]->tile[33][21]->growth = 1;
	field[0]->tile[34][21]->type = TILE_TYPE_EXTRACTOR;
	field[0]->tile[34][21]->growth = 1;

	cast->actor[22]->type = ACTOR_TYPE_WEATHER_GAUGE;
	cast->actor[22]->fx = 22.5f;
	cast->actor[22]->fy = 21.5f;
	cast->actor[22]->px = 22;
	cast->actor[22]->py = 21;
	cast->actor[22]->present_field = 0;
	cast->actor[22]->rx1 = 22.5f;
	cast->actor[22]->ry1 = 21.5f;
	cast->actor[22]->rx2 = 22.5f;
	cast->actor[22]->ry2 = 21.5f;
	cast->actor[22]->tx = 22.5f;
	cast->actor[22]->ty = 21.5f;
	cast->actor[22]->primary_color[0] = 0.5f;
	cast->actor[22]->primary_color[1] = 0.5f;
	cast->actor[22]->primary_color[2] = 0.5f;
	cast->actor[22]->secondary_color[0] = 0.3f;
	cast->actor[22]->secondary_color[1] = 0.3f;
	cast->actor[22]->secondary_color[2] = 0.3f;
	cast->actor[22]->affection = 1;

	// player's house

	for (int i=20; i<=28; i++)
	{
		for (int j=20; j<=30; j++)
		{
			field[1]->tile[i][j]->type = TILE_TYPE_PATH;
			field[1]->tile[i][j]->growth = 0;
			field[1]->tile[i][j]->style = 1;
		}
	}

	for (int i=0; i<=9; i++)
	{
		field[1]->tile[19][21+i]->type = TILE_TYPE_BOUNDED;
		field[1]->tile[19][21+i]->growth = 1;
		field[1]->tile[19][21+i]->style = 1;
	
		field[1]->tile[28][21+i]->type = TILE_TYPE_BOUNDED;
		field[1]->tile[28][21+i]->growth = 1;
		field[1]->tile[28][21+i]->style = 1;
	}

	for (int i=0; i<=9; i++)
	{
		field[1]->tile[19+i][20]->type = TILE_TYPE_BOUNDED;
		field[1]->tile[19+i][20]->growth = 1;
		field[1]->tile[19+i][20]->style = 1;
		
		field[1]->tile[19+i][30]->type = TILE_TYPE_BOUNDED;
		field[1]->tile[19+i][30]->growth = 1;
		field[1]->tile[19+i][30]->style = 1;
	}

	field[1]->tile[20][30]->type = TILE_TYPE_CLOSED_DOOR;
	field[1]->tile[20][30]->growth = -1;
	field[1]->tile[20][30]->style = 2;
	field[1]->tile[20][29]->type = TILE_TYPE_PATH;
	field[1]->tile[20][29]->growth = 0;
	field[1]->tile[20][29]->style = 1;

	field[1]->tile[27][28]->type = TILE_TYPE_ARCADE;
	field[1]->tile[27][28]->growth = 1;

	field[1]->tile[26][22]->type = TILE_TYPE_CHARGING_STATION;
	field[1]->tile[26][22]->growth = 1;

	field[1]->tile[20][21]->type = TILE_TYPE_CONTAINER;
	field[1]->tile[20][21]->growth = TOOL_TYPE_NONE+1;
	field[1]->tile[20][21]->style = 0;
	field[1]->tile[20][22]->type = TILE_TYPE_CONTAINER;
	field[1]->tile[20][22]->growth = TOOL_TYPE_NONE+1;
	field[1]->tile[20][22]->style = 0;
	field[1]->tile[20][23]->type = TILE_TYPE_CONTAINER;
	field[1]->tile[20][23]->growth = TOOL_TYPE_NONE+1;
	field[1]->tile[20][23]->style = 0;
	field[1]->tile[20][24]->type = TILE_TYPE_CONTAINER;
	field[1]->tile[20][24]->growth = TOOL_TYPE_NONE+1;
	field[1]->tile[20][24]->style = 0;
	field[1]->tile[20][25]->type = TILE_TYPE_CONTAINER;
	field[1]->tile[20][25]->growth = TOOL_TYPE_NONE+1;
	field[1]->tile[20][25]->style = 0;
	field[1]->tile[20][26]->type = TILE_TYPE_CONTAINER;
	field[1]->tile[20][26]->growth = TOOL_TYPE_NONE+1;
	field[1]->tile[20][26]->style = 0;

	cast->actor[23]->type = ACTOR_TYPE_TELEVISION;
	cast->actor[23]->fx = 23.5f;
	cast->actor[23]->fy = 21.5f;
	cast->actor[23]->px = 23;
	cast->actor[23]->py = 21;
	cast->actor[23]->present_field = 1;
	cast->actor[23]->rx1 = 23.5f;
	cast->actor[23]->ry1 = 21.5f;
	cast->actor[23]->rx2 = 23.5f;
	cast->actor[23]->ry2 = 21.5f;
	cast->actor[23]->tx = 23.5f;
	cast->actor[23]->ty = 21.5f;
	cast->actor[23]->rot = 0.0f;
	cast->actor[23]->primary_color[0] = 0.5f;
	cast->actor[23]->primary_color[1] = 0.5f;
	cast->actor[23]->primary_color[2] = 0.5f;
	cast->actor[23]->secondary_color[0] = 0.3f;
	cast->actor[23]->secondary_color[1] = 0.3f;
	cast->actor[23]->secondary_color[2] = 0.3f;
	cast->actor[23]->affection = 0;
	
	// player's rover building

	for (int i=20; i<=28; i++)
	{
		for (int j=20; j<=30; j++)
		{
			field[2]->tile[i][j]->type = TILE_TYPE_PATH;
			field[2]->tile[i][j]->growth = 0;
			field[2]->tile[i][j]->style = 1;
		}
	}

	for (int i=0; i<=9; i++)
	{
		field[2]->tile[19][21+i]->type = TILE_TYPE_BOUNDED;
		field[2]->tile[19][21+i]->growth = 1;
		field[2]->tile[19][21+i]->style = 1;
	
		field[2]->tile[28][21+i]->type = TILE_TYPE_BOUNDED;
		field[2]->tile[28][21+i]->growth = 1;
		field[2]->tile[28][21+i]->style = 1;
	}

	for (int i=0; i<=9; i++)
	{
		field[2]->tile[19+i][20]->type = TILE_TYPE_BOUNDED;
		field[2]->tile[19+i][20]->growth = 1;
		field[2]->tile[19+i][20]->style = 1;
		
		field[2]->tile[19+i][30]->type = TILE_TYPE_BOUNDED;
		field[2]->tile[19+i][30]->growth = 1;
		field[2]->tile[19+i][30]->style = 1;
	}

	field[2]->tile[20][30]->type = TILE_TYPE_CLOSED_DOOR;
	field[2]->tile[20][30]->growth = -1;
	field[2]->tile[20][30]->style = 2;
	field[2]->tile[20][29]->type = TILE_TYPE_PATH;
	field[2]->tile[20][29]->growth = 0;
	field[2]->tile[20][29]->style = 1;

	field[2]->tile[20][21]->type = TILE_TYPE_NANOTUBE_DISTRIBUTOR;
	field[2]->tile[20][21]->growth = 1;

	field[2]->tile[22][21]->type = TILE_TYPE_EMPTY_ROVER_STATION;
	field[2]->tile[22][21]->growth = 1;
	field[2]->tile[23][21]->type = TILE_TYPE_EMPTY_ROVER_STATION;
	field[2]->tile[23][21]->growth = 1;
	field[2]->tile[24][21]->type = TILE_TYPE_EMPTY_ROVER_STATION;
	field[2]->tile[24][21]->growth = 1;
	field[2]->tile[25][21]->type = TILE_TYPE_EMPTY_ROVER_STATION;
	field[2]->tile[25][21]->growth = 1;

	field[2]->tile[27][21]->type = TILE_TYPE_EXCHANGER;
	field[2]->tile[27][21]->growth = 1;

	field[2]->tile[27][25]->type = TILE_TYPE_EMPTY_ROVER_DEPOSIT;
	field[2]->tile[27][25]->growth = 1;
	field[2]->tile[27][26]->type = TILE_TYPE_EMPTY_ROVER_DEPOSIT;
	field[2]->tile[27][26]->growth = 1;
	field[2]->tile[27][27]->type = TILE_TYPE_EMPTY_ROVER_DEPOSIT;
	field[2]->tile[27][27]->growth = 1;
	field[2]->tile[27][28]->type = TILE_TYPE_EMPTY_ROVER_DEPOSIT;
	field[2]->tile[27][28]->growth = 1;

	// intersection

	for (int i=0; i<100; i++)
	{
		for (int j=0; j<100; j++)
		{
			field[3]->tile[i][j]->type = TILE_TYPE_DIRT;

			if (rand() % 100 < 1)
			{
				field[3]->tile[i][j]->type = TILE_TYPE_ROCK;
	
				field[3]->tile[i][j]->growth = 5;
				field[3]->tile[i][j]->style = rand() % 3;
			}
			else if (rand() % 100 < 2)
			{
				field[3]->tile[i][j]->type = TILE_TYPE_WEED;
			
				field[3]->tile[i][j]->growth = 1;
				field[3]->tile[i][j]->style = rand() % 3;
			}
			else if (rand() % 100 < 10)
			{
				field[3]->tile[i][j]->type = TILE_TYPE_WALL;
						
				field[3]->tile[i][j]->growth = 1;
				field[3]->tile[i][j]->style = rand() % 5;
			}
		}
	}

	
	for (int i=20; i<=30; i++)
	{
		field[3]->tile[i][30]->type = TILE_TYPE_WALL;
		field[3]->tile[i][30]->growth = 1;
		field[3]->tile[i][30]->style = rand() % 3;

		field[3]->tile[i][29]->type = TILE_TYPE_DIRT;
		field[3]->tile[i][29]->growth = 0;
		
		field[3]->tile[i][28]->type = TILE_TYPE_PATH;
		field[3]->tile[i][28]->growth = 0;
		field[3]->tile[i][28]->style = 0;
		field[3]->tile[i][27]->type = TILE_TYPE_PATH;
		field[3]->tile[i][27]->growth = 0;
		field[3]->tile[i][27]->style = 0;
		field[3]->tile[i][26]->type = TILE_TYPE_PATH;
		field[3]->tile[i][26]->growth = 0;
		field[3]->tile[i][26]->style = 0;

		field[3]->tile[i][25]->type = TILE_TYPE_DIRT;
		field[3]->tile[i][25]->growth = 0;
	
		field[3]->tile[i][24]->type = TILE_TYPE_WALL;
		field[3]->tile[i][24]->growth = 1;
		field[3]->tile[i][24]->style = rand() % 3;
	}

	for (int i=0; i<=23; i++)
	{
		field[3]->tile[26][23-i]->type = TILE_TYPE_PATH;
		field[3]->tile[26][23-i]->growth = 1;
		field[3]->tile[26][23-i]->style = 0;
		field[3]->tile[27][23-i]->type = TILE_TYPE_PATH;
		field[3]->tile[27][23-i]->growth = 1;
		field[3]->tile[27][23-i]->style = 0;
	}

	for (int i=0; i<20; i++)
	{
		field[3]->tile[i][26]->type = TILE_TYPE_PATH;
		field[3]->tile[i][26]->growth = 1;
		field[3]->tile[i][26]->style = 0;
		field[3]->tile[i][27]->type = TILE_TYPE_PATH;
		field[3]->tile[i][27]->growth = 1;
		field[3]->tile[i][27]->style = 0;
		field[3]->tile[i][28]->type = TILE_TYPE_PATH;
		field[3]->tile[i][28]->growth = 1;
		field[3]->tile[i][28]->style = 0;
	}

	for (int i=31; i<100; i++)
	{
		field[3]->tile[i][26]->type = TILE_TYPE_PATH;
		field[3]->tile[i][26]->growth = 1;
		field[3]->tile[i][26]->style = 0;
		field[3]->tile[i][27]->type = TILE_TYPE_PATH;
		field[3]->tile[i][27]->growth = 1;
		field[3]->tile[i][27]->style = 0;
		field[3]->tile[i][28]->type = TILE_TYPE_PATH;
		field[3]->tile[i][28]->growth = 1;
		field[3]->tile[i][28]->style = 0;
	}	

	field[3]->tile[26][25]->type = TILE_TYPE_PATH;
	field[3]->tile[26][25]->growth = 0;
	field[3]->tile[26][25]->style = 0;
	field[3]->tile[27][25]->type = TILE_TYPE_PATH;
	field[3]->tile[27][25]->growth = 0;
	field[3]->tile[27][25]->style = 0;
	
	field[3]->tile[26][24]->type = TILE_TYPE_CLOSED_DOOR;
	field[3]->tile[26][24]->growth = -5;
	field[3]->tile[26][24]->style = 0;
	field[3]->tile[27][24]->type = TILE_TYPE_CLOSED_DOOR;
	field[3]->tile[27][24]->growth = -5;
	field[3]->tile[27][24]->style = 0;

	field[3]->tile[30][25]->type = TILE_TYPE_WALL;
	field[3]->tile[30][25]->growth = 1;
	field[3]->tile[30][25]->style = rand() % 3;

	field[3]->tile[30][26]->type = TILE_TYPE_CLOSED_DOOR;
	field[3]->tile[30][26]->growth = -1;
	field[3]->tile[30][26]->style = 0;
	field[3]->tile[30][27]->type = TILE_TYPE_CLOSED_DOOR;
	field[3]->tile[30][27]->growth = -1;
	field[3]->tile[30][27]->style = 0;
	field[3]->tile[30][28]->type = TILE_TYPE_CLOSED_DOOR;
	field[3]->tile[30][28]->growth = -1;
	field[3]->tile[30][28]->style = 0;

	field[3]->tile[30][29]->type = TILE_TYPE_WALL;
	field[3]->tile[30][29]->growth = 1;
	field[3]->tile[30][29]->style = rand() % 3;

	field[3]->tile[20][25]->type = TILE_TYPE_WALL;
	field[3]->tile[20][25]->growth = 1;
	field[3]->tile[20][25]->style = rand() % 3;

	field[3]->tile[20][26]->type = TILE_TYPE_CLOSED_DOOR;
	field[3]->tile[20][26]->growth = -7;
	field[3]->tile[20][26]->style = 0;
	field[3]->tile[20][27]->type = TILE_TYPE_CLOSED_DOOR;
	field[3]->tile[20][27]->growth = -7;
	field[3]->tile[20][27]->style = 0;
	field[3]->tile[20][28]->type = TILE_TYPE_CLOSED_DOOR;
	field[3]->tile[20][28]->growth = -7;
	field[3]->tile[20][28]->style = 0;

	field[3]->tile[20][29]->type = TILE_TYPE_WALL;
	field[3]->tile[20][29]->growth = 1;
	field[3]->tile[20][29]->style = rand() % 3;

	// mountainside

	for (int i=0; i<100; i++)
	{
		for (int j=0; j<100; j++)
		{
			field[4]->tile[i][j]->type = TILE_TYPE_DIRT;

			if (rand() % 100 < 1)
			{
				field[4]->tile[i][j]->type = TILE_TYPE_ROCK;
	
				field[4]->tile[i][j]->growth = 5;
				field[4]->tile[i][j]->style = rand() % 3;
			}
			else if (rand() % 100 < 2)
			{
				field[4]->tile[i][j]->type = TILE_TYPE_WEED;
			
				field[4]->tile[i][j]->growth = 1;
				field[4]->tile[i][j]->style = rand() % 3;
			}
			else if (rand() % 100 < 10)
			{
				field[4]->tile[i][j]->type = TILE_TYPE_WALL;
						
				field[4]->tile[i][j]->growth = 1;
				field[4]->tile[i][j]->style = rand() % 5;
			}
		}
	}

	for (int i=20; i<=40; i++)
	{
		for (int j=0; j<=60; j++)
		{
			if (field[4]->tile[i][j]->type == TILE_TYPE_WALL)
			{
				field[4]->tile[i][j]->type = TILE_TYPE_DIRT;
						
				field[4]->tile[i][j]->growth = 0;
				field[4]->tile[i][j]->style = 0;
			}
		}
	}
	
	for (int i=0; i<=60; i++)
	{
		for (int j=0; j<=60; j++)
		{
			if (field[4]->tile[i][j]->type == TILE_TYPE_WALL)
			{
				field[4]->tile[i][j]->type = TILE_TYPE_DIRT;
						
				field[4]->tile[i][j]->growth = 0;
				field[4]->tile[i][j]->style = 0;
			}
		}
	}

	for (int i=41; i<100; i++)
	{
		if (i >= 61)
		{
			field[4]->tile[30][i]->type = TILE_TYPE_PATH;
			field[4]->tile[30][i]->growth = 1;
			field[4]->tile[30][i]->style = 0;
			field[4]->tile[31][i]->type = TILE_TYPE_PATH;
			field[4]->tile[31][i]->growth = 1;
			field[4]->tile[31][i]->style = 0;
		}
		else
		{
			field[4]->tile[30][i]->type = TILE_TYPE_PATH;
			field[4]->tile[30][i]->growth = 0;
			field[4]->tile[30][i]->style = 0;
			field[4]->tile[31][i]->type = TILE_TYPE_PATH;
			field[4]->tile[31][i]->growth = 0;
			field[4]->tile[31][i]->style = 0;
		}
	}
	
	for (int i=21; i<=31; i++)
	{
		field[4]->tile[i][40]->type = TILE_TYPE_PATH;
		field[4]->tile[i][40]->growth = 0;
		field[4]->tile[i][40]->style = 0;
		field[4]->tile[i][41]->type = TILE_TYPE_PATH;
		field[4]->tile[i][41]->growth = 0;
		field[4]->tile[i][41]->style = 0;
	}
	
	for (int i=31; i<=41; i++)
	{
		field[4]->tile[21][i]->type = TILE_TYPE_PATH;
		field[4]->tile[21][i]->growth = 0;
		field[4]->tile[21][i]->style = 0;
		field[4]->tile[22][i]->type = TILE_TYPE_PATH;
		field[4]->tile[22][i]->growth = 0;
		field[4]->tile[22][i]->style = 0;
	}

	for (int i=30; i<=61; i++)
	{
		field[4]->tile[19][i]->type = TILE_TYPE_WALL;			
		field[4]->tile[19][i]->growth = 1;
		field[4]->tile[19][i]->style = rand() % 5;
		field[4]->tile[41][i]->type = TILE_TYPE_WALL;		
		field[4]->tile[41][i]->growth = 1;
		field[4]->tile[41][i]->style = rand() % 5;
	}

	for (int i=19; i<=41; i++)
	{
		field[4]->tile[i][30]->type = TILE_TYPE_BOUNDED;			
		field[4]->tile[i][30]->growth = 1;
		field[4]->tile[i][30]->style = 0;
		field[4]->tile[i][61]->type = TILE_TYPE_WALL;		
		field[4]->tile[i][61]->growth = 1;
		field[4]->tile[i][61]->style = rand() % 5;
	}

	field[4]->tile[30][61]->type = TILE_TYPE_CLOSED_DOOR;
	field[4]->tile[30][61]->growth = -4;
	field[4]->tile[30][61]->style = 0;
	field[4]->tile[31][61]->type = TILE_TYPE_CLOSED_DOOR;
	field[4]->tile[31][61]->growth = -4;
	field[4]->tile[31][61]->style = 0;

	field[4]->tile[21][30]->type = TILE_TYPE_CLOSED_DOOR;
	field[4]->tile[21][30]->growth = -6;
	field[4]->tile[21][30]->style = 0;
	field[4]->tile[22][30]->type = TILE_TYPE_CLOSED_DOOR;
	field[4]->tile[22][30]->growth = -6;
	field[4]->tile[22][30]->style = 0;

	field[4]->tile[37][31]->type = TILE_TYPE_ORE;
	field[4]->tile[37][31]->growth = 5;
	field[4]->tile[37][31]->style = 0;
	
	field[4]->tile[35][36]->type = TILE_TYPE_ORE;
	field[4]->tile[35][36]->growth = 5;
	field[4]->tile[35][36]->style = 1;

	field[4]->tile[21][51]->type = TILE_TYPE_ORE;
	field[4]->tile[21][51]->growth = 5;
	field[4]->tile[21][51]->style = 2;

	field[4]->tile[24][53]->type = TILE_TYPE_ORE;
	field[4]->tile[24][53]->growth = 5;
	field[4]->tile[24][53]->style = 0;
	
	field[4]->tile[36][58]->type = TILE_TYPE_ORE;
	field[4]->tile[36][58]->growth = 5;
	field[4]->tile[36][58]->style = 1;

	field[4]->tile[27][45]->type = TILE_TYPE_ORE;
	field[4]->tile[27][45]->growth = 5;
	field[4]->tile[27][45]->style = 2;

	field[4]->tile[25][33]->type = TILE_TYPE_BERRY_BUSH;
	field[4]->tile[25][33]->growth = 1;

	field[4]->tile[30][38]->type = TILE_TYPE_BERRY_BUSH;
	field[4]->tile[30][38]->growth = 1;

	field[4]->tile[26][52]->type = TILE_TYPE_BERRY_BUSH;
	field[4]->tile[26][52]->growth = 1;

	field[4]->tile[38][43]->type = TILE_TYPE_APPLE_TREE;
	field[4]->tile[38][43]->growth = 1;

	field[4]->tile[22][57]->type = TILE_TYPE_APPLE_TREE;
	field[4]->tile[22][57]->growth = 1;

	field[4]->tile[21][44]->type = TILE_TYPE_MUSHROOM_BED;
	field[4]->tile[21][44]->growth = 1;

	field[4]->tile[36][54]->type = TILE_TYPE_MUSHROOM_BED;
	field[4]->tile[36][54]->growth = 1;

	field[4]->tile[24][36]->type = TILE_TYPE_MUSHROOM_BED;
	field[4]->tile[24][36]->growth = 1;

	// mines under the mountain

	for (int i=20; i<=28; i++)
	{
		for (int j=20; j<=45; j++)
		{
			field[5]->tile[i][j]->type = TILE_TYPE_CRYSTAL;
			field[5]->tile[i][j]->growth = 0;
			field[5]->tile[i][j]->style = 0;
		}
	}

	for (int i=20; i<=28; i++)
	{
		for (int j=47; j<=50; j++)
		{
			field[5]->tile[i][j]->type = TILE_TYPE_PATH;
			field[5]->tile[i][j]->growth = 0;
			field[5]->tile[i][j]->style = 0;
		}
	}

	for (int i=0; i<=29; i++)
	{
		field[5]->tile[19][21+i]->type = TILE_TYPE_BOUNDED;
		field[5]->tile[19][21+i]->growth = 1;
		field[5]->tile[19][21+i]->style = 0;
	
		field[5]->tile[28][21+i]->type = TILE_TYPE_BOUNDED;
		field[5]->tile[28][21+i]->growth = 1;
		field[5]->tile[28][21+i]->style = 0;
	}

	for (int i=0; i<=9; i++)
	{
		field[5]->tile[19+i][20]->type = TILE_TYPE_BOUNDED;
		field[5]->tile[19+i][20]->growth = 1;
		field[5]->tile[19+i][20]->style = 0;
		
		field[5]->tile[19+i][50]->type = TILE_TYPE_BOUNDED;
		field[5]->tile[19+i][50]->growth = 1;
		field[5]->tile[19+i][50]->style = 0;
	}

	for (int i=19; i<=28; i++)
	{
		field[5]->tile[i][46]->type = TILE_TYPE_WALL;
		field[5]->tile[i][46]->growth = 2;
		field[5]->tile[i][46]->style = rand() % 5 + 5; // for inside the cave?
	}

	field[5]->tile[21][46]->type = TILE_TYPE_PATH;
	field[5]->tile[21][46]->growth = 0;
	field[5]->tile[21][46]->style = 0;

	field[5]->tile[21][50]->type = TILE_TYPE_CLOSED_DOOR;
	field[5]->tile[21][50]->growth = -5;
	field[5]->tile[21][50]->style = 2;
	field[5]->tile[22][50]->type = TILE_TYPE_CLOSED_DOOR;
	field[5]->tile[22][50]->growth = -5;
	field[5]->tile[22][50]->style = 2;
	field[5]->tile[21][49]->type = TILE_TYPE_PATH;
	field[5]->tile[21][49]->growth = 0;
	field[5]->tile[21][49]->style = 0;
	field[5]->tile[22][49]->type = TILE_TYPE_PATH;
	field[5]->tile[22][49]->growth = 0;
	field[5]->tile[22][49]->style = 0;

	cast->actor[6]->type = ACTOR_TYPE_ROVER;
	cast->actor[6]->fx = 24.5f;
	cast->actor[6]->fy = 27.5f;
	cast->actor[6]->px = 24;
	cast->actor[6]->py = 27;
	cast->actor[6]->present_field = 5;
	cast->actor[6]->rx1 = 20.0f;
	cast->actor[6]->ry1 = 20.0f;
	cast->actor[6]->rx2 = 28.0f;
	cast->actor[6]->ry2 = 42.0f;
	cast->actor[6]->tx = 24.5f;
	cast->actor[6]->ty = 27.5f;
	cast->actor[6]->affection = 1;

	cast->actor[6]->primary_color[0] = 0.5f;
	cast->actor[6]->primary_color[1] = 0.25f;
	cast->actor[6]->primary_color[2] = 0.35f;
	cast->actor[6]->secondary_color[0] = 0.3f;
	cast->actor[6]->secondary_color[1] = 0.3f;
	cast->actor[6]->secondary_color[2] = 0.3f;

	cast->actor[7]->type = ACTOR_TYPE_ROVER;
	cast->actor[7]->fx = 25.5f;
	cast->actor[7]->fy = 40.5f;
	cast->actor[7]->px = 25;
	cast->actor[7]->py = 37;
	cast->actor[7]->present_field = 5;
	cast->actor[7]->rx1 = 20.0f;
	cast->actor[7]->ry1 = 20.0f;
	cast->actor[7]->rx2 = 28.0f;
	cast->actor[7]->ry2 = 42.0f;
	cast->actor[7]->tx = 25.5f;
	cast->actor[7]->ty = 37.5f;
	cast->actor[7]->affection = 1;

	cast->actor[7]->primary_color[0] = 0.35f;
	cast->actor[7]->primary_color[1] = 0.5f;
	cast->actor[7]->primary_color[2] = 0.25f;
	cast->actor[7]->secondary_color[0] = 0.3f;
	cast->actor[7]->secondary_color[1] = 0.3f;
	cast->actor[7]->secondary_color[2] = 0.3f;

	// town

	for (int i=0; i<100; i++)
	{
		for (int j=0; j<100; j++)
		{
			field[6]->tile[i][j]->type = TILE_TYPE_DIRT;

			if (rand() % 100 < 1)
			{
				field[6]->tile[i][j]->type = TILE_TYPE_ROCK;
	
				field[6]->tile[i][j]->growth = 5;
				field[6]->tile[i][j]->style = rand() % 3;
			}
			else if (rand() % 100 < 2)
			{
				field[6]->tile[i][j]->type = TILE_TYPE_WEED;
			
				field[6]->tile[i][j]->growth = 1;
				field[6]->tile[i][j]->style = rand() % 3;
			}
			else if (rand() % 100 < 10)
			{
				field[6]->tile[i][j]->type = TILE_TYPE_WALL;
						
				field[6]->tile[i][j]->growth = 1;
				field[6]->tile[i][j]->style = rand() % 5;
			}
		}
	}	
	
	for (int i=20; i<=80; i++)
	{
		for (int j=20; j<=50; j++)
		{
			field[6]->tile[i][j]->type = TILE_TYPE_PATH;
			field[6]->tile[i][j]->growth = 0;
			field[6]->tile[i][j]->style = 0;
		}
	}

	for (int i=20; i<=80; i++)
	{
		field[6]->tile[i][20]->type = TILE_TYPE_WALL;
		field[6]->tile[i][20]->growth = 1;
		field[6]->tile[i][20]->style = rand() % 5;
	
		field[6]->tile[i][50]->type = TILE_TYPE_WALL;
		field[6]->tile[i][50]->growth = 1;
		field[6]->tile[i][50]->style = rand() % 5;
	}

	for (int i=20; i<=50; i++)
	{
		field[6]->tile[20][i]->type = TILE_TYPE_WALL;
		field[6]->tile[20][i]->growth = 1;
		field[6]->tile[20][i]->style = rand() % 5;
	
		field[6]->tile[80][i]->type = TILE_TYPE_WALL;
		field[6]->tile[80][i]->growth = 1;
		field[6]->tile[80][i]->style = rand() % 5;
	}

	for (int i=81; i<100; i++)
	{
		field[6]->tile[i][30]->type = TILE_TYPE_PATH;
		field[6]->tile[i][30]->growth = 1;
		field[6]->tile[i][30]->style = 0;
		field[6]->tile[i][31]->type = TILE_TYPE_PATH;
		field[6]->tile[i][31]->growth = 1;
		field[6]->tile[i][31]->style = 0;
		field[6]->tile[i][32]->type = TILE_TYPE_PATH;
		field[6]->tile[i][32]->growth = 1;
		field[6]->tile[i][32]->style = 0;
	}

	for (int i=65; i<75; i++)
	{
		for (int j=15; j<25; j++)
		{
			field[6]->tile[i][j]->type = TILE_TYPE_BOUNDED;
			field[6]->tile[i][j]->growth = 1;
			field[6]->tile[i][j]->style = 0;
		}
	}

	field[6]->tile[66][24]->type = TILE_TYPE_CLOSED_DOOR;
	field[6]->tile[66][24]->growth = -8;
	field[6]->tile[66][24]->style = 1;

	for (int i=70; i<80; i++)
	{
		for (int j=36; j<46; j++)
		{
			field[6]->tile[i][j]->type = TILE_TYPE_BOUNDED;
			field[6]->tile[i][j]->growth = 1;
			field[6]->tile[i][j]->style = 0;
		}
	}

	field[6]->tile[71][45]->type = TILE_TYPE_CLOSED_DOOR;
	field[6]->tile[71][45]->growth = -9;
	field[6]->tile[71][45]->style = 1;
	
	for (int i=50; i<60; i++)
	{
		for (int j=25; j<35; j++)
		{
			field[6]->tile[i][j]->type = TILE_TYPE_BOUNDED;
			field[6]->tile[i][j]->growth = 1;
			field[6]->tile[i][j]->style = 0;
		}
	}

	field[6]->tile[51][34]->type = TILE_TYPE_CLOSED_DOOR;
	field[6]->tile[51][34]->growth = -10;
	field[6]->tile[51][34]->style = 1;

	for (int i=25; i<45; i++)
	{
		for (int j=19; j<40; j++)
		{
			field[6]->tile[i][j]->type = TILE_TYPE_BOUNDED;
			field[6]->tile[i][j]->growth = 1;
			field[6]->tile[i][j]->style = 0;
		}
	}

	field[6]->tile[34][39]->type = TILE_TYPE_CLOSED_DOOR;
	field[6]->tile[34][39]->growth = -11;
	field[6]->tile[34][39]->style = 1;
	field[6]->tile[35][39]->type = TILE_TYPE_CLOSED_DOOR;
	field[6]->tile[35][39]->growth = -11;
	field[6]->tile[35][39]->style = 1;


	field[6]->tile[80][30]->type = TILE_TYPE_CLOSED_DOOR;
	field[6]->tile[80][30]->growth = -4;
	field[6]->tile[80][30]->style = 0;
	field[6]->tile[80][31]->type = TILE_TYPE_CLOSED_DOOR;
	field[6]->tile[80][31]->growth = -4;
	field[6]->tile[80][31]->style = 0;
	field[6]->tile[80][32]->type = TILE_TYPE_CLOSED_DOOR;
	field[6]->tile[80][32]->growth = -4;
	field[6]->tile[80][32]->style = 0;

	field[6]->tile[62][30]->type = TILE_TYPE_DYNAMO_CHARGER;
	field[6]->tile[62][30]->growth = 1;

	field[6]->tile[79][29]->type = TILE_TYPE_OBELISK;
	field[6]->tile[79][29]->growth = 1;
	field[6]->tile[79][33]->type = TILE_TYPE_OBELISK;
	field[6]->tile[79][33]->growth = 1;

	field[6]->tile[21][21]->type = TILE_TYPE_OBELISK;
	field[6]->tile[21][21]->growth = 1;
	field[6]->tile[79][21]->type = TILE_TYPE_OBELISK;
	field[6]->tile[79][21]->growth = 1;
	field[6]->tile[79][49]->type = TILE_TYPE_OBELISK;
	field[6]->tile[79][49]->growth = 1;
	field[6]->tile[21][49]->type = TILE_TYPE_OBELISK;
	field[6]->tile[21][49]->growth = 1;

	for (int i=53; i<63; i++)
	{
		for (int j=40; j<50; j++)
		{
			field[6]->tile[i][j]->type = TILE_TYPE_PATH;
			field[6]->tile[i][j]->growth = 0;
			field[6]->tile[i][j]->style = 1;
		}
	}	

	field[6]->tile[53][40]->type = TILE_TYPE_OBELISK;
	field[6]->tile[53][40]->growth = 1;
	field[6]->tile[53][49]->type = TILE_TYPE_OBELISK;
	field[6]->tile[53][49]->growth = 1;
	field[6]->tile[62][40]->type = TILE_TYPE_OBELISK;
	field[6]->tile[62][40]->growth = 1;
	field[6]->tile[62][49]->type = TILE_TYPE_OBELISK;
	field[6]->tile[62][49]->growth = 1;

	// plant shop

	for (int i=20; i<=28; i++)
	{
		for (int j=20; j<=30; j++)
		{
			field[7]->tile[i][j]->type = TILE_TYPE_PATH;
			field[7]->tile[i][j]->growth = 0;
			field[7]->tile[i][j]->style = 1;
		}
	}

	for (int i=0; i<=9; i++)
	{
		field[7]->tile[19][21+i]->type = TILE_TYPE_BOUNDED;
		field[7]->tile[19][21+i]->growth = 1;
		field[7]->tile[19][21+i]->style = 1;
	
		field[7]->tile[28][21+i]->type = TILE_TYPE_BOUNDED;
		field[7]->tile[28][21+i]->growth = 1;
		field[7]->tile[28][21+i]->style = 1;
	}

	for (int i=0; i<=9; i++)
	{
		field[7]->tile[19+i][20]->type = TILE_TYPE_BOUNDED;
		field[7]->tile[19+i][20]->growth = 1;
		field[7]->tile[19+i][20]->style = 1;
		
		field[7]->tile[19+i][30]->type = TILE_TYPE_BOUNDED;
		field[7]->tile[19+i][30]->growth = 1;
		field[7]->tile[19+i][30]->style = 1;
	}

	field[7]->tile[20][30]->type = TILE_TYPE_CLOSED_DOOR;
	field[7]->tile[20][30]->growth = -7;
	field[7]->tile[20][30]->style = 2;
	field[7]->tile[20][29]->type = TILE_TYPE_PATH;
	field[7]->tile[20][29]->growth = 0;
	field[7]->tile[20][29]->style = 1;

	cast->actor[13]->type = ACTOR_TYPE_BUY_RADISH_SEEDS;
	cast->actor[13]->fx = 21.5f;
	cast->actor[13]->fy = 21.5f;
	cast->actor[13]->px = 21;
	cast->actor[13]->py = 21;
	cast->actor[13]->present_field = 7;
	cast->actor[13]->rx1 = 21.5f;
	cast->actor[13]->ry1 = 21.5f;
	cast->actor[13]->rx2 = 21.5f;
	cast->actor[13]->ry2 = 21.5f;
	cast->actor[13]->tx = 21.5f;
	cast->actor[13]->ty = 21.5f;
	cast->actor[13]->primary_color[0] = 0.5f;
	cast->actor[13]->primary_color[1] = 0.5f;
	cast->actor[13]->primary_color[2] = 0.5f;
	cast->actor[13]->secondary_color[0] = 0.3f;
	cast->actor[13]->secondary_color[1] = 0.3f;
	cast->actor[13]->secondary_color[2] = 0.3f;
	cast->actor[13]->affection = 0;

	cast->actor[14]->type = ACTOR_TYPE_BUY_CABBAGE_SEEDS;
	cast->actor[14]->fx = 26.5f;
	cast->actor[14]->fy = 21.5f;
	cast->actor[14]->px = 26;
	cast->actor[14]->py = 21;
	cast->actor[14]->present_field = 7;
	cast->actor[14]->rx1 = 26.5f;
	cast->actor[14]->ry1 = 21.5f;
	cast->actor[14]->rx2 = 26.5f;
	cast->actor[14]->ry2 = 21.5f;
	cast->actor[14]->tx = 26.5f;
	cast->actor[14]->ty = 21.5f;
	cast->actor[14]->primary_color[0] = 0.5f;
	cast->actor[14]->primary_color[1] = 0.5f;
	cast->actor[14]->primary_color[2] = 0.5f;
	cast->actor[14]->secondary_color[0] = 0.3f;
	cast->actor[14]->secondary_color[1] = 0.3f;
	cast->actor[14]->secondary_color[2] = 0.3f;
	cast->actor[14]->affection = 0;

	cast->actor[15]->type = ACTOR_TYPE_BUY_RYE_SEEDS;
	cast->actor[15]->fx = 21.5f;
	cast->actor[15]->fy = 24.5f;
	cast->actor[15]->px = 21;
	cast->actor[15]->py = 24;
	cast->actor[15]->present_field = 7;
	cast->actor[15]->rx1 = 21.5f;
	cast->actor[15]->ry1 = 24.5f;
	cast->actor[15]->rx2 = 21.5f;
	cast->actor[15]->ry2 = 24.5f;
	cast->actor[15]->tx = 21.5f;
	cast->actor[15]->ty = 24.5f;
	cast->actor[15]->primary_color[0] = 0.5f;
	cast->actor[15]->primary_color[1] = 0.5f;
	cast->actor[15]->primary_color[2] = 0.5f;
	cast->actor[15]->secondary_color[0] = 0.3f;
	cast->actor[15]->secondary_color[1] = 0.3f;
	cast->actor[15]->secondary_color[2] = 0.3f;
	cast->actor[15]->affection = 0;

	cast->actor[16]->type = ACTOR_TYPE_BUY_NANOTUBE_SEEDS;
	cast->actor[16]->fx = 26.5f;
	cast->actor[16]->fy = 24.5f;
	cast->actor[16]->px = 26;
	cast->actor[16]->py = 24;
	cast->actor[16]->present_field = 7;
	cast->actor[16]->rx1 = 26.5f;
	cast->actor[16]->ry1 = 24.5f;
	cast->actor[16]->rx2 = 26.5f;
	cast->actor[16]->ry2 = 24.5f;
	cast->actor[16]->tx = 26.5f;
	cast->actor[16]->ty = 24.5f;
	cast->actor[16]->primary_color[0] = 0.5f;
	cast->actor[16]->primary_color[1] = 0.5f;
	cast->actor[16]->primary_color[2] = 0.5f;
	cast->actor[16]->secondary_color[0] = 0.3f;
	cast->actor[16]->secondary_color[1] = 0.3f;
	cast->actor[16]->secondary_color[2] = 0.3f;
	cast->actor[16]->affection = 0;

	cast->actor[17]->type = ACTOR_TYPE_BUY_GIFT_BASKET;
	cast->actor[17]->fx = 26.5f;
	cast->actor[17]->fy = 27.5f;
	cast->actor[17]->px = 26;
	cast->actor[17]->py = 27;
	cast->actor[17]->present_field = 7;
	cast->actor[17]->rx1 = 26.5f;
	cast->actor[17]->ry1 = 27.5f;
	cast->actor[17]->rx2 = 26.5f;
	cast->actor[17]->ry2 = 27.5f;
	cast->actor[17]->tx = 26.5f;
	cast->actor[17]->ty = 27.5f;
	cast->actor[17]->primary_color[0] = 0.5f;
	cast->actor[17]->primary_color[1] = 0.5f;
	cast->actor[17]->primary_color[2] = 0.5f;
	cast->actor[17]->secondary_color[0] = 0.3f;
	cast->actor[17]->secondary_color[1] = 0.3f;
	cast->actor[17]->secondary_color[2] = 0.3f;
	cast->actor[17]->affection = 0;

	cast->actor[21]->type = ACTOR_TYPE_PARROT;
	cast->actor[21]->fx = 22.5f;
	cast->actor[21]->fy = 22.5f;
	cast->actor[21]->px = 22;
	cast->actor[21]->py = 22;
	cast->actor[21]->present_field = 7;
	cast->actor[21]->rx1 = 22.5f;
	cast->actor[21]->ry1 = 22.5f;
	cast->actor[21]->rx2 = 25.5f;
	cast->actor[21]->ry2 = 26.5f;
	cast->actor[21]->tx = 23.5f;
	cast->actor[21]->ty = 22.5f;
	cast->actor[21]->primary_color[0] = 1.0f;
	cast->actor[21]->primary_color[1] = 1.0f;
	cast->actor[21]->primary_color[2] = 0.5f;
	cast->actor[21]->secondary_color[0] = 0.3f;
	cast->actor[21]->secondary_color[1] = 0.3f;
	cast->actor[21]->secondary_color[2] = 0.3f;
	cast->actor[21]->affection = 1;

	// mechanics shop

	for (int i=20; i<=28; i++)
	{
		for (int j=20; j<=30; j++)
		{
			field[8]->tile[i][j]->type = TILE_TYPE_PATH;
			field[8]->tile[i][j]->growth = 0;
			field[8]->tile[i][j]->style = 1;
		}
	}

	for (int i=0; i<=9; i++)
	{
		field[8]->tile[19][21+i]->type = TILE_TYPE_BOUNDED;
		field[8]->tile[19][21+i]->growth = 1;
		field[8]->tile[19][21+i]->style = 1;
	
		field[8]->tile[28][21+i]->type = TILE_TYPE_BOUNDED;
		field[8]->tile[28][21+i]->growth = 1;
		field[8]->tile[28][21+i]->style = 1;
	}

	for (int i=0; i<=9; i++)
	{
		field[8]->tile[19+i][20]->type = TILE_TYPE_BOUNDED;
		field[8]->tile[19+i][20]->growth = 1;
		field[8]->tile[19+i][20]->style = 1;
	
		field[8]->tile[19+i][30]->type = TILE_TYPE_BOUNDED;
		field[8]->tile[19+i][30]->growth = 1;
		field[8]->tile[19+i][30]->style = 1;
	}

	field[8]->tile[20][30]->type = TILE_TYPE_CLOSED_DOOR;
	field[8]->tile[20][30]->growth = -7;
	field[8]->tile[20][30]->style = 2;
	field[8]->tile[20][29]->type = TILE_TYPE_PATH;
	field[8]->tile[20][29]->growth = 0;
	field[8]->tile[20][29]->style = 1;

	cast->actor[8]->type = ACTOR_TYPE_BUY_ROVER;
	cast->actor[8]->fx = 21.5f;
	cast->actor[8]->fy = 21.5f;
	cast->actor[8]->px = 21;
	cast->actor[8]->py = 21;
	cast->actor[8]->present_field = 8;
	cast->actor[8]->rx1 = 21.5f;
	cast->actor[8]->ry1 = 21.5f;
	cast->actor[8]->rx2 = 21.5f;
	cast->actor[8]->ry2 = 21.5f;
	cast->actor[8]->tx = 21.5f;
	cast->actor[8]->ty = 21.5f;
	cast->actor[8]->primary_color[0] = 1.0f;
	cast->actor[8]->primary_color[1] = 1.0f;
	cast->actor[8]->primary_color[2] = 1.0f;
	cast->actor[8]->secondary_color[0] = 0.3f;
	cast->actor[8]->secondary_color[1] = 0.3f;
	cast->actor[8]->secondary_color[2] = 0.3f;
	cast->actor[8]->affection = 1;

	cast->actor[9]->type = ACTOR_TYPE_SELL_ROVER;
	cast->actor[9]->fx = 26.5f;
	cast->actor[9]->fy = 21.5f;
	cast->actor[9]->px = 26;
	cast->actor[9]->py = 21;
	cast->actor[9]->present_field = 8;
	cast->actor[9]->rx1 = 26.5f;
	cast->actor[9]->ry1 = 21.5f;
	cast->actor[9]->rx2 = 26.5f;
	cast->actor[9]->ry2 = 21.5f;
	cast->actor[9]->tx = 26.5f;
	cast->actor[9]->ty = 21.5f;
	cast->actor[9]->primary_color[0] = 0.5f;
	cast->actor[9]->primary_color[1] = 0.5f;
	cast->actor[9]->primary_color[2] = 0.5f;
	cast->actor[9]->secondary_color[0] = 0.3f;
	cast->actor[9]->secondary_color[1] = 0.3f;
	cast->actor[9]->secondary_color[2] = 0.3f;
	cast->actor[9]->affection = 0;

	cast->actor[10]->type = ACTOR_TYPE_BUY_WATER_GENERATOR;
	cast->actor[10]->fx = 21.5f;
	cast->actor[10]->fy = 24.5f;
	cast->actor[10]->px = 21;
	cast->actor[10]->py = 24;
	cast->actor[10]->present_field = 8;
	cast->actor[10]->rx1 = 21.5f;
	cast->actor[10]->ry1 = 24.5f;
	cast->actor[10]->rx2 = 21.5f;
	cast->actor[10]->ry2 = 24.5f;
	cast->actor[10]->tx = 21.5f;
	cast->actor[10]->ty = 24.5f;
	cast->actor[10]->primary_color[0] = 0.5f;
	cast->actor[10]->primary_color[1] = 0.5f;
	cast->actor[10]->primary_color[2] = 0.5f;
	cast->actor[10]->secondary_color[0] = 0.3f;
	cast->actor[10]->secondary_color[1] = 0.3f;
	cast->actor[10]->secondary_color[2] = 0.3f;
	cast->actor[10]->affection = 0;

	cast->actor[11]->type = ACTOR_TYPE_BUY_NANOTUBE;
	cast->actor[11]->fx = 26.5f;
	cast->actor[11]->fy = 24.5f;
	cast->actor[11]->px = 26;
	cast->actor[11]->py = 24;
	cast->actor[11]->present_field = 8;
	cast->actor[11]->rx1 = 26.5f;
	cast->actor[11]->ry1 = 24.5f;
	cast->actor[11]->rx2 = 26.5f;
	cast->actor[11]->ry2 = 24.5f;
	cast->actor[11]->tx = 26.5f;
	cast->actor[11]->ty = 24.5f;
	cast->actor[11]->primary_color[0] = 0.5f;
	cast->actor[11]->primary_color[1] = 0.5f;
	cast->actor[11]->primary_color[2] = 0.5f;
	cast->actor[11]->secondary_color[0] = 0.3f;
	cast->actor[11]->secondary_color[1] = 0.3f;
	cast->actor[11]->secondary_color[2] = 0.3f;
	cast->actor[11]->affection = 0;

	cast->actor[12]->type = ACTOR_TYPE_BUY_ORE;
	cast->actor[12]->fx = 26.5f;
	cast->actor[12]->fy = 27.5f;
	cast->actor[12]->px = 26;
	cast->actor[12]->py = 27;
	cast->actor[12]->present_field = 8;
	cast->actor[12]->rx1 = 26.5f;
	cast->actor[12]->ry1 = 27.5f;
	cast->actor[12]->rx2 = 26.5f;
	cast->actor[12]->ry2 = 27.5f;
	cast->actor[12]->tx = 26.5f;
	cast->actor[12]->ty = 27.5f;
	cast->actor[12]->primary_color[0] = 0.5f;
	cast->actor[12]->primary_color[1] = 0.5f;
	cast->actor[12]->primary_color[2] = 0.5f;
	cast->actor[12]->secondary_color[0] = 0.3f;
	cast->actor[12]->secondary_color[1] = 0.3f;
	cast->actor[12]->secondary_color[2] = 0.3f;
	cast->actor[12]->affection = 0;

	cast->actor[20]->type = ACTOR_TYPE_PARROT;
	cast->actor[20]->fx = 22.5f;
	cast->actor[20]->fy = 22.5f;
	cast->actor[20]->px = 22;
	cast->actor[20]->py = 22;
	cast->actor[20]->present_field = 8;
	cast->actor[20]->rx1 = 22.5f;
	cast->actor[20]->ry1 = 22.5f;
	cast->actor[20]->rx2 = 25.5f;
	cast->actor[20]->ry2 = 26.5f;
	cast->actor[20]->tx = 23.5f;
	cast->actor[20]->ty = 22.5f;
	cast->actor[20]->primary_color[0] = 0.5f;
	cast->actor[20]->primary_color[1] = 1.0f;
	cast->actor[20]->primary_color[2] = 1.0f;
	cast->actor[20]->secondary_color[0] = 0.3f;
	cast->actor[20]->secondary_color[1] = 0.3f;
	cast->actor[20]->secondary_color[2] = 0.3f;
	cast->actor[20]->affection = 1;

	// fishery

	for (int i=20; i<=28; i++)
	{
		for (int j=20; j<=30; j++)
		{
			field[9]->tile[i][j]->type = TILE_TYPE_PATH;
			field[9]->tile[i][j]->growth = 0;
			field[9]->tile[i][j]->style = 1;
		}
	}

	for (int i=0; i<=9; i++)
	{
		field[9]->tile[19][21+i]->type = TILE_TYPE_BOUNDED;
		field[9]->tile[19][21+i]->growth = 1;
		field[9]->tile[19][21+i]->style = 1;
	
		field[9]->tile[28][21+i]->type = TILE_TYPE_BOUNDED;
		field[9]->tile[28][21+i]->growth = 1;
		field[9]->tile[28][21+i]->style = 1;
	}

	for (int i=0; i<=9; i++)
	{
		field[9]->tile[19+i][20]->type = TILE_TYPE_BOUNDED;
		field[9]->tile[19+i][20]->growth = 1;
		field[9]->tile[19+i][20]->style = 1;
		
		field[9]->tile[19+i][30]->type = TILE_TYPE_BOUNDED;
		field[9]->tile[19+i][30]->growth = 1;
		field[9]->tile[19+i][30]->style = 1;
	}

	field[9]->tile[20][30]->type = TILE_TYPE_CLOSED_DOOR;
	field[9]->tile[20][30]->growth = -7;
	field[9]->tile[20][30]->style = 2;
	field[9]->tile[20][29]->type = TILE_TYPE_PATH;
	field[9]->tile[20][29]->growth = 0;
	field[9]->tile[20][29]->style = 1;

	for (int i=21; i<=26; i++)
	{
		for (int j=22; j<=26; j++)
		{
			field[9]->tile[i][j]->type = TILE_TYPE_FISHERY;
			field[9]->tile[i][j]->growth = 1;
		}
	}

	for (int i=21; i<=26; i++)
	{
		field[9]->tile[i][27]->type = TILE_TYPE_BOUNDED;
		field[9]->tile[i][27]->growth = 1;
		field[9]->tile[i][27]->style = 2;
	}

	// church
	
	for (int i=20; i<=37; i++)
	{
		for (int j=20; j<=40; j++)
		{
			field[10]->tile[i][j]->type = TILE_TYPE_PATH;
			field[10]->tile[i][j]->growth = 0;
			field[10]->tile[i][j]->style = 1;
		}
	}

	for (int i=0; i<=19; i++)
	{
		field[10]->tile[19][21+i]->type = TILE_TYPE_BOUNDED;
		field[10]->tile[19][21+i]->growth = 1;
		field[10]->tile[19][21+i]->style = 1;
	
		field[10]->tile[37][21+i]->type = TILE_TYPE_BOUNDED;
		field[10]->tile[37][21+i]->growth = 1;
		field[10]->tile[37][21+i]->style = 1;
	}

	for (int i=0; i<=18; i++)
	{
		field[10]->tile[19+i][20]->type = TILE_TYPE_BOUNDED;
		field[10]->tile[19+i][20]->growth = 1;
		field[10]->tile[19+i][20]->style = 1;
		
		field[10]->tile[19+i][40]->type = TILE_TYPE_BOUNDED;
		field[10]->tile[19+i][40]->growth = 1;
		field[10]->tile[19+i][40]->style = 1;
	}

	field[10]->tile[27][21]->type = TILE_TYPE_BOUNDED;
	field[10]->tile[27][21]->growth = 1;
	field[10]->tile[27][21]->style = 1;
	field[10]->tile[28][21]->type = TILE_TYPE_BOUNDED;
	field[10]->tile[28][21]->growth = 1;
	field[10]->tile[28][21]->style = 1;

	field[10]->tile[27][40]->type = TILE_TYPE_CLOSED_DOOR;
	field[10]->tile[27][40]->growth = -7;
	field[10]->tile[27][40]->style = 0;
	field[10]->tile[28][40]->type = TILE_TYPE_CLOSED_DOOR;
	field[10]->tile[28][40]->growth = -7;
	field[10]->tile[28][40]->style = 0;
	field[10]->tile[27][39]->type = TILE_TYPE_PATH;
	field[10]->tile[27][39]->growth = 0;
	field[10]->tile[27][39]->style = 0;
	field[10]->tile[28][39]->type = TILE_TYPE_PATH;
	field[10]->tile[28][39]->growth = 0;
	field[10]->tile[28][39]->style = 0;

	cast->actor[18]->type = ACTOR_TYPE_BIBLE_STATION;
	cast->actor[18]->fx = 25.5f;
	cast->actor[18]->fy = 23.5f;
	cast->actor[18]->px = 25;
	cast->actor[18]->py = 23;
	cast->actor[18]->present_field = 10;
	cast->actor[18]->rx1 = 25.5f;
	cast->actor[18]->ry1 = 23.5f;
	cast->actor[18]->rx2 = 25.5f;
	cast->actor[18]->ry2 = 23.5f;
	cast->actor[18]->tx = 25.5f;
	cast->actor[18]->ty = 23.5f;
	cast->actor[18]->primary_color[0] = 0.5f;
	cast->actor[18]->primary_color[1] = 0.5f;
	cast->actor[18]->primary_color[2] = 0.5f;
	cast->actor[18]->secondary_color[0] = 0.3f;
	cast->actor[18]->secondary_color[1] = 0.3f;
	cast->actor[18]->secondary_color[2] = 0.3f;
	cast->actor[18]->affection = 1;

	cast->actor[19]->type = ACTOR_TYPE_BIBLE_STATION;
	cast->actor[19]->fx = 30.5f;
	cast->actor[19]->fy = 23.5f;
	cast->actor[19]->px = 30;
	cast->actor[19]->py = 23;
	cast->actor[19]->present_field = 10;
	cast->actor[19]->rx1 = 30.5f;
	cast->actor[19]->ry1 = 23.5f;
	cast->actor[19]->rx2 = 30.5f;
	cast->actor[19]->ry2 = 23.5f;
	cast->actor[19]->tx = 30.5f;
	cast->actor[19]->ty = 23.5f;
	cast->actor[19]->primary_color[0] = 0.5f;
	cast->actor[19]->primary_color[1] = 0.5f;
	cast->actor[19]->primary_color[2] = 0.5f;
	cast->actor[19]->secondary_color[0] = 0.3f;
	cast->actor[19]->secondary_color[1] = 0.3f;
	cast->actor[19]->secondary_color[2] = 0.3f;
	cast->actor[19]->affection = 1;


	// other stuff...

	//inventory->tool[0]->type = TOOL_TYPE_ADAMANTINE_HOE; // these adamantine tools should be acquired through dialog and affection...
	//inventory->tool[1]->type = TOOL_TYPE_ADAMANTINE_HAMMER;
	//inventory->tool[2]->type = TOOL_TYPE_ADAMANTINE_SCYTHE;
	//inventory->tool[3]->type = TOOL_TYPE_ADAMANTINE_WATERING_CAN;
	inventory->tool[0]->type = TOOL_TYPE_HOE;
	inventory->tool[1]->type = TOOL_TYPE_HAMMER;
	inventory->tool[2]->type = TOOL_TYPE_SCYTHE;
	inventory->tool[3]->type = TOOL_TYPE_WATERING_CAN;
	inventory->tool[3]->quantity = 25;
	inventory->tool[4]->type = TOOL_TYPE_RADISH_SEED;
	inventory->tool[4]->quantity = 2;
	//inventory->tool[6]->type = TOOL_TYPE_PORTABLE_EXCHANGER;

	cast->actor[4]->type = ACTOR_TYPE_BUY_ACCEPTED;
	cast->actor[5]->type = ACTOR_TYPE_BUY_REJECTED;


	stats->px = 23;
	stats->py = 26;
	stats->fx = 23.5f;
	stats->fy = 26.5f;
	stats->dx = 23;
	stats->dy = 27;
	stats->rot = 3.0f * 3.14159f / 2.0f;
	stats->current_field = 1;
	stats->current_tool = 0;

	stats->energy = 200;
	stats->feed = 0;
	stats->credits = 500;
	stats->materials = 0;

	stats->year = 1;
	stats->season = 1;
	stats->day = 0; // it will travel a day // 0
	stats->day_of_week = 3; // it will travel a day // 3
	stats->days_in_a_season = 30; // would be best if divides 30 evenly...

	//sprintf(stats->name, "Player");

	// below are kindof temporary colors...

	stats->sex = 0;

	if (stats->sex == 0) // male
	{
		stats->primary_color[0] = 0.0f;
		stats->primary_color[1] = 0.5f;
		stats->primary_color[2] = 1.0f;
		stats->secondary_color[0] = 1.0f;
		stats->secondary_color[1] = 1.0f;
		stats->secondary_color[2] = 1.0f;
		//stats->tertiary_color[0] = 0.5f;
		//stats->tertiary_color[1] = 0.75f;
		//stats->tertiary_color[2] = 1.0f;

		stats->tertiary_color[0] = (stats->primary_color[0] + stats->secondary_color[0]) / 2.0f;
		stats->tertiary_color[1] = (stats->primary_color[1] + stats->secondary_color[1]) / 2.0f;
		stats->tertiary_color[2] = (stats->primary_color[2] + stats->secondary_color[2]) / 2.0f;
	}
	else if (stats->sex == 1) // female
	{
		stats->primary_color[0] = 1.0f;
		stats->primary_color[1] = 0.0f;
		stats->primary_color[2] = 1.0f;
		stats->secondary_color[0] = 1.0f;
		stats->secondary_color[1] = 1.0f;
		stats->secondary_color[2] = 1.0f;
		//stats->tertiary_color[0] = 1.0f;
		//stats->tertiary_color[1] = 0.5f;
		//stats->tertiary_color[2] = 1.0f;

		stats->tertiary_color[0] = (stats->primary_color[0] + stats->secondary_color[0]) / 2.0f;
		stats->tertiary_color[1] = (stats->primary_color[1] + stats->secondary_color[1]) / 2.0f;
		stats->tertiary_color[2] = (stats->primary_color[2] + stats->secondary_color[2]) / 2.0f;
	}

	return;
};

