
char *self_string;

FILE *input;

char buffer, temp_buffer, *bible_word;
int bible_book, bible_chapter, bible_verse, bible_line, bible_pos;

// Number in the front for face style,
// ~ means new-line, about 6 total possible
// ` means end of conversation
// _ means a yes/no question
// After end, if there is another number after it, it will start a new dialog
// If it's another ` character, it will simply end.
const char *RandomConversation(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats, int t, int n, int r)
{
	if (t == -3) // prayer
	{
		r = r % 5;

		if (r == 0) return "0Lord, I pray to~You every day.~Thank you for~Your gifts and~guide my ways to You.~Amen.``";
		else if (r == 1) return "0Father, let me be~a vessel for Your~doings.~Give me strength~to carry on for Your~sake. Amen.``";
		else if (r == 2) return "0God, be with me~continually.~Heal my soul and~feed me my daily bread.~Amen.``";
		else if (r == 3) return "0Lord, thank You for Your~Son Jesus Christ,~my Savior.~And for the Holy Spirit,~Amen.``";
		else if (r == 4) return "0Lord, be my strength~and shield. Keep~me for your tasks,~and guide my every~step. Amen.``";
	}
	else if (t == -2) // self
	{
		sprintf(self_string, "0%s, %s %d, %02d:%02d~Credits: %lu~Ore: %d, Nano: %d~Energy: %d%%``", //~Continue working?~_ _0Going home!``", 
			(stats->day_of_week == 1?"Sun":(stats->day_of_week == 2?"Mon":(stats->day_of_week == 3?"Tue":(stats->day_of_week == 4?"Wed":
			(stats->day_of_week == 5?"Thu":(stats->day_of_week == 6?"Fri":(stats->day_of_week == 7?"Sat":"???"))))))),
			(stats->season == 1?"Spring":(stats->season == 2?"Summer":(stats->season == 3?"Fall":(stats->season == 4?"Winter":"???")))),			
			stats->day, stats->hour, stats->minute, stats->credits, stats->materials, stats->feed, stats->energy/2);

		return self_string;
	}
	else if (t == ACTOR_TYPE_NONE)
	{
		return "0Error``";
	}
	else if (t == ACTOR_TYPE_ROVER)
	{
		r = r % 1;

		if (r == 0) return "0STATUS: REPAIRED``";
	}
	else if (t == ACTOR_TYPE_PARROT)
	{
		r = r % 1;
		
		if (stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			return "0MESSAGE:~FESTIVAL IS TODAY~EASTER DAY``";
		}
		else if (stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) // festivals
		{
			return "0MESSAGE:~FESTIVAL IS TODAY~INDEPENDENCE DAY``";
		}
		else if (stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			return "0MESSAGE:~FESTIVAL IS TODAY~THANKSGIVING DAY``";
		}
		else if (stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25))) // festivals
		{
			return "0MESSAGE:~FESTIVAL IS TODAY~CHRISTMAS DAY``";
		}
		else
		{
			if (r == 0) return "0EXCHANGE: CREDITS~FOR: THESE GOODS``";
		}
	}
	else if (t == ACTOR_TYPE_DAVID) // 0 = plain, 1 = angry, 2 = happy, 3 = very happy, 4 = sad
	{
		if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 103) // gift
		{
			return "3Ah! Thank you~very much!~My favorite!``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 102) // gift
		{
			return "2Thank you for this.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 101) // gift
		{
			return "0Was this meant~as a gift of~some sort?``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 100) // gift
		{
			return "1Disgraceful!``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 99) // already gave gift
		{
			return "2Thank you, but you~really mustn't do~so much.``";
		}
		else if (cast->actor[n]->affection >= 50 && stats->upgrade[0] == 0)
		{
			if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_HOE)
			{
				return "0I have an extra~hoe that I could~exchange with yours~if you would like.`2It is very helpful,~especially in winter!~Would you like~to exchange?~_3Good!~Here it is!_1Fine then!~I was just trying~to be nice.``";
			}
			else
			{
				return "0Speak to me again~with your hoe in~your hand. I would~like to make an~exchange if you like.``";
			}
		}	
		else if (stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 0) return "1You're not my type.``";
				else if (stats->sex == 1) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				if (stats->current_field == 10) return "4I will remember~our Lord Jesus all~of my days.``";
				else return "0I suppose that~I might be persuaded~to dance later.``";
			}
		}
		else if (stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 0) return "1You're not my type.``";
				else if (stats->sex == 1) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				return "0Yes, it seems we~have yet another~time to get together.``";
			}
		}
		else if (stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 0) return "1You're not my type.``";
				else if (stats->sex == 1) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				return "2Thanksgiving Day~reminds me of food.~That alone keeps~me here.``";
			}
		}
		else if (stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25))) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 0) return "1You're not my type.``";
				else if (stats->sex == 1) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				if (stats->current_field == 10) return "2Be thankful for~the gift of the Son~from the Father.``";
				else return "3Soon the new year will~come! That is~much welcomed.``";
			}
		}
		else
		{
			if (stats->day_of_week == 1) // Sunday
			{
				return "1Do you interrupt~everyone while~they are praying?``";
			}
			else if (stats->weather == 1) // raining
			{
				return "1*grumble*``";
			}
			else if (stats->day_of_week == 7) // Saturday
			{
				return "0What brings you~here today? Perhaps~you desire to~relax?``";
			}
			else if (stats->season == 1) // Spring weekdays
			{
				return "0I often plan~well ahead for~my rovers. It is~an important income~source.``";
			}
			else if (stats->season == 2) // Summer weekdays
			{
				return "2Good day to you.~Are you doing~well?~_2That is good~to hear._4I am terribly~sorry for you.``";
			}
			else if (stats->season == 3) // Fall weekdays
			{
				return "0Study enables one~to grow in more~ways than one.~Remember that.``";
			}
			else if (stats->season == 4) // Winter weekdays
			{
				return "0I am keeping a~detailed inspection~of the rover's work.``";
			}
			else return "0David: Error.``";
		}	
	}
	else if (t == ACTOR_TYPE_CLARA) // 0 = plain, 1 = angry, 2 = happy, 3 = very happy, 4 = sad
	{
		if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 103) // gift
		{
			return "3Oh wow!~Thank you!~I love it!``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 102) // gift
		{
			return "2Thank you for~thinking of me.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 101) // gift
		{
			return "0Um, are you sure~you want to~give this to me?``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 100) // gift
		{
			return "1Ok, that's enough.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 99) // already gave gift
		{
			return "0No need to shower me~with gifts.``";
		}
		else if (cast->actor[n]->affection >= 50 && stats->upgrade[1] == 0)
		{
			if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_WATERING_CAN)
			{
				return "0I have an extra~watering can that I could~exchange with yours~if you would like.`2It is very helpful,~especially in summer!~Would you like~to exchange?~_3Good!~Here it is!_1Fine then!~I was just trying~to be nice.``";
			}
			else
			{
				return "0Speak to me again~with your watering can in~your hand. I would~like to make an~exchange if you like.``";
			}
		}
		else if (stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 1) return "1You're not my type.``";
				else if (stats->sex == 0) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				if (stats->current_field == 10) return "2Easter Sunday is~a time to join~with family and~friends.`3Be happy!``";
				else return "3I would not miss~this dance for~anything. It is~always a fun event.``";
			}
		}
		else if (stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 1) return "1You're not my type.``";
				else if (stats->sex == 0) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				return "2You cannot possibly~miss a festival!``";
			}
		}
		else if (stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 1) return "1You're not my type.``";
				else if (stats->sex == 0) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				return "0There is a donation~box in the church,~if you are so~inclined...?``";
			}
		}
		else if (stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25))) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 1) return "1You're not my type.``";
				else if (stats->sex == 0) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				if (stats->current_field == 10) return "4I did not receive~a lot of gifts~when I was a little~girl.`2Though Jesus was~my gift all along!``";
				else return "0Do you wish to~stand out in~the cold like us~all day long?~_0Oh I see!_1So I bore you then?``";
			}
		}
		else
		{
			if (stats->day_of_week == 1) // Sunday
			{
				return "0You should come to~church every Sunday.~It is healthy for you!``";
			}
			else if (stats->weather == 1) // raining
			{
				return "1Oh why does it~have to rain?``";
			}
			else if (stats->day_of_week == 7) // Saturday
			{
				return "2I have been told~that I am excellent~walker.``";
			}
			else if (stats->season == 1) // Spring weekdays
			{
				return "0Come to buy~some seeds?~_0Then I will not~stop you._2Ah, so then~what did you~come for?``";
			}
			else if (stats->season == 2) // Summer weekdays
			{
				return "3It is fun to~have someone to talk~to. Thanks for coming~out here to see me.``";
			}
			else if (stats->season == 3) // Fall weekdays
			{
				return "0Another day,~another credit.~I suppose you~stay busy?``";
			}
			else if (stats->season == 4) // Winter weekdays
			{
				return "0Reading builds your~mind.`2Do you read often?~_3Excellent!_1Typical, I suppose.``";
			}
			else return "0Clara: Error.``";
		}	
	}
	else if (t == ACTOR_TYPE_ANDREW) // 0 = plain, 1 = angry, 2 = happy, 3 = very happy, 4 = sad
	{
		if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 103) // gift
		{
			return "3Much appreciated!~You really thought~this out didn't you?``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 102) // gift
		{
			return "2This is good.~Thank you for your~kindness.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 101) // gift
		{
			return "0Oh, yes of course.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 100) // gift
		{
			return "1Why would you~do this to me?``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 99) // already gave gift
		{
			return "2You are truly too~kind.``";
		}
		else if (cast->actor[n]->affection >= 50 && stats->upgrade[2] == 0)
		{
			if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_HAMMER)
			{
				return "0I have an extra~hammer that I could~exchange with yours~if you would like.`2It is very helpful,~any time really!~Would you like~to exchange?~_3Good!~Here it is!_1Fine then!~I was just trying~to be nice.``";
			}
			else
			{
				return "0Speak to me again~with your hammer in~your hand. I would~like to make an~exchange if you like.``";
			}
		}
		else if (stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 0) return "1You're not my type.``";
				else if (stats->sex == 1) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				if (stats->current_field == 10) return "3Rejoice!~For He has risen!``";
				else return "2There's nothing I~love more than a~country dance!``";
			}
		}
		else if (stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 0) return "1You're not my type.``";
				else if (stats->sex == 1) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				return "2Happy Independence~Day! What a fine~day indeed!``";
			}
		}
		else if (stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 0) return "1You're not my type.``";
				else if (stats->sex == 1) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				return "2Let us all give~thanks for everything~we have been given.``";
			}
		}
		else if (stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25))) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 0) return "1You're not my type.``";
				else if (stats->sex == 1) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				if (stats->current_field == 10) return "3Let us celebrate~the birth of our~Lord Jesus Christ!``";
				else return "2There will be dance~later. It still cut~the winter chill.``";
			}
		}
		else
		{
			if (stats->day_of_week == 1) // Sunday
			{
				return "4I often think~of the sacrifice~our Lord gave for~us.`2But it is a~blessing indeed!`0Let us never forget.``";
			}
			else if (stats->weather == 1) // raining
			{
				return "4Oh what a gloomy~day! So very~dreadful.``";
			}
			else if (stats->day_of_week == 7) // Saturday
			{
				return "2Ah what a~fine day. Do you~not agree?~_3Indeed!_1It was a~rhetorical question.``";
			}
			else if (stats->season == 1) // Spring weekdays
			{
				return "0I often sit~here, to stare out~into this world.`0It makes me often~think of what our~lives will be like~later.``";
			}
			else if (stats->season == 2) // Summer weekdays
			{
				return "0Was there something~you needed?~_2Whatever you need~I will do my best~to help._0So be it.``";
			}
			else if (stats->season == 3) // Fall weekdays
			{
				return "2I see we meet here!~Going into town? Or~perhaps towards the~mountain?``";
			}
			else if (stats->season == 4) // Winter weekdays
			{
				return "0It is cold, yes.`2But it nice to~meet you on this~frosty day.``";
			}
			else return "0Andrew: Error.``";
		}	
	}
	else if (t == ACTOR_TYPE_EMILY) // 0 = plain, 1 = angry, 2 = happy, 3 = very happy, 4 = sad
	{
		if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 103) // gift
		{
			return "3Excellent!~I really appreciate you.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 102) // gift
		{
			return "2Thank you for~time with me.~You are very~kind.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 101) // gift
		{
			return "0Well, I see.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 100) // gift
		{
			return "1Disgusting.``";
		}
		else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE &&
			inventory->tool[stats->current_tool]->quantity == 99) // already gave gift
		{
			return "2Thank you once again.``";
		}
		else if (cast->actor[n]->affection >= 50 && stats->upgrade[3] == 0)
		{
			if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_SCYTHE)
			{
				return "0I have an extra~scythe that I could~exchange with yours~if you would like.`2It is very helpful,~any time really!~Would you like~to exchange?~_3Good!~Here it is!_1Fine then!~I was just trying~to be nice.``";
			}
			else
			{
				return "0Speak to me again~with your scythe in~your hand. I would~like to make an~exchange if you like.``";
			}
		}
		else if (stats->season == 1 && stats->day_of_week == 1 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 1) return "1You're not my type.``";
				else if (stats->sex == 0) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				if (stats->current_field == 10) return "4Though Christ's death~was truly a sad day,`2He is now risen,~and we are to~follow Christ when~He calls us home to~heaven.``";
				else return "0We will dance~tonight.`2Do stay and join~in later.``";
			}
		}
		else if (stats->season == 2 && ((stats->day == 4 && stats->days_in_a_season >= 4) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 4))) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 1) return "1You're not my type.``";
				else if (stats->sex == 0) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				return "0It is hotter today~than any other here.`0Enjoy it while~we can.``";
			}
		}
		else if (stats->season == 3 && stats->day_of_week == 5 && stats->day >= stats->days_in_a_season-6 && stats->day <= stats->days_in_a_season) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 1) return "1You're not my type.``";
				else if (stats->sex == 0) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				return "2Give thanks to~the Lord, for~all his workings~upon us.``";
			}
		}
		else if (stats->season == 4 && ((stats->day == 25 && stats->days_in_a_season >= 25) || (stats->day == stats->days_in_a_season && stats->days_in_a_season < 25))) // festivals
		{
			if (stats->hour >= 18 && stats->current_field == 6)
			{
				if (stats->sex == 1) return "1You're not my type.``";
				else if (stats->sex == 0) return "2Would you like to~dance with me?~_ _``";
			}
			else
			{
				if (stats->current_field == 10) return "3Jesus was a gift~from God to us!~How wonderful!``";
				else return "0Do you give~gifts to others on~Christmas Day?~_2It is a nice custom._4But doesn't that~make you sad?``";
			}
		}
		else
		{
			if (stats->day_of_week == 1) // Sunday
			{
				return "3Give praise to~the Lord! Sing~about His Holy~Name!``";
			}
			else if (stats->weather == 1) // raining
			{
				return "0I try to find~other things to do~when it is raining~outside.``";
			}
			else if (stats->day_of_week == 7) // Saturday
			{
				return "2I love the smell~of the mountains.~It reminds me~of home.``";
			}
			else if (stats->season == 1) // Spring weekdays
			{
				return "0I sit here thinking~and praying. It is~good to set aside~time alone.``";
			}
			else if (stats->season == 2) // Summer weekdays
			{
				return "2I am taking in~all of the sun~that I can manage.~Summer is a very~nice time.``";
			}
			else if (stats->season == 3) // Fall weekdays
			{
				return "0Fall is here,~but Winter is upon~us.`4Then it will~get cold again.``";
			}
			else if (stats->season == 4) // Winter weekdays
			{
				return "0It is warmer~in here during~the Winter, trying~to keep the fish~more comfortable.``";
			}
			else return "0Emily: Error.``";
		}	
	}
	else if (t == ACTOR_TYPE_BUY_ROVER)
	{
		return "0Buy a new Rover!~Purchase for~2000 Credits~and 250 Ore?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_SELL_ROVER)
	{
		return "0Sell an existing Rover.~Exchange for 500 Credits~and 100 Ore?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_WATER_GENERATOR)
	{
		return "0Buy a Water Geneator~for 1000 Credits~and 50 Ore?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_GIFT_BASKET)
	{
		return "0Buy a Gift Basket~for 100 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_ORE)
	{
		return "0Buy 5 Ore~for 100 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_NANOTUBE)
	{
		return "0Buy 20 Nanotubes~for 500 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_RADISH_SEEDS)
	{
		return "0Buy 1 Radish Seed~for 200 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_CABBAGE_SEEDS)
	{
		return "0Buy 1 Cabbage Seed~for 200 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_CUCUMBER_SEEDS)
	{
		return "0Buy 1 Cucumber Seed~for 300 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_BEANS_SEEDS)
	{
		return "0Buy 1 Bean Seed~for 300 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_MELON_SEEDS)
	{
		return "0Buy 1 Melon Seed~for 300 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_TURNIP_SEEDS)
	{
		return "0Buy 1 Turnip Seed~for 200 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_ONION_SEEDS)
	{
		return "0Buy 1 Onion Seed~for 200 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_RYE_SEEDS)
	{
		return "0Buy 1 Rye Seed~for 80 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_NANOTUBE_SEEDS)
	{
		return "0Buy 1 Nanotube Seed~for 500 Credits?~_ _ ``";
	}
	else if (t == ACTOR_TYPE_BUY_NOTHING)
	{
		return "0Nothing to buy!``";
	}
	else if (t == ACTOR_TYPE_BUY_ACCEPTED)
	{
		return "0Great, thank you!``";
	}
	else if (t == ACTOR_TYPE_BUY_REJECTED)
	{
		return "0Sorry, cannot do that.``";
	}
	else if (t == ACTOR_TYPE_WEATHER_GAUGE)
	{
		if (stats->future_weather == 0) return "0Looks like a sunny~forecast tomorrow!``";
		else if (stats->future_weather == 1)
		{
			if (stats->season == 4) return "0Looks like a snowy~forecast tomorrow!``";
			else return "0Looks like a rainy~forecast tomorrow!``";
		}

		return "0Error``";
	}
	else if (t == ACTOR_TYPE_TELEVISION)
	{
		r = r % 10;

		if (r == 0) return "0Plants must have water~to grow. Though~plants are hardy, and~will not die if not~watered.``";
		else if (r == 1) return "0Rovers run on nanotubes.~They are used as~a specific fuel~source that powers~the rovers overnight.``";
		else if (r == 2) return "0Water Generators gather~moisture from the~air and condense it~for use on the farm.``";
		else if (r == 3) return "0Some vegetables will~stay alive during~seasons when they are not~sold in the shop.``";
		else if (r == 4) return "0Crystals hold very~specific molecular~structures that are~needed for advanced~technologies.``";
		else if (r == 5) return "0Rain is very new~to this planet,~but a sure sign that~the terraforming process~is going well.``";
		else if (r == 6) return "0Controlling a robot~is done by a short~distance connection:~from the planet's surface~to low space orbit.``";
		else if (r == 7) return "0The days move~faster than Earth's,~and the seasons likewise~progress quicker as well.``";
		else if (r == 8) return "0All fruits and vegetables~have been specifically~designed to grow and thrive~on the planet.``";
		else if (r == 9) return "0Extractors process~vegetable matter into~a volatile liquid that~is used for many~purposes.``";

		return "0Default``";
	}
	else if (t == ACTOR_TYPE_BIBLE_STATION)
	{
		r = r % 7958;

		input = NULL;

		input = fopen("NewTestamentWEBEnglish.txt", "rt");

		for (int i=0; i<r; i++)
		{
			buffer = 0;

			while (buffer != '$') { fscanf(input, "%c", &buffer); }
		}

		fscanf(input, " %d:%d:%d", &bible_book, &bible_chapter, &bible_verse);
		
		fscanf(input, "%c", &buffer); // space

		for (int i=0; i<1024; i++) self_string[i] = 0;

		for (int i=0; i<32; i++) bible_word[i] = 0;

		self_string[0] = '0';

		if (bible_book == 0) strcat(self_string, "Matt ");
		else if (bible_book == 1) strcat(self_string, "Mark ");
		else if (bible_book == 2) strcat(self_string, "Luke ");
		else if (bible_book == 3) strcat(self_string, "John ");
		else if (bible_book == 4) strcat(self_string, "Acts ");
		else if (bible_book == 5) strcat(self_string, "Rom ");
		else if (bible_book == 6) strcat(self_string, "1Cor ");
		else if (bible_book == 7) strcat(self_string, "2Cor ");
		else if (bible_book == 8) strcat(self_string, "Gal ");
		else if (bible_book == 9) strcat(self_string, "Eph ");
		else if (bible_book == 10) strcat(self_string, "Phil ");
		else if (bible_book == 11) strcat(self_string, "Col ");
		else if (bible_book == 12) strcat(self_string, "1Ths ");
		else if (bible_book == 13) strcat(self_string, "2Ths ");
		else if (bible_book == 14) strcat(self_string, "1Tim ");
		else if (bible_book == 15) strcat(self_string, "2Tim ");
		else if (bible_book == 16) strcat(self_string, "Tit ");
		else if (bible_book == 17) strcat(self_string, "Phlm ");
		else if (bible_book == 18) strcat(self_string, "Heb ");
		else if (bible_book == 19) strcat(self_string, "Jam ");
		else if (bible_book == 20) strcat(self_string, "1Pet ");
		else if (bible_book == 21) strcat(self_string, "2Pet ");
		else if (bible_book == 22) strcat(self_string, "1Jhn ");
		else if (bible_book == 23) strcat(self_string, "2Jhn ");
		else if (bible_book == 24) strcat(self_string, "3Jhn ");
		else if (bible_book == 25) strcat(self_string, "Jude ");
		else if (bible_book == 26) strcat(self_string, "Rev ");

		if (bible_chapter >= 10) 
		{
			buffer = (char)(bible_chapter / 10) + '0';

			strcat(self_string, &buffer);
		}

		buffer = (char)(bible_chapter % 10) + '0';
		
		strcat(self_string, &buffer);

		strcat(self_string, ":");

		if (bible_verse >= 10) 
		{
			buffer = (char)(bible_verse / 10) + '0';

			strcat(self_string, &buffer);
		}

		buffer = (char)(bible_verse % 10) + '0';

		strcat(self_string, &buffer);

		strcat(self_string, "~");	

		bible_line = 1;
		bible_pos = 0;	

		while (buffer != '\n')
		{
			fscanf(input, "%c", &buffer);

			if (buffer == ' ')
			{
				fscanf(input, "%c", &buffer);

				if (buffer == '.' || buffer == ',' || buffer == '!' || buffer == '?' || buffer == ':' || buffer == ';')
				{
					strcat(bible_word, &buffer);

					fscanf(input, "%c", &buffer); // space

					bible_pos += 2;
	
					if (bible_pos >= 24)
					{
						bible_pos = 0;
	
						for (int i=0; i<32; i++) 
						{
							if (bible_word[i] != 0) bible_pos++;
						}
	
						bible_line++;
	
						if (bible_line >= 6)
						{
							strcat(self_string, "`0");
								
							bible_line = 0;
						}
						else strcat(self_string, "~");
					}

					strcat(self_string, bible_word);
	
					for (int i=0; i<32; i++) 
					{
						bible_word[i] = 0;
					}
	
					strcat(self_string, " ");
				}
				else if (buffer == '<')
				{
					fscanf(input, "%c", &buffer);

					strcat(bible_word, &buffer);
	
					bible_pos++;
	
					if (bible_pos >= 24)
					{
						bible_pos = 0;
	
						for (int i=0; i<32; i++) 
						{
							if (bible_word[i] != 0) bible_pos++;
						}
	
						bible_line++;
	
						if (bible_line >= 6)
						{
							strcat(self_string, "`0");
								
							bible_line = 0;
						}
						else strcat(self_string, "~");
					}
	
					//fscanf(input, "%c", &buffer); // space
				}
				else if (buffer == '>')
				{
					//fscanf(input, "%c", &buffer);

					fscanf(input, "%c", &buffer);

					strcat(bible_word, &buffer);
	
					bible_pos++;
	
					if (bible_pos >= 24)
					{
						bible_pos = 0;
	
						for (int i=0; i<32; i++) 
						{
							if (bible_word[i] != 0) bible_pos++;
						}
	
						bible_line++;
	
						if (bible_line >= 6)
						{
							strcat(self_string, "`0");
								
							bible_line = 0;
						}
						else strcat(self_string, "~");
					}
	
					//fscanf(input, "%c", &buffer); // space
				}
				else if (buffer == '/')
				{
					fscanf(input, "%c", &buffer);
				}
				else if (buffer == '\\')
				{
					fscanf(input, "%c", &buffer);
				}
				else
				{
					bible_pos++;
	
					if (bible_pos >= 24)
					{
						bible_pos = 0;
	
						for (int i=0; i<32; i++) 
						{
							if (bible_word[i] != 0) bible_pos++;
						}
	
						bible_line++;
	
						if (bible_line >= 6)
						{
							strcat(self_string, "`0");
								
							bible_line = 0;
						}
						else strcat(self_string, "~");
					}
								
					strcat(self_string, bible_word);
	
					for (int i=0; i<32; i++) 
					{
						bible_word[i] = 0;
					}
	
					strcat(self_string, " ");


					strcat(bible_word, &buffer);
	
					bible_pos++;
	
					if (bible_pos >= 24)
					{
						bible_pos = 0;
	
						for (int i=0; i<32; i++) 
						{
							if (bible_word[i] != 0) bible_pos++;
						}
	
						bible_line++;
	
						if (bible_line >= 6)
						{
							strcat(self_string, "`0");
								
							bible_line = 0;
						}
						else strcat(self_string, "~");
					}
				}
			}
			else if (buffer == '<')
			{
				fscanf(input, "%c", &buffer);

				strcat(bible_word, &buffer);

				bible_pos++;

				if (bible_pos >= 24)
				{
					bible_pos = 0;

					for (int i=0; i<32; i++) 
					{
						if (bible_word[i] != 0) bible_pos++;
					}

					bible_line++;

					if (bible_line >= 6)
					{
						strcat(self_string, "`0");
							
						bible_line = 0;
					}
					else strcat(self_string, "~");
				}

				//fscanf(input, "%c", &buffer); // space
			}
			else if (buffer == '>')
			{
				//fscanf(input, "%c", &buffer);

				fscanf(input, "%c", &buffer);

				strcat(bible_word, &buffer);

				bible_pos++;

				if (bible_pos >= 24)
				{
					bible_pos = 0;

					for (int i=0; i<32; i++) 
					{
						if (bible_word[i] != 0) bible_pos++;
					}

					bible_line++;

					if (bible_line >= 6)
					{
						strcat(self_string, "`0");
							
						bible_line = 0;
					}
					else strcat(self_string, "~");
				}

				//fscanf(input, "%c", &buffer); // space
			}
			else if (buffer == '/')
			{
				fscanf(input, "%c", &buffer);
			}
			else if (buffer == '\\')
			{
				fscanf(input, "%c", &buffer);
			}
			else
			{
				strcat(bible_word, &buffer);

				bible_pos++;

				if (bible_pos >= 24)
				{
					bible_pos = 0;

					for (int i=0; i<32; i++) 
					{
						if (bible_word[i] != 0) bible_pos++;
					}

					bible_line++;

					if (bible_line >= 6)
					{
						strcat(self_string, "`0");
							
						bible_line = 0;
					}
					else strcat(self_string, "~");
				}
			}
		}

		if (bible_pos >= 24)
		{
			bible_pos = 0;

			bible_line++;

			if (bible_line >= 6)
			{
				strcat(self_string, "`0");
							
				bible_line = 0;
			}
			else strcat(self_string, "~");
		}
					
		strcat(self_string, bible_word);

		for (int i=0; i<32; i++) bible_word[i] = 0;	

		fclose(input);

		strcat(self_string, "``");
		
		return self_string;
	}
	else return "0Error``";
	
	return "0Error``";
};		

void DrawDialog(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats, int type, int num, int random_number, bool key_down)
{
	char temp_string[1024];

	int temp_dist = 0;

	int previous_question = 0;

	for (int i=0; i<1024; i++) temp_string[i] = 0;

	if (type == -2 || type == ACTOR_TYPE_BIBLE_STATION) self_string = new char[1024];
	if (type == ACTOR_TYPE_BIBLE_STATION) bible_word = new char[32];

	sprintf(temp_string, "%s", RandomConversation(field, inventory, cast, stats, type, num, random_number));

	//printf("%s", temp_string);

	if (type == -2 || type == ACTOR_TYPE_BIBLE_STATION) delete self_string;
	if (type == ACTOR_TYPE_BIBLE_STATION) delete bible_word;

	for (int i=0; i<=stats->dialog_place; i++) 
	{
		if (temp_string[i] == '_') previous_question++;
	}

	glDisable(GL_LIGHTING);

	if (temp_string[stats->dialog_place] >= '0' && temp_string[stats->dialog_place] <= '9')
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
			
		glColor3f(1,1,1);
		
		glBegin(GL_QUADS);
	
		glVertex3f(-0.525f, -0.125f, -1.0f);
		glVertex3f(-0.525f, -0.5f, -1.0f);
		glVertex3f(0.525f, -0.5f, -1.0f);
		glVertex3f(0.525f, -0.125f, -1.0f);

		glTexCoord2f(0,1);
		glVertex3f(-0.535f, -0.06f, -0.99f);
		glTexCoord2f(0,0);
		glVertex3f(-0.535f, -0.115f, -0.99f);
		glTexCoord2f(1,0);
		glVertex3f(-0.35f, -0.115f, -0.99f);
		glTexCoord2f(1,1);
		glVertex3f(-0.35f, -0.06f, -0.99f);
	
		glEnd();

/*
		if (type == -2 || type == -3) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]); // self
		else if (type == ACTOR_TYPE_NONE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		else if (type == ACTOR_TYPE_ROVER || type == ACTOR_TYPE_PARROT) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ROVER_FACES]);
		else if (type == ACTOR_TYPE_DAVID) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_DAVID_FACES]);
		else if (type == ACTOR_TYPE_CLARA) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CLARA_FACES]);
		else if (type == ACTOR_TYPE_ANDREW) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ANDREW_FACES]);
		else if (type == ACTOR_TYPE_EMILY) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMILY_FACES]);
		else if (type == ACTOR_TYPE_BIBLE_STATION) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CROSS_FACES]);
		else if (type == ACTOR_TYPE_TELEVISION) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TELEVISION_FACES]);
		else glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
	
		glColor3f(1,1,1);

		glBegin(GL_QUADS);
		
		glTexCoord2f((float)(temp_string[stats->dialog_place]-'0') * 0.2f, 1.0f);
		glVertex3f(-0.535f, -0.115f, -0.99f);
		glTexCoord2f((float)(temp_string[stats->dialog_place]-'0') * 0.2f, 0.0f);
		glVertex3f(-0.535f, -0.375f, -0.99f);
		glTexCoord2f((float)(temp_string[stats->dialog_place]-'0'+1) * 0.2f, 0.0f);
		glVertex3f(-0.275f, -0.375f, -0.99f);
		glTexCoord2f((float)(temp_string[stats->dialog_place]-'0'+1) * 0.2f, 1.0f);
		glVertex3f(-0.275f, -0.115f, -0.99f);
	
		glEnd();
*/
		if (type == -2 || type == -3) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]); // self
		else if (type == ACTOR_TYPE_NONE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		else if (type == ACTOR_TYPE_ROVER || type == ACTOR_TYPE_PARROT) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ROVER_FACES]);
		else if (type == ACTOR_TYPE_DAVID)
		{
			if (temp_string[stats->dialog_place] == '0') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_DAVID_FACES_0]);
			else if (temp_string[stats->dialog_place] == '1') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_DAVID_FACES_1]);
			else if (temp_string[stats->dialog_place] == '2') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_DAVID_FACES_2]);
			else if (temp_string[stats->dialog_place] == '3') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_DAVID_FACES_3]);
			else if (temp_string[stats->dialog_place] == '4') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_DAVID_FACES_4]);
		}
		else if (type == ACTOR_TYPE_CLARA)
		{
			if (temp_string[stats->dialog_place] == '0') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CLARA_FACES_0]);
			else if (temp_string[stats->dialog_place] == '1') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CLARA_FACES_1]);
			else if (temp_string[stats->dialog_place] == '2') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CLARA_FACES_2]);
			else if (temp_string[stats->dialog_place] == '3') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CLARA_FACES_3]);
			else if (temp_string[stats->dialog_place] == '4') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CLARA_FACES_4]);
		}
		else if (type == ACTOR_TYPE_ANDREW)
		{
			if (temp_string[stats->dialog_place] == '0') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ANDREW_FACES_0]);
			else if (temp_string[stats->dialog_place] == '1') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ANDREW_FACES_1]);
			else if (temp_string[stats->dialog_place] == '2') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ANDREW_FACES_2]);
			else if (temp_string[stats->dialog_place] == '3') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ANDREW_FACES_3]);
			else if (temp_string[stats->dialog_place] == '4') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ANDREW_FACES_4]);
		}
		else if (type == ACTOR_TYPE_EMILY)
		{
			if (temp_string[stats->dialog_place] == '0') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMILY_FACES_0]);
			else if (temp_string[stats->dialog_place] == '1') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMILY_FACES_1]);
			else if (temp_string[stats->dialog_place] == '2') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMILY_FACES_2]);
			else if (temp_string[stats->dialog_place] == '3') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMILY_FACES_3]);
			else if (temp_string[stats->dialog_place] == '4') glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMILY_FACES_4]);
		}
		else if (type == ACTOR_TYPE_BIBLE_STATION) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CROSS_FACES]);
		else if (type == ACTOR_TYPE_TELEVISION) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TELEVISION_FACES]);
		else glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
	
		glColor3f(1,1,1);

		glBegin(GL_QUADS);
		
		if (type == ACTOR_TYPE_DAVID || type == ACTOR_TYPE_CLARA || type == ACTOR_TYPE_ANDREW || type == ACTOR_TYPE_EMILY)
		{
			glTexCoord2f(0.1f, 0.9f);
			glVertex3f(-0.535f, -0.115f, -0.99f);
			glTexCoord2f(0.1f, 0.1f);
			glVertex3f(-0.535f, -0.375f, -0.99f);
			glTexCoord2f(0.9f, 0.1f);
			glVertex3f(-0.275f, -0.375f, -0.99f);
			glTexCoord2f(0.9f, 0.9f);
			glVertex3f(-0.275f, -0.115f, -0.99f);
		}
		else
		{
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-0.535f, -0.115f, -0.99f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-0.535f, -0.375f, -0.99f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(-0.275f, -0.375f, -0.99f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(-0.275f, -0.115f, -0.99f);
		}
	
		glEnd();


		stats->dialog_place++;
		temp_dist++;

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(0.01f, 0.01f, 0.01f);			
		glLineWidth(2);

		glPushMatrix();	
		glTranslatef(-0.52f, -0.1f, -0.98f);
		glScalef(0.00025f, 0.0003f, 0.0003f);

		if (type == -3)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'Y');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		}
		else if (type == -2)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'U');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		}
		else if (type == ACTOR_TYPE_ROVER)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'O');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'V');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		}
		else if (type == ACTOR_TYPE_PARROT)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'O');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		}
		else if (type == ACTOR_TYPE_BUY_ACCEPTED)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'C');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'C');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		}
		else if (type == ACTOR_TYPE_BUY_REJECTED)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'J');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'C');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		}
		else if (type == ACTOR_TYPE_WEATHER_GAUGE)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'G');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'U');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'G');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
		}
		else if (type == ACTOR_TYPE_TELEVISION)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'V');
		}
		else if (type == ACTOR_TYPE_BUY_ROVER ||
			type == ACTOR_TYPE_SELL_ROVER ||
			type == ACTOR_TYPE_BUY_WATER_GENERATOR ||
			type == ACTOR_TYPE_BUY_GIFT_BASKET ||
			type == ACTOR_TYPE_BUY_ORE ||
			type == ACTOR_TYPE_BUY_NANOTUBE ||
			type == ACTOR_TYPE_BUY_RADISH_SEEDS ||
			type == ACTOR_TYPE_BUY_CABBAGE_SEEDS ||
			type == ACTOR_TYPE_BUY_CUCUMBER_SEEDS ||
			type == ACTOR_TYPE_BUY_BEANS_SEEDS ||
			type == ACTOR_TYPE_BUY_MELON_SEEDS ||
			type == ACTOR_TYPE_BUY_TURNIP_SEEDS ||
			type == ACTOR_TYPE_BUY_ONION_SEEDS ||
			type == ACTOR_TYPE_BUY_RYE_SEEDS ||
			type == ACTOR_TYPE_BUY_NANOTUBE_SEEDS)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'N');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, '.');
		}
		else if (type == ACTOR_TYPE_DAVID)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'D');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'V');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'I');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'D');
		}
		else if (type == ACTOR_TYPE_CLARA)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'C');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
		}
		else if (type == ACTOR_TYPE_ANDREW)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'N');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'D');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'W');
		}
		else if (type == ACTOR_TYPE_EMILY)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'M');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'I');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'Y');
		}
		else if (type == ACTOR_TYPE_BIBLE_STATION)
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'I');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
		}
		else
		{
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'O');
			glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		}
			
		glPopMatrix();
		
		for (int i=0; i<6; i++)
		{
			glPushMatrix();	
			glTranslatef(-0.25f, -0.175f - 0.04f * (float)i, -0.99f);
			glScalef(0.00025f, 0.0003f, 0.0003f);	
	
			for (int j=0; j<1024; j++)
			{
				if (temp_string[stats->dialog_place] == '`') { i = 7; j = 1025; } // end of string
				else if (temp_string[stats->dialog_place] == '~') { j = 1025; } // end of line
				else if (temp_string[stats->dialog_place] == '_' && previous_question == 0) // yes/no question
				{
					glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
					glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
					if (stats->dialog_selection == 0) glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '<');
					else glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
					glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'Y');
					glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'e');
					glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 's');
					if (stats->dialog_selection == 0) glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '>');
					else glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
					glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
					if (stats->dialog_selection == 1) glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '<');
					else glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');
					glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'N');
					glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, 'o');
					if (stats->dialog_selection == 1) glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, '>');
					else glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, ' ');

					i = 7; 
					j = 1025;
				}
				else if (temp_string[stats->dialog_place] == '_' && previous_question > 0) // answered already
				{
					for (int k=0; k<1024; k++)
					{
						if (!(temp_string[stats->dialog_place] == '`' && temp_string[stats->dialog_place+1] == '`'))
						{
							stats->dialog_place++;
							temp_dist++;
						}
						else k = 1025;
					}

					stats->dialog_place++;
					temp_dist++;

					i = 7; 
					j = 1025;
				}
				else if (temp_string[stats->dialog_place] != 0) glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, temp_string[stats->dialog_place]);
	
				stats->dialog_place++;
				temp_dist++;
			}
				
			glPopMatrix();
		}
	}
	else stats->dialog_up = -1;

	glEnable(GL_LIGHTING);

	if (key_down == true && stats->activate_on == false && stats->dialog_selection != -1)
	{
		if (type == ACTOR_TYPE_DAVID || type == ACTOR_TYPE_CLARA || type == ACTOR_TYPE_ANDREW || type == ACTOR_TYPE_EMILY ||
			type == ACTOR_TYPE_ROVER || type == ACTOR_TYPE_PARROT)
		{
			if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Chat.wav &");
			else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Chat.wav"), NULL, SND_FILENAME | SND_ASYNC);
		}
		else
		{
			if (linux_box == true && sound_on == true) system("play -q -v 1.0 ./Sounds/Beep.wav &");
			else if (linux_box == false && sound_on == true) PlaySound(TEXT("Sounds\\Beep.wav"), NULL, SND_FILENAME | SND_ASYNC);
		}

		stats->activate_on = true;

		if (temp_string[stats->dialog_place-1] == '_' && stats->dialog_selection == 1)
		{
			for (int i=0; i<1024; i++)
			{
				if (temp_string[stats->dialog_place] != '_') stats->dialog_place++;
				else i = 1025;
			}

			stats->dialog_place++;
		}
	}
	else
	{
		stats->dialog_place -= temp_dist;
	}
	
	if (key_down == false)
	{
		stats->activate_on = false;
	}

	return;
};

void DrawInventory(_Inventory *inventory, int selected, float tool_rot)
{
	glTranslatef(0.0f, -0.015f, 0.0f);

	for (int i=0; i<12; i++)
	{
		glDisable(GL_LIGHTING);
	
		if (selected == i) glColor3f(0,0,1);
		else glColor3f(1,1,1);
	
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glBegin(GL_QUADS);
	
		glTexCoord2f(0,1);
		glVertex3f(-0.45f+(float)i*0.075f, 0.365f, -0.9f);
		glTexCoord2f(0,0);
		glVertex3f(-0.45f+(float)i*0.075f, 0.29f, -0.9f);
		glTexCoord2f(1,0);
		glVertex3f(-0.375f+(float)i*0.075f, 0.29f, -0.9f);
		glTexCoord2f(1,1);
		glVertex3f(-0.375f+(float)i*0.075f, 0.365f, -0.9f);
		
		glEnd();

		if (inventory->tool[i]->type == TOOL_TYPE_HOE || inventory->tool[i]->type == TOOL_TYPE_ADAMANTINE_HOE)
		{
			glTranslatef(-0.45f+0.06f+(float)i*0.071f, 0.365f-0.05f, -0.85f);
			glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
			glScalef(0.015f, 0.015f, 0.015f);
			if (inventory->tool[i]->type == TOOL_TYPE_HOE) glColor3f(0.75f, 0.75f, 0.75f);
			else if (inventory->tool[i]->type == TOOL_TYPE_ADAMANTINE_HOE) glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(hoe_point, hoe_indice, 18);
			glScalef(1.0f / 0.015f, 1.0f / 0.015f, 1.0f / 0.015f);
			glRotatef(-45.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			glTranslatef(0.45f-0.06f-(float)i*0.071f, -0.365f+0.05f, 0.85f);

			if (selected == i)
			{
				glColor3f(1,1,1);

				glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		
				glBegin(GL_QUADS);
	
				glTexCoord2f(0,1);
				glVertex3f(-0.45f+(float)i*0.075f, 0.29f, -0.9f);
				glTexCoord2f(0,0);
				glVertex3f(-0.45f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,0);
				glVertex3f(-0.375f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,1);
				glVertex3f(-0.375f+(float)i*0.075f, 0.29f, -0.9f);
				
				glEnd();
	
				glColor3f(0.01f, 0.01f, 0.01f);
	
				glPushMatrix();	
				glTranslatef(-0.4325f+(float)i*0.075f, 0.26f, -0.89f);
				glScalef(0.0002f, 0.0002f, 0.0002f);
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'H');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
				glPopMatrix();
			}	
		}
		else if (inventory->tool[i]->type == TOOL_TYPE_HAMMER || inventory->tool[i]->type == TOOL_TYPE_ADAMANTINE_HAMMER)
		{
			glTranslatef(-0.45f+0.06f+(float)i*0.071f, 0.365f-0.05f, -0.85f);
			glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
			glScalef(0.015f, 0.015f, 0.015f);
			if (inventory->tool[i]->type == TOOL_TYPE_HAMMER) glColor3f(0.75f, 0.75f, 0.75f);
			else if (inventory->tool[i]->type == TOOL_TYPE_ADAMANTINE_HAMMER) glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(hammer_point, hammer_indice, 26);
			glScalef(1.0f / 0.015f, 1.0f / 0.015f, 1.0f / 0.015f);
			glRotatef(-45.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			glTranslatef(0.45f-0.06f-(float)i*0.071f, -0.365f+0.05f, 0.85f);

			if (selected == i)
			{
				glColor3f(1,1,1);

				glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

				glBegin(GL_QUADS);
	
				glTexCoord2f(0,1);
				glVertex3f(-0.45f+(float)i*0.075f, 0.29f, -0.9f);
				glTexCoord2f(0,0);
				glVertex3f(-0.45f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,0);
				glVertex3f(-0.375f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,1);
				glVertex3f(-0.375f+(float)i*0.075f, 0.29f, -0.9f);
		
				glEnd();
		
				glColor3f(0.01f, 0.01f, 0.01f);
	
				glPushMatrix();	
				glTranslatef(-0.445f+(float)i*0.075f, 0.265f, -0.89f);
				glScalef(0.00014f, 0.00014f, 0.00014f);
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'H');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
				glPopMatrix();
			}
		}
		else if (inventory->tool[i]->type == TOOL_TYPE_SCYTHE || inventory->tool[i]->type == TOOL_TYPE_ADAMANTINE_SCYTHE)
		{
			glTranslatef(-0.45f+0.06f+(float)i*0.071f, 0.365f-0.06f, -0.85f);
			glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
			glScalef(0.0125f, 0.0125f, 0.0125f);
			if (inventory->tool[i]->type == TOOL_TYPE_SCYTHE) glColor3f(0.75f, 0.75f, 0.75f);
			else if (inventory->tool[i]->type == TOOL_TYPE_ADAMANTINE_SCYTHE) glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(scythe_point, scythe_indice, 30);
			glScalef(1.0f / 0.0125f, 1.0f / 0.0125f, 1.0f / 0.0125f);
			glRotatef(-45.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			glTranslatef(0.45f-0.06f-(float)i*0.071f, -0.365f+0.06f, 0.85f);

			if (selected == i)
			{
				glColor3f(1,1,1);

				glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

				glBegin(GL_QUADS);
	
				glTexCoord2f(0,1);
				glVertex3f(-0.45f+(float)i*0.075f, 0.29f, -0.9f);
				glTexCoord2f(0,0);
				glVertex3f(-0.45f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,0);
				glVertex3f(-0.375f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,1);
				glVertex3f(-0.375f+(float)i*0.075f, 0.29f, -0.9f);
		
				glEnd();
		
				glColor3f(0.01f, 0.01f, 0.01f);
	
				glPushMatrix();	
				glTranslatef(-0.445f+(float)i*0.075f, 0.265f, -0.89f);
				glScalef(0.000165f, 0.000165f, 0.000165f);
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
				glPopMatrix();
			}
		}
		else if (inventory->tool[i]->type == TOOL_TYPE_WATERING_CAN || inventory->tool[i]->type == TOOL_TYPE_ADAMANTINE_WATERING_CAN)
		{
			glTranslatef(-0.45f+0.06f+(float)i*0.071f, 0.365f-0.055f, -0.85f);
			glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
			glScalef(0.0175f, 0.0175f, 0.0175f);
			if (inventory->tool[i]->type == TOOL_TYPE_WATERING_CAN) glColor3f(0.75f, 0.75f, 0.75f);
			else if (inventory->tool[i]->type == TOOL_TYPE_ADAMANTINE_WATERING_CAN) glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(watering_can_point, watering_can_indice, 22);
			glScalef(1.0f / 0.0175f, 1.0f / 0.0175f, 1.0f / 0.0175f);
			glRotatef(-45.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			glTranslatef(0.45f-0.06f-(float)i*0.071f, -0.365f+0.055f, 0.85f);

			if (selected == i)
			{
				glColor3f(1,1,1);

				glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		
				glBegin(GL_QUADS);
	
				glTexCoord2f(0,1);
				glVertex3f(-0.45f+(float)i*0.075f, 0.29f, -0.9f);
				glTexCoord2f(0,0);
				glVertex3f(-0.45f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,0);
				glVertex3f(-0.375f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,1);
				glVertex3f(-0.375f+(float)i*0.075f, 0.29f, -0.9f);
		
				glEnd();

				glColor3f(0.01f, 0.01f, 0.01f);
	
				glPushMatrix();	
				glTranslatef(-0.445f+(float)i*0.075f, 0.265f, -0.89f);
				glScalef(0.00013f, 0.00013f, 0.00013f);
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'W');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'C');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
				glPopMatrix();
			}
		}
		else if (inventory->tool[i]->type == TOOL_TYPE_PORTABLE_EXCHANGER)
		{
			glTranslatef(-0.45f+0.06f+(float)i*0.071f, 0.365f-0.07f, -0.85f);
			glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(-45.0f, 1.0f, 0.0f, 0.0f);
			glScalef(0.0175f, 0.0175f, 0.0175f);
			

			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

			glPushMatrix();

			glScalef(0.65f, 0.65f, 0.65f);

			glColor3f(0.5f, 0.5f, 0.5f);
	
			DrawComponent(exchanger_point, exchanger_indice, 10);
	
			glColor3f(1,1,1);
	
			glTranslatef(0.0f, 0.0f, 1.5f);
			
			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
			//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
	
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	
			glTranslatef(0.0f, 0.0f, 3.1f);
	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXCHANGER]);
		
			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.4f, 2.9f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.4f, 0.1f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.4f, 0.1f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.4f, 2.9f, 0.0f);
			
			glEnd();

			glPopMatrix();


			glScalef(1.0f / 0.0175f, 1.0f / 0.0175f, 1.0f / 0.0175f);
			glRotatef(45.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-tool_rot * 180.0f / 3.14159f, 0.0f, 0.0f, 1.0f);
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
			glTranslatef(0.45f-0.06f-(float)i*0.071f, -0.365f+0.07f, 0.85f);

			if (selected == i)
			{
				glColor3f(1,1,1);

				glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		
				glBegin(GL_QUADS);
	
				glTexCoord2f(0,1);
				glVertex3f(-0.45f+(float)i*0.075f, 0.29f, -0.9f);
				glTexCoord2f(0,0);
				glVertex3f(-0.45f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,0);
				glVertex3f(-0.375f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,1);
				glVertex3f(-0.375f+(float)i*0.075f, 0.29f, -0.9f);
		
				glEnd();

				glColor3f(0.01f, 0.01f, 0.01f);
	
				glPushMatrix();	
				glTranslatef(-0.445f+(float)i*0.075f, 0.265f, -0.89f);
				glScalef(0.00013f, 0.00013f, 0.00013f);
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'X');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'C');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'g');
				glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
				glPopMatrix();
			}
		}
		else if (inventory->tool[i]->type != TOOL_TYPE_NONE)
		{
			glColor3f(1,1,1);

			if (inventory->tool[i]->type == TOOL_TYPE_RYE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_RYE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE]);
			else if (inventory->tool[i]->type == TOOL_TYPE_NANOTUBE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_NANOTUBE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE]);
			else if (inventory->tool[i]->type == TOOL_TYPE_RADISH_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_RADISH) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH]);
			else if (inventory->tool[i]->type == TOOL_TYPE_CABBAGE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_CABBAGE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE]);
			else if (inventory->tool[i]->type == TOOL_TYPE_CUCUMBER_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_CUCUMBER) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER]);
			else if (inventory->tool[i]->type == TOOL_TYPE_BEANS_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_BEANS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS]);
			else if (inventory->tool[i]->type == TOOL_TYPE_MELON_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_MELON) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON]);
			else if (inventory->tool[i]->type == TOOL_TYPE_TURNIP_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_TURNIP) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP]);
			else if (inventory->tool[i]->type == TOOL_TYPE_ONION_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION_SEED]);
			else if (inventory->tool[i]->type == TOOL_TYPE_ONION) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION]);
			else if (inventory->tool[i]->type == TOOL_TYPE_ORE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE]);
			else if (inventory->tool[i]->type == TOOL_TYPE_BERRY) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BERRY]);
			else if (inventory->tool[i]->type == TOOL_TYPE_APPLE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_APPLE]);
			else if (inventory->tool[i]->type == TOOL_TYPE_MUSHROOM) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MUSHROOM]);
			else if (inventory->tool[i]->type == TOOL_TYPE_CRYSTAL) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CRYSTAL]);
			else if (inventory->tool[i]->type == TOOL_TYPE_FISH) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_FISH]);
			else if (inventory->tool[i]->type == TOOL_TYPE_EXTRACT) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXTRACT]);
			else if (inventory->tool[i]->type == TOOL_TYPE_GIFT_BASKET) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BASKET_HERB]);

			glBegin(GL_QUADS);
		
			glTexCoord2f(0,1);
			glVertex3f(-0.45f+(float)i*0.075f, 0.365f, -0.9f);
			glTexCoord2f(0,0);
			glVertex3f(-0.45f+(float)i*0.075f, 0.29f, -0.9f);
			glTexCoord2f(1,0);
			glVertex3f(-0.375f+(float)i*0.075f, 0.29f, -0.9f);
			glTexCoord2f(1,1);
			glVertex3f(-0.375f+(float)i*0.075f, 0.365f, -0.9f);
	
			glEnd();

			if (selected == i)
			{
				glColor3f(1,1,1);

				glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

				glBegin(GL_QUADS);
		
				glTexCoord2f(0,1);
				glVertex3f(-0.45f+(float)i*0.075f, 0.29f, -0.9f);
				glTexCoord2f(0,0);
				glVertex3f(-0.45f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,0);
				glVertex3f(-0.375f+(float)i*0.075f, 0.25f, -0.9f);
				glTexCoord2f(1,1);
				glVertex3f(-0.375f+(float)i*0.075f, 0.29f, -0.9f);
		
				glEnd();

				glColor3f(0.01f, 0.01f, 0.01f);

				if (inventory->tool[i]->type == TOOL_TYPE_RYE_SEED ||
					inventory->tool[i]->type == TOOL_TYPE_NANOTUBE_SEED ||
					inventory->tool[i]->type == TOOL_TYPE_RADISH_SEED ||
					inventory->tool[i]->type == TOOL_TYPE_CABBAGE_SEED ||
					inventory->tool[i]->type == TOOL_TYPE_CUCUMBER_SEED ||
					inventory->tool[i]->type == TOOL_TYPE_BEANS_SEED ||
					inventory->tool[i]->type == TOOL_TYPE_MELON_SEED ||
					inventory->tool[i]->type == TOOL_TYPE_TURNIP_SEED ||
					inventory->tool[i]->type == TOOL_TYPE_ONION_SEED)
				{
					glPushMatrix();	
					glTranslatef(-0.44f+(float)i*0.075f, 0.26f, -0.89f);
					glScalef(0.0002f, 0.0002f, 0.0002f);
					glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
					glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
					glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
					glutStrokeCharacter(GLUT_STROKE_ROMAN, 'd');
					glPopMatrix();
				}
				else
				{
					glPushMatrix();	
					glTranslatef(-0.44f+(float)i*0.075f, 0.26f, -0.89f);
					glScalef(0.0002f, 0.0002f, 0.0002f);
					glutStrokeCharacter(GLUT_STROKE_ROMAN, 'I');
					glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
					glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
					glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
					glPopMatrix();
				}
			}
		}

		glEnable(GL_LIGHTING);
	}

	glTranslatef(0.0f, 0.015f, 0.0f);

	return;
};

const char *ActivateMessage(_Field **field, _Inventory *inventory, _Cast *cast, _Stats *stats)
{	
	float character_radius = 0.35f;

	bool test;

	if (stats->activate_on == false) // enter, activate
	{
		test = false;

		for (int k=0; k<30; k++)
		{
			if (cast->actor[k]->type != ACTOR_TYPE_NONE &&
				cast->actor[k]->present_field == stats->current_field &&
				fabs((stats->fx + 1.5f * character_radius * (float)(stats->dx - stats->px)) - cast->actor[k]->fx) < character_radius &&
				fabs((stats->fy + 1.5f * character_radius * (float)(stats->dy - stats->py)) - cast->actor[k]->fy) < character_radius)
			{
				test = true;

				if (cast->actor[k]->type == ACTOR_TYPE_ROVER)
				{
					return "Repair";
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_DAVID)
				{
					if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH) // best
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL) // good
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE) // meh
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET) // bad
					{
						return "Give";
					}
					else // talking
					{
						return "Talk";
					}
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_CLARA)
				{
					if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY) // best
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET) // good
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT) // meh
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH) // bad
					{
						return "Give";
					}
					else // talking
					{
						return "Talk";
					}
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_ANDREW)
				{
					if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON) // best
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET) // good
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT) // meh
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE) // bad
					{
						return "Give";
					}
					else // talking
					{
						return "Talk";
					}
				}
				else if (cast->actor[k]->type == ACTOR_TYPE_EMILY)
				{
					if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET) // best
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT) // good
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE ||
						inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE) // meh
					{
						return "Give";
					}
					else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM) // bad
					{
						return "Give";
					}
					else // talking
					{
						return "Talk";
					}
				}

				return "View";
			}
		}

		if (test == false)
		{
			if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
			{
				if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CHARGING_STATION)
				{
					return "Sleep";
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY)
				{
					return "Fish";
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_WAITING)
				{
					return "";
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_HOOKED)
				{
					return "Catch";
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DYNAMO_CHARGER)
				{
					return "Charge";
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MINI_SPEED_CHALLENGE)
				{
					if (stats->countdown > 0)
					{
						return "Raise";
					}
					else if (stats->countdown <= -5) 
					{
						return "Start";
					}
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MINI_TIMING_CHALLENGE)
				{
					if (stats->countdown > 0)
					{
						return "Target";
					}
					else if (stats->countdown <= -5) 
					{
						return "Start";
					}
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MATCHING_CHALLENGE)
				{
					if (stats->countdown <= -5)
					{
						return "Start";
					}

					if (stats->countdown > 0 && field[stats->current_field]->tile[stats->dx][stats->dy]->growth == 1)
					{
						return "Select";
					}
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DONATION_BOX && stats->credits >= 100)
				{
					return "Donate";
				}			
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ARCADE)
				{
					return "Play";
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CONTAINER &&
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_NONE+1 &&
					inventory->tool[stats->current_tool]->type != TOOL_TYPE_NONE &&
					inventory->tool[stats->current_tool]->type != TOOL_TYPE_PORTABLE_EXCHANGER)
				{
					return "Store";
				}
				else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CONTAINER &&
					(field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_RADISH_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_CABBAGE_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_CUCUMBER_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_BEANS_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_MELON_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_TURNIP_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_ONION_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_RYE_SEED+1 ||
					field[stats->current_field]->tile[stats->dx][stats->dy]->growth == TOOL_TYPE_NANOTUBE_SEED+1) &&
					inventory->tool[stats->current_tool]->type == field[stats->current_field]->tile[stats->dx][stats->dy]->growth-1 &&
					inventory->tool[stats->current_tool]->type != TOOL_TYPE_NONE &&
					inventory->tool[stats->current_tool]->type != TOOL_TYPE_PORTABLE_EXCHANGER)
				{
					return "Store";
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_HOE && stats->energy > 1 && stats->animation_type != 4)
				{
					return "Dig";
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_HAMMER && stats->energy > 1 && stats->animation_type != 5) 
				{
					return "Smash";
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_SCYTHE && stats->energy > 1 && stats->animation_type != 6)
				{
					return "Cut";
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_WATERING_CAN && stats->energy > 0 && stats->animation_type != 7)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WATER_GENERATOR)
						{
							return "Fill";
						}
					}

					return "Water";
				}

				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_HOE && stats->energy > 2 && stats->animation_type != 13)
				{
					return "Dig";
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_HAMMER && stats->energy > 2 && stats->animation_type != 14) 
				{
					return "Smash";
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_SCYTHE && stats->energy > 2 && stats->animation_type != 15)
				{
					return "Cut";
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ADAMANTINE_WATERING_CAN && stats->energy > 1 && stats->animation_type != 16)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_WATER_GENERATOR)
						{
							return "Fill";
						}
					}

					return "Water";
				}

				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE_SEED ||
					inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE_SEED)
				{			
					if (inventory->tool[stats->current_tool]->quantity > 0 && stats->energy > 0 && stats->animation_type != 8)
					{
						return "Sow";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RADISH)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CABBAGE)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							inventory->tool[stats->current_tool]->type = TOOL_TYPE_RADISH_SEED;
							
							inventory->tool[stats->current_tool]->quantity = 5;
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CUCUMBER)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BEANS)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MELON)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_TURNIP)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ONION)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_RYE)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NANOTUBE)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							
						}
*/
/*
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_SEED_EXTRACTOR)
						{
							
						}
*/
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EMPTY_ROVER_STATION)
						{
							return "Place";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE_DISTRIBUTOR)
						{
							return "Store";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_ORE)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Store";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Store";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_BERRY)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_APPLE)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_MUSHROOM)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_CRYSTAL)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_FISH)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type != TILE_TYPE_FISHERY_CAUGHT) // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_EXTRACT)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER &&
							stats->hour * 60 + stats->minute <= 1020) // 5:00pm
						{
							return "Sell";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR)
						{
							return "Fill";
						}
						else // destroyed?
						{
							return "Toss";
						}
					}
					else
					{
						return "Toss";
					}
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_GIFT_BASKET)
				{
					return "Toss";
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_PORTABLE_EXCHANGER)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_DIRT &&
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth == 0)
						{
							return "Place";
						}
					}	
				}
				else if (inventory->tool[stats->current_tool]->type == TOOL_TYPE_NONE)
				{
					if (stats->dx >= 0 && stats->dx < 100 && stats->dy >= 0 && stats->dy < 100)
					{
						if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_RADISH && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 4)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CABBAGE && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 7)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUCUMBER && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 9)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BEANS && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 12)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MELON && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 15)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_TURNIP && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 6)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ONION && 
							field[stats->current_field]->tile[stats->dx][stats->dy]->growth >= 11)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CUT_RYE)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BROKEN_ORE)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BERRY_BUSH)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_APPLE_TREE)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_MUSHROOM_BED)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_BROKEN_CRYSTAL)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_NANOTUBE_DISTRIBUTOR)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_ROVER_DEPOSIT)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_FISHERY_CAUGHT)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_EXTRACTOR_READY)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_CONTAINER)
						{
							return "Grab";
						}
						else if (field[stats->current_field]->tile[stats->dx][stats->dy]->type == TILE_TYPE_PORTABLE_EXCHANGER)
						{
							return "Grab";
						}
					}
				}
			}
		}
	}

	return "";
};
