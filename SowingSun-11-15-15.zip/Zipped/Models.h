

// Any picture in the .bmp format, 24 bit, should be good to go now.
bool LoadBitmap(const char *filename, GLuint &tex)
{
	FILE *bitmap;

	unsigned long int width, height;
	
	unsigned char *bits, *final;
	unsigned char header[54], temp;

	bitmap = fopen(filename, "rb");
	if (!bitmap) return false;

	fread(&header, 54, 1, bitmap);

	// If it's not a Bitmap, exit!
	if (256 * header[1] + header[0] != 19778)
	{
		fclose(bitmap);

		return false;
	}

	width = 256 * header[19] + header[18];
	height = 256 * header[23] + header[22];

	// Once the size is found, malloc() that much to 'bits' and read.
	bits = (unsigned char *) malloc(width*height*3);

	fread(bits, width*height*3, 1, bitmap);

	fclose(bitmap);

	// Flip the BGR pixels to RGB.
	for (int i=0; i<width*height*3; i+=3)
	{
		temp = bits[i];
		bits[i] = bits[i+2];
		bits[i+2] = temp;
	}

	final = (unsigned char *) malloc(width*height*4);

	unsigned long int count = 0;

	// Put in Alpha values.
	for (int i=0; i<width*height*3; i+=3)
	{
		final[count] = bits[i];
		count++;
		final[count] = bits[i+1];
		count++;
		final[count] = bits[i+2];
		count++;
		
		if (bits[i] == 0 && bits[i+1] == 0 && bits[i+2] == 0)
		{
			final[count] = 0;
			count++;
		}
		else
		{
			final[count] = 255;
			count++;
		}
	}
	
	// Remember each malloc() needs a free().
	free(bits);

	glGenTextures(1, &tex);
	glBindTexture(GL_TEXTURE_2D, tex);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, final);
	
	// Remember each malloc() needs a free().
	free(final);

	return true;
};

const int TEXTURE_TRANSPARENT = 0;
const int TEXTURE_BLANK = 1;

const int TEXTURE_ROCK_1 = 2;
const int TEXTURE_ROCK_2 = 3;
const int TEXTURE_ROCK_3 = 4;

const int TEXTURE_WEED_1 = 5;
const int TEXTURE_WEED_2 = 6;
const int TEXTURE_WEED_3 = 7;

const int TEXTURE_RYE_SEED = 8;
const int TEXTURE_RYE_PLANT = 9;
const int TEXTURE_RYE_RIPE = 10;
const int TEXTURE_RYE = 11;

const int TEXTURE_NANOTUBE_SEED = 12;
const int TEXTURE_NANOTUBE_PLANT = 13;
const int TEXTURE_NANOTUBE = 14;

const int TEXTURE_RADISH_SEED = 15;
const int TEXTURE_RADISH_PLANT = 16;
const int TEXTURE_RADISH = 17;

const int TEXTURE_CABBAGE_SEED = 18;
const int TEXTURE_CABBAGE_PLANT = 19;
const int TEXTURE_CABBAGE = 20;

const int TEXTURE_CUCUMBER_SEED = 21;
const int TEXTURE_CUCUMBER_PLANT = 22;
const int TEXTURE_CUCUMBER = 23;

const int TEXTURE_BEANS_SEED = 24;
const int TEXTURE_BEANS_PLANT = 25;
const int TEXTURE_FULL_BEANS_PLANT = 26;
const int TEXTURE_BEANS = 27;

const int TEXTURE_MELON_SEED = 28;
const int TEXTURE_MELON_PLANT = 29;
const int TEXTURE_MELON = 30;

const int TEXTURE_TURNIP_SEED = 31;
const int TEXTURE_TURNIP_PLANT = 32;
const int TEXTURE_TURNIP = 33;

const int TEXTURE_ONION_SEED = 34;
const int TEXTURE_ONION_PLANT = 35;
const int TEXTURE_ONION = 36;

const int TEXTURE_ORE_RESOURCE_1 = 37;
const int TEXTURE_ORE_RESOURCE_2 = 38;
const int TEXTURE_ORE_RESOURCE_3 = 39;
const int TEXTURE_ORE_EMPTY = 40;
const int TEXTURE_ORE = 41;

const int TEXTURE_BERRY_BUSH = 42;
const int TEXTURE_EMPTY_BERRY_BUSH = 43;
const int TEXTURE_BERRY = 44;

const int TEXTURE_APPLE_TREE_1 = 45;
const int TEXTURE_APPLE_TREE_2 = 46;
const int TEXTURE_EMPTY_APPLE_TREE_1 = 47;
const int TEXTURE_EMPTY_APPLE_TREE_2 = 48;
const int TEXTURE_APPLE = 49;

const int TEXTURE_MUSHROOM_BED = 50;
const int TEXTURE_MUSHROOM = 51;

const int TEXTURE_CRYSTAL_ROCK_1 = 52;
const int TEXTURE_CRYSTAL_ROCK_2 = 53;
const int TEXTURE_CRYSTAL_ROCK_3 = 54;
const int TEXTURE_EMPTY_CRYSTAL = 55;
const int TEXTURE_CRYSTAL = 56;

const int TEXTURE_FISH = 57;
const int TEXTURE_EXTRACT = 58;

const int TEXTURE_EXCHANGER = 59;
const int TEXTURE_CHARGING = 60;

const int TEXTURE_WALL_1 = 61;
const int TEXTURE_WALL_2 = 62;
const int TEXTURE_WALL_3 = 63;
const int TEXTURE_WALL_4 = 64;
const int TEXTURE_WALL_5 = 65;

const int TEXTURE_HOUSE_SIGN = 66;
const int TEXTURE_ROVERS_SIGN = 67;
const int TEXTURE_PLANT_SIGN = 68;
const int TEXTURE_MECHANICS_SIGN = 69;
const int TEXTURE_FISH_SIGN = 70;
const int TEXTURE_CROSS_SIGN = 71;
const int TEXTURE_BLOCKING_SIGN = 72;

const int TEXTURE_MATCHING_1 = 73;
const int TEXTURE_MATCHING_2 = 74;
const int TEXTURE_MATCHING_3 = 75;
const int TEXTURE_MATCHING_4 = 76;
const int TEXTURE_MATCHING_5 = 77;
const int TEXTURE_MATCHING_6 = 78;

const int TEXTURE_GROUND = 79;
const int TEXTURE_METAL = 80;
const int TEXTURE_SQUARE_SHADOW = 81;
const int TEXTURE_ROUND_SHADOW = 82;
const int TEXTURE_LATTICE = 83;

const int TEXTURE_BIG_WALL = 84;

const int TEXTURE_ROVER_FACES = 85;

const int TEXTURE_DAVID_FACES_0 = 86;
const int TEXTURE_DAVID_FACES_1 = 87;
const int TEXTURE_DAVID_FACES_2 = 88;
const int TEXTURE_DAVID_FACES_3 = 89;
const int TEXTURE_DAVID_FACES_4 = 90;

const int TEXTURE_CLARA_FACES_0 = 91;
const int TEXTURE_CLARA_FACES_1 = 92;
const int TEXTURE_CLARA_FACES_2 = 93;
const int TEXTURE_CLARA_FACES_3 = 94;
const int TEXTURE_CLARA_FACES_4 = 95;

const int TEXTURE_ANDREW_FACES_0 = 96;
const int TEXTURE_ANDREW_FACES_1 = 97;
const int TEXTURE_ANDREW_FACES_2 = 98;
const int TEXTURE_ANDREW_FACES_3 = 99;
const int TEXTURE_ANDREW_FACES_4 = 100;

const int TEXTURE_EMILY_FACES_0 = 101;
const int TEXTURE_EMILY_FACES_1 = 102;
const int TEXTURE_EMILY_FACES_2 = 103;
const int TEXTURE_EMILY_FACES_3 = 104;
const int TEXTURE_EMILY_FACES_4 = 105;

const int TEXTURE_CROSS_FACES = 106;

const int TEXTURE_TELEVISION = 107;
const int TEXTURE_TELEVISION_FACES = 108;

const int TEXTURE_BLUE_HERB = 109;
const int TEXTURE_GREEN_HERB = 110;
const int TEXTURE_HAIRY_HERB = 111;
const int TEXTURE_PURPLE_HERB = 112;
const int TEXTURE_SPIKY_HERB = 113;
const int TEXTURE_TWISTY_HERB = 114;
const int TEXTURE_YELLOW_HERB = 115;
const int TEXTURE_BASKET_HERB = 116;

const int TEXTURE_DONATION = 117;

const int TEXTURE_INTRO_SCREEN = 118;
const int TEXTURE_OPTIONS_SCREEN = 119;
const int TEXTURE_MENU_SCREEN = 120;
const int TEXTURE_CREATION_SCREEN = 121;
const int TEXTURE_NEW_SURE_SCREEN = 122;
const int TEXTURE_STORY_SCREEN = 123;
const int TEXTURE_END_GAME_SCREEN = 124;
const int TEXTURE_SHOW_SCORE_SCREEN = 125;

void InitializeBitmaps()
{
	LoadBitmap("Images/Transparent.bmp", texture[TEXTURE_TRANSPARENT]);
	LoadBitmap("Images/Blank.bmp", texture[TEXTURE_BLANK]);

	LoadBitmap("Images/Rock1.bmp", texture[TEXTURE_ROCK_1]);
	LoadBitmap("Images/Rock2.bmp", texture[TEXTURE_ROCK_2]);
	LoadBitmap("Images/Rock3.bmp", texture[TEXTURE_ROCK_3]);

	LoadBitmap("Images/Weed1.bmp", texture[TEXTURE_WEED_1]);
	LoadBitmap("Images/Weed2.bmp", texture[TEXTURE_WEED_2]);
	LoadBitmap("Images/Weed3.bmp", texture[TEXTURE_WEED_3]);

	LoadBitmap("Images/RyeSeed.bmp", texture[TEXTURE_RYE_SEED]);
	LoadBitmap("Images/RyePlant.bmp", texture[TEXTURE_RYE_PLANT]);
	LoadBitmap("Images/RyeRipe.bmp", texture[TEXTURE_RYE_RIPE]);
	LoadBitmap("Images/Rye.bmp", texture[TEXTURE_RYE]);

	LoadBitmap("Images/NanotubeSeed.bmp", texture[TEXTURE_NANOTUBE_SEED]);
	LoadBitmap("Images/NanotubePlant.bmp", texture[TEXTURE_NANOTUBE_PLANT]);
	LoadBitmap("Images/Nanotube.bmp", texture[TEXTURE_NANOTUBE]);

	LoadBitmap("Images/RadishSeed.bmp", texture[TEXTURE_RADISH_SEED]);
	LoadBitmap("Images/RadishPlant.bmp", texture[TEXTURE_RADISH_PLANT]);
	LoadBitmap("Images/Radish.bmp", texture[TEXTURE_RADISH]);

	LoadBitmap("Images/CabbageSeed.bmp", texture[TEXTURE_CABBAGE_SEED]);
	LoadBitmap("Images/CabbagePlant.bmp", texture[TEXTURE_CABBAGE_PLANT]);
	LoadBitmap("Images/Cabbage.bmp", texture[TEXTURE_CABBAGE]);

	LoadBitmap("Images/CucumberSeed.bmp", texture[TEXTURE_CUCUMBER_SEED]);
	LoadBitmap("Images/CucumberPlant.bmp", texture[TEXTURE_CUCUMBER_PLANT]);
	LoadBitmap("Images/Cucumber.bmp", texture[TEXTURE_CUCUMBER]);
	
	LoadBitmap("Images/BeansSeed.bmp", texture[TEXTURE_BEANS_SEED]);
	LoadBitmap("Images/BeansPlant.bmp", texture[TEXTURE_BEANS_PLANT]);
	LoadBitmap("Images/BeansPlantFull.bmp", texture[TEXTURE_FULL_BEANS_PLANT]);
	LoadBitmap("Images/Beans.bmp", texture[TEXTURE_BEANS]);

	LoadBitmap("Images/MelonSeed.bmp", texture[TEXTURE_MELON_SEED]);
	LoadBitmap("Images/MelonPlant.bmp", texture[TEXTURE_MELON_PLANT]);
	LoadBitmap("Images/Melon.bmp", texture[TEXTURE_MELON]);

	LoadBitmap("Images/TurnipSeed.bmp", texture[TEXTURE_TURNIP_SEED]);
	LoadBitmap("Images/TurnipPlant.bmp", texture[TEXTURE_TURNIP_PLANT]);
	LoadBitmap("Images/Turnip.bmp", texture[TEXTURE_TURNIP]);

	LoadBitmap("Images/OnionSeed.bmp", texture[TEXTURE_ONION_SEED]);
	LoadBitmap("Images/OnionPlant.bmp", texture[TEXTURE_ONION_PLANT]);
	LoadBitmap("Images/Onion.bmp", texture[TEXTURE_ONION]);

	LoadBitmap("Images/OreResource1.bmp", texture[TEXTURE_ORE_RESOURCE_1]);
	LoadBitmap("Images/OreResource2.bmp", texture[TEXTURE_ORE_RESOURCE_2]);
	LoadBitmap("Images/OreResource3.bmp", texture[TEXTURE_ORE_RESOURCE_3]);
	LoadBitmap("Images/OreEmpty.bmp", texture[TEXTURE_ORE_EMPTY]);
	LoadBitmap("Images/Ore.bmp", texture[TEXTURE_ORE]);

	LoadBitmap("Images/BerryBush.bmp", texture[TEXTURE_BERRY_BUSH]);
	LoadBitmap("Images/BerryBushEmpty.bmp", texture[TEXTURE_EMPTY_BERRY_BUSH]);
	LoadBitmap("Images/Berry.bmp", texture[TEXTURE_BERRY]);
	
	LoadBitmap("Images/AppleTree1.bmp", texture[TEXTURE_APPLE_TREE_1]);
	LoadBitmap("Images/AppleTree2.bmp", texture[TEXTURE_APPLE_TREE_2]);
	LoadBitmap("Images/AppleTreeEmpty1.bmp", texture[TEXTURE_EMPTY_APPLE_TREE_1]);
	LoadBitmap("Images/AppleTreeEmpty2.bmp", texture[TEXTURE_EMPTY_APPLE_TREE_2]);
	LoadBitmap("Images/Apple.bmp", texture[TEXTURE_APPLE]);

	LoadBitmap("Images/MushroomBed.bmp", texture[TEXTURE_MUSHROOM_BED]);
	LoadBitmap("Images/Mushroom.bmp", texture[TEXTURE_MUSHROOM]);

	LoadBitmap("Images/CrystalRock1.bmp", texture[TEXTURE_CRYSTAL_ROCK_1]);
	LoadBitmap("Images/CrystalRock2.bmp", texture[TEXTURE_CRYSTAL_ROCK_2]);
	LoadBitmap("Images/CrystalRock3.bmp", texture[TEXTURE_CRYSTAL_ROCK_3]);
	LoadBitmap("Images/CrystalEmpty.bmp", texture[TEXTURE_EMPTY_CRYSTAL]);
	LoadBitmap("Images/Crystal.bmp", texture[TEXTURE_CRYSTAL]);

	LoadBitmap("Images/Fish.bmp", texture[TEXTURE_FISH]);
	LoadBitmap("Images/Extract.bmp", texture[TEXTURE_EXTRACT]);

	LoadBitmap("Images/Exchanger.bmp", texture[TEXTURE_EXCHANGER]);
	LoadBitmap("Images/Charging.bmp", texture[TEXTURE_CHARGING]);

	LoadBitmap("Images/Wall1.bmp", texture[TEXTURE_WALL_1]);
	LoadBitmap("Images/Wall2.bmp", texture[TEXTURE_WALL_2]);
	LoadBitmap("Images/Wall3.bmp", texture[TEXTURE_WALL_3]);
	LoadBitmap("Images/Wall4.bmp", texture[TEXTURE_WALL_4]);
	LoadBitmap("Images/Wall5.bmp", texture[TEXTURE_WALL_5]);

	LoadBitmap("Images/SignHouse.bmp", texture[TEXTURE_HOUSE_SIGN]);
	LoadBitmap("Images/SignRovers.bmp", texture[TEXTURE_ROVERS_SIGN]);
	LoadBitmap("Images/SignPlant.bmp", texture[TEXTURE_PLANT_SIGN]);
	LoadBitmap("Images/SignMechanics.bmp", texture[TEXTURE_MECHANICS_SIGN]);
	LoadBitmap("Images/SignFish.bmp", texture[TEXTURE_FISH_SIGN]);
	LoadBitmap("Images/SignCross.bmp", texture[TEXTURE_CROSS_SIGN]);
	LoadBitmap("Images/SignBlocking.bmp", texture[TEXTURE_BLOCKING_SIGN]);

	LoadBitmap("Images/Matching1.bmp", texture[TEXTURE_MATCHING_1]);
	LoadBitmap("Images/Matching2.bmp", texture[TEXTURE_MATCHING_2]);
	LoadBitmap("Images/Matching3.bmp", texture[TEXTURE_MATCHING_3]);
	LoadBitmap("Images/Matching4.bmp", texture[TEXTURE_MATCHING_4]);
	LoadBitmap("Images/Matching5.bmp", texture[TEXTURE_MATCHING_5]);
	LoadBitmap("Images/Matching6.bmp", texture[TEXTURE_MATCHING_6]);

	LoadBitmap("Images/Ground.bmp", texture[TEXTURE_GROUND]);
	LoadBitmap("Images/Metal.bmp", texture[TEXTURE_METAL]);
	LoadBitmap("Images/ShadowSquare.bmp", texture[TEXTURE_SQUARE_SHADOW]);
	LoadBitmap("Images/ShadowRound.bmp", texture[TEXTURE_ROUND_SHADOW]);
	LoadBitmap("Images/Lattice.bmp", texture[TEXTURE_LATTICE]);

	LoadBitmap("Images/WallBig.bmp", texture[TEXTURE_BIG_WALL]);

	LoadBitmap("Images/RoverFaces0.bmp", texture[TEXTURE_ROVER_FACES]);

	LoadBitmap("Images/DavidFace0.bmp", texture[TEXTURE_DAVID_FACES_0]);
	LoadBitmap("Images/DavidFace1.bmp", texture[TEXTURE_DAVID_FACES_1]);
	LoadBitmap("Images/DavidFace2.bmp", texture[TEXTURE_DAVID_FACES_2]);
	LoadBitmap("Images/DavidFace3.bmp", texture[TEXTURE_DAVID_FACES_3]);
	LoadBitmap("Images/DavidFace4.bmp", texture[TEXTURE_DAVID_FACES_4]);

	LoadBitmap("Images/ClaraFace0.bmp", texture[TEXTURE_CLARA_FACES_0]);
	LoadBitmap("Images/ClaraFace1.bmp", texture[TEXTURE_CLARA_FACES_1]);
	LoadBitmap("Images/ClaraFace2.bmp", texture[TEXTURE_CLARA_FACES_2]);
	LoadBitmap("Images/ClaraFace3.bmp", texture[TEXTURE_CLARA_FACES_3]);
	LoadBitmap("Images/ClaraFace4.bmp", texture[TEXTURE_CLARA_FACES_4]);

	LoadBitmap("Images/AndrewFace0.bmp", texture[TEXTURE_ANDREW_FACES_0]);
	LoadBitmap("Images/AndrewFace1.bmp", texture[TEXTURE_ANDREW_FACES_1]);
	LoadBitmap("Images/AndrewFace2.bmp", texture[TEXTURE_ANDREW_FACES_2]);
	LoadBitmap("Images/AndrewFace3.bmp", texture[TEXTURE_ANDREW_FACES_3]);
	LoadBitmap("Images/AndrewFace4.bmp", texture[TEXTURE_ANDREW_FACES_4]);

	LoadBitmap("Images/EmilyFace0.bmp", texture[TEXTURE_EMILY_FACES_0]);
	LoadBitmap("Images/EmilyFace1.bmp", texture[TEXTURE_EMILY_FACES_1]);
	LoadBitmap("Images/EmilyFace2.bmp", texture[TEXTURE_EMILY_FACES_2]);
	LoadBitmap("Images/EmilyFace3.bmp", texture[TEXTURE_EMILY_FACES_3]);
	LoadBitmap("Images/EmilyFace4.bmp", texture[TEXTURE_EMILY_FACES_4]);

	LoadBitmap("Images/CrossFaces0.bmp", texture[TEXTURE_CROSS_FACES]);

	LoadBitmap("Images/Television.bmp", texture[TEXTURE_TELEVISION]);
	LoadBitmap("Images/TelevisionFaces0.bmp", texture[TEXTURE_TELEVISION_FACES]);

	LoadBitmap("Images/HerbBlue.bmp", texture[TEXTURE_BLUE_HERB]);
	LoadBitmap("Images/HerbGreen.bmp", texture[TEXTURE_GREEN_HERB]);
	LoadBitmap("Images/HerbHairy.bmp", texture[TEXTURE_HAIRY_HERB]);
	LoadBitmap("Images/HerbPurple.bmp", texture[TEXTURE_PURPLE_HERB]);
	LoadBitmap("Images/HerbSpiky.bmp", texture[TEXTURE_SPIKY_HERB]);
	LoadBitmap("Images/HerbTwisty.bmp", texture[TEXTURE_TWISTY_HERB]);
	LoadBitmap("Images/HerbYellow.bmp", texture[TEXTURE_YELLOW_HERB]);
	LoadBitmap("Images/HerbBasket.bmp", texture[TEXTURE_BASKET_HERB]);

	LoadBitmap("Images/Donation.bmp", texture[TEXTURE_DONATION]);

	LoadBitmap("Images/IntroScreen.bmp", texture[TEXTURE_INTRO_SCREEN]);
	LoadBitmap("Images/OptionsScreen.bmp", texture[TEXTURE_OPTIONS_SCREEN]);
	LoadBitmap("Images/MenuScreen.bmp", texture[TEXTURE_MENU_SCREEN]);
	LoadBitmap("Images/CreationScreen.bmp", texture[TEXTURE_CREATION_SCREEN]);
	LoadBitmap("Images/NewSureScreen.bmp", texture[TEXTURE_NEW_SURE_SCREEN]);
	LoadBitmap("Images/StoryScreen.bmp", texture[TEXTURE_STORY_SCREEN]);
	LoadBitmap("Images/EndGameScreen.bmp", texture[TEXTURE_END_GAME_SCREEN]);
	LoadBitmap("Images/ShowScoreScreen.bmp", texture[TEXTURE_SHOW_SCORE_SCREEN]);

	return;
};

const float exchanger_point[8*3] = {

-1.5f, 3.0f, -1.5f,
-1.5f, 3.0f, 1.5f,
1.5f, 3.0f, 1.5f,
1.5f, 3.0f, -1.5f,

-1.5f, 0.0f, -1.5f,
-1.5f, 0.0f, 1.5f,
1.5f, 0.0f, 1.5f,
1.5f, 0.0f, -1.5f,

};

const int exchanger_indice[10*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

};

const float charging_station_point[24*3] = {

-4.25f, 0.1f, -4.25f, // 0
-4.25f, 0.1f, 4.25f,
4.25f, 0.1f, 4.25f,
4.25f, 0.1f, -4.25f,

-4.35f, 0.0f, -4.35f, // 4
-4.35f, 0.0f, 4.35f,
4.35f, 0.0f, 4.35f,
4.35f, 0.0f, -4.35f,

-0.2f, 7.0f, -0.2f, // 8
-0.2f, 7.0f, 0.2f,
0.2f, 7.0f, 0.2f,
0.2f, 7.0f, -0.2f,

-0.3f, 0.0f, -0.3f, // 12
-0.3f, 0.0f, 0.3f,
0.3f, 0.0f, 0.3f,
0.3f, 0.0f, -0.3f,

-0.5f, 8.0f, -0.5f, // 16
-0.5f, 8.0f, 0.5f,
0.5f, 8.0f, 0.5f,
0.5f, 8.0f, -0.5f,

-0.5f, 7.0f, -0.5f, // 20
-0.5f, 7.0f, 0.5f,
0.5f, 7.0f, 0.5f,
0.5f, 7.0f, -0.5f,

};

const int charging_station_indice[28*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

8, 12, 13, // 10
8, 13, 9,
9, 13, 14,
9, 14, 10,
10, 14, 15,
10, 15, 11,
11, 15, 12,
11, 12, 8,

16, 20, 21, // 18
16, 21, 17,
17, 21, 22,
17, 22, 18,
18, 22, 23,
18, 23, 19,
19, 23, 20,
19, 20, 16,

16, 17, 18,
16, 18, 19,

};

const float water_generator_point[8*3] = {

-1.0f, 4.0f, -1.0f, // 0
-1.0f, 4.0f, 1.0f,
1.0f, 4.0f, 1.0f,
1.0f, 4.0f, -1.0f,

-1.5f, 0.0f, -1.5f, // 4
-1.5f, 0.0f, 1.5f,
1.5f, 0.0f, 1.5f,
1.5f, 0.0f, -1.5f,

};

const int water_generator_indice[10*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

};

const float rover_station_point[24*3] = {

-1.25f, 0.1f, -1.25f, // 0
-1.25f, 0.1f, 1.25f,
1.25f, 0.1f, 1.25f,
1.25f, 0.1f, -1.25f,

-1.35f, 0.0f, -1.35f, // 4
-1.35f, 0.0f, 1.35f,
1.35f, 0.0f, 1.35f,
1.35f, 0.0f, -1.35f,

-1.5f, 2.0f, -1.5f, // 8
-1.5f, 2.0f, -1.2f,
-1.2f, 2.0f, -1.2f,
-1.2f, 2.0f, -1.5f,

-1.4f, 0.0f, -1.4f, // 12
-1.4f, 0.0f, -1.3f,
-1.3f, 0.0f, -1.3f,
-1.3f, 0.0f, -1.4f,

1.2f, 2.0f, 1.2f, // 16
1.2f, 2.0f, 1.5f,
1.5f, 2.0f, 1.5f,
1.5f, 2.0f, 1.2f,

1.3f, 0.0f, 1.3f, // 20
1.3f, 0.0f, 1.4f,
1.4f, 0.0f, 1.4f,
1.4f, 0.0f, 1.3f,

};

const int rover_station_indice[30*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

8, 12, 13, // 10
8, 13, 9,
9, 13, 14,
9, 14, 10,
10, 14, 15,
10, 15, 11,
11, 15, 12,
11, 12, 8,

8, 9, 10,
8, 10, 11,

16, 20, 21, // 20
16, 21, 17,
17, 21, 22,
17, 22, 18,
18, 22, 23,
18, 23, 19,
19, 23, 20,
19, 20, 16,

16, 17, 18,
16, 18, 19,

};

const float rover_deposit_point[9*3] = {

-1.15f, 0.5f, -1.15f, // 0
-1.15f, 0.5f, 1.15f,
1.15f, 0.5f, 1.15f,
1.15f, 0.5f, -1.15f,

-1.35f, 0.0f, -1.35f, // 4
-1.35f, 0.0f, 1.35f,
1.35f, 0.0f, 1.35f,
1.35f, 0.0f, -1.35f,

0.0f, 0.15f, 0.0f,

};

const int rover_deposit_indice[12*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 8,
1, 2, 8,
2, 3, 8,
3, 0, 8,

};

const float dynamo_charger_point[24*3] = {

-2.5f, 0.1f, -2.5f, // 0
-2.5f, 0.1f, 2.5f,
2.5f, 0.1f, 2.5f,
2.5f, 0.1f, -2.5f,

-2.6f, 0.0f, -2.6f, // 4
-2.6f, 0.0f, 2.6f,
2.6f, 0.0f, 2.6f,
2.6f, 0.0f, -2.6f,

-0.1f, 4.0f, -0.1f, // 8
-0.1f, 4.0f, 0.1f,
0.1f, 4.0f, 0.1f,
0.1f, 4.0f, -0.1f,

-0.2f, 0.0f, -0.2f, // 12
-0.2f, 0.0f, 0.2f,
0.2f, 0.0f, 0.2f,
0.2f, 0.0f, -0.2f,

-0.25f, 5.0f, -0.25f, // 16
-0.25f, 5.0f, 0.25f,
0.25f, 5.0f, 0.25f,
0.25f, 5.0f, -0.25f,

-0.25f, 4.0f, -0.25f, // 20
-0.25f, 4.0f, 0.25f,
0.25f, 4.0f, 0.25f,
0.25f, 4.0f, -0.25f,

};

const int dynamo_charger_indice[28*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

8, 12, 13, // 10
8, 13, 9,
9, 13, 14,
9, 14, 10,
10, 14, 15,
10, 15, 11,
11, 15, 12,
11, 12, 8,

16, 20, 21, // 18
16, 21, 17,
17, 21, 22,
17, 22, 18,
18, 22, 23,
18, 23, 19,
19, 23, 20,
19, 20, 16,

16, 17, 18,
16, 18, 19,

};

const float nanotube_distributor_point[8*3] = {

-1.4f, 3.0f, -1.4f,
-1.4f, 3.0f, 1.4f,
1.4f, 3.0f, 1.4f,
1.4f, 3.0f, -1.4f,

-1.4f, 0.0f, -1.4f,
-1.4f, 0.0f, 1.4f,
1.4f, 0.0f, 1.4f,
1.4f, 0.0f, -1.4f,

};

const int nanotube_distributor_indice[10*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

};

const float fishery_point[8*3] = {

-1.4f, 3.0f, -1.4f,
-1.4f, 3.0f, 1.4f,
1.4f, 3.0f, 1.4f,
1.4f, 3.0f, -1.4f,

-1.4f, 0.0f, -1.4f,
-1.4f, 0.0f, 1.4f,
1.4f, 0.0f, 1.4f,
1.4f, 0.0f, -1.4f,

};

const int fishery_indice[8*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

};

const float extractor_point[32*3] = {

1.0f, 0.0f, 0.0f, // 0
0.707f, 0.0f, 0.707f,
0.0f, 0.0f, 1.0f,
-0.707f, 0.0f, 0.707f,
-1.0f, 0.0f, 0.0f,
-0.707f, 0.0f, -0.707f,
0.0f, 0.0f, -1.0f,
0.707f, 0.0f, -0.707f,

1.25f, 1.0f, 0.0f, // 8
0.884f, 1.0f, 0.884f,
0.0f, 1.0f, 1.25f,
-0.884f, 1.0f, 0.884f,
-1.25f, 1.0f, 0.0f,
-0.884f, 1.0f, -0.884f,
0.0f, 1.0f, -1.25f,
0.884f, 1.0f, -0.884f,

1.25f, 3.0f, 0.0f, // 16
0.884f, 3.0f, 0.884f,
0.0f, 3.0f, 1.25f,
-0.884f, 3.0f, 0.884f,
-1.25f, 3.0f, 0.0f,
-0.884f, 3.0f, -0.884f,
0.0f, 3.0f, -1.25f,
0.884f, 3.0f, -0.884f,

1.0f, 4.0f, 0.0f, // 24
0.707f, 4.0f, 0.707f,
0.0f, 4.0f, 1.0f,
-0.707f, 4.0f, 0.707f,
-1.0f, 4.0f, 0.0f,
-0.707f, 4.0f, -0.707f,
0.0f, 4.0f, -1.0f,
0.707f, 4.0f, -0.707f,

};

const int extractor_indice[48*3] = {

0, 8, 9, // 0
0, 9, 1,
1, 9, 10,
1, 10, 2,
2, 10, 11,
2, 11, 3,
3, 11, 12,
3, 12, 4,
4, 12, 13,
4, 13, 5,
5, 13, 14,
5, 14, 6,
6, 14, 15,
6, 15, 7,
7, 15, 8,
7, 8, 0,

8, 16, 17, // 16
8, 17, 9,
9, 17, 18,
9, 18, 10,
10, 18, 19,
10, 19, 11,
11, 19, 20,
11, 20, 12,
12, 20, 21,
12, 21, 13,
13, 21, 22,
13, 22, 14,
14, 22, 23,
14, 23, 15,
15, 23, 16,
15, 16, 8,

16, 24, 25, // 32
16, 25, 17,
17, 25, 26,
17, 26, 18,
18, 26, 27,
18, 27, 19,
19, 27, 28,
19, 28, 20,
20, 28, 29,
20, 29, 21,
21, 29, 30,
21, 30, 22,
22, 30, 31,
22, 31, 23,
23, 31, 24,
23, 24, 16,

};

const float extractor_top_point[8*3] = {

1.0f, 4.0f, 0.0f, // 0
0.707f, 4.0f, 0.707f,
0.0f, 4.0f, 1.0f,
-0.707f, 4.0f, 0.707f,
-1.0f, 4.0f, 0.0f,
-0.707f, 4.0f, -0.707f,
0.0f, 4.0f, -1.0f,
0.707f, 4.0f, -0.707f,

};

const int extractor_top_indice[6*3] = {

0, 2, 1,
0, 3, 2,
0, 4, 3,
0, 5, 4,
0, 6, 5,
0, 7, 6,

};

const float arcade_point[8*3] = {

-1.25f, 3.5f, -1.25f,
-1.25f, 3.5f, 1.25f,
1.25f, 3.5f, 1.25f,
1.25f, 3.5f, -1.25f,

-1.25f, 0.0f, -1.25f,
-1.25f, 0.0f, 1.25f,
1.25f, 0.0f, 1.25f,
1.25f, 0.0f, -1.25f,

};

const int arcade_indice[8*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

};

const float obelisk_point[9*3] = {

-1.0f, 10.0f, -1.0f,
-1.0f, 10.0f, 1.0f,
1.0f, 10.0f, 1.0f,
1.0f, 10.0f, -1.0f,

-1.5f, 0.0f, -1.5f,
-1.5f, 0.0f, 1.5f,
1.5f, 0.0f, 1.5f,
1.5f, 0.0f, -1.5f,

0.0f, 12.0f, 0.0f,

};

const int obelisk_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

8, 0, 1,
8, 1, 2,
8, 2, 3,
8, 3, 0,

};

const float container_point[9*3] = {

-1.5f, 3.5f, -1.5f, // 0
-1.5f, 3.5f, 1.5f,
1.5f, 3.5f, 1.5f,
1.5f, 3.5f, -1.5f,

-1.5f, 0.0f, -1.5f, // 4
-1.5f, 0.0f, 1.5f,
1.5f, 0.0f, 1.5f,
1.5f, 0.0f, -1.5f,

0.0f, 3.15f, 0.0f,

};

const int container_indice[12*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 8,
1, 2, 8,
2, 3, 8,
3, 0, 8,

};

const float cross_point[28*3] = {

1.0f, 0.0f, 1.0f,
0.5f, 1.0f, 0.5f,
0.5f, 5.0f, 0.5f,
2.0f, 5.0f, 0.5f,
2.0f, 6.0f, 0.5f,
0.5f, 6.0f, 0.5f,
0.5f, 7.5f, 0.5f,
-0.5f, 7.5f, 0.5f,
-0.5f, 6.0f, 0.5f,
-2.0f, 6.0f, 0.5f,
-2.0f, 5.0f, 0.5f,
-0.5f, 5.0f, 0.5f,
-0.5f, 1.0f, 0.5f,
-1.0f, 0.0f, 1.0f,

1.0f, 0.0f, -1.0f,
0.5f, 1.0f, -0.5f,
0.5f, 5.0f, -0.5f,
2.0f, 5.0f, -0.5f,
2.0f, 6.0f, -0.5f,
0.5f, 6.0f, -0.5f,
0.5f, 7.5f, -0.5f,
-0.5f, 7.5f, -0.5f,
-0.5f, 6.0f, -0.5f,
-2.0f, 6.0f, -0.5f,
-2.0f, 5.0f, -0.5f,
-0.5f, 5.0f, -0.5f,
-0.5f, 1.0f, -0.5f,
-1.0f, 0.0f, -1.0f,
 
};

const int cross_indice[52*3] = {

11, 12, 1, // front
11, 1, 2,
8, 11, 2,
8, 2, 5,
9, 10, 11,
9, 11, 8,
5, 2, 3,
5, 3, 4,
7, 8, 5,
7, 5, 6,
16, 15, 26, // back
16, 26, 25,
19, 16, 25,
19, 25, 22,
22, 25, 24,
22, 24, 23,
18, 17, 16,
18, 16, 19,
20, 19, 22,
20, 22, 21,
2, 1, 15, // sides
2, 15, 16,
3, 2, 16,
3, 16, 17,
4, 3, 17,
4, 17, 18,
5, 4, 18,
5, 18, 19,
6, 5, 19,
6, 19, 20,
7, 6, 20,
7, 20, 21,
21, 22, 8,
21, 8, 7,
22, 23, 9,
22, 9, 8,
23, 24, 10,
23, 10, 9,
24, 25, 11,
24, 11, 10,
25, 26, 12,
25, 12, 11,
12, 13, 0, // base
12, 0, 1,
15, 14, 27,
15, 27, 26,
1, 0, 14,
1, 14, 15,
26, 27, 13,
26, 13, 12,
13, 27, 14,
13, 14, 0,

};

const float weather_gauge_lower_point[8*3] = {

-1.0f, 1.1f, -1.0f, // 0
-1.0f, 1.1f, 1.0f,
1.0f, 1.1f, 1.0f,
1.0f, 1.1f, -1.0f,

-1.4f, 0.0f, -1.4f, // 4
-1.4f, 0.0f, 1.4f,
1.4f, 0.0f, 1.4f,
1.4f, 0.0f, -1.4f,

};

const int weather_gauge_lower_indice[10*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

};

const float weather_gauge_upper_point[16*3] = {

-0.2f, 4.0f, -0.2f, // 0
-0.2f, 4.0f, 0.2f,
0.2f, 4.0f, 0.2f,
0.2f, 4.0f, -0.2f,

-0.2f, 1.0f, -0.2f, // 4
-0.2f, 1.0f, 0.2f,
0.2f, 1.0f, 0.2f,
0.2f, 1.0f, -0.2f,

-0.5f, 7.0f, -0.5f, // 8
-0.5f, 7.0f, 0.5f,
0.5f, 7.0f, 0.5f,
0.5f, 7.0f, -0.5f,

};

const int weather_gauge_upper_indice[18*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

8, 0, 1, // 8
8, 1, 9,
9, 1, 2,
9, 2, 10,
10, 2, 3,
10, 3, 11,
11, 3, 0,
11, 0, 8,

8, 9, 10,
8, 10, 11,

};

const float television_point[8*3] = {

-1.25f, 5.5f, -1.25f,
-1.25f, 5.5f, 1.25f,
1.25f, 5.5f, 1.25f,
1.25f, 5.5f, -1.25f,

-1.25f, 0.0f, -1.25f,
-1.25f, 0.0f, 1.25f,
1.25f, 0.0f, 1.25f,
1.25f, 0.0f, -1.25f,

};

const int television_indice[10*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

};

const float mini_challenge_point[16*3] = {

-2.5f, 0.1f, -2.5f, // 0
-2.5f, 0.1f, 2.5f,
2.5f, 0.1f, 2.5f,
2.5f, 0.1f, -2.5f,

-2.6f, 0.0f, -2.6f, // 4
-2.6f, 0.0f, 2.6f,
2.6f, 0.0f, 2.6f,
2.6f, 0.0f, -2.6f,

-0.1f, 10.0f, -0.1f, // 8
-0.1f, 10.0f, 0.1f,
0.1f, 10.0f, 0.1f,
0.1f, 10.0f, -0.1f,

-0.1f, 0.0f, -0.1f, // 12
-0.1f, 0.0f, 0.1f,
0.1f, 0.0f, 0.1f,
0.1f, 0.0f, -0.1f,

};

const int mini_challenge_indice[20*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2,
0, 2, 3,

8, 12, 13, // 10
8, 13, 9,
9, 13, 14,
9, 14, 10,
10, 14, 15,
10, 15, 11,
11, 15, 12,
11, 12, 8,

8, 9, 10,
8, 10, 11,

};


// Hoe tool
const float hoe_point[14*3] = {

	-0.05f, 0.05f, 2.0f, // 0
	0.05f, 0.05f, 2.0f,
	0.05f, -0.05f, 2.0f,
	-0.05f, -0.05f, 2.0f,
	-0.05f, 0.05f, -1.0f,
	0.05f, 0.05f, -1.0f,
	0.05f, -0.05f, -1.0f,
	-0.05f, -0.05f, -1.0f,
	
	0.25f, 0.25f, -1.0f, // 8
	-0.25f, 0.25f, -1.0f,
	-0.25f, -1.25f, -1.0f,
	0.25f, -1.25f, -1.0f,

	0.25f, 0.25f, -1.2f, // 12
	-0.25f, 0.25f, -1.2f,
};

const int hoe_indice[18*3] = {

	0, 5, 4, // 0
	0, 1, 5,
	1, 6, 5,
	1, 2, 6,
	2, 7, 6,
	2, 3, 7,
	3, 4, 7,
	3, 0, 4,

	0, 2, 1, // 8
	0, 3, 2,
	
	8, 10, 11, // 10
	8, 9, 10,
	13, 11, 10,
	13, 12, 11,
	
	8, 12, 13, // 14
	8, 13, 9,
	8, 11, 12,
	9, 13, 10,
};

const float hammer_point[18*3] = {

	-0.05f, 0.05f, 2.0f, // 0
	0.05f, 0.05f, 2.0f,
	0.05f, -0.05f, 2.0f,
	-0.05f, -0.05f, 2.0f,
	-0.05f, 0.05f, -1.0f,
	0.05f, 0.05f, -1.0f,
	0.05f, -0.05f, -1.0f,
	-0.05f, -0.05f, -1.0f,

	-0.1f, 0.1f, -1.0f, // 8
	0.1f, 0.1f, -1.0f,
	0.2f, -0.9f, -0.9f,
	-0.2f, -0.9f, -0.9f,
	-0.1f, 0.1f, -1.2f,
	0.1f, 0.1f, -1.2f,
	0.2f, -0.9f, -1.3f,
	-0.2f, -0.9f, -1.3f,
	
	0.0f, 1.0f, -0.9f, // 16
	0.0f, -1.0f, -1.1f,
};

const int hammer_indice[26*3] = {

	0, 5, 4, // 0
	0, 1, 5,
	1, 6, 5,
	1, 2, 6,
	2, 7, 6,
	2, 3, 7,
	3, 4, 7,
	3, 0, 4,

	0, 2, 1, // 8
	0, 3, 2,

	9, 14, 13, // 10
	9, 10, 14,
	11, 12, 15,
	11, 8, 12,

	8, 10, 9, // 14
	8, 11, 10,
	12, 14, 15,
	12, 13, 14,

	16, 13, 12, // 18
	16, 9, 13,
	16, 8, 9,
	16, 12, 8,
	
	17, 15, 14, // 22
	17, 11, 15,
	17, 10, 11,
	17, 14, 10,
};

const float scythe_point[20*3] = {

	-0.05f, 0.05f, 2.0f, // 0
	0.05f, 0.05f, 2.0f,
	0.05f, -0.05f, 2.0f,
	-0.05f, -0.05f, 2.0f,
	-0.05f, 0.05f, -1.0f,
	0.05f, 0.05f, -1.0f,
	0.05f, -0.05f, -1.0f,
	-0.05f, -0.05f, -1.0f,

	-0.1f, 0.1f, -1.0f, // 8
	0.1f, 0.1f, -1.0f,
	0.1f, -0.1f, -1.0f,
	-0.1f, -0.1f, -1.0f,
	-0.1f, 0.1f, -1.2f,
	0.1f, 0.1f, -1.2f,
	0.1f, -0.1f, -1.2f,
	-0.1f, -0.1f, -1.2f,

	-0.1f, -0.2f, -1.2f, // 16
	0.1f, -0.2f, -1.2f,
	0.0f, -0.2f, -1.0f,
	
	0.0f, -3.0f, -0.6f, // 19
};

const int scythe_indice[30*3] = {

	0, 5, 4, // 0
	0, 1, 5,
	1, 6, 5,
	1, 2, 6,
	2, 7, 6,
	2, 3, 7,
	3, 4, 7,
	3, 0, 4,

	0, 2, 1, // 8
	0, 3, 2,

	8, 13, 12, // 10
	8, 9, 13,
	9, 14, 13,
	9, 10, 14,
	11, 12, 15,
	11, 8, 12,

	8, 10, 9, // 16
	8, 11, 10,
	12, 14, 15,
	12, 13, 14,
	
	15, 17, 16, // 20
	15, 14, 17,
	15, 16, 18,
	15, 18, 11,
	14, 18, 17,
	14, 10, 18,
	18, 10, 11,
	
	16, 17, 19, // 27
	16, 19, 18,
	17, 18, 19,
};

const float watering_can_point[16*3] = {

	-0.35f, 0.0f, 1.0f, // 0
	0.35f, 0.0f, 1.0f,
	0.35f, -0.7f, 1.0f,
	-0.35f, -0.7f, 1.0f,
	-0.35f, 0.0f, -0.5f,
	0.35f, 0.0f, -0.5f,
	0.35f, -0.7f, -0.5f,
	-0.35f, -0.7f, -0.5f,

	-0.05f, -0.7f, 0.6f, // 8
	0.05f, -0.7f, 0.6f,
	0.05f, -0.7f, 0.9f,
	-0.05f, -0.7f, 0.9f,
	-0.15f, -1.3f, -0.6f,
	0.15f, -1.3f, -0.6f,
	0.15f, -1.5f, -0.4f,
	-0.15f, -1.5f, -0.4f,
};

const int watering_can_indice[22*3] = {

	0, 5, 4, // 0
	0, 1, 5,
	1, 6, 5,
	1, 2, 6,
	2, 7, 6,
	2, 3, 7,
	3, 4, 7,
	3, 0, 4,

	0, 2, 1, // 8
	0, 3, 2,
	4, 6, 7,
	4, 5, 6,

	8, 13, 12, // 12
	8, 9, 13,
	9, 14, 13,
	9, 10, 14,
	10, 15, 14,
	10, 11, 15,
	11, 12, 15,
	11, 8, 12,
	
	12, 14, 15, // 20
	12, 13, 14,
};

const float fishing_pole_point[8*3] = {

	-0.05f, 0.05f, 1.0f, // 0
	0.05f, 0.05f, 1.0f,
	0.05f, -0.05f, 1.0f,
	-0.05f, -0.05f, 1.0f,
	-0.01f, 0.01f, -3.0f,
	0.01f, 0.01f, -3.0f,
	0.01f, -0.01f, -3.0f,
	-0.01f, -0.01f, -3.0f,
};

const int fishing_pole_indice[12*3] = {

	0, 5, 4, // 0
	0, 1, 5,
	1, 6, 5,
	1, 2, 6,
	2, 7, 6,
	2, 3, 7,
	3, 4, 7,
	3, 0, 4,

	0, 2, 1, // 8
	0, 3, 2,
	
	4, 7, 6,
	4, 6, 5,
};	  

const float fishing_bobber_point[6*3] = {

	0.25f, 0.0f, 0.0f, // 0
	0.0f, 0.0f, 0.25f,
	-0.25f, 0.0f, 0.0f,
	0.0f, 0.0f, -0.25f,
	
	0.0f, 0.5f, 0.0f, // 4
	0.0f, -0.5f, 0.0f,
};

const int fishing_bobber_indice[8*3] = {

	5, 0, 1, // 0
	5, 1, 2,
	5, 2, 3,
	5, 3, 0,
	
	4, 1, 0, // 4
	4, 2, 1,
	4, 3, 2,
	4, 0, 3,
};

const float instrument_point[16*3] = {

	-0.5f, -0.05f, 2.5f, // 0
	0.5f, -0.05f, 2.5f,
	0.5f, 0.25f, 2.5f,
	-0.5f, 0.25f, 2.5f,
	
	-0.5f, -0.05f, 1.5f, // 4
	0.5f, -0.05f, 1.5f,
	0.5f, 0.15f, 1.5f,
	-0.5f, 0.15f, 1.5f,

	-0.1f, -0.05f, 1.5f, // 8
	0.1f, -0.05f, 1.5f,
	0.1f, 0.05f, 1.5f,
	-0.1f, 0.05f, 1.5f,

	-0.1f, -0.05f, -0.5f, // 12
	0.1f, -0.05f, -0.5f,
	0.1f, 0.05f, -0.5f,
	-0.1f, 0.05f, -0.5f,
};

const int instrument_indice[24*3] = {

	0, 4, 5, // 0
	0, 5, 1,
	1, 5, 6,
	1, 6, 2,
	2, 6, 7,
	2, 7, 3,
	3, 7, 4,
	3, 4, 0,

	0, 1, 2, // 8
	0, 2, 3,

	4, 7, 6,
	4, 6, 5,

	8, 12, 13, // 12
	8, 13, 9,
	9, 13, 14,
	9, 14, 10,
	10, 14, 15,
	10, 15, 11,
	11, 15, 12,
	11, 12, 8,

	8, 9, 10, // 20
	8, 10, 11,
	
	12, 15, 14,
	12, 14, 13,
};
	

// Robot models
const float male_upper_torso_point[6*3] = {

-1.0f, 0.0f, 0.5f,
0.0f, -2.0f, 0.25f,
1.0f, 0.0f, 0.5f,
-1.0f, 0.0f, -0.5f,
0.0f, -2.0f, -0.25f,
1.0f, 0.0f, -0.5f,

};

const int male_upper_torso_indice[8*3] = {

0, 1, 2,
5, 4, 3,
3, 0, 2,
3, 2, 5,
3, 4, 1,
3, 1, 0,
2, 1, 4,
2, 4, 5,

};

const float female_upper_torso_point[8*3] = {

-0.5f, 0.0f, 0.25f,
0.0f, -1.5f, 0.25f,
0.5f, 0.0f, 0.25f,
-0.5f, 0.0f, -0.25f,
0.0f, -1.5f, -0.25f,
0.5f, 0.0f, -0.25f,
-0.3f, -0.6f, 0.4f,
0.3f, -0.6f, 0.4f,

};

const int female_upper_torso_indice[12*3] = {

0, 1, 6,
2, 7, 1,
0, 6, 7,
0, 7, 2,
6, 1, 7,
5, 4, 3,
3, 0, 2,
3, 2, 5,
3, 4, 1,
3, 1, 0,
2, 1, 4,
2, 4, 5,

};

const float male_middle_torso_point[10*3] = {

0.0f, 0.25f, 0.0f,
-0.25f, 0.0f, 0.0f,
-0.18f, 0.0f, 0.18f,
0.0f, 0.0f, 0.25f,
0.18f, 0.0f, 0.18f,
0.25f, 0.0f, 0.0f,
0.18f, 0.0f, -0.18f,
0.0f, 0.0f, -0.25f,
-0.18f, 0.0f, -0.18f,
0.0f, -0.25f, 0.0f,

};

const int male_middle_torso_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float female_middle_torso_point[10*3] = {

0.0f, 0.125f, 0.0f,
-0.125f, 0.0f, 0.0f,
-0.09f, 0.0f, 0.09f,
0.0f, 0.0f, 0.125f,
0.09f, 0.0f, 0.09f,
0.125f, 0.0f, 0.0f,
0.09f, 0.0f, -0.09f,
0.0f, 0.0f, -0.125f,
-0.09f, 0.0f, -0.09f,
0.0f, -0.125f, 0.0f,

};

const int female_middle_torso_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float male_lower_torso_point[6*3] = {

0.0f, 0.0f, 0.25f,
-0.5f, -0.5f, 0.25f,
0.5f, -0.5f, 0.25f,
0.0f, 0.0f, -0.25f,
-0.5f, -0.5f, -0.25f,
0.5f, -0.5f, -0.25f,

};

const int male_lower_torso_indice[8*3] = {

0, 1, 2,
3, 5, 4,
3, 4, 1,
3, 1, 0,
0, 2, 5,
0, 5, 3,
1, 4, 5,
1, 5, 2,

};

const float female_lower_torso_point[6*3] = {

0.0f, 0.0f, 0.25f,
-0.625f, -1.0f, 0.25f,
0.625f, -1.0f, 0.25f,
0.0f, 0.0f, -0.25f,
-0.625f, -1.0f, -0.25f,
0.625f, -1.0f, -0.25f,

};

const int female_lower_torso_indice[8*3] = {

0, 1, 2,
3, 5, 4,
3, 4, 1,
3, 1, 0,
0, 2, 5,
0, 5, 3,
1, 4, 5,
1, 5, 2,

};

const float male_upper_arm_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.05f, -1.5f, 0.05f,
0.05f, -1.5f, 0.05f,
0.05f, -1.5f, -0.05f,
-0.05f, -1.5f, -0.05f,

};

const int male_upper_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_upper_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.05f, -1.25f, 0.05f,
0.05f, -1.25f, 0.05f,
0.05f, -1.25f, -0.05f,
-0.05f, -1.25f, -0.05f,

};

const int female_upper_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_lower_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.25f, -1.5f, 0.25f,
0.25f, -1.5f, 0.25f,
0.25f, -1.5f, -0.25f,
-0.25f, -1.5f, -0.25f,

};

const int male_lower_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_lower_arm_point[8*3] = {

-0.05f, -0.05f, 0.05f,
0.05f, -0.05f, 0.05f,
0.05f, -0.05f, -0.05f,
-0.05f, -0.05f, -0.05f,
-0.15f, -1.25f, 0.15f,
0.15f, -1.25f, 0.15f,
0.15f, -1.25f, -0.15f,
-0.15f, -1.25f, -0.15f,

};

const int female_lower_arm_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_upper_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.15f, -2.0f, 0.15f,
0.15f, -2.0f, 0.15f,
0.15f, -2.0f, -0.15f,
-0.15f, -2.0f, -0.15f,

};

const int male_upper_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_upper_leg_point[8*3] = {

-0.25f, -0.1f, 0.25f,
0.25f, -0.1f, 0.25f,
0.25f, -0.1f, -0.25f,
-0.25f, -0.1f, -0.25f,
-0.15f, -2.0f, 0.15f,
0.15f, -2.0f, 0.15f,
0.15f, -2.0f, -0.15f,
-0.15f, -2.0f, -0.15f,

};

const int female_upper_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_lower_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.35f, -2.0f, 0.35f,
0.35f, -2.0f, 0.35f,
0.35f, -2.0f, -0.35f,
-0.35f, -2.0f, -0.35f,

};


const int male_lower_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float female_lower_leg_point[8*3] = {

-0.15f, -0.1f, 0.15f,
0.15f, -0.1f, 0.15f,
0.15f, -0.1f, -0.15f,
-0.15f, -0.1f, -0.15f,
-0.35f, -2.0f, 0.35f,
0.35f, -2.0f, 0.35f,
0.35f, -2.0f, -0.35f,
-0.35f, -2.0f, -0.35f,

};

const int female_lower_leg_indice[12*3] = {

0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
3, 0, 1,
3, 1, 2,
4, 7, 6,
4, 6, 5,

};

const float male_head_point[16*3] = {

0.5f, 1.0f, 0.25f,
0.5f, 1.0f, -0.25f,
-0.5f, 1.0f, -0.25f,
-0.5f, 1.0f, 0.25f,
0.5f, 0.0f, 0.25f,
0.5f, 0.0f, -0.25f,
-0.5f, 0.0f, -0.25f,
-0.5f, 0.0f, 0.25f,

};

const int male_head_indice[12*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
5, 4, 7,
5, 7, 6,

};

const float female_head_point[16*3] = {

0.4f, 1.0f, 0.25f,
0.4f, 1.0f, -0.25f,
-0.4f, 1.0f, -0.25f,
-0.4f, 1.0f, 0.25f,
0.25f, 0.0f, 0.25f,
0.25f, 0.0f, -0.25f,
-0.25f, 0.0f, -0.25f,
-0.25f, 0.0f, 0.25f,

};

const int female_head_indice[12*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,
5, 4, 7,
5, 7, 6,

};

const float male_visor_point[8*3] = {

0.4f, 0.55f, -0.25f,
0.4f, 0.55f, -0.3f,
-0.4f, 0.55f, -0.3f,
-0.4f, 0.55f, -0.25f,
0.4f, 0.45f, -0.25f,
0.4f, 0.45f, -0.3f,
-0.4f, 0.45f, -0.3f,
-0.4f, 0.45f, -0.25f,

};

const int male_visor_indice[10*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
5, 4, 7,
5, 7, 6,

};

const float female_visor_point[8*3] = {

0.275f, 0.55f, -0.25f,
0.275f, 0.55f, -0.3f,
-0.275f, 0.55f, -0.3f,
-0.275f, 0.55f, -0.25f,
0.275f, 0.45f, -0.25f,
0.275f, 0.45f, -0.3f,
-0.275f, 0.45f, -0.3f,
-0.275f, 0.45f, -0.25f,

};

const int female_visor_indice[10*3] = {

0, 1, 2,
0, 2, 3,
0, 4, 5,
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
5, 4, 7,
5, 7, 6,

};

const float large_joint_point[10*3] = {

0.0f, 0.25f, 0.0f,
-0.25f, 0.0f, 0.0f,
-0.18f, 0.0f, 0.18f,
0.0f, 0.0f, 0.25f,
0.18f, 0.0f, 0.18f,
0.25f, 0.0f, 0.0f,
0.18f, 0.0f, -0.18f,
0.0f, 0.0f, -0.25f,
-0.18f, 0.0f, -0.18f,
0.0f, -0.25f, 0.0f,

};

const int large_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,

0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float medium_joint_point[10*3] = {

0.0f, 0.15f, 0.0f,
-0.15f, 0.0f, 0.0f,
-0.11f, 0.0f, 0.11f,
0.0f, 0.0f, 0.15f,
0.11f, 0.0f, 0.11f,
0.15f, 0.0f, 0.0f,
0.11f, 0.0f, -0.11f,
0.0f, 0.0f, -0.15f,
-0.11f, 0.0f, -0.11f,
0.0f, -0.15f, 0.0f,

};

const int medium_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float small_joint_point[10*3] = {

0.0f, 0.05f, 0.0f,
-0.05f, 0.0f, 0.0f,
-0.04f, 0.0f, 0.04f,
0.0f, 0.0f, 0.05f,
0.04f, 0.0f, 0.04f,
0.05f, 0.0f, 0.0f,
0.04f, 0.0f, -0.04f,
0.0f, 0.0f, -0.05f,
-0.04f, 0.0f, -0.04f,
0.0f, -0.05f, 0.0f,

};

const int small_joint_indice[16*3] = {

0, 1, 2,
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,
0, 7, 8,
0, 8, 1,
9, 2, 1,
9, 3, 2,
9, 4, 3,
9, 5, 4,
9, 6, 5,
9, 7, 6,
9, 8, 7,
9, 1, 8,

};

const float rover_body_point[8*3] = {

-1.0f, 2.0f, -1.25f, // 0
-0.75f, 1.5f, 1.25f,
0.75f, 1.5f, 1.25f,
1.0f, 2.0f, -1.25f,

-1.0f, 0.0f, -1.0f, // 4
-1.0f, 0.0f, 1.0f,
1.0f, 0.0f, 1.0f,
1.0f, 0.0f, -1.0f,

};

const int rover_body_indice[12*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

0, 1, 2, // 8
0, 2, 3,

7, 6, 5, // 10
7, 5, 4,

};

const float parrot_body_point[12*3] = {

-0.5f, 1.0f, -0.5f, // 0
-0.5f, 1.0f, 0.5f,
0.5f, 1.0f, 0.5f,
0.5f, 1.0f, -0.5f,

-1.0f, 0.0f, -1.0f, // 4
-1.0f, 0.0f, 1.0f,
1.0f, 0.0f, 1.0f,
1.0f, 0.0f, -1.0f,

-1.0f, 4.0f, -1.0f, // 8
-1.0f, 4.0f, 1.0f,
1.0f, 4.0f, 1.0f,
1.0f, 4.0f, -1.0f,

};

const int parrot_body_indice[20*3] = {

0, 4, 5, // 0
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

7, 6, 5, // 8
7, 5, 4,

8, 0, 1, // 10
8, 1, 9,
9, 1, 2,
9, 2, 10,
10, 2, 3,
10, 3, 11,
11, 3, 0,
11, 0, 8,

8, 9, 10,
8, 10, 11,

};

const float rover_wheel_point[16*3] = {

-0.1f, 0.0f, 0.25f, // 0
-0.1f, 0.177f, 0.177f,
-0.1f, 0.25f, 0.0f,
-0.1f, 0.177f, -0.177f,
-0.1f, 0.0f, -0.25f,
-0.1f, -0.177f, -0.177f,
-0.1f, -0.25f, 0.0f,
-0.1f, -0.177f, 0.177f,

0.1f, 0.0f, 0.25f, // 8
0.1f, 0.177f, 0.177f,
0.1f, 0.25f, 0.0f,
0.1f, 0.177f, -0.177f,
0.1f, 0.0f, -0.25f,
0.1f, -0.177f, -0.177f,
0.1f, -0.25f, 0.0f,
0.1f, -0.177f, 0.177f,

};

const int rover_wheel_indice[28*3] = {

0, 8, 9, // 0
0, 9, 1,
1, 9, 10,
1, 10, 2,
2, 10, 11,
2, 11, 3,
3, 11, 12,
3, 12, 4,
4, 12, 13,
4, 13, 5,
5, 13, 14,
5, 14, 6,
6, 14, 15,
6, 15, 7,
7, 15, 8,
7, 8, 0,

0, 1, 2, // 16
0, 2, 3,
0, 3, 4,
0, 4, 5,
0, 5, 6,
0, 6, 7,

8, 10, 9, // 22
8, 11, 10,
8, 12, 11,
8, 13, 12,
8, 14, 13,
8, 15, 14,

};

const float rover_eye_point[8*3] = {

-0.1f, 0.1f, -0.25f, // 0
-0.1f, 0.1f, 0.25f,
0.1f, 0.1f, 0.25f,
0.1f, 0.1f, -0.25f,

-0.1f, -0.1f, -0.25f, // 4
-0.1f, -0.1f, 0.25f,
0.1f, -0.1f, 0.25f,
0.1f, -0.1f, -0.25f,

};

const int rover_eye_indice[12*3] = {

0, 1, 2, // 0
0, 2, 3,

4, 7, 6, // 2
4, 6, 5,

0, 4, 5, // 4
0, 5, 1,
1, 5, 6,
1, 6, 2,
2, 6, 7,
2, 7, 3,
3, 7, 4,
3, 4, 0,

};


// Draws single component
void DrawComponent(const float *point, const int *indice, const int NUM_TRIANGLES)
{
	//glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]); // blank

	for (int i=0; i<NUM_TRIANGLES; i++)
	{	
		glBegin(GL_TRIANGLES);
		
		glNormal3f((point[indice[i*3+1]*3+1] - point[indice[i*3+0]*3+1]) * (point[indice[i*3+2]*3+2] - point[indice[i*3+0]*3+2]) -
			(point[indice[i*3+1]*3+2] - point[indice[i*3+0]*3+2]) * (point[indice[i*3+2]*3+1] - point[indice[i*3+0]*3+1]),
			-(point[indice[i*3+1]*3+0] - point[indice[i*3+0]*3+0]) * (point[indice[i*3+2]*3+2] - point[indice[i*3+0]*3+2]) +
			(point[indice[i*3+1]*3+2] - point[indice[i*3+0]*3+2]) * (point[indice[i*3+2]*3+0] - point[indice[i*3+0]*3+0]),
			(point[indice[i*3+1]*3+0] - point[indice[i*3+0]*3+0]) * (point[indice[i*3+2]*3+1] - point[indice[i*3+0]*3+1]) -
			(point[indice[i*3+1]*3+1] - point[indice[i*3+0]*3+1]) * (point[indice[i*3+2]*3+0] - point[indice[i*3+0]*3+0]));
		glVertex3f(point[indice[i*3+0]*3+0], point[indice[i*3+0]*3+1], point[indice[i*3+0]*3+2]);
		glVertex3f(point[indice[i*3+1]*3+0], point[indice[i*3+1]*3+1], point[indice[i*3+1]*3+2]);
		glVertex3f(point[indice[i*3+2]*3+0], point[indice[i*3+2]*3+1], point[indice[i*3+2]*3+2]);

		glEnd();
	}

	return;
};

void DrawRobot(int sex, int build, int attachment, float universal_y_rot, float *primary_color, float *secondary_color, float *tertiary_color, int animation_type, float &animation_timer)
{
	//animation_timer += 0.1f;
	//if (animation_timer > 6.28f) animation_timer -= 6.28f;

	float rot_x = 0.0f, rot_y = 0.0f;

	float hip[3][2], knee[3][2], shoulder[3][2], elbow[3][2], neck[3];

	if (animation_type == 0) // standing
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}
	}
	else if (animation_type == 1) // sitting down
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(-1.0f, -3.5f, 0.0f);

		hip[0][0] = 150.0f;
		hip[0][1] = 150.0f;
		knee[0][0] = -120.0f;
		knee[0][1] = -120.0f;
	}
	else if (animation_type == 2) // walking
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		hip[0][0] = 30.0f * sin(animation_timer);
		hip[0][1] = 30.0f * sin(animation_timer + 3.14159f);
		knee[0][0] = -30.0f * sin(animation_timer + 1.57f) - 30.0f;
		knee[0][1] = -30.0f * sin(animation_timer + 3.14159f + 1.57f) - 30.0f;

		shoulder[0][0] = 30.0f * sin(animation_timer + 3.14159f); 
		shoulder[0][1] = 30.0f * sin(animation_timer); 
	}
	else if (animation_type == 3) // running
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		hip[0][0] = 60.0f * sin(animation_timer);
		hip[0][1] = 60.0f * sin(animation_timer + 3.14159f);
		knee[0][0] = -60.0f * sin(animation_timer + 1.57f) - 60.0f;
		knee[0][1] = -60.0f * sin(animation_timer + 3.14159f + 1.57f) - 60.0f;

		shoulder[0][0] = 45.0f * sin(animation_timer + 3.14159f); 
		elbow[0][0] = 90.0f;
		shoulder[0][1] = 45.0f * sin(animation_timer); 
		elbow[0][1] = 90.0f;
	}
	else if (animation_type == 4) // hoe
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 5) // hammer
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 6) // scythe
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 7) // watering can
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 8) // seeds
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 9) // toss
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}
		
		shoulder[0][1] = 60.0f * sin(animation_timer) + 60.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 10) // grab
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);

		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;

		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
		shoulder[0][1] = 60.0f * sin(animation_timer) + 60.0f;

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 11) // charge
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		rot_x = -3.14159f / 6.0f;
		
		shoulder[0][0] = 30.0f;
		shoulder[0][1] = 30.0f;
	}
	else if (animation_type == 12) // fishing
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}
		
		if (animation_timer == 0.0f)
		{
			shoulder[0][0] = 15.0f;
			shoulder[0][1] = 30.0f;
			shoulder[1][0] = -45.0f + 30.0f * sex;
			shoulder[1][1] = 0.0f;
			elbow[0][0] = 60.0f;
			elbow[0][1] = 30.0f;
			elbow[1][0] = -60.0f;
			elbow[1][1] = 0.0f;
			elbow[2][0] = 0.0f;
			elbow[2][1] = -45.0f;
		}
		else
		{
			shoulder[0][0] = 15.0f + animation_timer * 15.0f;
			shoulder[0][1] = 30.0f + animation_timer * 15.0f;
			shoulder[1][0] = -45.0f + 30.0f * sex;
			shoulder[1][1] = 0.0f;
			elbow[0][0] = 60.0f + animation_timer * 15.0f;
			elbow[0][1] = 30.0f + animation_timer * 15.0f;
			elbow[1][0] = -60.0f;
			elbow[1][1] = 0.0f;
			elbow[2][0] = 0.0f;
			elbow[2][1] = -45.0f;
		}
	}
	else if (animation_type == 13) // ADAMANTINE hoe
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 2.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 14) // ADAMANTINE hammer
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x -= 3.14159f / 2.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 15) // ADAMANTINE scythe
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y -= 3.14159f * sin(animation_timer) - 3.14159f / 2.0f;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 16) // ADAMANTINE watering can
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		glTranslatef(0.0f, -0.3f, 0.0f);
	
		rot_y = 2.0f * animation_timer;
		rot_x -= 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	
		hip[0][0] = 30.0f;
		hip[0][1] = -15.0f;
		knee[0][0] = -30.0f;
		knee[0][1] = -15.0f;
		
	 	shoulder[0][0] = 15.0f * sin(animation_timer) + 30.0f;
		shoulder[0][1] = 30.0f * sin(animation_timer) + 0.0f;
		shoulder[1][0] = 15.0f;
		shoulder[1][1] = 0.0f;
		if (sex == 0) shoulder[2][0] = 45.0f;
		else if (sex == 1) shoulder[2][0] = 30.0f;
		shoulder[2][1] = 10.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 0.0f;
		elbow[0][1] = 30.0f * sin(animation_timer) + 90.0f;
		elbow[1][0] = 0.0f;
		elbow[1][1] = -20.0f * sin(animation_timer) - 20.0f;
		elbow[2][0] = 30.0f;
		elbow[2][1] = -15.0f;
		

		//shoulder[0][0] = 90.0f; // gun hand up
		//elbow[0][1] = 90.0f;

	}
	else if (animation_type == 17) // dancing!
	{
		attachment = 0; // should be temporary...

		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		if (animation_timer <= 8.0f * 3.14149f || (animation_timer >= 16.0f * 3.14159f && animation_timer <= 24.0f * 3.14159f))
		{
			glTranslatef(2.0f * cos(animation_timer) - 2.0f, 0.0f, 0.0f);
		
			hip[0][0] = 30.0f * sin(animation_timer);
			hip[0][1] = 30.0f * sin(animation_timer + 3.14159f);
			knee[0][0] = -30.0f * sin(animation_timer + 1.57f) - 30.0f;
			knee[0][1] = -30.0f * sin(animation_timer + 3.14159f + 1.57f) - 30.0f;

		 	shoulder[0][0] = -90.0f * cos(animation_timer) + 90.0f;
			shoulder[0][1] = -90.0f * cos(animation_timer) + 90.0f;
		}
		else
		{
			glTranslatef(-1.0f, -0.3f, 0.0f);

			rot_y += 3.14159f / 2.0f * sin(animation_timer);

			hip[0][0] = 15.0f;
			hip[0][1] = 15.0f;
			knee[0][0] = -30.0f;
			knee[0][1] = -30.0f;
		
			shoulder[0][0] = 60.0f;
			shoulder[0][1] = 60.0f;
		
			shoulder[2][0] = -45.0f;
			shoulder[2][1] = 45.0f;
		
			elbow[2][0] = 90.0f;
			elbow[2][1] = -90.0f;	
		}	
	}
	else if (animation_type == 18) // playing instrument!
	{
		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		shoulder[1][1] = 45.0f;
		shoulder[2][1] = 45.0f;
		elbow[0][1] = 90.0f;
		elbow[1][1] = -90.0f;
		elbow[2][1] = -45.0f;

		shoulder[0][0] = 15.0f;
		shoulder[1][0] = -30.0f - 15.0f * (1 - sex);
		shoulder[2][0] = -15.0f;
		elbow[0][0] = 60.0f * sin(animation_timer) + 60.0f;

		//glRotatef(0.25f * animation_timer * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);		
	}
	else if (animation_type == 19) // prayer
	{
		attachment = 0; // should be temporary...

		for (int i=0; i<3; i++)
		{
			hip[i][0] = 0.0f;
			hip[i][1] = 0.0f;
			knee[i][0] = 0.0f;
			knee[i][1] = 0.0f;
			shoulder[i][0] = 0.0f;
			shoulder[i][1] = 0.0f;
			elbow[i][0] = 0.0f;
			elbow[i][1] = 0.0f;
			neck[i] = 0.0f;
		}

		shoulder[0][0] = 90.0f;
		shoulder[0][1] = 90.0f;
		shoulder[1][0] = 45.0f;
		shoulder[1][1] = -45.0f;
		shoulder[2][0] = -30.0f;
		shoulder[2][1] = 30.0f;

		elbow[0][0] = 60.0f;
		elbow[0][1] = 60.0f;		
	}


	if (sex == 0) // male
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
		glTranslatef(0.0f, 4.5f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_torso_point, male_lower_torso_indice, 8);

		glTranslatef(-0.25f, -0.5f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_leg_point, male_upper_leg_indice, 12);

		if (build == 1 || build == 3)
		{
			glTranslatef(0.0f, -0.5f, 0.0f);

			glScalef(1.5f, 0.5f, 1.5f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_upper_leg_point, male_upper_leg_indice, 12);
	
			glScalef(1.0f / 1.5f, 1.0f / 0.5f, 1.0f / 1.5f);

			glTranslatef(0.0f, 0.5f, 0.0f);
		}

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_leg_point, male_lower_leg_indice, 12);

		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.25f, 0.5f, 0.0f);

		glTranslatef(0.25f, -0.5f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_leg_point, male_upper_leg_indice, 12);

		if (build == 1 || build == 3)
		{
			glTranslatef(0.0f, -0.5f, 0.0f);

			glScalef(1.5f, 0.5f, 1.5f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_upper_leg_point, male_upper_leg_indice, 12);
	
			glScalef(1.0f / 1.5f, 1.0f / 0.5f, 1.0f / 1.5f);

			glTranslatef(0.0f, 0.5f, 0.0f);
		}

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_leg_point, male_lower_leg_indice, 12);

		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.25f, 0.5f, 0.0f);
	
		glRotatef(rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glRotatef(rot_x/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(male_middle_torso_point, male_middle_torso_indice, 16);
	
		glRotatef(rot_x/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_torso_point, male_upper_torso_indice, 8);

		if (build == 1 || build == 3)
		{
			glTranslatef(0.0f, 0.1f, 0.0f);

			glScalef(0.85f, 0.75f, 1.25f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_upper_torso_point, male_upper_torso_indice, 8);
	
			glScalef(1.0f / 0.85f, 1.0f / 0.75f, 1.0f / 1.25f);

			glTranslatef(0.0f, -0.1f, 0.0f);
		}

		if (build == 2 || build == 3)
		{
			glTranslatef(-0.65f, 0.0f, 0.0f);

			glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(105.0f, 1.0f, 0.0f, 0.0f);

			glScalef(2.0f, 0.5f, 0.75f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_upper_arm_point, male_upper_arm_indice, 12);

			glScalef(1.0f / 2.0f, 1.0f / 0.5f, 1.0f / 0.75f);

			glRotatef(-105.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);

			glTranslatef(0.65f, 0.0f, 0.0f);
		}	

		glTranslatef(-1.0f, -0.25f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_arm_point, male_upper_arm_indice, 12);

		if (build == 2 || build == 3)
		{
			glTranslatef(0.0f, -0.5f, 0.0f);

			glScalef(1.5f, 0.5f, 1.5f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_upper_arm_point, male_upper_arm_indice, 12);
	
			glScalef(1.0f / 1.5f, 1.0f / 0.5f, 1.0f / 1.5f);

			glTranslatef(0.0f, 0.5f, 0.0f);
		}

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_arm_point, male_lower_arm_indice, 12);

		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(1.0f, 0.25f, 0.0f);

		if (build == 2 || build == 3)
		{
			glTranslatef(0.65f, 0.0f, 0.0f);

			glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(105.0f, 1.0f, 0.0f, 0.0f);

			glScalef(2.0f, 0.5f, 0.75f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_upper_arm_point, male_upper_arm_indice, 12);

			glScalef(1.0f / 2.0f, 1.0f / 0.5f, 1.0f / 0.75f);

			glRotatef(-105.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

			glTranslatef(-0.65f, 0.0f, 0.0f);
		}

		glTranslatef(1.0f, -0.25f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_upper_arm_point, male_upper_arm_indice, 12);

		if (build == 2 || build == 3)
		{
			glTranslatef(0.0f, -0.5f, 0.0f);

			glScalef(1.5f, 0.5f, 1.5f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_upper_arm_point, male_upper_arm_indice, 12);
	
			glScalef(1.0f / 1.5f, 1.0f / 0.5f, 1.0f / 1.5f);

			glTranslatef(0.0f, 0.5f, 0.0f);
		}

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		if (attachment != TOOL_TYPE_NONE && animation_type < 3)
		{
			glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
		}

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);	

		if (attachment != TOOL_TYPE_NONE && animation_type < 3)
		{
			glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
		}
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_lower_arm_point, male_lower_arm_indice, 12);
		
		if (animation_type == 12) // fishing
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (animation_type == 18) // playing instrument
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(instrument_point, instrument_indice, 24);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_HOE)
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(hoe_point, hoe_indice, 18);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_HAMMER)
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(hammer_point, hammer_indice, 26);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_SCYTHE)
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(scythe_point, scythe_indice, 30);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_WATERING_CAN)
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(watering_can_point, watering_can_indice, 22);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_ADAMANTINE_HOE)
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(hoe_point, hoe_indice, 18);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_ADAMANTINE_HAMMER)
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(hammer_point, hammer_indice, 26);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_ADAMANTINE_SCYTHE)
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(scythe_point, scythe_indice, 30);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_ADAMANTINE_WATERING_CAN)
		{
			glTranslatef(0.0f, -1.5f, 0.0f);
			glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(watering_can_point, watering_can_indice, 22);
			glTranslatef(0.0f, 1.5f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_PORTABLE_EXCHANGER)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

			glPushMatrix();

			glTranslatef(0.0f, -1.5f, 0.0f);

			glRotatef(180.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(180.0f, 0.0f, 1.0f, 0.0f);

			glScalef(0.25f, 0.25f, 0.25f);

			glColor3f(0.5f, 0.5f, 0.5f);
	
			DrawComponent(exchanger_point, exchanger_indice, 10);
	
			glColor3f(1,1,1);
	
			glTranslatef(0.0f, 0.0f, 1.5f);
			
			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
			//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
	
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	
			glTranslatef(0.0f, 0.0f, 3.1f);
	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXCHANGER]);
		
			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.4f, 2.9f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.4f, 0.1f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.4f, 0.1f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.4f, 2.9f, 0.0f);
			
			glEnd();

			glPopMatrix();
		}
		else if (attachment != TOOL_TYPE_NONE)
		{
			glColor3f(1,1,1);

			if (attachment == TOOL_TYPE_RYE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE_SEED]);
			else if (attachment == TOOL_TYPE_RYE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE]);
			else if (attachment == TOOL_TYPE_NANOTUBE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE_SEED]);
			else if (attachment == TOOL_TYPE_NANOTUBE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE]);
			else if (attachment == TOOL_TYPE_RADISH_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH_SEED]);
			else if (attachment == TOOL_TYPE_RADISH) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH]);
			else if (attachment == TOOL_TYPE_CABBAGE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE_SEED]);
			else if (attachment == TOOL_TYPE_CABBAGE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE]);
			else if (attachment == TOOL_TYPE_CUCUMBER_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER_SEED]);
			else if (attachment == TOOL_TYPE_CUCUMBER) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER]);
			else if (attachment == TOOL_TYPE_BEANS_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS_SEED]);
			else if (attachment == TOOL_TYPE_BEANS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS]);
			else if (attachment == TOOL_TYPE_MELON_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON_SEED]);
			else if (attachment == TOOL_TYPE_MELON) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON]);
			else if (attachment == TOOL_TYPE_TURNIP_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP_SEED]);
			else if (attachment == TOOL_TYPE_TURNIP) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP]);
			else if (attachment == TOOL_TYPE_ONION_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION_SEED]);
			else if (attachment == TOOL_TYPE_ONION) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION]);
			else if (attachment == TOOL_TYPE_ORE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE]);
			else if (attachment == TOOL_TYPE_BERRY) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BERRY]);
			else if (attachment == TOOL_TYPE_APPLE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_APPLE]);
			else if (attachment == TOOL_TYPE_MUSHROOM) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MUSHROOM]);
			else if (attachment == TOOL_TYPE_CRYSTAL) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CRYSTAL]);
			else if (attachment == TOOL_TYPE_FISH) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_FISH]);
			else if (attachment == TOOL_TYPE_EXTRACT) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXTRACT]);
			else if (attachment == TOOL_TYPE_GIFT_BASKET) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BASKET_HERB]);

			glPushMatrix();
					
			glTranslatef(0.0f, -1.75f, 0.0f);

			if (attachment != TOOL_TYPE_NONE && animation_type < 3)
			{
				glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
			}

			glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
	
			if (attachment != TOOL_TYPE_NONE && animation_type < 3)
			{
				glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
			}
	
			glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		
			glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);

			glRotatef(-rot_x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
			glRotatef(-rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);		

			glRotatef(90.0f, 0.0f, 1.0f, 0.0f);		

			glRotatef(-universal_y_rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);		

			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
			//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

			
			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-0.75f, 1.5f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-0.75f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(0.75f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0.75f, 1.5f, 0.0f);
			
			glEnd();
			
			glPopMatrix();
		}

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		if (attachment != TOOL_TYPE_NONE && animation_type < 3)
		{
			glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
		}

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);

		if (attachment != TOOL_TYPE_NONE && animation_type < 3)
		{
			glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
		}

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-1.0f, 0.25f, 0.0f);

		glTranslatef(0.0f, 0.1f, 0.0f);
		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(male_head_point, male_head_indice, 12);

		if (build == 1)
		{
			glTranslatef(0.0f, 0.5f, 0.1f);

			glScalef(1.1f, 0.25f, 1.0f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_head_point, male_head_indice, 12);
		
			glScalef(1.0f / 1.1f, 1.0f / 0.25f, 1.0f);

			glTranslatef(0.0f, -0.5f, -0.1f);
		}

		if (build == 2)
		{
			glTranslatef(0.0f, 0.0f, 0.1f);

			glScalef(1.1f, 1.1f, 1.0f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(male_head_point, male_head_indice, 12);
		
			glScalef(1.0f / 1.1f, 1.0f / 1.1f, 1.0f);

			glTranslatef(0.0f, 0.0f, -0.1f);
		}

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(male_visor_point, male_visor_indice, 10);

		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, -0.1f, 0.0f);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-rot_x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glRotatef(-rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);		

		glTranslatef(0.0f, -4.5f, 0.0f);
		glRotatef(90.0f, 0.0f, 1.0f, 0.0f);		
	}
	else if (sex == 1) // female
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
		glTranslatef(0.0f, 5.0f, 0.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_torso_point, female_lower_torso_indice, 8);

		if (build == 2 || build == 3)
		{
			glTranslatef(0.0f, 0.1f, 0.0f);

			glScalef(1.1f, 1.0f, 1.1f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(female_lower_torso_point, female_lower_torso_indice, 8);
		
			glScalef(1.0f / 1.1f, 1.0f, 1.0f / 1.1f);

			glTranslatef(0.0f, -0.1f, 0.0f);
		}

		glTranslatef(-0.25f, -1.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_leg_point, female_upper_leg_indice, 12);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_leg_point, female_lower_leg_indice, 12);

		if (build == 1 || build == 3)
		{
			glTranslatef(0.0f, -0.25f, 0.0f);

			glScalef(1.25f, 0.75f, 1.25f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(female_lower_leg_point, female_lower_leg_indice, 12);
		
			glScalef(1.0f / 1.25f, 1.0f / 0.75f, 1.0f / 1.25f);

			glTranslatef(0.0f, 0.25f, 0.0f);
		}

		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.25f, 1.0f, 0.0f);

		glTranslatef(0.25f, -1.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(large_joint_point, large_joint_indice, 16);

		glRotatef(hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_leg_point, female_upper_leg_indice, 12);

		glTranslatef(0.0f, -2.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_leg_point, female_lower_leg_indice, 12);

		if (build == 1 || build == 3)
		{
			glTranslatef(0.0f, -0.25f, 0.0f);

			glScalef(1.25f, 0.75f, 1.25f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(female_lower_leg_point, female_lower_leg_indice, 12);
		
			glScalef(1.0f / 1.25f, 1.0f / 0.75f, 1.0f / 1.25f);

			glTranslatef(0.0f, 0.25f, 0.0f);
		}

		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-knee[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-knee[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-knee[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.0f, 2.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-hip[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-hip[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-hip[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-5.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.25f, 1.0f, 0.0f);

		glRotatef(rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		glRotatef(rot_x/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(female_middle_torso_point, female_middle_torso_indice, 16);
	
		glRotatef(rot_x/2.0f * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.5f, 0.0f);

		glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_torso_point, female_upper_torso_indice, 12);
		glRotatef(-180.0f, 0.0f, 1.0f, 0.0f);

		if (build == 1 || build == 3)
		{
			glTranslatef(0.0f, -0.275f, 0.0f);

			glScalef(0.9f, 0.5f, 1.25f);

			glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(female_upper_torso_point, female_upper_torso_indice, 12);
			glRotatef(-180.0f, 0.0f, 1.0f, 0.0f);
		
			glScalef(1.0f / 0.9f, 1.0f / 0.5f, 1.0f / 1.25f);

			glTranslatef(0.0f, 0.275f, 0.0f);
		}

		if (build == 2 || build == 3)
		{
			glTranslatef(0.1f, 0.0f, 0.0f);

			glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(105.0f, 1.0f, 0.0f, 0.0f);

			glScalef(3.0f, 0.5f, 1.0f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(female_upper_arm_point, female_upper_arm_indice, 12);

			glScalef(1.0f / 3.0f, 1.0f / 0.5f, 1.0f);

			glRotatef(-105.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

			glTranslatef(-0.1f, 0.0f, 0.0f);
		}

		glTranslatef(-0.475f, -0.225f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);

		glRotatef(shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_arm_point, female_upper_arm_indice, 12);

		glTranslatef(0.0f, -1.25f, 0.0f);
		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);	
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_arm_point, female_lower_arm_indice, 12);

		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-elbow[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.25f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][0]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][0]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(0.475f, 0.225f, 0.0f);

		if (build == 2 || build == 3)
		{
			glTranslatef(-0.1f, 0.0f, 0.0f);

			glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(105.0f, 1.0f, 0.0f, 0.0f);

			glScalef(3.0f, 0.5f, 1.0f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(female_upper_arm_point, female_upper_arm_indice, 12);

			glScalef(1.0f / 3.0f, 1.0f / 0.5f, 1.0f);

			glRotatef(-105.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);

			glTranslatef(0.1f, 0.0f, 0.0f);
		}

		glTranslatef(0.475f, -0.225f, 0.0f);
		glRotatef(10.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);

		glRotatef(shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_upper_arm_point, female_upper_arm_indice, 12);

		glTranslatef(0.0f, -1.25f, 0.0f);
		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		if (attachment != TOOL_TYPE_NONE && animation_type < 3)
		{
			glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
		}

		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(small_joint_point, small_joint_indice, 16);	

		glRotatef(elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);

		if (attachment != TOOL_TYPE_NONE && animation_type < 3)
		{
			glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
		}
	
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_lower_arm_point, female_lower_arm_indice, 12);

		if (animation_type == 12) // fishing
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(fishing_pole_point, fishing_pole_indice, 12);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (animation_type == 18) // playing instrument
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(instrument_point, instrument_indice, 24);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_HOE)
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(hoe_point, hoe_indice, 18);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_HAMMER)
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(hammer_point, hammer_indice, 26);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_SCYTHE)
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(scythe_point, scythe_indice, 30);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_WATERING_CAN)
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.75f, 0.75f, 0.75f);
			DrawComponent(watering_can_point, watering_can_indice, 22);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_ADAMANTINE_HOE)
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(hoe_point, hoe_indice, 18);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_ADAMANTINE_HAMMER)
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(hammer_point, hammer_indice, 26);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_ADAMANTINE_SCYTHE)
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(scythe_point, scythe_indice, 30);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_ADAMANTINE_WATERING_CAN)
		{
			glTranslatef(0.0f, -1.25f, 0.0f);
			glColor3f(0.0f, 0.75f, 0.75f);
			DrawComponent(watering_can_point, watering_can_indice, 22);
			glTranslatef(0.0f, 1.25f, 0.0f);
		}
		else if (attachment == TOOL_TYPE_PORTABLE_EXCHANGER)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

			glPushMatrix();

			glTranslatef(0.0f, -1.25f, 0.0f);

			glRotatef(180.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(180.0f, 0.0f, 1.0f, 0.0f);

			glScalef(0.25f, 0.25f, 0.25f);

			glColor3f(0.5f, 0.5f, 0.5f);
	
			DrawComponent(exchanger_point, exchanger_indice, 10);
	
			glColor3f(1,1,1);
	
			glTranslatef(0.0f, 0.0f, 1.5f);
			
			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
			//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
	
			glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	
			glTranslatef(0.0f, 0.0f, 3.1f);
	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXCHANGER]);
		
			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.4f, 2.9f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.4f, 0.1f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.4f, 0.1f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.4f, 2.9f, 0.0f);
			
			glEnd();

			glPopMatrix();
		}
		else if (attachment != TOOL_TYPE_NONE)
		{
			glColor3f(1,1,1);

			if (attachment == TOOL_TYPE_RYE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE_SEED]);
			else if (attachment == TOOL_TYPE_RYE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE]);
			else if (attachment == TOOL_TYPE_NANOTUBE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE_SEED]);
			else if (attachment == TOOL_TYPE_NANOTUBE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE]);
			else if (attachment == TOOL_TYPE_RADISH_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH_SEED]);
			else if (attachment == TOOL_TYPE_RADISH) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH]);
			else if (attachment == TOOL_TYPE_CABBAGE_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE_SEED]);
			else if (attachment == TOOL_TYPE_CABBAGE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE]);
			else if (attachment == TOOL_TYPE_CUCUMBER_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER_SEED]);
			else if (attachment == TOOL_TYPE_CUCUMBER) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER]);
			else if (attachment == TOOL_TYPE_BEANS_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS_SEED]);
			else if (attachment == TOOL_TYPE_BEANS) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS]);
			else if (attachment == TOOL_TYPE_MELON_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON_SEED]);
			else if (attachment == TOOL_TYPE_MELON) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON]);
			else if (attachment == TOOL_TYPE_TURNIP_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP_SEED]);
			else if (attachment == TOOL_TYPE_TURNIP) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP]);
			else if (attachment == TOOL_TYPE_ONION_SEED) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION_SEED]);
			else if (attachment == TOOL_TYPE_ONION) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION]);
			else if (attachment == TOOL_TYPE_ORE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE]);	
			else if (attachment == TOOL_TYPE_BERRY) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BERRY]);
			else if (attachment == TOOL_TYPE_APPLE) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_APPLE]);
			else if (attachment == TOOL_TYPE_MUSHROOM) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MUSHROOM]);
			else if (attachment == TOOL_TYPE_CRYSTAL) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CRYSTAL]);
			else if (attachment == TOOL_TYPE_FISH) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_FISH]);
			else if (attachment == TOOL_TYPE_EXTRACT) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXTRACT]);
			else if (attachment == TOOL_TYPE_GIFT_BASKET) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BASKET_HERB]);

			glPushMatrix();
					
			glTranslatef(0.0f, -1.25f, 0.0f);

			if (attachment != TOOL_TYPE_NONE && animation_type < 3)
			{
				glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
			}

			glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
	
			if (attachment != TOOL_TYPE_NONE && animation_type < 3)
			{
				glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
			}
	
			glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		
			glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
			glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
			glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
			glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);

			glRotatef(-rot_x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
			glRotatef(-rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);		

			glRotatef(90.0f, 0.0f, 1.0f, 0.0f);		

			glRotatef(-universal_y_rot * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);		

			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
			//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

			
			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-0.75f, 1.5f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-0.75f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(0.75f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0.75f, 1.5f, 0.0f);
			
			glEnd();
			
			glPopMatrix();
		}

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		if (attachment != TOOL_TYPE_NONE && animation_type < 3)
		{
			glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
		}

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);

		if (attachment != TOOL_TYPE_NONE && animation_type < 3)
		{
			glRotatef(-30.0f, 1.0f, 0.0f, 0.0f);
		}

		glRotatef(-elbow[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-elbow[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-elbow[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glTranslatef(0.0f, 1.25f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-shoulder[2][1]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-shoulder[1][1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-shoulder[0][1]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(-10.0f, 0.0f, 0.0f, 1.0f);
		glTranslatef(-0.475f, 0.225f, 0.0f);

		glTranslatef(0.0f, 0.05f, 0.0f);
		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(medium_joint_point, medium_joint_indice, 16);

		glRotatef(neck[0]/2.0f, 1.0f, 0.0f, 0.0f);
		glRotatef(neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		
		glColor3f(primary_color[0], primary_color[1], primary_color[2]);
		DrawComponent(female_head_point, female_head_indice, 12);

		if (build == 1)
		{
			glTranslatef(0.0f, 1.15f, 0.1f);

			glScalef(1.65f, 0.8f, 1.0f);

			glRotatef(180.0f, 0.0f, 0.0f, 1.0f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(female_head_point, female_head_indice, 12);

			glRotatef(-180.0f, 0.0f, 0.0f, 1.0f);
		
			glScalef(1.0f / 1.65f, 1.0f / 0.8f, 1.0f);

			glTranslatef(0.0f, -1.15f, -0.1f);
		}


		if (build == 2)
		{
			glTranslatef(0.0f, 0.0f, 0.1f);

			glScalef(1.2f, 1.1f, 1.0f);

			glColor3f(tertiary_color[0], tertiary_color[1], tertiary_color[2]);
			DrawComponent(female_head_point, female_head_indice, 12);
		
			glScalef(1.0f / 1.2f, 1.0f / 1.1f, 1.0f);

			glTranslatef(0.0f, 0.0f, -0.1f);
		}


		glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
		DrawComponent(female_visor_point, female_visor_indice, 10);

		glRotatef(-neck[0], 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1], 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[2], 1.0f, 0.0f, 0.0f);
		glRotatef(-neck[2]/2.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(-neck[1]/2.0f, 0.0f, 1.0f, 0.0f);
		glRotatef(-neck[0]/2.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, -0.05f, 0.0f);

		glTranslatef(0.0f, -1.5f, 0.0f);
		glRotatef(-rot_x * 180.0f / 3.14159f, 1.0f, 0.0f, 0.0f);
		glRotatef(-rot_y * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
		
		glTranslatef(0.0f, -5.0f, 0.0f);
		glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	}

	if (animation_type == 1) // sitting down
	{
		glTranslatef(1.0f, 3.5f, 0.0f);
	}
	else if (animation_type == 4) // hoe
	{
		glTranslatef(0.0f, 0.3f, 0.0f);

		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 5) // hammer
	{
		glTranslatef(0.0f, 0.3f, 0.0f);

		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 6) // scythe
	{
		glTranslatef(0.0f, 0.3f, 0.0f);

		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 7) // watering can
	{
		glTranslatef(0.0f, 0.3f, 0.0f);

		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 8) // seeds
	{
		glTranslatef(0.0f, 0.3f, 0.0f);

		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 10) // grab
	{
		glTranslatef(0.0f, 0.3f, 0.0f);

		rot_y -= 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 13) // ADAMANTINE hoe
	{
		glTranslatef(0.0f, 0.3f, 0.0f);
	
		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 2.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 14) // ADAMANTINE hammer
	{
		glTranslatef(0.0f, 0.3f, 0.0f);
	
		rot_y += 3.14159f / 16.0f * sin(animation_timer) + 3.14159f / 16.0f;
		rot_x += 3.14159f / 2.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 15) // ADAMANTINE scythe
	{
		glTranslatef(0.0f, 0.3f, 0.0f);
	
		rot_y += 3.14159f * sin(animation_timer) - 3.14159f / 2.0f;
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 16) // ADAMANTINE watering can
	{
		glTranslatef(0.0f, 0.3f, 0.0f);
	
		rot_y = 0.0f; // ???
		rot_x += 3.14159f / 8.0f * sin(animation_timer + 3.14159f) + 3.14159f / 8.0f;
	}
	else if (animation_type == 17) // dancing!
	{
		if (animation_timer <= 8.0f * 3.14149f || (animation_timer >= 16.0f * 3.14159f && animation_timer <= 24.0f * 3.14159f))
		{
			glTranslatef(-2.0f * cos(animation_timer) + 2.0f, 0.0f, 0.0f);
		}
		else
		{
			glTranslatef(1.0f, 0.3f, 0.0f);

			rot_y -= 3.14159f / 2.0f * sin(animation_timer);
		}
	}
	else if (animation_type == 18) // instruments
	{
		//glRotatef(-0.25f * animation_timer * 180.0f / 3.14159f, 0.0f, 1.0f, 0.0f);
	}

	glColor3f(1,1,1);

	return;
};

void DrawRover(int build, float universal_y_rot, float *primary_color, float *secondary_color, float *tertiary_color, int animation_type, float &animation_timer)
{
	//animation_timer += 0.1f;
	//if (animation_timer > 6.28f) animation_timer -= 6.28f;

	float rot_x = 0.0f, rot_y = 0.0f;

	float wheel[3][4];

	if (animation_type == 0) // standing
	{
		for (int i=0; i<3; i++)
		{
			wheel[i][0] = 0.0f;
			wheel[i][1] = 0.0f;
			wheel[i][2] = 0.0f;
			wheel[i][3] = 0.0f;
		}
	}
	else if (animation_type == 1) // jumping in place
	{
		for (int i=0; i<3; i++)
		{
			wheel[i][0] = 0.0f;
			wheel[i][1] = 0.0f;
			wheel[i][2] = 0.0f;
			wheel[i][3] = 0.0f;
		}
	}
	else if (animation_type == 2) // walking
	{
		for (int i=0; i<3; i++)
		{
			wheel[i][0] = 0.0f;
			wheel[i][1] = 0.0f;
			wheel[i][2] = 0.0f;
			wheel[i][3] = 0.0f;
		}

		wheel[0][0] = -animation_timer * 180.0f / 3.14159f;
		wheel[0][1] = -animation_timer * 180.0f / 3.14159f;
		wheel[0][2] = -animation_timer * 180.0f / 3.14159f;
		wheel[0][3] = -animation_timer * 180.0f / 3.14159f;
	}

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

	glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
	if (build == 0) glTranslatef(0.0f, 0.10f, 0.0f);
	else glTranslatef(0.0f, 0.25f, 0.0f);

	if (build == 0) glColor3f(primary_color[0] / 2.0f, primary_color[1] / 2.0f, primary_color[2] / 2.0f);
	else glColor3f(primary_color[0], primary_color[1], primary_color[2]);
	DrawComponent(rover_body_point, rover_body_indice, 12);

	glTranslatef(1.0f, 1.95f, -1.15f);
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	DrawComponent(rover_eye_point, rover_eye_indice, 12);
	glTranslatef(-1.0f, -1.95f, 1.15f);

	glTranslatef(-1.2f, 0.25f, -0.75f);
	if (build == 0) glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(wheel[0][0], 1.0f, 0.0f, 0.0f);
	
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	glScalef(2.0f, 2.0f, 2.0f);
	DrawComponent(rover_wheel_point, rover_wheel_indice, 28);
	glScalef(0.5f, 0.5f, 0.5f);

	glRotatef(-wheel[0][0], 1.0f, 0.0f, 0.0f);
	if (build == 0) glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(1.2f, -0.25f, 0.75f);
		
	glTranslatef(1.2f, 0.25f, -0.75f);
	if (build == 0) glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(wheel[0][1], 1.0f, 0.0f, 0.0f);
	
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	glScalef(2.0f, 2.0f, 2.0f);
	DrawComponent(rover_wheel_point, rover_wheel_indice, 28);
	glScalef(0.5f, 0.5f, 0.5f);

	glRotatef(-wheel[0][1], 1.0f, 0.0f, 0.0f);
	if (build == 0) glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-1.2f, -0.25f, 0.75f);

	glTranslatef(-1.2f, 0.25f, 0.75f);
	if (build == 0) glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(wheel[0][2], 1.0f, 0.0f, 0.0f);
	
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	glScalef(2.0f, 2.0f, 2.0f);
	DrawComponent(rover_wheel_point, rover_wheel_indice, 28);
	glScalef(0.5f, 0.5f, 0.5f);

	glRotatef(-wheel[0][2], 1.0f, 0.0f, 0.0f);
	if (build == 0) glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(1.2f, -0.25f, -0.75f);

	glTranslatef(1.2f, 0.25f, 0.75f);
	if (build == 0) glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(wheel[0][3], 1.0f, 0.0f, 0.0f);
	
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	glScalef(2.0f, 2.0f, 2.0f);
	DrawComponent(rover_wheel_point, rover_wheel_indice, 28);
	glScalef(0.5f, 0.5f, 0.5f);

	glRotatef(-wheel[0][3], 1.0f, 0.0f, 0.0f);
	if (build == 0) glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-1.2f, -0.25f, -0.75f);
	
	if (build == 0) glTranslatef(0.0f, -0.10f, 0.0f);
	else glTranslatef(0.0f, -0.25f, 0.0f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

	return;
};

void DrawParrot(int build, float universal_y_rot, float *primary_color, float *secondary_color, float *tertiary_color, int animation_type, float &animation_timer)
{
	//animation_timer += 0.1f;
	//if (animation_timer > 6.28f) animation_timer -= 6.28f;

	float rot_x = 0.0f, rot_y = 0.0f;

	float wheel[3][4];

	if (animation_type == 0) // standing
	{
		for (int i=0; i<3; i++)
		{
			wheel[i][0] = 0.0f;
			wheel[i][1] = 0.0f;
			wheel[i][2] = 0.0f;
			wheel[i][3] = 0.0f;
		}
	}
	else if (animation_type == 1) // jumping in place
	{
		for (int i=0; i<3; i++)
		{
			wheel[i][0] = 0.0f;
			wheel[i][1] = 0.0f;
			wheel[i][2] = 0.0f;
			wheel[i][3] = 0.0f;
		}
	}
	else if (animation_type == 2) // walking
	{
		for (int i=0; i<3; i++)
		{
			wheel[i][0] = 0.0f;
			wheel[i][1] = 0.0f;
			wheel[i][2] = 0.0f;
			wheel[i][3] = 0.0f;
		}

		wheel[0][0] = -animation_timer * 180.0f / 3.14159f;
		wheel[0][1] = -animation_timer * 180.0f / 3.14159f;
		wheel[0][2] = -animation_timer * 180.0f / 3.14159f;
		wheel[0][3] = -animation_timer * 180.0f / 3.14159f;
	}

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

	glRotatef(-90.0f, 0.0f, 1.0f, 0.0f);
	if (build == 0) glTranslatef(0.0f, 0.10f, 0.0f);
	else glTranslatef(0.0f, 0.25f, 0.0f);

	if (build == 0) glColor3f(primary_color[0] / 2.0f, primary_color[1] / 2.0f, primary_color[2] / 2.0f);
	else glColor3f(primary_color[0], primary_color[1], primary_color[2]);
	DrawComponent(parrot_body_point, parrot_body_indice, 20);

	glTranslatef(1.0f, 3.95f, -1.0f);
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	DrawComponent(rover_eye_point, rover_eye_indice, 12);
	glTranslatef(-1.0f, -3.95f, 1.0f);

	glTranslatef(-1.0f, 3.95f, -1.0f);
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	DrawComponent(rover_eye_point, rover_eye_indice, 12);
	glTranslatef(1.0f, -3.95f, 1.0f);

	glTranslatef(-0.5f, 3.95f, 0.5f);
	glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
	glScalef(1.0f, 1.0f, 5.0f);
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	DrawComponent(rover_eye_point, rover_eye_indice, 12);
	glScalef(1.0f, 1.0f, 0.2f);
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glTranslatef(0.5f, -3.95f, -0.5f);

	glTranslatef(-1.2f, 0.25f, -0.75f);
	if (build == 0) glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(wheel[0][0], 1.0f, 0.0f, 0.0f);
	
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	glScalef(2.0f, 2.0f, 2.0f);
	DrawComponent(rover_wheel_point, rover_wheel_indice, 28);
	glScalef(0.5f, 0.5f, 0.5f);

	glRotatef(-wheel[0][0], 1.0f, 0.0f, 0.0f);
	if (build == 0) glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(1.2f, -0.25f, 0.75f);
		
	glTranslatef(1.2f, 0.25f, -0.75f);
	if (build == 0) glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(wheel[0][1], 1.0f, 0.0f, 0.0f);
	
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	glScalef(2.0f, 2.0f, 2.0f);
	DrawComponent(rover_wheel_point, rover_wheel_indice, 28);
	glScalef(0.5f, 0.5f, 0.5f);

	glRotatef(-wheel[0][1], 1.0f, 0.0f, 0.0f);
	if (build == 0) glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-1.2f, -0.25f, 0.75f);

	glTranslatef(-1.2f, 0.25f, 0.75f);
	if (build == 0) glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(wheel[0][2], 1.0f, 0.0f, 0.0f);
	
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	glScalef(2.0f, 2.0f, 2.0f);
	DrawComponent(rover_wheel_point, rover_wheel_indice, 28);
	glScalef(0.5f, 0.5f, 0.5f);

	glRotatef(-wheel[0][2], 1.0f, 0.0f, 0.0f);
	if (build == 0) glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(1.2f, -0.25f, -0.75f);

	glTranslatef(1.2f, 0.25f, 0.75f);
	if (build == 0) glRotatef(-30.0f, 0.0f, 0.0f, 1.0f);
	glRotatef(wheel[0][3], 1.0f, 0.0f, 0.0f);
	
	glColor3f(secondary_color[0], secondary_color[1], secondary_color[2]);
	glScalef(2.0f, 2.0f, 2.0f);
	DrawComponent(rover_wheel_point, rover_wheel_indice, 28);
	glScalef(0.5f, 0.5f, 0.5f);

	glRotatef(-wheel[0][3], 1.0f, 0.0f, 0.0f);
	if (build == 0) glRotatef(30.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-1.2f, -0.25f, -0.75f);
	
	if (build == 0) glTranslatef(0.0f, -0.10f, 0.0f);
	else glTranslatef(0.0f, -0.25f, 0.0f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

	return;
};
	
void DrawSprite(int x, int y, int type, int water, int &growth, int &style, int season)
{
	if (type == TILE_TYPE_NONE) glColor3f(0,0,0);
	else if (type == TILE_TYPE_TILLED && water == 0) glColor3f(1.0f, 0.5f, 0.0f);
	else if ((type == TILE_TYPE_RADISH ||
		type == TILE_TYPE_CABBAGE ||
		type == TILE_TYPE_CUCUMBER ||
		type == TILE_TYPE_BEANS ||
		type == TILE_TYPE_MELON ||
		type == TILE_TYPE_TURNIP ||
		type == TILE_TYPE_ONION) && water == 0) glColor3f(1.0f, 0.6f, 0.2f);
	else if (type == TILE_TYPE_TILLED && water == 1) glColor3f(0.5f, 0.25f, 0.0f);
	else if ((type == TILE_TYPE_RADISH ||
		type == TILE_TYPE_CABBAGE ||
		type == TILE_TYPE_CUCUMBER ||
		type == TILE_TYPE_BEANS ||
		type == TILE_TYPE_MELON ||
		type == TILE_TYPE_TURNIP ||
		type == TILE_TYPE_ONION) && water == 1) glColor3f(0.5f, 0.3f, 0.1f);
	else if (type == TILE_TYPE_RYE ||
		type == TILE_TYPE_NANOTUBE) glColor3f(0.7f, 0.7f, 0.5f);
	else if (type == TILE_TYPE_CRYSTAL ||
		type == TILE_TYPE_EXPOSED_CRYSTAL ||
		type == TILE_TYPE_BROKEN_CRYSTAL ||
		type == TILE_TYPE_EMPTY_CRYSTAL) glColor3f(0.85f, 0.65f, 0.5f);
	else if (type == TILE_TYPE_EMPTY_ROVER_STATION ||
		type == TILE_TYPE_FULL_ROVER_STATION ||
		type == TILE_TYPE_ROVER_DEPOSIT ||
		type == TILE_TYPE_EMPTY_ROVER_DEPOSIT ||
		type == TILE_TYPE_NANOTUBE_DISTRIBUTOR ||
		type == TILE_TYPE_ARCADE ||
		type == TILE_TYPE_FISHERY ||
		type == TILE_TYPE_FISHERY_WAITING ||
		type == TILE_TYPE_FISHERY_HOOKED ||
		type == TILE_TYPE_FISHERY_CAUGHT ||
		type == TILE_TYPE_MATCHING_CHALLENGE) glColor3f(0.75f, 0.75f, 0.75f);
	else if (type == TILE_TYPE_CLOSED_DOOR) glColor3f(1.0f, 0.5f, 0.5f);
	else if (type == TILE_TYPE_OPEN_DOOR) glColor3f(1.0f, 0.5f, 0.5f);
	else if ((type == TILE_TYPE_PATH && style == 0) ||
		(type == TILE_TYPE_WALL && style >= 5) ||
		type == TILE_TYPE_BLOCKING_SIGN ||
		type == TILE_TYPE_POTTED_HERB) glColor3f(1.0f, 0.5f, 0.5f);
	else if (type == TILE_TYPE_PATH && style == 1) glColor3f(0.75f, 0.75f, 0.75f);
	else if (type == TILE_TYPE_BOUNDED && style == 0) glColor3f(1.0f, 0.5f, 0.5f);
	else if (type == TILE_TYPE_BOUNDED && (style == 1 || style == 2)) glColor3f(0.75f, 0.75f, 0.75f);
	else 
	{
		if (season == 1) glColor3f(0.65f, 0.75f, 0.25f);
		else if (season == 2) glColor3f(1.0f, 1.0f, 0.5f);
		else if (season == 3) glColor3f(0.75f, 0.65f, 0.25f);
		else if (season == 4) glColor3f(0.8f, 0.8f, 1.0f);
	}

	glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_GROUND]);
				
	glBegin(GL_QUADS);
				
	glNormal3f(0.0f, 1.0f, 0.0f);
	glTexCoord2f((float)(x) / 15.0f, (float)(y) / 15.0f);
	glVertex3f((float)(x)*3.0f, 0.0f, (float)(y)*3.0f);
	glTexCoord2f((float)(x) / 15.0f,(float)(y+1) / 15.0f);
	glVertex3f((float)(x)*3.0f, 0.0f, (float)(y+1)*3.0f);
	glTexCoord2f((float)(x+1) / 15.0f, (float)(y+1) / 15.0f);
	glVertex3f((float)(x+1)*3.0f, 0.0f, (float)(y+1)*3.0f);
	glTexCoord2f((float)(x+1) / 15.0f, (float)(y) / 15.0f);
	glVertex3f((float)(x+1)*3.0f, 0.0f, (float)(y)*3.0f);
	
	glEnd();

	glColor3f(1,1,1);

	if (type == TILE_TYPE_NONE)
	{
		
	}
	else if (type == TILE_TYPE_DIRT)
	{

	}
	else if (type == TILE_TYPE_TILLED)
	{

	}
	else if (type == TILE_TYPE_ROCK)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ROCK_1+style]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.75f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glColor3f(1.0f, 0.75f, 0.75f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 3.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 3.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_WEED)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_WEED_1+style]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 3.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 3.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_RYE)
	{
		if (growth == 3) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE_RIPE]);
		else glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE_PLANT]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-3.0f*((float)growth)/30.0f, 7.0f*((float)growth)/30.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-3.0f*((float)growth)/30.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(3.0f*((float)growth)/30.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(3.0f*((float)growth)/30.0f, 7.0f*((float)growth)/30.0f, 0.0f);

		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_CUT_RYE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.0f, 2.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.0f, 2.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_NANOTUBE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE_PLANT]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f + 0.25f, 0.0f, ((float)(y)+0.5f)*3.0f + 1.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.5f*((float)-growth + 0.3f)/9.0f, 3.0f*((float)-growth + 0.3f)/9.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.5f*((float)-growth + 0.3f)/9.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.5f*((float)-growth + 0.3f)/9.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.5f*((float)-growth + 0.3f)/9.0f, 3.0f*((float)-growth + 0.3f)/9.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f - 0.25f, 0.0f, ((float)(y)+0.5f)*3.0f - 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.5f*((float)-growth + 0.3f)/9.0f, 3.0f*((float)-growth + 0.3f)/9.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.5f*((float)-growth + 0.3f)/9.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.5f*((float)-growth + 0.3f)/9.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.5f*((float)-growth + 0.3f)/9.0f, 3.0f*((float)-growth + 0.3f)/9.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_RADISH)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH_PLANT]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.0f*(float)growth/4.0f, 2.0f*(float)growth/4.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.0f*(float)growth/4.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.0f*(float)growth/4.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.0f*(float)growth/4.0f, 2.0f*(float)growth/4.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_CABBAGE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE_PLANT]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.25f*(float)growth/7.0f, 2.0f*(float)growth/7.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.25f*(float)growth/7.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.25f*(float)growth/7.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.25f*(float)growth/7.0f, 2.0f*(float)growth/7.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_CUCUMBER)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		if (growth < 6)
		{	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f*(float)growth/6.0f, 3.0f*(float)growth/6.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f*(float)growth/6.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f*(float)growth/6.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f*(float)growth/6.0f, 3.0f*(float)growth/6.0f, 0.0f);
		
			glEnd();
		}		
		else if (growth < 9)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f, 3.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f, 3.0f, 0.0f);
		
			glEnd();
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f, 3.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f, 3.0f, 0.0f);
		
			glEnd();

			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.0f, 1.0f, 0.2f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.0f, 0.0f, 0.2f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.0f, 0.0f, 0.2f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.0f, 1.0f, 0.2f);
		
			glEnd();
		}
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_BEANS)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		if (growth < 8)
		{	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f*(float)growth/8.0f, 4.0f*(float)growth/8.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f*(float)growth/8.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f*(float)growth/8.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f*(float)growth/8.0f, 4.0f*(float)growth/8.0f, 0.0f);
		
			glEnd();
		}		
		else if (growth < 12)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f, 4.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f, 4.0f, 0.0f);
		
			glEnd();
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_FULL_BEANS_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f, 4.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f, 4.0f, 0.0f);
		
			glEnd();
		}
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_MELON)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		if (growth < 10)
		{	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f*(float)growth/10.0f, 3.0f*(float)growth/10.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f*(float)growth/10.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f*(float)growth/10.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f*(float)growth/10.0f, 3.0f*(float)growth/10.0f, 0.0f);
		
			glEnd();
		}		
		else if (growth < 15)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f, 3.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f, 3.0f, 0.0f);
		
			glEnd();
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON_PLANT]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.25f, 3.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.25f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.25f, 3.0f, 0.0f);
		
			glEnd();

			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.0f, 1.0f, -0.1f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.0f, 0.0f, -0.1f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(0.5f, 0.0f, -0.1f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(0.5f, 1.0f, -0.1f);
		
			glEnd();
		}
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_TURNIP)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP_PLANT]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f+0.25f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.1f*(float)growth/6.0f, 2.5f*(float)growth/6.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.1f*(float)growth/6.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.1f*(float)growth/6.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.1f*(float)growth/6.0f, 2.5f*(float)growth/6.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_ONION)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION_PLANT]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f+0.25f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.1f*(float)growth/11.0f, 3.0f*(float)growth/11.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.1f*(float)growth/11.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.1f*(float)growth/11.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.1f*(float)growth/11.0f, 3.0f*(float)growth/11.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_ORE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE_RESOURCE_1+style]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 3.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 3.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_BROKEN_ORE)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE_EMPTY]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.5f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.5f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.5f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.5f, 1.0f, 0.0f);
		
		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.0f, 2.0f, 0.1f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.0f, 0.1f, 0.1f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.0f, 0.1f, 0.1f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.0f, 2.0f, 0.1f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_EMPTY_ORE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE_EMPTY]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.5f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.5f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.5f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.5f, 1.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_BERRY_BUSH)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BERRY_BUSH]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 3.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 3.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_EMPTY_BERRY_BUSH)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMPTY_BERRY_BUSH]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 3.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 3.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_APPLE_TREE)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, -0.5f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_APPLE_TREE_1]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-3.0f, 10.0f, 0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-3.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(3.0f, 10.0f, 0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_APPLE_TREE_2]);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-3.2f, 10.0f, -0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-3.2f, 0.0f, -0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.8f, 0.0f, -0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.8f, 10.0f, -0.5f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_EMPTY_APPLE_TREE)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, -0.5f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMPTY_APPLE_TREE_1]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-3.0f, 10.0f, 0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-3.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(3.0f, 10.0f, 0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMPTY_APPLE_TREE_2]);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-3.2f, 10.0f, -0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-3.2f, 0.0f, -0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.8f, 0.0f, -0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.8f, 10.0f, -0.5f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_MUSHROOM_BED)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MUSHROOM_BED]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 3.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 3.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_EMPTY_MUSHROOM_BED)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MUSHROOM_BED]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glScalef(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 3.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 3.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_CRYSTAL)
	{

	}
	else if (type == TILE_TYPE_EXPOSED_CRYSTAL)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CRYSTAL_ROCK_1+style]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 3.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 3.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_BROKEN_CRYSTAL)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMPTY_CRYSTAL]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.0f, 0.1f, -1.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.0f, 0.1f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.0f, 0.1f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.0f, 0.1f, -1.5f);
		
		glEnd();

		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CRYSTAL]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.0f, 1.5f, 0.1f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.0f, 0.1f, 0.1f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.0f, 0.1f, 0.1f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.0f, 1.5f, 0.1f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_EMPTY_CRYSTAL)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 0.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EMPTY_CRYSTAL]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.0f, 0.1f, -1.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.0f, 0.1f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.0f, 0.1f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.0f, 0.1f, -1.5f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_EXCHANGER)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(exchanger_point, exchanger_indice, 10);

		glColor3f(1,1,1);

		glTranslatef(0.0f, 0.0f, 1.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, 0.0f, 3.1f);

		glRotatef(30.0f * (float)growth / 100.0f, 1.0f, 0.0f, 0.0f);

		if (growth > 1) growth -= 1 * compute_cycles_total;

		if (growth < 1) growth = 1;

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXCHANGER]);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.4f, 2.9f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.4f, 0.1f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.4f, 0.1f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.4f, 2.9f, 0.0f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_CHARGING_STATION)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(charging_station_point, charging_station_indice, 28);

		glColor3f(1,1,1);

		glTranslatef(0.0f, 8.5f, 0.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		growth += 1 * compute_cycles_total;
		
		if (growth > 101) growth -= 100;

		glRotatef(360.0f * (float)(growth-1) / 100.0f, 0.0f, 0.0f, 1.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CHARGING]);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 1.4f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 1.4f, 0.0f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_WATER_GENERATOR)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(water_generator_point, water_generator_indice, 10);

		glColor3f(1,1,1);

		glTranslatef(0.0f, 4.0f, 0.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
		
		glBegin(GL_QUADS);
		
		glColor3f(0.25f, 0.25f, 1.0f);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-0.75f, 3.0f * (float)growth / 100.0f, 0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-0.75f, 0.0f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.75f, 0.0f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.75f, 3.0f * (float)growth / 100.0f, 0.5f);

		glColor3f(0.25f, 0.25f, 1.0f);
		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-0.8f, 3.0f * (float)growth / 100.0f, -0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-0.8f, 3.0f * (float)growth / 100.0f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.8f, 3.0f * (float)growth / 100.0f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.8f, 3.0f * (float)growth / 100.0f, -0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);
		
		glBegin(GL_QUADS);

		glColor3f(0.5f, 0.5f, 0.5f);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-0.8f, 3.0f, 0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-0.8f, 0.0f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(-0.75f, 0.0f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(-0.75f, 3.0f, 0.5f);

		glColor3f(0.5f, 0.5f, 0.5f);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.75f, 3.0f, 0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.75f, 0.0f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.8f, 0.0f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.8f, 3.0f, 0.5f);

		glColor3f(0.5f, 0.5f, 0.5f);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-0.8f, 3.2f, 0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-0.8f, 3.0f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.8f, 3.0f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.8f, 3.2f, 0.5f);

		glColor3f(0.5f, 0.5f, 0.5f);
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-0.8f, 3.2f, -0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-0.8f, 0.0f, -0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(-0.8f, 0.0f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(-0.8f, 3.2f, 0.5f);

		glColor3f(0.5f, 0.5f, 0.5f);
		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.8f, 3.2f, 0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.8f, 0.0f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.8f, 0.0f, -0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.8f, 3.2f, -0.5f);

		glColor3f(0.5f, 0.5f, 0.5f);
		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-0.8f, 3.2f, -0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-0.8f, 3.2f, 0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.8f, 3.2f, 0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.8f, 3.2f, -0.5f);
/*
		glColor3f(0.5f, 0.5f, 0.5f);
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-0.8f, 3.2f, -0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-0.8f, 0.0f, -0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.8f, 0.0f, -0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.8f, 3.2f, -0.5f);
*/
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_EMPTY_ROVER_STATION)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(rover_station_point, rover_station_indice, 30);

		glColor3f(1,1,1);

		growth += 1 * compute_cycles_total;
		
		if (growth > 101) growth -= 100;

		glTranslatef(-1.35f, 2.5f, -1.35f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glRotatef(360.0f * (float)(growth-1) / 100.0f, 0.0f, 0.0f, 1.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CHARGING]);

		glScalef(0.25f, 0.25f, 0.25f);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 1.4f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 1.4f, 0.0f);
		
		glEnd();

		glPopMatrix();

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(1,1,1);

		glTranslatef(1.35f, 2.5f, 1.35f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glRotatef(360.0f * (float)(growth-1) / 100.0f, 0.0f, 0.0f, 1.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CHARGING]);

		glScalef(0.25f, 0.25f, 0.25f);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 1.4f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 1.4f, 0.0f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_FULL_ROVER_STATION)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(rover_station_point, rover_station_indice, 30);

		glColor3f(1,1,1);

		growth += 1 * compute_cycles_total;
		
		if (growth > 101) growth -= 100;

		glTranslatef(-1.35f, 2.5f, -1.35f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glRotatef(360.0f * (float)(growth-1) / 100.0f, 0.0f, 0.0f, 1.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CHARGING]);

		glScalef(0.25f, 0.25f, 0.25f);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 1.4f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 1.4f, 0.0f);
		
		glEnd();

		glPopMatrix();

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(1,1,1);

		glTranslatef(1.35f, 2.5f, 1.35f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glRotatef(360.0f * (float)(growth-1) / 100.0f, 0.0f, 0.0f, 1.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CHARGING]);

		glScalef(0.25f, 0.25f, 0.25f);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 1.4f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 1.4f, 0.0f);
		
		glEnd();

		glPopMatrix();

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 1.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(1,1,1);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE]);

		glScalef(0.75f, 0.75f, 0.75f);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 1.4f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, -1.4f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 1.4f, 0.0f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_ROVER_DEPOSIT)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(rover_deposit_point, rover_deposit_indice, 12);
					
		glTranslatef(0.0f, 0.0f, 0.35f);

		glColor3f(1,1,1);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CRYSTAL]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.0f, 1.4f, 0.1f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.0f, 0.0f, 0.1f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.0f, 0.0f, 0.1f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.0f, 1.4f, 0.1f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_EMPTY_ROVER_DEPOSIT)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(rover_deposit_point, rover_deposit_indice, 12);

		glPopMatrix();
	}
	else if (type == TILE_TYPE_DYNAMO_CHARGER)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(dynamo_charger_point, dynamo_charger_indice, 28);

		glColor3f(1,1,1);

		glTranslatef(0.0f, 5.5f, 0.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		if (growth > 1)
		{
			style += growth / 2;

			if (style > 100) style -= 100;
		}
	
		glRotatef(360.0f * (float)(style-1) / 100.0f, 0.0f, 0.0f, 1.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CHARGING]);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-0.65f, 0.7f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-0.65f, -0.7f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.65f, -0.7f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.65f, 0.7f, 0.0f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_NANOTUBE_DISTRIBUTOR)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(exchanger_point, exchanger_indice, 10);

		glTranslatef(0.0f, 0.0f, 1.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, 0.0f, 3.1f);

		glRotatef(30.0f * (float)growth / 100.0f, 1.0f, 0.0f, 0.0f);

		if (growth > 1) growth -= 1 * compute_cycles_total;

		if (growth < 1) growth = 1;

		glColor3f(0.5f, 0.5f, 0.5f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 2.9f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, 0.1f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, 0.1f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 2.9f, 0.0f);
		
		glEnd();

		glColor3f(1,1,1);

		glScalef(0.75f, 0.75f, 0.75f);

		glTranslatef(0.0f, 0.5f, 0.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE]);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 2.9f, 0.1f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, 0.1f, 0.1f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, 0.1f, 0.1f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 2.9f, 0.1f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_FISHERY)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		//DrawComponent(fishery_point, fishery_indice, 8);

		growth = 1;
/*
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(0.25f, 0.25f, 1.0f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(-1.4f, 2.9f, -1.4f);
		glTexCoord2f(0,0);
		glVertex3f(-1.4f, 2.9f, 1.4f);
		glTexCoord2f(1,0);
		glVertex3f(1.4f, 2.9f, 1.4f);
		glTexCoord2f(1,1);
		glVertex3f(1.4f, 2.9f, -1.4f);

		glEnd();
*/
		glPopMatrix();
	}
	else if (type == TILE_TYPE_FISHERY_WAITING)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		//DrawComponent(fishery_point, fishery_indice, 8);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		growth = 1;

		glTranslatef(0.0f, 2.9f, 0.0f);
		
		glColor3f(1,0,0);

		DrawComponent(fishing_bobber_point, fishing_bobber_indice, 8);
/*
		glTranslatef(0.0f, -2.9f, 0.0f);

		glColor3f(0.25f, 0.25f, 1.0f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(-1.4f, 2.9f, -1.4f);
		glTexCoord2f(0,0);
		glVertex3f(-1.4f, 2.9f, 1.4f);
		glTexCoord2f(1,0);
		glVertex3f(1.4f, 2.9f, 1.4f);
		glTexCoord2f(1,1);
		glVertex3f(1.4f, 2.9f, -1.4f);

		glEnd();
*/
		glPopMatrix();
	}
	else if (type == TILE_TYPE_FISHERY_HOOKED)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		//DrawComponent(fishery_point, fishery_indice, 8);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		growth += 10 * compute_cycles_total;
		
		if (growth > 101) growth -= 100;

		glTranslatef(0.0f, 2.9f + 0.3f * sin((float)growth / 100.0f * 6.28f), 0.0f);
		
		glColor3f(1,0,0);

		DrawComponent(fishing_bobber_point, fishing_bobber_indice, 8);
/*
		glTranslatef(0.0f, -2.9f - 0.3f * sin((float)growth / 100.0f * 6.28f), 0.0f);

		glColor3f(0.25f, 0.25f, 1.0f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(-1.4f, 2.9f, -1.4f);
		glTexCoord2f(0,0);
		glVertex3f(-1.4f, 2.9f, 1.4f);
		glTexCoord2f(1,0);
		glVertex3f(1.4f, 2.9f, 1.4f);
		glTexCoord2f(1,1);
		glVertex3f(1.4f, 2.9f, -1.4f);

		glEnd();
*/
		glPopMatrix();
	}
	else if (type == TILE_TYPE_FISHERY_CAUGHT)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		//DrawComponent(fishery_point, fishery_indice, 8);

		growth = 1;

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(-1.4f, 3.0f, -1.4f);
		glTexCoord2f(0,0);
		glVertex3f(-1.4f, 3.0f, 1.4f);
		glTexCoord2f(1,0);
		glVertex3f(1.4f, 3.0f, 1.4f);
		glTexCoord2f(1,1);
		glVertex3f(1.4f, 3.0f, -1.4f);

		glEnd();

		glTranslatef(0.15f, 3.0f, 0.15f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glColor3f(1,1,1);

		glScalef(0.75f, 0.75f, 0.75f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_FISH]);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.3f, 1.9f, 0.1f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.3f, 0.0f, 0.1f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.3f, 0.0f, 0.1f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.3f, 1.9f, 0.1f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_EXTRACTOR)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(extractor_point, extractor_indice, 48);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glTranslatef(0.0f, -1.0f + 1.0f * (float)(growth-1) / 5.0f, 0.0f);

		glScalef(1.25f - 0.25f * (float)(growth-1) / 5.0f, 1.0f, 1.25f - 0.25f * (float)(growth-1) / 5.0f);

		glColor3f(0.75f, 0.75f, 0.25f);

		DrawComponent(extractor_top_point, extractor_top_indice, 6);

		glPopMatrix();
	}
	else if (type == TILE_TYPE_EXTRACTOR_FULL)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(extractor_point, extractor_indice, 48);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(extractor_top_point, extractor_top_indice, 6);

		glPopMatrix();
	}
	else if (type == TILE_TYPE_EXTRACTOR_READY)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		growth += 5 * compute_cycles_total;
		
		if (growth > 101) growth -= 100;

		glScalef(1.0f - 0.05f * sin((float)growth / 100.0f * 6.28f), 1.0f + 0.05f * sin((float)growth / 100.0f * 6.28f), 1.0f - 0.05f * sin((float)growth / 100.0f * 6.28f));

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(extractor_point, extractor_indice, 48);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(extractor_top_point, extractor_top_indice, 6);

		glPopMatrix();
	}
	else if (type == TILE_TYPE_ARCADE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(1,1,1);

		DrawComponent(arcade_point, arcade_indice, 8);

		growth += 1 * compute_cycles_total;

		if (growth > 101) growth -= 100;

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		if (growth < 33)
		{
			glColor3f((float)growth / 33.0f / 2.0f, 0.01f, 0.01f);
		}
		else if (growth < 66)
		{
			glColor3f(0.01f, (float)(growth-33) / 33.0f / 2.0f, 0.01f);
		}
		else
		{
			glColor3f(0.01f, 0.01f, (float)(growth-66) / 33.0f / 2.0f);
		}

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(-1.6f, 3.55f, -1.6f);
		glTexCoord2f(0,0);
		glVertex3f(-1.6f, 3.55f, 1.6f);
		glTexCoord2f(1,0);
		glVertex3f(1.6f, 3.55f, 1.6f);
		glTexCoord2f(1,1);
		glVertex3f(1.6f, 3.55f, -1.6f);

		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_WALL)
	{
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_WALL_1+style%5]);

		glColor3f(1.0f, 0.75f, 0.75f);

		glBegin(GL_QUADS);

		for (float d=-1.5f; d<=1.5f; d+=0.3f)
		{
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.5f + 0.2f * sin(d / 1.5f * 6.28f * 2.0f + (float)(x+y)), 1.0f + 4.0f * cos(d / 1.5f * 3.14159f / 2.0f), d);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.5f + 0.2f * sin(d / 1.5f * 6.28f * 2.0f + (float)(x+y)), 0.0f, d);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.5f + 0.2f * sin(d / 1.5f * 6.28f * 2.0f + (float)(x+y)), 0.0f, d);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.5f + 0.2f * sin(d / 1.5f * 6.28f * 2.0f + (float)(x+y)), 1.0f + 4.0f * cos(d / 1.5f * 3.14159f / 2.0f), d);
		}

		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_BOUNDED)
	{

	}
	else if (type == TILE_TYPE_OPEN_DOOR)
	{
		if (style == 2)
		{
			glPushMatrix();
					
			glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 1.0f);
	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);
	
			glColor3f(1.0f, 0.5f, 0.5f);
	
			glBegin(GL_QUADS);
	
			glNormal3f(0.0f, 1.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.5f, 0.1f, -3.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.5f, 0.1f, 1.5f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.5f, 0.1f, 1.5f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.5f, 0.1f, -3.0f);
		
			glEnd();
	
			glPopMatrix();
		}
	}
	else if (type == TILE_TYPE_CLOSED_DOOR)
	{
		if (style == 0)
		{
			
		}
		else if (style == 1)
		{
			glPushMatrix();
					
			glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 1.0f);
			
			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
			//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);
	
			glColor3f(0.75f, 0.75f, 0.75f);
	
			glBegin(GL_QUADS);
	
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.5f, 8.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.5f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.5f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.5f, 8.0f, 0.0f);
		
			glEnd();
	
			glPopMatrix();
		}
		else if (style == 2)
		{
			glPushMatrix();
					
			glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f + 1.0f);
	
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);
	
			glColor3f(1.0f, 0.5f, 0.5f);
	
			glBegin(GL_QUADS);
	
			glNormal3f(0.0f, 1.0f, 0.0f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.5f, 0.1f, -3.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.5f, 0.1f, 1.5f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.5f, 0.1f, 1.5f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.5f, 0.1f, -3.0f);
		
			glEnd();
	
			glPopMatrix();
		}
	}
	else if (type == TILE_TYPE_PATH)
	{
	
	}
	else if (type == TILE_TYPE_OBELISK)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.85f, 1.0f, 1.0f);

		DrawComponent(obelisk_point, obelisk_indice, 12);

		glPopMatrix();
	}
	else if (type == TILE_TYPE_CONTAINER)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(container_point, container_indice, 12);

		if (growth == TOOL_TYPE_HOE+1)
		{
			glTranslatef(0.0f, 3.0f, 0.0f);

			glColor3f(0.75f, 0.75f, 0.75f);
		
			glRotatef(90.0f, 1, 0, 0);
			glRotatef(-90.0f, 0, 0, 1);

			DrawComponent(hoe_point, hoe_indice, 18);
		}
		else if (growth == TOOL_TYPE_HAMMER+1)
		{
			glTranslatef(0.0f, 3.0f, 0.0f);

			glColor3f(0.75f, 0.75f, 0.75f);
		
			glRotatef(90.0f, 1, 0, 0);
			glRotatef(-90.0f, 0, 0, 1);

			DrawComponent(hammer_point, hammer_indice, 26);
		}
		else if (growth == TOOL_TYPE_SCYTHE+1)
		{
			glTranslatef(0.0f, 3.0f, 0.0f);

			glColor3f(0.75f, 0.75f, 0.75f);
		
			glRotatef(90.0f, 1, 0, 0);
			glRotatef(-90.0f, 0, 0, 1);

			DrawComponent(scythe_point, scythe_indice, 30);
		}
		else if (growth == TOOL_TYPE_WATERING_CAN+1)
		{
			glTranslatef(0.0f, 4.0f, 0.0f);

			glColor3f(0.75f, 0.75f, 0.75f);
		
			glRotatef(90.0f, 1, 0, 0);
			glRotatef(-90.0f, 0, 0, 1);

			DrawComponent(watering_can_point, watering_can_indice, 22);
		}	
		else if (growth == TOOL_TYPE_ADAMANTINE_HOE+1)
		{
			glTranslatef(0.0f, 3.0f, 0.0f);

			glColor3f(0.0f, 0.75f, 0.75f);
		
			glRotatef(90.0f, 1, 0, 0);
			glRotatef(-90.0f, 0, 0, 1);

			DrawComponent(hoe_point, hoe_indice, 18);
		}
		else if (growth == TOOL_TYPE_ADAMANTINE_HAMMER+1)
		{
			glTranslatef(0.0f, 3.0f, 0.0f);

			glColor3f(0.0f, 0.75f, 0.75f);
		
			glRotatef(90.0f, 1, 0, 0);
			glRotatef(-90.0f, 0, 0, 1);

			DrawComponent(hammer_point, hammer_indice, 26);
		}
		else if (growth == TOOL_TYPE_ADAMANTINE_SCYTHE+1)
		{
			glTranslatef(0.0f, 3.0f, 0.0f);

			glColor3f(0.0f, 0.75f, 0.75f);
		
			glRotatef(90.0f, 1, 0, 0);
			glRotatef(-90.0f, 0, 0, 1);

			DrawComponent(scythe_point, scythe_indice, 30);
		}
		else if (growth == TOOL_TYPE_ADAMANTINE_WATERING_CAN+1)
		{
			glTranslatef(0.0f, 4.0f, 0.0f);

			glColor3f(0.0f, 0.75f, 0.75f);
		
			glRotatef(90.0f, 1, 0, 0);
			glRotatef(-90.0f, 0, 0, 1);

			DrawComponent(watering_can_point, watering_can_indice, 22);
		}
		else if (growth != TOOL_TYPE_NONE+1)
		{
			if (growth == TOOL_TYPE_RADISH+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH]);
			else if (growth == TOOL_TYPE_CABBAGE+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE]);
			else if (growth == TOOL_TYPE_CUCUMBER+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER]);
			else if (growth == TOOL_TYPE_BEANS+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS]);
			else if (growth == TOOL_TYPE_MELON+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON]);
			else if (growth == TOOL_TYPE_TURNIP+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP]);
			else if (growth == TOOL_TYPE_ONION+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION]);
			else if (growth == TOOL_TYPE_RYE+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE]);
			else if (growth == TOOL_TYPE_NANOTUBE+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE]);
			else if (growth == TOOL_TYPE_ORE+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ORE]);
			else if (growth == TOOL_TYPE_BERRY+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BERRY]);
			else if (growth == TOOL_TYPE_APPLE+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_APPLE]);
			else if (growth == TOOL_TYPE_MUSHROOM+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MUSHROOM]);
			else if (growth == TOOL_TYPE_CRYSTAL+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CRYSTAL]);
			else if (growth == TOOL_TYPE_RADISH_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RADISH_SEED]);
			else if (growth == TOOL_TYPE_CABBAGE_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CABBAGE_SEED]);
			else if (growth == TOOL_TYPE_CUCUMBER_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CUCUMBER_SEED]);
			else if (growth == TOOL_TYPE_BEANS_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BEANS_SEED]);
			else if (growth == TOOL_TYPE_MELON_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MELON_SEED]);
			else if (growth == TOOL_TYPE_TURNIP_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_TURNIP_SEED]);
			else if (growth == TOOL_TYPE_ONION_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ONION_SEED]);
			else if (growth == TOOL_TYPE_RYE_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_RYE_SEED]);
			else if (growth == TOOL_TYPE_NANOTUBE_SEED+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_NANOTUBE_SEED]);
			else if (growth == TOOL_TYPE_FISH+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_FISH]);
			else if (growth == TOOL_TYPE_EXTRACT+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXTRACT]);
			else if (growth == TOOL_TYPE_GIFT_BASKET+1) glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BASKET_HERB]);
			else glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);
	
			glTranslatef(0.0f, 3.0f, 0.35f);

			glColor3f(1,1,1);
		
			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
			glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

			glBegin(GL_QUADS);
			
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.0f, 2.0f, 0.1f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.0f, 0.0f, 0.1f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.0f, 0.0f, 0.1f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.0f, 2.0f, 0.1f);
		
			glEnd();
		}
	
		glPopMatrix();
	}
	else if (type == TILE_TYPE_BLOCKING_SIGN)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLOCKING_SIGN]);
	
		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f + 0.2f, 0.0f, ((float)(y)+0.5f)*3.0f + 1.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);
			
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-2.0f, 4.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(2.0f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(2.0f, 4.0f, 0.0f);
		
		glEnd();
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_PORTABLE_EXCHANGER)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glScalef(0.75f, 0.75f, 0.75f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(exchanger_point, exchanger_indice, 10);

		glColor3f(1,1,1);

		glTranslatef(0.0f, 0.0f, 1.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, 0.0f, 3.1f);

		glRotatef(30.0f * (float)growth / 100.0f, 1.0f, 0.0f, 0.0f);

		if (growth > 1) growth -= 1 * compute_cycles_total;

		if (growth < 1) growth = 1;

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_EXCHANGER]);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.4f, 2.9f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.4f, 0.1f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.4f, 0.1f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.4f, 2.9f, 0.0f);
		
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_MINI_SPEED_CHALLENGE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(mini_challenge_point, mini_challenge_indice, 20);

		glColor3f(1,1,1);

		glTranslatef(0.0f, 3.0f+7.0f*(float)growth/50.0f, 0.0f);

		glColor3f(1,0,0);

		glScalef(0.2f, 0.2f, 0.2f);
		
		DrawComponent(exchanger_point, exchanger_indice, 10);
	
		glScalef(5.0f, 5.0f, 5.0f);

		glTranslatef(0.0f, -3.0f-7.0f*(float)growth/50.0f, 0.0f);
		glTranslatef(0.0f, 10.0f, 0.0f);

		glColor3f(1,0,0);

		glScalef(0.2f, 0.2f, 0.2f);
		
		DrawComponent(exchanger_point, exchanger_indice, 10);
	
		glScalef(5.0f, 5.0f, 5.0f);
		
		glPopMatrix();
	}
	else if (type == TILE_TYPE_MINI_TIMING_CHALLENGE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(mini_challenge_point, mini_challenge_indice, 20);

		glColor3f(1,1,1);

		if (growth < 50 && growth > 1) growth -= 1 * compute_cycles_total;

		if (growth < 1) growth = 1;

		glTranslatef(0.0f, 3.0f+7.0f*(float)growth/50.0f, 0.0f);
		
		glColor3f(0,1,0);

		glScalef(0.2f, 0.2f, 0.2f);
		
		DrawComponent(exchanger_point, exchanger_indice, 10);
	
		glScalef(5.0f, 5.0f, 5.0f);

		glTranslatef(0.0f, -3.0f-7.0f*(float)growth/50.0f, 0.0f);
		glTranslatef(0.0f, 6.5f, 0.0f);

		glColor3f(0,1,0);

		glScalef(0.2f, 0.2f, 0.2f);
		
		DrawComponent(exchanger_point, exchanger_indice, 10);
	
		glScalef(5.0f, 5.0f, 5.0f);

		glPopMatrix();
	}
	else if (type == TILE_TYPE_MATCHING_CHALLENGE)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glScalef(0.75f, 0.75f, 0.75f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(exchanger_point, exchanger_indice, 10);

		glColor3f(1,1,1);

		if (growth > 1)
		{
			if (growth < 99)
			{
				growth += 2;

				if (growth > 99) growth = 99;
			}

			glTranslatef(0.0f, 1.5f + 1.5f * (float)growth / 100.0f, 0.0f);
		
			glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
			glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
			glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MATCHING_1+style]);

			glBegin(GL_QUADS);
		
			glNormal3f(0.0f, 0.707f, 0.707f);
			glTexCoord2f(0.0f, 1.0f);
			glVertex3f(-1.0f, 2.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex3f(-1.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 0.0f);
			glVertex3f(1.0f, 0.0f, 0.0f);
			glTexCoord2f(1.0f, 1.0f);
			glVertex3f(1.0f, 2.0f, 0.0f);
			
			glEnd();
		}

		glPopMatrix();
	}
	else if (type == TILE_TYPE_POTTED_HERB)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glScalef(0.75f, 0.75f, 0.75f);

		glColor3f(1.0f, 0.75f, 0.5f);

		DrawComponent(exchanger_point, exchanger_indice, 10);

		glColor3f(1,1,1);

		if (style < 7) glTranslatef(0.0f, 2.5f, 1.0f);
		else if (style == 7) glTranslatef(0.0f, 2.25f, 1.25f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLUE_HERB+style]);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.5f, 6.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.5f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.5f, 0.0f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.5f, 6.0f, 0.0f);
			
		glEnd();

		glPopMatrix();
	}
	else if (type == TILE_TYPE_DONATION_BOX)
	{
		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glPushMatrix();
					
		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);

		glColor3f(0.5f, 0.5f, 0.5f);

		DrawComponent(exchanger_point, exchanger_indice, 10);

		glColor3f(1,1,1);

		glTranslatef(0.0f, 0.0f, 1.5f);
		
		glRotatef(camera_rot->z * 180.0f / 3.14159f, 0, 0, 1);
		glRotatef(camera_rot->y * 180.0f / 3.14159f, 0, 1, 0);
		//glRotatef(camera_rot->x * 180.0f / 3.14159f, 1, 0, 0);

		glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);

		glTranslatef(0.0f, 0.0f, 3.1f);

		glRotatef(30.0f * (float)growth / 100.0f, 1.0f, 0.0f, 0.0f);

		if (growth > 1) growth -= 1 * compute_cycles_total;

		if (growth < 1) growth = 1;

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_DONATION]);
		
		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(-1.4f, 2.9f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(-1.4f, 0.1f, 0.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(1.4f, 0.1f, 0.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(1.4f, 2.9f, 0.0f);
		
		glEnd();

		glPopMatrix();
	}

	return;
};

void DrawShadow(float x, float y, int type, int growth, int style, int hour, int minute)
{
	if (growth != 0 &&
		type != TILE_TYPE_CLOSED_DOOR &&
		type != TILE_TYPE_OPEN_DOOR &&
		type != TILE_TYPE_PATH)
	{
		glPushMatrix();		

		glTranslatef(((float)(x)+0.5f)*3.0f, 0.0f, ((float)(y)+0.5f)*3.0f);
	
		if (type == TILE_TYPE_NONE ||
			type == TILE_TYPE_DIRT ||
			type == TILE_TYPE_TILLED ||
			type == TILE_TYPE_ROCK ||
			type == TILE_TYPE_WEED ||
			type == TILE_TYPE_ORE ||
			type == TILE_TYPE_BROKEN_ORE ||
			type == TILE_TYPE_EMPTY_ORE ||
			type == TILE_TYPE_BERRY_BUSH ||
			type == TILE_TYPE_EMPTY_BERRY_BUSH ||
			type == TILE_TYPE_APPLE_TREE ||
			type == TILE_TYPE_EMPTY_APPLE_TREE ||
			type == TILE_TYPE_CRYSTAL ||
			type == TILE_TYPE_EXPOSED_CRYSTAL ||
			type == TILE_TYPE_BROKEN_CRYSTAL ||
			type == TILE_TYPE_EMPTY_CRYSTAL)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ROUND_SHADOW]);

			glColor3f(0.01f, 0.01f, 0.01f);

			glBegin(GL_QUADS);

			if (hour < 12) glNormal3f(0.0f, 1.0f, 0.0f);
			else glNormal3f(0.0f, -1.0f, 0.0f);
			glTexCoord2f(0,1);
			glVertex3f(-3.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -2.5f);
			glTexCoord2f(0,0);
			glVertex3f(-3.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 0.5f);
			glTexCoord2f(1,0);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 1.0f);
			glTexCoord2f(1,1);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -2.0f);
	
			glEnd();
		}
		else if (type == TILE_TYPE_RADISH ||
			type == TILE_TYPE_CABBAGE ||
			type == TILE_TYPE_CUCUMBER ||
			type == TILE_TYPE_BEANS ||
			type == TILE_TYPE_MELON ||
			type == TILE_TYPE_TURNIP ||
			type == TILE_TYPE_ONION ||
			type == TILE_TYPE_RYE ||
			type == TILE_TYPE_CUT_RYE ||
			type == TILE_TYPE_NANOTUBE ||
			type == TILE_TYPE_MUSHROOM_BED ||
			type == TILE_TYPE_EMPTY_MUSHROOM_BED)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ROUND_SHADOW]);

			glColor3f(0.01f, 0.01f, 0.01f);

			glBegin(GL_QUADS);

			if (hour < 12) glNormal3f(0.0f, 1.0f, 0.0f);
			else glNormal3f(0.0f, -1.0f, 0.0f);
			glTexCoord2f(0,1);
			glVertex3f(-1.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -1.0f);
			glTexCoord2f(0,0);
			glVertex3f(-1.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 0.5f);
			glTexCoord2f(1,0);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 0.5f);
			glTexCoord2f(1,1);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -1.0f);
	
			glEnd();
		}
		else if (type == TILE_TYPE_BOUNDED && style != 2)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_SQUARE_SHADOW]);
	
			glColor3f(0.01f, 0.01f, 0.01f);

			glBegin(GL_QUADS);

			if (hour < 12) glNormal3f(0.0f, 1.0f, 0.0f);
			else glNormal3f(0.0f, -1.0f, 0.0f);
			glTexCoord2f(0,1);
			glVertex3f(-12.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -2.5f);
			glTexCoord2f(0,0);
			glVertex3f(-12.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 0.5f);
			glTexCoord2f(1,0);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 1.0f);
			glTexCoord2f(1,1);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -2.0f);
	
			glEnd();
		}
		else if (type == TILE_TYPE_OBELISK)
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_SQUARE_SHADOW]);
	
			glColor3f(0.01f, 0.01f, 0.01f);

			glBegin(GL_QUADS);

			if (hour < 12) glNormal3f(0.0f, 1.0f, 0.0f);
			else glNormal3f(0.0f, -1.0f, 0.0f);
			glTexCoord2f(0,1);
			glVertex3f(-12.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -2.5f);
			glTexCoord2f(0,0);
			glVertex3f(-12.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 0.5f);
			glTexCoord2f(1,0);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 1.5f);
			glTexCoord2f(1,1);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -1.5f);
	
			glEnd();
		}
		else
		{
			glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_SQUARE_SHADOW]);
	
			glColor3f(0.01f, 0.01f, 0.01f);

			glBegin(GL_QUADS);

			if (hour < 12) glNormal3f(0.0f, 1.0f, 0.0f);
			else glNormal3f(0.0f, -1.0f, 0.0f);
			glTexCoord2f(0,1);
			glVertex3f(-6.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -2.0f);
			glTexCoord2f(0,0);
			glVertex3f(-6.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 1.0f);
			glTexCoord2f(1,0);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, 1.25f);
			glTexCoord2f(1,1);
			glVertex3f(0.0f * (6.0f - (float)(hour-6) - (float)minute / 60.0f) / 6.0f, 0.01f, -1.75f);
	
			glEnd();
		}
	
		glPopMatrix();
	}
		

	return;
};

void DrawFieldStructures(int f)
{
	if (f == 0) // farming field
	{
		glTranslatef(23.0f*3.0f, 0.0f, 22.0f*3.0f-0.5f); // bottom-left corner

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_HOUSE_SIGN]);
		
		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 4.9f, 0.5f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, -0.1f, 0.5f);
		glTexCoord2f(1,0);
		glVertex3f(11.0f, -0.1f, 0.5f);
		glTexCoord2f(1,1);
		glVertex3f(11.0f, 4.9f, 0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,1);
		glVertex3f(3.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1f, 1.0f);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0.1f, 0.8f);
		glVertex3f(3.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 0.8f);
		glVertex3f(6.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 1.0f);
		glVertex3f(6.0f, 10.0f, 0.0f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.2f,1);
		glVertex3f(6.0f, 10.0f, 0.0f);
		glTexCoord2f(0.2f,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, 0.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, -30.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.0f, 10.0f, 0.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, -30.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(3.0f, 0.0f, -3.0f);
		glTexCoord2f(1,1);
		glVertex3f(3.0f, 10.0f, -3.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 10.0f, -3.0f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, 0.0f, -3.0f);
		glTexCoord2f(1,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(6.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 10.0f, -3.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 10.0f, -3.0f);

		glEnd();

		glColor3f(0.75f, 0.75f, 0.75f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 8.0f, -3.0f+0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 8.0f, -3.0f+0.5f);

		glEnd();

		glTranslatef(-23.0f*3.0f, 0.0f, -22.0f*3.0f+0.5f); // bottom-left corner


		glTranslatef(35.0f*3.0f, 0.0f, 22.0f*3.0f-0.5f); // bottom-left corner

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_ROVERS_SIGN]);
		
		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 4.9f, 0.5f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, -0.1f, 0.5f);
		glTexCoord2f(1,0);
		glVertex3f(11.0f, -0.1f, 0.5f);
		glTexCoord2f(1,1);
		glVertex3f(11.0f, 4.9f, 0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,1);
		glVertex3f(3.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1f, 1.0f);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0.1f, 0.8f);
		glVertex3f(3.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 0.8f);
		glVertex3f(6.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 1.0f);
		glVertex3f(6.0f, 10.0f, 0.0f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.2f,1);
		glVertex3f(6.0f, 10.0f, 0.0f);
		glTexCoord2f(0.2f,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, 0.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, -30.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.0f, 10.0f, 0.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, -30.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(3.0f, 0.0f, -3.0f);
		glTexCoord2f(1,1);
		glVertex3f(3.0f, 10.0f, -3.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 10.0f, -3.0f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, 0.0f, -3.0f);
		glTexCoord2f(1,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(6.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 10.0f, -3.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 10.0f, -3.0f);

		glEnd();

		glColor3f(0.75f, 0.75f, 0.75f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 8.0f, -3.0f+0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 8.0f, -3.0f+0.5f);

		glEnd();

		glTranslatef(-35.0f*3.0f, 0.0f, -22.0f*3.0f+0.5f); // bottom-left corner
	}
	else if (f == 1)
	{
		glTranslatef(19.0f*3.0f, 0.0f, 30.0f*3.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 5.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, 1.5f);
		glTexCoord2f(0.0556f,0);
		glVertex3f(3.0f, 0.0f, 1.5f);
		glTexCoord2f(0.0556f,1);
		glVertex3f(3.0f, 5.0f, 1.5f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1667f,1);
		glVertex3f(6.0f, 5.0f, 1.5f);
		glTexCoord2f(0.1667f,0);
		glVertex3f(6.0f, 0.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 5.0f, 1.5f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -28.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -28.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -28.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -28.5f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -28.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -28.5f);
		glTexCoord2f(1,0);
		glVertex3f(1.5f, 0.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(1.5f, 10.0f, 1.5f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(28.5f, 10.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(28.5f, 0.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -28.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -28.5f);

		glEnd();

		glTranslatef(-19.0f*3.0f, 0.0f, -30.0f*3.0f);
	}
	else if (f == 2)
	{
		glTranslatef(19.0f*3.0f, 0.0f, 30.0f*3.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 5.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, 1.5f);
		glTexCoord2f(0.0556f,0);
		glVertex3f(3.0f, 0.0f, 1.5f);
		glTexCoord2f(0.0556f,1);
		glVertex3f(3.0f, 5.0f, 1.5f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1667f,1);
		glVertex3f(6.0f, 5.0f, 1.5f);
		glTexCoord2f(0.1667f,0);
		glVertex3f(6.0f, 0.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 5.0f, 1.5f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -28.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -28.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -28.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -28.5f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -28.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -28.5f);
		glTexCoord2f(1,0);
		glVertex3f(1.5f, 0.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(1.5f, 10.0f, 1.5f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(28.5f, 10.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(28.5f, 0.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -28.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -28.5f);

		glEnd();

		glTranslatef(-19.0f*3.0f, 0.0f, -30.0f*3.0f);
	}
	else if (f == 3)
	{

	}
	else if (f == 4)
	{
		glTranslatef(0.0f, 0.0f, 31.0f*3.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BIG_WALL]);

		glColor3f(1.0f, 0.85f, 0.85f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 20.0f, -20.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, -10.0f, 10.0f);
		glTexCoord2f(4,0);
		glVertex3f(60.0f*3.0f, -10.0f, 10.0f);
		glTexCoord2f(4,1);
		glVertex3f(60.0f*3.0f, 20.0f, -20.0f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(0.01f, 0.01f, 0.01f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0,1);
		glVertex3f(21.0f*3.0f, 8.0f, -7.9f);
		glTexCoord2f(0,0);
		glVertex3f(21.0f*3.0f, 0.0f, 0.1f);
		glTexCoord2f(1,0);
		glVertex3f(23.0f*3.0f, 0.0f, 0.1f);
		glTexCoord2f(1,1);
		glVertex3f(23.0f*3.0f, 8.0f, -7.9f);

		glEnd();

		glTranslatef(0.0f, 0.0f, -31.0f*3.0f);
	}
	else if (f == 5)
	{
		glTranslatef(19.0f*3.0f, 0.0f, 50.0f*3.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BIG_WALL]);

		glColor3f(1.0f, 0.85f, 0.85f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 5.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, -5.0f, 1.5f);
		glTexCoord2f(0.1667f,0);
		glVertex3f(6.0f, -5.0f, 1.5f);
		glTexCoord2f(0.1667f,1);
		glVertex3f(6.0f, 5.0f, 1.5f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.3889f,1);
		glVertex3f(12.0f, 5.0f, 1.5f);
		glTexCoord2f(0.3889f,0);
		glVertex3f(12.0f, -5.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, -5.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 5.0f, 1.5f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 15.0f, -88.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, -5.0f, -88.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, -5.0f, -88.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 15.0f, -88.5f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 15.0f, -88.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, -5.0f, -88.5f);
		glTexCoord2f(1,0);
		glVertex3f(1.5f, -5.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(1.5f, 15.0f, 1.5f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(28.5f, 15.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(28.5f, -5.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, -5.0f, -88.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 15.0f, -88.5f);

		glEnd();

		glTranslatef(-19.0f*3.0f, 0.0f, -50.0f*3.0f);
	}
	else if (f == 6)
	{
		glTranslatef(65.0f*3.0f, 0.0f, 25.0f*3.0f-0.5f); // bottom-left corner

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_PLANT_SIGN]);
		
		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 4.9f, 0.5f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, -0.1f, 0.5f);
		glTexCoord2f(1,0);
		glVertex3f(11.0f, -0.1f, 0.5f);
		glTexCoord2f(1,1);
		glVertex3f(11.0f, 4.9f, 0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,1);
		glVertex3f(3.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1f, 1.0f);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0.1f, 0.8f);
		glVertex3f(3.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 0.8f);
		glVertex3f(6.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 1.0f);
		glVertex3f(6.0f, 10.0f, 0.0f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.2f,1);
		glVertex3f(6.0f, 10.0f, 0.0f);
		glTexCoord2f(0.2f,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, 0.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, -30.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.0f, 10.0f, 0.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, -30.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(3.0f, 0.0f, -3.0f);
		glTexCoord2f(1,1);
		glVertex3f(3.0f, 10.0f, -3.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 10.0f, -3.0f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, 0.0f, -3.0f);
		glTexCoord2f(1,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(6.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 10.0f, -3.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 10.0f, -3.0f);

		glEnd();

		glColor3f(0.75f, 0.75f, 0.75f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 8.0f, -3.0f+0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 8.0f, -3.0f+0.5f);

		glEnd();

		glTranslatef(-65.0f*3.0f, 0.0f, -25.0f*3.0f+0.5f); // bottom-left corner


		glTranslatef(70.0f*3.0f, 0.0f, 46.0f*3.0f-0.5f); // bottom-left corner

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_MECHANICS_SIGN]);
		
		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 4.9f, 0.5f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, -0.1f, 0.5f);
		glTexCoord2f(1,0);
		glVertex3f(11.0f, -0.1f, 0.5f);
		glTexCoord2f(1,1);
		glVertex3f(11.0f, 4.9f, 0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,1);
		glVertex3f(3.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1f, 1.0f);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0.1f, 0.8f);
		glVertex3f(3.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 0.8f);
		glVertex3f(6.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 1.0f);
		glVertex3f(6.0f, 10.0f, 0.0f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.2f,1);
		glVertex3f(6.0f, 10.0f, 0.0f);
		glTexCoord2f(0.2f,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, 0.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, -30.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.0f, 10.0f, 0.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, -30.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(3.0f, 0.0f, -3.0f);
		glTexCoord2f(1,1);
		glVertex3f(3.0f, 10.0f, -3.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 10.0f, -3.0f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, 0.0f, -3.0f);
		glTexCoord2f(1,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(6.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 10.0f, -3.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 10.0f, -3.0f);

		glEnd();

		glColor3f(0.75f, 0.75f, 0.75f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 8.0f, -3.0f+0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 8.0f, -3.0f+0.5f);

		glEnd();

		glTranslatef(-70.0f*3.0f, 0.0f, -46.0f*3.0f+0.5f); // bottom-left corner


		glTranslatef(50.0f*3.0f, 0.0f, 35.0f*3.0f-0.5f); // bottom-left corner

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_FISH_SIGN]);
		
		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 4.9f, 0.5f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, -0.1f, 0.5f);
		glTexCoord2f(1,0);
		glVertex3f(11.0f, -0.1f, 0.5f);
		glTexCoord2f(1,1);
		glVertex3f(11.0f, 4.9f, 0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(0.1f,1);
		glVertex3f(3.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1f, 1.0f);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0.1f, 0.8f);
		glVertex3f(3.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 0.8f);
		glVertex3f(6.0f, 8.0f, 0.0f);
		glTexCoord2f(0.2f, 1.0f);
		glVertex3f(6.0f, 10.0f, 0.0f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.2f,1);
		glVertex3f(6.0f, 10.0f, 0.0f);
		glTexCoord2f(0.2f,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, 0.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, -30.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.0f, 10.0f, 0.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(30.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(30.0f, 0.0f, -30.0f);
		glTexCoord2f(1,1);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(3.0f, 10.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(3.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(3.0f, 0.0f, -3.0f);
		glTexCoord2f(1,1);
		glVertex3f(3.0f, 10.0f, -3.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.0f, 10.0f, -3.0f);
		glTexCoord2f(0,0);
		glVertex3f(6.0f, 0.0f, -3.0f);
		glTexCoord2f(1,0);
		glVertex3f(6.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(6.0f, 10.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 10.0f, -3.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 10.0f, -3.0f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_LATTICE]);
				
		glColor3f(1,1,1);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,10);
		glVertex3f(0.0f, 10.0f, -30.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 10.0f, 0.0f);
		glTexCoord2f(10,0);
		glVertex3f(30.0f, 10.0f, 0.0f);
		glTexCoord2f(10,10);
		glVertex3f(30.0f, 10.0f, -30.0f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.75f, 0.75f, 0.75f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(3.0f, 8.0f, -3.0f+0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(3.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(6.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(6.0f, 8.0f, -3.0f+0.5f);

		glEnd();

		glTranslatef(-50.0f*3.0f, 0.0f, -35.0f*3.0f+0.5f); // bottom-left corner

		
		glTranslatef(25.0f*3.0f, 0.0f, 40.0f*3.0f-0.5f); // bottom-left corner

		glColor3f(1,1,1);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_CROSS_SIGN]);
		
		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(33.0f, 4.9f, 0.5f);
		glTexCoord2f(0,0);
		glVertex3f(33.0f, -0.1f, 0.5f);
		glTexCoord2f(1,0);
		glVertex3f(38.0f, -0.1f, 0.5f);
		glTexCoord2f(1,1);
		glVertex3f(38.0f, 4.9f, 0.5f);

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 15.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(0.45f,0);
		glVertex3f(27.0f, 0.0f, 0.0f);
		glTexCoord2f(0.45f,1);
		glVertex3f(27.0f, 15.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.45f, 1.0f);
		glVertex3f(27.0f, 15.0f, 0.0f);
		glTexCoord2f(0.45f, 0.533f);
		glVertex3f(27.0f, 8.0f, 0.0f);
		glTexCoord2f(0.55f, 0.533f);
		glVertex3f(33.0f, 8.0f, 0.0f);
		glTexCoord2f(0.55f, 1.0f);
		glVertex3f(33.0f, 15.0f, 0.0f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.55f,1);
		glVertex3f(33.0f, 15.0f, 0.0f);
		glTexCoord2f(0.55f,0);
		glVertex3f(33.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(60.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(60.0f, 15.0f, 0.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 15.0f, -63.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 0.0f, -63.0f);
		glTexCoord2f(1,0);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(0.0f, 15.0f, 0.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(60.0f, 15.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(60.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(60.0f, 0.0f, -63.0f);
		glTexCoord2f(1,1);
		glVertex3f(60.0f, 15.0f, -63.0f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(0.0f, 15.0f, -63.0f);
		glTexCoord2f(0,0);
		glVertex3f(0.0f, 15.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(60.0f, 15.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(60.0f, 15.0f, -63.0f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(27.0f, 15.0f, 0.0f);
		glTexCoord2f(0,0);
		glVertex3f(27.0f, 0.0f, 0.0f);
		glTexCoord2f(1,0);
		glVertex3f(27.0f, 0.0f, -3.0f);
		glTexCoord2f(1,1);
		glVertex3f(27.0f, 15.0f, -3.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(33.0f, 15.0f, -3.0f);
		glTexCoord2f(0,0);
		glVertex3f(33.0f, 0.0f, -3.0f);
		glTexCoord2f(1,0);
		glVertex3f(33.0f, 0.0f, 0.0f);
		glTexCoord2f(1,1);
		glVertex3f(33.0f, 15.0f, 0.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(27.0f, 15.0f, -3.0f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(27.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(33.0f, 8.0f, -3.0f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(33.0f, 15.0f, -3.0f);

		glEnd();

		glColor3f(0.75f, 0.75f, 0.75f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(27.0f, 8.0f, -3.0f+0.5f);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(27.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(33.0f, 0.0f, -3.0f+0.5f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(33.0f, 8.0f, -3.0f+0.5f);

		glEnd();

		glTranslatef(-25.0f*3.0f, 0.0f, -40.0f*3.0f+0.5f); // bottom-left corner
	}
	else if (f == 7)
	{
		glTranslatef(19.0f*3.0f, 0.0f, 30.0f*3.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 5.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, 1.5f);
		glTexCoord2f(0.0556f,0);
		glVertex3f(3.0f, 0.0f, 1.5f);
		glTexCoord2f(0.0556f,1);
		glVertex3f(3.0f, 5.0f, 1.5f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1667f,1);
		glVertex3f(6.0f, 5.0f, 1.5f);
		glTexCoord2f(0.1667f,0);
		glVertex3f(6.0f, 0.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 5.0f, 1.5f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -28.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -28.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -28.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -28.5f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -28.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -28.5f);
		glTexCoord2f(1,0);
		glVertex3f(1.5f, 0.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(1.5f, 10.0f, 1.5f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(28.5f, 10.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(28.5f, 0.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -28.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -28.5f);

		glEnd();

		glTranslatef(-19.0f*3.0f, 0.0f, -30.0f*3.0f);
	}
	else if (f == 8)
	{
		glTranslatef(19.0f*3.0f, 0.0f, 30.0f*3.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 5.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, 1.5f);
		glTexCoord2f(0.0556f,0);
		glVertex3f(3.0f, 0.0f, 1.5f);
		glTexCoord2f(0.0556f,1);
		glVertex3f(3.0f, 5.0f, 1.5f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1667f,1);
		glVertex3f(6.0f, 5.0f, 1.5f);
		glTexCoord2f(0.1667f,0);
		glVertex3f(6.0f, 0.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 5.0f, 1.5f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -28.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -28.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -28.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -28.5f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -28.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -28.5f);
		glTexCoord2f(1,0);
		glVertex3f(1.5f, 0.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(1.5f, 10.0f, 1.5f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(28.5f, 10.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(28.5f, 0.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -28.5f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -28.5f);

		glEnd();

		glTranslatef(-19.0f*3.0f, 0.0f, -30.0f*3.0f);
	}
	else if (f == 9)
	{
		glTranslatef(19.0f*3.0f, 0.0f, 30.0f*3.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 8.0f, 3.0f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, 3.0f);
		glTexCoord2f(0.0556f,0);
		glVertex3f(3.0f, 0.0f, 3.0f);
		glTexCoord2f(0.0556f,1);
		glVertex3f(3.0f, 8.0f, 3.0f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.1667f,1);
		glVertex3f(6.0f, 8.0f, 3.0f);
		glTexCoord2f(0.1667f,0);
		glVertex3f(6.0f, 0.0f, 3.0f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, 3.0f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 8.0f, 3.0f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -27.25f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -27.25f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -27.25f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -27.25f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 10.0f, -27.25f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, 0.0f, -27.25f);
		glTexCoord2f(1,0);
		glVertex3f(1.5f, 0.0f, 3.0f);
		glTexCoord2f(1,1);
		glVertex3f(1.5f, 10.0f, 3.0f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(28.5f, 10.0f, 3.0f);
		glTexCoord2f(0,0);
		glVertex3f(28.5f, 0.0f, 3.0f);
		glTexCoord2f(1,0);
		glVertex3f(28.5f, 0.0f, -27.25f);
		glTexCoord2f(1,1);
		glVertex3f(28.5f, 10.0f, -27.25f);

		// fish stuff
	
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.25f, 3.0f, -23.0f);
		glTexCoord2f(0,0);
		glVertex3f(6.25f, 0.0f, -23.5f);
		glTexCoord2f(1,0);
		glVertex3f(23.75f, 0.0f, -23.5f);
		glTexCoord2f(1,1);
		glVertex3f(23.75f, 3.0f, -23.0f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.25f, 3.0f, -23.25f);
		glTexCoord2f(0,0);
		glVertex3f(6.25f, 3.0f, -23.0f);
		glTexCoord2f(1,0);
		glVertex3f(23.75f, 3.0f, -23.0f);
		glTexCoord2f(1,1);
		glVertex3f(23.75f, 3.0f, -23.25f);

		glNormal3f(0.0f, 0.707f, 0.707f);
		glTexCoord2f(0,1);
		glVertex3f(6.25f, 3.0f, -8.75f);
		glTexCoord2f(0,0);
		glVertex3f(6.25f, 0.0f, -6.25f);
		glTexCoord2f(1,0);
		glVertex3f(23.75f, 0.0f, -6.25f);
		glTexCoord2f(1,1);
		glVertex3f(23.75f, 3.0f, -8.75f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.25f, 3.0f, -9.5f);
		glTexCoord2f(0,0);
		glVertex3f(6.25f, 3.0f, -8.75f);
		glTexCoord2f(1,0);
		glVertex3f(23.75f, 3.0f, -8.75f);
		glTexCoord2f(1,1);
		glVertex3f(23.75f, 3.0f, -9.5f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.25f, 3.0f, -23.25f);
		glTexCoord2f(0,0);
		glVertex3f(6.25f, 0.0f, -23.75f);
		glTexCoord2f(1,0);
		glVertex3f(6.25f, 0.0f, -6.25f);
		glTexCoord2f(1,1);
		glVertex3f(6.25f, 3.0f, -8.5f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.25f, 3.0f, -23.25f);
		glTexCoord2f(0,0);
		glVertex3f(6.25f, 3.0f, -8.75f);
		glTexCoord2f(1,0);
		glVertex3f(6.5f, 3.0f, -8.75f);
		glTexCoord2f(1,1);
		glVertex3f(6.5f, 3.0f, -23.25f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.5f, 3.0f, -23.25f);
		glTexCoord2f(0,0);
		glVertex3f(6.5f, 0.0f, -23.75f);
		glTexCoord2f(1,0);
		glVertex3f(6.5f, 0.0f, -6.25f);
		glTexCoord2f(1,1);
		glVertex3f(6.5f, 3.0f, -8.75f);

		
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(23.5f, 3.0f, -23.25f);
		glTexCoord2f(0,0);
		glVertex3f(23.5f, 0.0f, -23.75f);
		glTexCoord2f(1,0);
		glVertex3f(23.5f, 0.0f, -6.25f);
		glTexCoord2f(1,1);
		glVertex3f(23.5f, 3.0f, -8.75f);

		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(23.5f, 3.0f, -23.25f);
		glTexCoord2f(0,0);
		glVertex3f(23.5f, 3.0f, -8.75f);
		glTexCoord2f(1,0);
		glVertex3f(23.75f, 3.0f, -8.75f);
		glTexCoord2f(1,1);
		glVertex3f(23.75f, 3.0f, -23.25f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(23.75f, 3.0f, -23.25f);
		glTexCoord2f(0,0);
		glVertex3f(23.75f, 0.0f, -23.75f);
		glTexCoord2f(1,0);
		glVertex3f(23.75f, 0.0f, -6.25f);
		glTexCoord2f(1,1);
		glVertex3f(23.75f, 3.0f, -8.75f);
		

		glEnd();

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_BLANK]);

		glColor3f(0.25f, 0.25f, 1.0f);

		glBegin(GL_QUADS);
		
		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(6.35f, 2.9f, -23.15f);
		glTexCoord2f(0,0);
		glVertex3f(6.35f, 2.9f, -9.35f);
		glTexCoord2f(1,0);
		glVertex3f(23.65f, 2.9f, -9.35f);
		glTexCoord2f(1,1);
		glVertex3f(23.65f, 2.9f, -23.15f);
		
		glEnd();

		glTranslatef(-19.0f*3.0f, 0.0f, -30.0f*3.0f);
	}
	else if (f == 10)
	{
		glTranslatef(19.0f*3.0f, 0.0f, 40.0f*3.0f);

		glBindTexture(GL_TEXTURE_2D, texture[TEXTURE_METAL]);

		glColor3f(0.5f, 0.5f, 0.5f);

		glBegin(GL_QUADS);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 5.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, -5.0f, 1.5f);
		glTexCoord2f(0.4167,0);
		glVertex3f(24.0f, -5.0f, 1.5f);
		glTexCoord2f(0.4167f,1);
		glVertex3f(24.0f, 5.0f, 1.5f);

		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0.4722f,1);
		glVertex3f(30.0f, 5.0f, 1.5f);
		glTexCoord2f(0.4722f,0);
		glVertex3f(30.0f, -5.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(55.5f, -5.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(55.5f, 5.0f, 1.5f);
		
		glNormal3f(0.0f, 0.0f, 1.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 15.0f, -58.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, -5.0f, -58.5f);
		glTexCoord2f(1,0);
		glVertex3f(55.5f, -5.0f, -58.5f);
		glTexCoord2f(1,1);
		glVertex3f(55.5f, 15.0f, -58.5f);

		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(1.5f, 15.0f, -58.5f);
		glTexCoord2f(0,0);
		glVertex3f(1.5f, -5.0f, -58.5f);
		glTexCoord2f(1,0);
		glVertex3f(1.5f, -5.0f, 1.5f);
		glTexCoord2f(1,1);
		glVertex3f(1.5f, 15.0f, 1.5f);

		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0,1);
		glVertex3f(55.5f, 15.0f, 1.5f);
		glTexCoord2f(0,0);
		glVertex3f(55.5f, -5.0f, 1.5f);
		glTexCoord2f(1,0);
		glVertex3f(55.5f, -5.0f, -58.5f);
		glTexCoord2f(1,1);
		glVertex3f(55.5f, 15.0f, -58.5f);

		glEnd();

		glTranslatef(27.0f, 0.0f, -56.5f);

		glScalef(1.5f, 1.5f, 1.5f);

		glColor3f(0.70f, 0.65f, 0.25f);
	
		DrawComponent(cross_point, cross_indice, 52);

		glScalef(1.0f / 1.5f, 1.0f / 1.5f, 1.0f / 1.5f);

		glTranslatef(-27.0f, 0.0f, 56.5f);

		glTranslatef(-19.0f*3.0f, 0.0f, -40.0f*3.0f);
	
	}

	return;
};







