Ok, Sowing Sun is a Harvest Moon clone.

Controls can be changed the the ControlsFile.txt.  The game saves with SaveFile.txt.

To make this compile/run on Linux, make sure to have all of the packages required.  Anything that is glut, freeglut, mesa, opengl, and sox.
To make this compile/run on Windows, use Dev-C++ or something with the freeglut Media package.  Make sure that the libraries are attached too!

Be sure in Main.cpp to change the LINUX to WINDOWS, and also to put in 'freeglut' instead of 'glut' for the library, when going to Windows from Linux.

The sounds are run through 'sox' on Linux, and 'PlaySound()' on Windows.  Everything else is universal. 
'sox' is wonderful but it does have an easy on/off switch since it's all through system().
PlaySound is not that great, but it works for most of the sounds. 

Good luck!
