// Functions.h

int I_piece1[4*4] = {
0, 0, 0, 0,
1, 1, 1, 1,
0, 0, 0, 0,
0, 0, 0, 0 };

int I_piece2[4*4] = {
0, 1, 0, 0,
0, 1, 0, 0,
0, 1, 0, 0,
0, 1, 0, 0 };

int I_piece3[4*4] = {
0, 0, 0, 0,
1, 1, 1, 1,
0, 0, 0, 0,
0, 0, 0, 0 };

int I_piece4[4*4] = {
0, 1, 0, 0,
0, 1, 0, 0,
0, 1, 0, 0,
0, 1, 0, 0 };

int O_piece1[4*4] = {
0, 0, 0, 0,
0, 1, 1, 0,
0, 1, 1, 0,
0, 0, 0, 0 };

int O_piece2[4*4] = {
0, 0, 0, 0,
0, 1, 1, 0,
0, 1, 1, 0,
0, 0, 0, 0 };

int O_piece3[4*4] = {
0, 0, 0, 0,
0, 1, 1, 0,
0, 1, 1, 0,
0, 0, 0, 0 };

int O_piece4[4*4] = {
0, 0, 0, 0,
0, 1, 1, 0,
0, 1, 1, 0,
0, 0, 0, 0 };

int T_piece1[4*4] = {
0, 0, 0, 0,
1, 1, 1, 0,
0, 1, 0, 0,
0, 0, 0, 0 };

int T_piece2[4*4] = {
0, 1, 0, 0,
1, 1, 0, 0,
0, 1, 0, 0,
0, 0, 0, 0 };

int T_piece3[4*4] = {
0, 1, 0, 0,
1, 1, 1, 0,
0, 0, 0, 0,
0, 0, 0, 0 };

int T_piece4[4*4] = {
0, 1, 0, 0,
0, 1, 1, 0,
0, 1, 0, 0,
0, 0, 0, 0 };

int J_piece1[4*4] = {
0, 0, 0, 0,
1, 1, 1, 0,
0, 0, 1, 0,
0, 0, 0, 0 };

int J_piece2[4*4] = {
0, 1, 0, 0,
0, 1, 0, 0,
1, 1, 0, 0,
0, 0, 0, 0 };

int J_piece3[4*4] = {
1, 0, 0, 0,
1, 1, 1, 0,
0, 0, 0, 0,
0, 0, 0, 0 };

int J_piece4[4*4] = {
0, 1, 1, 0,
0, 1, 0, 0,
0, 1, 0, 0,
0, 0, 0, 0 };

int L_piece1[4*4] = {
0, 0, 0, 0,
1, 1, 1, 0,
1, 0, 0, 0,
0, 0, 0, 0 };

int L_piece2[4*4] = {
1, 1, 0, 0,
0, 1, 0, 0,
0, 1, 0, 0,
0, 0, 0, 0 };

int L_piece3[4*4] = {
0, 0, 1, 0,
1, 1, 1, 0,
0, 0, 0, 0,
0, 0, 0, 0 };

int L_piece4[4*4] = {
0, 1, 0, 0,
0, 1, 0, 0,
0, 1, 1, 0,
0, 0, 0, 0 };

int S_piece1[4*4] = {
0, 0, 0, 0,
0, 1, 1, 0,
1, 1, 0, 0,
0, 0, 0, 0 };

int S_piece2[4*4] = {
1, 0, 0, 0,
1, 1, 0, 0,
0, 1, 0, 0,
0, 0, 0, 0 };

int S_piece3[4*4] = {
0, 0, 0, 0,
0, 1, 1, 0,
1, 1, 0, 0,
0, 0, 0, 0 };

int S_piece4[4*4] = {
1, 0, 0, 0,
1, 1, 0, 0,
0, 1, 0, 0, 
0, 0, 0, 0 };

int Z_piece1[4*4] = {
0, 0, 0, 0,
1, 1, 0, 0,
0, 1, 1, 0,
0, 0, 0, 0 };

int Z_piece2[4*4] = {
0, 1, 0, 0,
1, 1, 0, 0,
1, 0, 0, 0,
0, 0, 0, 0 };

int Z_piece3[4*4] = {
0, 0, 0, 0,
1, 1, 0, 0,
0, 1, 1, 0,
0, 0, 0, 0 };

int Z_piece4[4*4] = {
0, 1, 0, 0,
1, 1, 0, 0,
1, 0, 0, 0,
0, 0, 0, 0 };


char grid_status[10][16];
int piece_x, piece_y;
char piece_type, piece_rotation, piece_next;
int piece_basket[7];
int game_score, game_lines, game_level;
bool full_line[16];
float game_timer, pause_timer;
bool game_over;
int gravity_counter;

char RandomPiece()
{
	int t = 0;

	for (int i=0; i<7; i++)
	{
		if (piece_basket[i] <= 0)
		{
			for (int j=0; j<7; j++)
			{
				piece_basket[j] += 10;
			}
		}
	}

	for (int i=0; i<7; i++)
	{
		t += piece_basket[i];
	}

	int r = rand() % t;

	t = 0;

	for (int i=0; i<7; i++)
	{
		t += piece_basket[i];

		if (r < t)
		{
			piece_basket[i] -= 1;

			if (i == 0) return 'I';
			else if (i == 1) return 'J';
			else if (i == 2) return 'L';
			else if (i == 3) return 'O';
			else if (i == 4) return 'S';
			else if (i == 5) return 'T';
			else if (i == 6) return 'Z';
		}
	}

	return 0;
};

void EmptyStart()
{
	for (int i=0; i<10; i++)
	{
		for (int j=0; j<16; j++)
		{
			grid_status[i][j] = 0;
		}
	}

	piece_x = 3;
	piece_y = -1;
	piece_rotation = 0;

	for (int i=0; i<7; i++)
	{
		piece_basket[i] = 10;
	}

	piece_type = RandomPiece();
	piece_next = RandomPiece();

	game_score = 0;
	game_lines = 0;
	game_level = 0;

	for (int i=0; i<16; i++)
	{
		full_line[i] = false;
	}

	game_timer = 0.0f;
	
	pause_timer = 0.0f;

	gravity_counter = 3600;

	game_over = false;
	
	return;
};

bool CheckGrid()
{
	int mini_grid[4][4];

	for (int i=0; i<4; i++)
	{
		for (int j=0; j<4; j++)
		{
			if (piece_type == 'I' && piece_rotation == 0)
			{
				mini_grid[i][j] = I_piece1[i+j*4];
			}
			else if (piece_type == 'I' && piece_rotation == 1)
			{
				mini_grid[i][j] = I_piece2[i+j*4];
			}
			else if (piece_type == 'I' && piece_rotation == 2)
			{
				mini_grid[i][j] = I_piece3[i+j*4];
			}
			else if (piece_type == 'I' && piece_rotation == 3)
			{
				mini_grid[i][j] = I_piece4[i+j*4];
			}

			else if (piece_type == 'J' && piece_rotation == 0)
			{
				mini_grid[i][j] = J_piece1[i+j*4];
			}
			else if (piece_type == 'J' && piece_rotation == 1)
			{
				mini_grid[i][j] = J_piece2[i+j*4];
			}
			else if (piece_type == 'J' && piece_rotation == 2)
			{
				mini_grid[i][j] = J_piece3[i+j*4];
			}
			else if (piece_type == 'J' && piece_rotation == 3)
			{
				mini_grid[i][j] = J_piece4[i+j*4];
			}
			
			else if (piece_type == 'L' && piece_rotation == 0)
			{
				mini_grid[i][j] = L_piece1[i+j*4];
			}
			else if (piece_type == 'L' && piece_rotation == 1)
			{
				mini_grid[i][j] = L_piece2[i+j*4];
			}
			else if (piece_type == 'L' && piece_rotation == 2)
			{
				mini_grid[i][j] = L_piece3[i+j*4];
			}
			else if (piece_type == 'L' && piece_rotation == 3)
			{
				mini_grid[i][j] = L_piece4[i+j*4];
			}
				
			else if (piece_type == 'O' && piece_rotation == 0)
			{
				mini_grid[i][j] = O_piece1[i+j*4];
			}
			else if (piece_type == 'O' && piece_rotation == 1)
			{
				mini_grid[i][j] = O_piece2[i+j*4];
			}
			else if (piece_type == 'O' && piece_rotation == 2)
			{
				mini_grid[i][j] = O_piece3[i+j*4];
			}
			else if (piece_type == 'O' && piece_rotation == 3)
			{
				mini_grid[i][j] = O_piece4[i+j*4];
			}

			else if (piece_type == 'S' && piece_rotation == 0)
			{
				mini_grid[i][j] = S_piece1[i+j*4];
			}
			else if (piece_type == 'S' && piece_rotation == 1)
			{
				mini_grid[i][j] = S_piece2[i+j*4];
			}
			else if (piece_type == 'S' && piece_rotation == 2)
			{
				mini_grid[i][j] = S_piece3[i+j*4];
			}
			else if (piece_type == 'S' && piece_rotation == 3)
			{
				mini_grid[i][j] = S_piece4[i+j*4];
			}

			else if (piece_type == 'T' && piece_rotation == 0)
			{
				mini_grid[i][j] = T_piece1[i+j*4];
			}
			else if (piece_type == 'T' && piece_rotation == 1)
			{
				mini_grid[i][j] = T_piece2[i+j*4];
			}
			else if (piece_type == 'T' && piece_rotation == 2)
			{
				mini_grid[i][j] = T_piece3[i+j*4];
			}
			else if (piece_type == 'T' && piece_rotation == 3)
			{
				mini_grid[i][j] = T_piece4[i+j*4];
			}
			
			else if (piece_type == 'Z' && piece_rotation == 0)
			{
				mini_grid[i][j] = Z_piece1[i+j*4];
			}
			else if (piece_type == 'Z' && piece_rotation == 1)
			{
				mini_grid[i][j] = Z_piece2[i+j*4];
			}
			else if (piece_type == 'Z' && piece_rotation == 2)
			{
				mini_grid[i][j] = Z_piece3[i+j*4];
			}
			else if (piece_type == 'Z' && piece_rotation == 3)
			{
				mini_grid[i][j] = Z_piece4[i+j*4];
			}
		
			else return true; // this is an error for sure
		}
	}

	for (int i=0; i<4; i++)
	{
		for (int j=0; j<4; j++)
		{
			if (mini_grid[i][j] == 1)
			{
				if (piece_x + i >= 0 &&
					piece_x + i < 10 &&
					piece_y + j >= 0 &&
					piece_y + j < 16)
				{	
					if (grid_status[piece_x+i][piece_y+j] != 0)
					{
						return true; // overlapping
					}
				}
				else if (piece_x + i >= 0 && piece_x + i < 10 && piece_y + j < 0)
				{
					// do nothing, it's ok
				}
				else return true; // off the edge
			}
		}
	}

	return false;
};

bool DetectLines()
{
	bool test;

	int count = 0;

	for (int j=0; j<16; j++)
	{
		test = true;

		for (int i=0; i<10; i++)
		{
			if (grid_status[i][j] == 0) test = false;
		}

		if (test == true)
		{
			full_line[j] = true;

			count++;
		}
		else full_line[j] = false;
	}

	if (count > 0)
	{
		pause_timer = 1.0f;

		if (count == 4)
		{
			// big sound effect
		}
		else
		{
			// small sound effect 
		}

		game_lines += count;

		if (count == 1) game_score += 40 * (game_level + 1);
		else if (count == 2) game_score += 100 * (game_level + 1);
		else if (count == 3) game_score += 300 * (game_level + 1);
		else if (count == 4) game_score += 1200 * (game_level + 1);
		else return true; // this is an error for sure

		if (count != 4) system("play -q -v 0.99 Disappear.mp3 &");
		else
		{
			system("play -q -v 0.99 Success1.mp3 &");
			system("play -q -v 0.99 Success2.mp3 &");
		}

		return true;
	}

	return false;
};

void DisappearLines()
{
	int count = 0;

	for (int j=15; j>=0; j--)
	{
		if (full_line[j] == true)
		{
			for (int k=j-1; k>=0; k--)
			{
				for (int i=0; i<10; i++)
				{
					grid_status[i][k+1] = grid_status[i][k];
				}

				full_line[k+1] = full_line[k];
			}

			for (int i=0; i<10; i++)
			{
				grid_status[i][0] = 0;
			}
	
			full_line[0] = 0;

			j++;

			count++;
		}
	}

	if (game_lines >= game_level * 10 + 10) 
	{
		game_level++;

		// sound effect here
		system("play -q -v 0.99 LevelUp.mp3 &");
	}

	piece_type = piece_next;
	piece_next = RandomPiece();

	return;
};

bool RotateForward()
{
	piece_rotation++;
	if (piece_rotation == 4) piece_rotation = 0;
	
	if (CheckGrid() == true)
	{
		piece_rotation--;
		if (piece_rotation == -1) piece_rotation = 3;

		return false;
	}

	system("play -q -v 0.99 Rotate.mp3 &");
	
	return true;
};

bool RotateBackward()
{
	piece_rotation--;
	if (piece_rotation == -1) piece_rotation = 3;
	
	if (CheckGrid() == true)
	{
		piece_rotation++;
		if (piece_rotation == 4) piece_rotation = 0;

		return false;
	}
	
	system("play -q -v 0.99 Rotate.mp3 &");

	return true;
};

bool MoveLeft()
{
	piece_x--;
	
	if (CheckGrid() == true)
	{
		piece_x++;
	
		return false;
	}

	return true;
};

bool MoveRight()
{
	piece_x++;

	if (CheckGrid() == true)
	{
		piece_x--;

		return false;
	}

	return true;
};

bool MoveDown() // returns true if it does touch the bottom
{
	piece_y++;
	
	if (CheckGrid() == true)
	{
		piece_y--;
		
		int mini_grid[4][4];

		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if (piece_type == 'I' && piece_rotation == 0)
				{
					mini_grid[i][j] = I_piece1[i+j*4];
				}
				else if (piece_type == 'I' && piece_rotation == 1)
				{
					mini_grid[i][j] = I_piece2[i+j*4];
				}
				else if (piece_type == 'I' && piece_rotation == 2)
				{
					mini_grid[i][j] = I_piece3[i+j*4];
				}
				else if (piece_type == 'I' && piece_rotation == 3)
				{
					mini_grid[i][j] = I_piece4[i+j*4];
				}
	
				else if (piece_type == 'J' && piece_rotation == 0)
				{
					mini_grid[i][j] = J_piece1[i+j*4];
				}
				else if (piece_type == 'J' && piece_rotation == 1)
				{
					mini_grid[i][j] = J_piece2[i+j*4];
				}
				else if (piece_type == 'J' && piece_rotation == 2)
				{
					mini_grid[i][j] = J_piece3[i+j*4];
				}
				else if (piece_type == 'J' && piece_rotation == 3)
				{
					mini_grid[i][j] = J_piece4[i+j*4];
				}
				
				else if (piece_type == 'L' && piece_rotation == 0)
				{
					mini_grid[i][j] = L_piece1[i+j*4];
				}
				else if (piece_type == 'L' && piece_rotation == 1)
				{
					mini_grid[i][j] = L_piece2[i+j*4];
				}
				else if (piece_type == 'L' && piece_rotation == 2)
				{
					mini_grid[i][j] = L_piece3[i+j*4];
				}
				else if (piece_type == 'L' && piece_rotation == 3)
				{
					mini_grid[i][j] = L_piece4[i+j*4];
				}
					
				else if (piece_type == 'O' && piece_rotation == 0)
				{
					mini_grid[i][j] = O_piece1[i+j*4];
				}
				else if (piece_type == 'O' && piece_rotation == 1)
				{
					mini_grid[i][j] = O_piece2[i+j*4];
				}
				else if (piece_type == 'O' && piece_rotation == 2)
				{
					mini_grid[i][j] = O_piece3[i+j*4];
				}
				else if (piece_type == 'O' && piece_rotation == 3)
				{
					mini_grid[i][j] = O_piece4[i+j*4];
				}
	
				else if (piece_type == 'S' && piece_rotation == 0)
				{
					mini_grid[i][j] = S_piece1[i+j*4];
				}
				else if (piece_type == 'S' && piece_rotation == 1)
				{
					mini_grid[i][j] = S_piece2[i+j*4];
				}
				else if (piece_type == 'S' && piece_rotation == 2)
				{
					mini_grid[i][j] = S_piece3[i+j*4];
				}
				else if (piece_type == 'S' && piece_rotation == 3)
				{
					mini_grid[i][j] = S_piece4[i+j*4];
				}
	
				else if (piece_type == 'T' && piece_rotation == 0)
				{
					mini_grid[i][j] = T_piece1[i+j*4];
				}
				else if (piece_type == 'T' && piece_rotation == 1)
				{
					mini_grid[i][j] = T_piece2[i+j*4];
				}
				else if (piece_type == 'T' && piece_rotation == 2)
				{
					mini_grid[i][j] = T_piece3[i+j*4];
				}
				else if (piece_type == 'T' && piece_rotation == 3)
				{
					mini_grid[i][j] = T_piece4[i+j*4];
				}
				
				else if (piece_type == 'Z' && piece_rotation == 0)
				{
					mini_grid[i][j] = Z_piece1[i+j*4];
				}
				else if (piece_type == 'Z' && piece_rotation == 1)
				{
					mini_grid[i][j] = Z_piece2[i+j*4];
				}
				else if (piece_type == 'Z' && piece_rotation == 2)
				{
					mini_grid[i][j] = Z_piece3[i+j*4];
				}
				else if (piece_type == 'Z' && piece_rotation == 3)
				{
					mini_grid[i][j] = Z_piece4[i+j*4];
				}
			
				else return true; // this is an error for sure
			}
		}

		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if (mini_grid[i][j] == 1)
				{
					if (piece_x + i >= 0 &&
						piece_x + i < 10 &&
						piece_y + j >= 0 &&
						piece_y + j < 16)
					{		
						grid_status[piece_x+i][piece_y+j] = piece_type; // make the grid solid
					}
				}
			}
		}

		if (piece_y > 0) game_score += piece_y;

		piece_x = 3;
		piece_y = -1;
		piece_rotation = 0;

		gravity_counter = 3600;

		if (DetectLines() == false)
		{
			piece_type = piece_next;
			piece_next = RandomPiece();

			if (CheckGrid() == true) game_over = true;
		}

		system("play -q -v 0.99 Impact.mp3 &");

		return true;
	}
	
	return false;
};

	















