// Tetra, the Tetris Clone for Math Day 2016

/*
In order to run this on Linux, you must include -lglut and -lGLU when compiling.
g++ -o Main.o Main.cpp -lglut -lGLU -lGL
./Main.o
Also make sure you have all of the glut and/or freeglut packages downloaded, GLU, maybe OpenGL Mesa Dev packages??

In order to run this on Windows, use Dev-C++.  Start a Multimedia Project with glut, not an empty project like normal.
To get that project, you need to go to Tools->Packages and download all glut and/or freeglut packages.
Remember that the Project Options->Linker has to have stuff like -lwinmm -lglut -lglut32 -lopengl32  (Something with GLU) etc....
*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <GL/glut.h>

#include "Functions.h"

#define WINDOW_WIDTH 800
#define WINDOW_HEIGHT 600

bool keyboard[256], special_keyboard[256];
int joystick_button[32];
bool joystick_enabled = false;
GLuint texture[5];
int frames_per_second = 0, frames_per_second_counter = 0, frames_per_second_timer = 0;

int mode = 0;

int left_button = 0, right_button = 0, down_button = 0, forward_button = 0, backward_button = 0;

float effects_timer = 0.0f;

int background_music_timer = 0;

class _Point {
public:
	_Point()
	{
		x = y = z = 0.0f;
	}

	float x, y, z;
	
	void Set(float my_x, float my_y, float my_z)
	{
		x = my_x;
		y = my_y;
		z = my_z;
	
		return;
	}

} *camera_pos, *camera_rot;

class _Mouse {
public:
	_Mouse()
	{
		x = y = 0;
	
		button = 0;
		state = 0;
	}

	int x, y;

	int button, state;

} *mouse;

class _Joystick {
public:
	_Joystick()
	{
		x = y = z = 0;
	}

	int x, y, z;

} *joystick_axis;

// Any picture in the .bmp format, 24 bit, should be good to go now.
bool LoadBitmap(const char *filename, GLuint &tex)
{
	FILE *bitmap;

	unsigned long int width, height;
	
	unsigned char *bits, *final;
	unsigned char header[54], temp;

	bitmap = fopen(filename, "rb");
	if (!bitmap) return false;

	fread(&header, 54, 1, bitmap);

	// If it's not a Bitmap, exit!
	if (256 * header[1] + header[0] != 19778)
	{
		fclose(bitmap);

		return false;
	}

	width = 256 * header[19] + header[18];
	height = 256 * header[23] + header[22];

	// Once the size is found, malloc() that much to 'bits' and read.
	bits = (unsigned char *) malloc(width*height*3);

	fread(bits, width*height*3, 1, bitmap);

	fclose(bitmap);

	// Flip the BGR pixels to RGB.
	for (int i=0; i<width*height*3; i+=3)
	{
		temp = bits[i];
		bits[i] = bits[i+2];
		bits[i+2] = temp;
	}

	final = (unsigned char *) malloc(width*height*4);

	unsigned long int count = 0;

	// Put in Alpha values.
	for (int i=0; i<width*height*3; i+=3)
	{
		final[count] = bits[i];
		count++;
		final[count] = bits[i+1];
		count++;
		final[count] = bits[i+2];
		count++;
		
		if (bits[i] == 0 && bits[i+1] == 0 && bits[i+2] == 0)
		{
			final[count] = 0;
			count++;
		}
		else
		{
			final[count] = 255;
			count++;
		}
	}
	
	// Remember each malloc() needs a free().
	free(bits);

	glGenTextures(1, &tex);
	glBindTexture(GL_TEXTURE_2D, tex);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, final);
	
	// Remember each malloc() needs a free().
	free(final);

	return true;
};

void OpenGLSetupFunction(int width, int height)
{
	glutWarpPointer(WINDOW_WIDTH / 2, WINDOW_HEIGHT / 2);


	for (int i=0; i<256; i++) 
	{
		keyboard[i] = false;
		special_keyboard[i] = false;
	}

	for (int i=0; i<32; i++) joystick_button[i] = 0;
	joystick_axis->x = 0;
	joystick_axis->y = 0;
	joystick_axis->z = 0;

	// If there is a joystick...
	if (glutDeviceGet(GLUT_HAS_JOYSTICK)) 
	{
		printf("Joystick Detected!\n");

		joystick_enabled = true;
	}

	glViewport(0, 0, width, height);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0f, (float)(width)/(float)(height), 0.1f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity(); 
	glEnable(GL_TEXTURE_2D);  
	glShadeModel(GL_SMOOTH);
	glClearColor(0.1f, 0.1f, 0.1f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);					
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	
	glAlphaFunc(GL_GREATER, 0.9f);									
	glEnable(GL_ALPHA_TEST);

	// allows colors to be still lit up      
	glEnable(GL_COLOR_MATERIAL);

	glDisable(GL_LIGHTING);

	LoadBitmap("Blank.bmp", texture[0]);
	LoadBitmap("Transparent.bmp", texture[1]);
	LoadBitmap("Block.bmp", texture[2]);
	LoadBitmap("DarkBlock.bmp", texture[3]);
	
	glLineWidth(3);

	// INITIALIZE HERE!!!



	return;
};

void OpenGLDisplayFunction()
{
	return;
};

void OpenGLIdleFunction()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	frames_per_second_counter++;

	if (frames_per_second_timer != time(0))
	{
		frames_per_second = frames_per_second_counter;
		frames_per_second_counter = 0;
		frames_per_second_timer = time(0);

		if (mode == 0)
		{
			background_music_timer = 0;

			piece_next = rand() % 7;

			if (piece_next == 0) piece_next = 'I';
			else if (piece_next == 1) piece_next = 'J';
			else if (piece_next == 2) piece_next = 'L';
			else if (piece_next == 3) piece_next = 'O';
			else if (piece_next == 4) piece_next = 'S';
			else if (piece_next == 5) piece_next = 'T';
			else if (piece_next == 6) piece_next = 'Z';
		}
		else if (mode == 1) 
		{
			game_timer += 1.0f; // to keep track of the game, add once a second
			
			background_music_timer++;
		}
	}

	effects_timer += 0.1f;
	if (effects_timer >= 6.28f) effects_timer -= 6.28f;
	
	//glDisable(GL_LIGHTING);

	// Blank texture.
	glBindTexture(GL_TEXTURE_2D, texture[0]);

	glColor3f(1,1,1);
	glRasterPos3f(-0.47f, 0.33f, -0.9f);
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'F');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'P');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, 'S');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, '=');
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 10000) - (frames_per_second % 1000)) / 1000 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 1000) - (frames_per_second % 100)) / 100 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)(((frames_per_second % 100) - (frames_per_second % 10)) / 10 + 48));
	glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_10, (char)((frames_per_second % 10) + 48));

	//glEnable(GL_LIGHTING);
/*
	// Mainly for Linux, Windows will automatically receive inputs	
	if (joystick_enabled) 
	{
		FILE *joystick_fd = NULL;

		joystick_fd = fopen("/dev/input/js0", "rt");
		if (joystick_fd >= 0) // This is where Windows will fail
		{
			int bytes = 1;
			char temp;

			// This is specifically for the SNES controller.  
			// 8 bytes per button, some are -1 and +1 (D-pad).
			// The 5th byte is always the value of that button.
			// 104 is the total needed for SNES controller
			for (int i=0; i<104; i++)
			{
				bytes = fscanf(joystick_fd, "%c", &temp);

				if (bytes > 0 && i % 8 == 4)
				{
					joystick_button[(i-4)/8] = (int)temp;
				}
			}

			fclose(joystick_fd);
		}
	}
*/
/*
	float move = 0.175f;

	if (keyboard['w'] || joystick_button[12] == 1) 
	{
		camera_pos->z -= move * cos(camera_rot->y);
		camera_pos->x -= move * sin(camera_rot->y);
	}
	if (keyboard['s'] || joystick_button[12] == -1) 
	{
		camera_pos->z += move * cos(camera_rot->y);
		camera_pos->x += move * sin(camera_rot->y);
	}
	if (keyboard['a'] || joystick_button[11] == 1) 
	{
		camera_pos->z -= move * cos(camera_rot->y + 3.14f / 2.0f);
		camera_pos->x -= move * sin(camera_rot->y + 3.14f / 2.0f);
	}
	if (keyboard['d'] || joystick_button[11] == -1) 
	{
		camera_pos->z -= move * cos(camera_rot->y - 3.14f / 2.0f);
		camera_pos->x -= move * sin(camera_rot->y - 3.14f / 2.0f);
	}
	if (keyboard['q'] || joystick_button[4]) camera_pos->y -= move;
	if (keyboard['e'] || joystick_button[5]) camera_pos->y += move;		

	if (keyboard['i'] || joystick_button[0]) camera_rot->x += move / 5.0f;
	if (keyboard['k'] || joystick_button[2]) camera_rot->x -= move / 5.0f;
	if (keyboard['j'] || joystick_button[3]) camera_rot->y += move / 5.0f;
	if (keyboard['l'] || joystick_button[1]) camera_rot->y -= move / 5.0f;
*/
			
	if (keyboard[27] || joystick_button[9]) exit(1);

	// DRAW HERE!!!

	if (mode == 0)
	{
		// menu stuff

		glBindTexture(GL_TEXTURE_2D, texture[0]);

		glLineWidth(7);		

		glPushMatrix();
		glTranslatef(-0.45f, 0.075f, -0.9f);
		glScalef(0.00115f, 0.00175f, 0.002f);
		glColor3f(0.75f + 0.25f * sin(effects_timer), 0.75f + 0.25f * sin(effects_timer), 0.75f + 0.25f * sin(effects_timer));	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'E');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'R');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
		glPopMatrix();

		glLineWidth(3);

		glPushMatrix();
		glTranslatef(-0.2f, -0.325f, -0.9f);
		glScalef(0.0003f, 0.0003f, 0.0003f);
		glColor3f(0.75f + 0.25f * sin(effects_timer), 0.75f + 0.25f * sin(effects_timer), 0.75f + 0.25f * sin(effects_timer));	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'b');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.075f, 0.285f, -0.9f);
		glScalef(0.0004f, 0.0004f, 0.0004f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((int)(game_timer/600.0f) + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((int)(game_timer/60.0f) % 10) + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((((int)game_timer % 60) / 10) + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((int)game_timer % 10) + 48));
		glPopMatrix();

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.075f, 0.205f, -0.9f);
		glScalef(0.0003f, 0.0004f, 0.0004f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		if (game_score >= 100000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 1000000) - (game_score % 100000)) / 10000 + 48));
		if (game_score >= 10000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 100000) - (game_score % 10000)) / 10000 + 48));
		if (game_score >= 1000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 10000) - (game_score % 1000)) / 1000 + 48));
		if (game_score >= 100) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 1000) - (game_score % 100)) / 100 + 48));
		if (game_score >= 10) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 100) - (game_score % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((game_score % 10) + 48));
		glPopMatrix();

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.075f, 0.125f, -0.9f);
		glScalef(0.0004f, 0.0004f, 0.0004f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		if (game_lines >= 10000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_lines % 100000) - (game_lines % 10000)) / 10000 + 48));
		if (game_lines >= 1000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_lines % 10000) - (game_lines % 1000)) / 1000 + 48));
		if (game_lines >= 100) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_lines % 1000) - (game_lines % 100)) / 100 + 48));
		if (game_lines >= 10) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_lines % 100) - (game_lines % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((game_lines % 10) + 48));
		glPopMatrix();

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.075f, 0.045f, -0.9f);
		glScalef(0.0004f, 0.0004f, 0.0004f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		if (game_level >= 10000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_level % 100000) - (game_level % 10000)) / 10000 + 48));
		if (game_level >= 1000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_level % 10000) - (game_level % 1000)) / 1000 + 48));
		if (game_level >= 100) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_level % 1000) - (game_level % 100)) / 100 + 48));
		if (game_level >= 10) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_level % 100) - (game_level % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((game_level % 10) + 48));
		glPopMatrix();


		if (keyboard['j'] || keyboard['k'] || keyboard['l'] || keyboard['z'] || keyboard['x'])
		{
			if (left_button == 0 && right_button == 0 && down_button == 0 && forward_button == 0 && backward_button == 0)
			{
				if (pause_timer <= 0.0f)
				{
					mode = 1;

					EmptyStart();
				}
			}
		}
		else
		{
			left_button = 0;
			right_button = 0;
			down_button = 0;
			forward_button = 0;
			backward_button = 0;
		}

		pause_timer -= 0.01f;
		if (pause_timer <= 0.0f) pause_timer = 0.0f;

		glTranslatef(-1.0f, 0.95f, -2.5f);
		glScalef(0.1f, 0.1f, 0.1f);

		int mini_grid[4][4];

		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if (piece_next == 'I')
				{
					mini_grid[i][j] = I_piece1[i+j*4];
				}
				else if (piece_next == 'J')
				{
					mini_grid[i][j] = J_piece1[i+j*4];
				}
				else if (piece_next == 'L')
				{
					mini_grid[i][j] = L_piece1[i+j*4];
				}	
				else if (piece_next == 'O')
				{
					mini_grid[i][j] = O_piece1[i+j*4];
				}
				else if (piece_next == 'S')
				{
					mini_grid[i][j] = S_piece1[i+j*4];
				}
				else if (piece_next == 'T')
				{
					mini_grid[i][j] = T_piece1[i+j*4];
				}
				else if (piece_next == 'Z')
				{
					mini_grid[i][j] = Z_piece1[i+j*4];
				}
			}
		}

		if (piece_next == 'I') glColor3f(1.0f, 0.0f, 0.0f);
		else if (piece_next == 'J') glColor3f(1.0f, 0.0f, 1.0f);
		else if (piece_next == 'L') glColor3f(1.0f, 1.0f, 0.0f);
		else if (piece_next == 'O') glColor3f(0.0f, 1.0f, 1.0f);
		else if (piece_next == 'S') glColor3f(0.0f, 0.0f, 1.0f);
		else if (piece_next == 'T') glColor3f(0.75f, 0.75f, 0.75f);
		else if (piece_next == 'Z') glColor3f(0.75f, 1.0f, 0.0f);

		glBindTexture(GL_TEXTURE_2D, texture[2]);

		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if (mini_grid[i][j] == 1)
				{
					glBegin(GL_QUADS);
	
					glTexCoord2f(0,0);
					glVertex3f((float)(2*i+6), -(float)(2*j+9), 0.0f);
					glTexCoord2f(0,1);
					glVertex3f((float)(2*i+6), -(float)(2*(j+1)+9), 0.0f);
					glTexCoord2f(1,1);
					glVertex3f((float)(2*(i+1)+6), -(float)(2*(j+1)+9), 0.0f);
					glTexCoord2f(1,0);
					glVertex3f((float)(2*(i+1)+6), -(float)(2*j+9), 0.0f);
		
					glEnd();
				}
			}
		}

		glScalef(10.0f, 10.0f, 10.0f);
		glTranslatef(1.0f, -0.75f, 2.5f);
	}
	else if (mode == 1)
	{
		// game stuff

		if (game_over == true) 
		{
			mode = 0;

			left_button = 10;
			right_button = 10;
			down_button = 10;
			forward_button = 10;
			backward_button = 10;

			pause_timer = 2.0f;

			system("x=$(ps -e | grep \"play\") ; kill $x ;"); // I know it kills all music/sound, but I think it will be ok...

			system("play -q -v 0.99 GameOver.mp3 &");
		}

		if (background_music_timer == 1)
		{
			system("play -q -v -0.99 RainBackgroundMusic.mp3 &");

			background_music_timer++;
		}

		if (background_music_timer >= 3 * 60 + 22)
		{
			background_music_timer = 0;
		}

		glBindTexture(GL_TEXTURE_2D, texture[0]);

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.175f, -0.175f, -0.9f);
		glScalef(0.0003f, 0.0003f, 0.0003f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'N');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'x');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.075f, 0.285f, -0.9f);
		glScalef(0.0004f, 0.0004f, 0.0004f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'T');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((int)(game_timer/600.0f) + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((int)(game_timer/60.0f) % 10) + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((((int)game_timer % 60) / 10) + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((int)game_timer % 10) + 48));
		glPopMatrix();

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.075f, 0.205f, -0.9f);
		glScalef(0.0003f, 0.0004f, 0.0004f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		if (game_score >= 100000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 1000000) - (game_score % 100000)) / 10000 + 48));
		if (game_score >= 10000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 100000) - (game_score % 10000)) / 10000 + 48));
		if (game_score >= 1000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 10000) - (game_score % 1000)) / 1000 + 48));
		if (game_score >= 100) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 1000) - (game_score % 100)) / 100 + 48));
		if (game_score >= 10) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_score % 100) - (game_score % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((game_score % 10) + 48));
		glPopMatrix();

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.075f, 0.125f, -0.9f);
		glScalef(0.0004f, 0.0004f, 0.0004f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		if (game_lines >= 10000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_lines % 100000) - (game_lines % 10000)) / 10000 + 48));
		if (game_lines >= 1000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_lines % 10000) - (game_lines % 1000)) / 1000 + 48));
		if (game_lines >= 100) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_lines % 1000) - (game_lines % 100)) / 100 + 48));
		if (game_lines >= 10) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_lines % 100) - (game_lines % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((game_lines % 10) + 48));
		glPopMatrix();

		glColor3f(1.0f, 1.0f, 1.0f);
		glPushMatrix();	
		glTranslatef(0.075f, 0.045f, -0.9f);
		glScalef(0.0004f, 0.0004f, 0.0004f);	
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		if (game_level >= 10000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_level % 100000) - (game_level % 10000)) / 10000 + 48));
		if (game_level >= 1000) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_level % 10000) - (game_level % 1000)) / 1000 + 48));
		if (game_level >= 100) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_level % 1000) - (game_level % 100)) / 100 + 48));
		if (game_level >= 10) glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((game_level % 100) - (game_level % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((game_level % 10) + 48));
		glPopMatrix();

		if (pause_timer <= 0.0f)
		{
			if (keyboard['j'])
			{
				if (left_button == 0)
				{
					if (MoveLeft() == true) left_button = 5;
				}
				else left_button--;
			}
			else left_button = 0;
			
			if (keyboard['l'])
			{
				if (right_button == 0)
				{
					if (MoveRight() == true) right_button = 5;
				}
				else right_button--;
			}
			else right_button = 0;

			if (keyboard['k'])
			{
				if (down_button == 0)
				{
					if (MoveDown() == false) 
					{
						down_button = 2;
					}
					else down_button = 20;

					gravity_counter = 3600;
				}
				else down_button--;
			}
			else down_button = 0;

			if (keyboard['z'])
			{
				if (forward_button == 0)
				{
					if (RotateForward() == true) forward_button = 5;
				}
				//else forward_button--;
			}
			else forward_button = 0;

			if (keyboard['x'])
			{
				if (backward_button == 0)
				{
					if (RotateBackward() == true) backward_button = 5;
				}
				//else backward_button--;
			}
			else backward_button = 0;

			gravity_counter -= 30 * (int)log(pow((float)game_level,2.0f)+1.0f) + 60;
		
			if (gravity_counter <= 0)
			{
				MoveDown();

				gravity_counter = 3600;
			}
		}
		else if (pause_timer > 0.0f)
		{
			pause_timer -= 0.01f;

			if (pause_timer <= 0.0f)
			{
				DisappearLines();

				pause_timer = 0.0f;
			}
		}

		glTranslatef(-1.0f, 0.75f, -2.5f);
		glScalef(0.1f, 0.1f, 0.1f);

		glColor3f(0.25f, 0.25f, 0.25f);

		glBegin(GL_QUADS);

		glVertex3f(-1.0f, 1.0f, 0.0f);
		glVertex3f(-1.0f, -17.0f, 0.0f);
		glVertex3f(11.0f, -17.0f, 0.0f);
		glVertex3f(11.0f, 1.0f, 0.0f);

		glEnd();

		glColor3f(0,0,0);

		glBegin(GL_QUADS);

		glVertex3f(0.0f, 2.0f, 0.0f);
		glVertex3f(0.0f, 0.0f, 0.0f);
		glVertex3f(10.0f, 0.0f, 0.0f);
		glVertex3f(10.0f, 2.0f, 0.0f);

		glEnd();



		glBindTexture(GL_TEXTURE_2D, texture[3]);

		for (int i=0; i<10; i++)
		{
			for (int j=0; j<16; j++)
			{
				if (pause_timer > 0.0f && full_line[j] == true)
				{
					glColor3f(0.25f + 0.25f * sin(pause_timer * 8.0f * 3.14149f),
						0.25f + 0.25f * sin(pause_timer * 8.0f * 3.14149f),
						0.25f + 0.25f * sin(pause_timer * 8.0f * 3.14149f));
				}
				else
				{
					if (grid_status[i][j] == 'I') glColor3f(1.0f, 0.0f, 0.0f);
					else if (grid_status[i][j] == 'J') glColor3f(1.0f, 0.0f, 1.0f);
					else if (grid_status[i][j] == 'L') glColor3f(1.0f, 1.0f, 0.0f);
					else if (grid_status[i][j] == 'O') glColor3f(0.0f, 1.0f, 1.0f);
					else if (grid_status[i][j] == 'S') glColor3f(0.0f, 0.0f, 1.0f);
					else if (grid_status[i][j] == 'T') glColor3f(0.75f, 0.75f, 0.75f);
					else if (grid_status[i][j] == 'Z') glColor3f(0.75f, 1.0f, 0.0f);
					else glColor3f(0,0,0);
				}

				glBegin(GL_QUADS);

				glTexCoord2f(0,0);
				glVertex3f((float)i, -(float)j, 0.0f);
				glTexCoord2f(0,1);
				glVertex3f((float)i, -(float)(j+1), 0.0f);
				glTexCoord2f(1,1);
				glVertex3f((float)(i+1), -(float)(j+1), 0.0f);
				glTexCoord2f(1,0);
				glVertex3f((float)(i+1), -(float)j, 0.0f);

				glEnd();
			}
		}

		int mini_grid[4][4];

		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if (piece_type == 'I' && piece_rotation == 0)
				{
					mini_grid[i][j] = I_piece1[i+j*4];
				}
				else if (piece_type == 'I' && piece_rotation == 1)
				{
					mini_grid[i][j] = I_piece2[i+j*4];
				}
				else if (piece_type == 'I' && piece_rotation == 2)
				{
					mini_grid[i][j] = I_piece3[i+j*4];
				}
				else if (piece_type == 'I' && piece_rotation == 3)
				{
					mini_grid[i][j] = I_piece4[i+j*4];
				}
	
				else if (piece_type == 'J' && piece_rotation == 0)
				{
					mini_grid[i][j] = J_piece1[i+j*4];
				}
				else if (piece_type == 'J' && piece_rotation == 1)
				{
					mini_grid[i][j] = J_piece2[i+j*4];
				}
				else if (piece_type == 'J' && piece_rotation == 2)
				{
					mini_grid[i][j] = J_piece3[i+j*4];
				}
				else if (piece_type == 'J' && piece_rotation == 3)
				{
					mini_grid[i][j] = J_piece4[i+j*4];
				}
				
				else if (piece_type == 'L' && piece_rotation == 0)
				{
					mini_grid[i][j] = L_piece1[i+j*4];
				}
				else if (piece_type == 'L' && piece_rotation == 1)
				{
					mini_grid[i][j] = L_piece2[i+j*4];
				}
				else if (piece_type == 'L' && piece_rotation == 2)
				{
					mini_grid[i][j] = L_piece3[i+j*4];
				}
				else if (piece_type == 'L' && piece_rotation == 3)
				{
					mini_grid[i][j] = L_piece4[i+j*4];
				}
					
				else if (piece_type == 'O' && piece_rotation == 0)
				{
					mini_grid[i][j] = O_piece1[i+j*4];
				}
				else if (piece_type == 'O' && piece_rotation == 1)
				{
					mini_grid[i][j] = O_piece2[i+j*4];
				}
				else if (piece_type == 'O' && piece_rotation == 2)
				{
					mini_grid[i][j] = O_piece3[i+j*4];
				}
				else if (piece_type == 'O' && piece_rotation == 3)
				{
					mini_grid[i][j] = O_piece4[i+j*4];
				}
	
				else if (piece_type == 'S' && piece_rotation == 0)
				{
					mini_grid[i][j] = S_piece1[i+j*4];
				}
				else if (piece_type == 'S' && piece_rotation == 1)
				{
					mini_grid[i][j] = S_piece2[i+j*4];
				}
				else if (piece_type == 'S' && piece_rotation == 2)
				{
					mini_grid[i][j] = S_piece3[i+j*4];
				}
				else if (piece_type == 'S' && piece_rotation == 3)
				{
					mini_grid[i][j] = S_piece4[i+j*4];
				}
	
				else if (piece_type == 'T' && piece_rotation == 0)
				{
					mini_grid[i][j] = T_piece1[i+j*4];
				}
				else if (piece_type == 'T' && piece_rotation == 1)
				{
					mini_grid[i][j] = T_piece2[i+j*4];
				}
				else if (piece_type == 'T' && piece_rotation == 2)
				{
					mini_grid[i][j] = T_piece3[i+j*4];
				}
				else if (piece_type == 'T' && piece_rotation == 3)
				{
					mini_grid[i][j] = T_piece4[i+j*4];
				}
				
				else if (piece_type == 'Z' && piece_rotation == 0)
				{
					mini_grid[i][j] = Z_piece1[i+j*4];
				}
				else if (piece_type == 'Z' && piece_rotation == 1)
				{
					mini_grid[i][j] = Z_piece2[i+j*4];
				}
				else if (piece_type == 'Z' && piece_rotation == 2)
				{
					mini_grid[i][j] = Z_piece3[i+j*4];
				}
				else if (piece_type == 'Z' && piece_rotation == 3)
				{
					mini_grid[i][j] = Z_piece4[i+j*4];
				}
			}
		}

		if (piece_type == 'I') glColor3f(1.0f, 0.0f, 0.0f);
		else if (piece_type == 'J') glColor3f(1.0f, 0.0f, 1.0f);
		else if (piece_type == 'L') glColor3f(1.0f, 1.0f, 0.0f);
		else if (piece_type == 'O') glColor3f(0.0f, 1.0f, 1.0f);
		else if (piece_type == 'S') glColor3f(0.0f, 0.0f, 1.0f);
		else if (piece_type == 'T') glColor3f(0.75f, 0.75f, 0.75f);
		else if (piece_type == 'Z') glColor3f(0.75f, 1.0f, 0.0f);

		glBindTexture(GL_TEXTURE_2D, texture[2]);

		if (pause_timer <= 0.0f)
		{
			for (int i=0; i<4; i++)
			{
				for (int j=0; j<4; j++)
				{
					if (mini_grid[i][j] == 1)
					{
						glBegin(GL_QUADS);
	
						glTexCoord2f(0,0);
						glVertex3f((float)(i+piece_x), -(float)(j+piece_y), 0.0f);
						glTexCoord2f(0,1);
						glVertex3f((float)(i+piece_x), -(float)(j+1+piece_y), 0.0f);
						glTexCoord2f(1,1);
						glVertex3f((float)(i+1+piece_x), -(float)(j+1+piece_y), 0.0f);
						glTexCoord2f(1,0);
						glVertex3f((float)(i+1+piece_x), -(float)(j+piece_y), 0.0f);
		
						glEnd();
					}
				}
			}
		}

		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if (piece_next == 'I')
				{
					mini_grid[i][j] = I_piece1[i+j*4];
				}
				else if (piece_next == 'J')
				{
					mini_grid[i][j] = J_piece1[i+j*4];
				}
				else if (piece_next == 'L')
				{
					mini_grid[i][j] = L_piece1[i+j*4];
				}	
				else if (piece_next == 'O')
				{
					mini_grid[i][j] = O_piece1[i+j*4];
				}
				else if (piece_next == 'S')
				{
					mini_grid[i][j] = S_piece1[i+j*4];
				}
				else if (piece_next == 'T')
				{
					mini_grid[i][j] = T_piece1[i+j*4];
				}
				else if (piece_next == 'Z')
				{
					mini_grid[i][j] = Z_piece1[i+j*4];
				}
			}
		}

		if (piece_next == 'I') glColor3f(1.0f, 0.0f, 0.0f);
		else if (piece_next == 'J') glColor3f(1.0f, 0.0f, 1.0f);
		else if (piece_next == 'L') glColor3f(1.0f, 1.0f, 0.0f);
		else if (piece_next == 'O') glColor3f(0.0f, 1.0f, 1.0f);
		else if (piece_next == 'S') glColor3f(0.0f, 0.0f, 1.0f);
		else if (piece_next == 'T') glColor3f(0.75f, 0.75f, 0.75f);
		else if (piece_next == 'Z') glColor3f(0.75f, 1.0f, 0.0f);

		glBindTexture(GL_TEXTURE_2D, texture[2]);

		for (int i=0; i<4; i++)
		{
			for (int j=0; j<4; j++)
			{
				if (mini_grid[i][j] == 1)
				{
					glBegin(GL_QUADS);
	
					glTexCoord2f(0,0);
					glVertex3f((float)(i+15), -(float)(j+12), 0.0f);
					glTexCoord2f(0,1);
					glVertex3f((float)(i+15), -(float)(j+1+12), 0.0f);
					glTexCoord2f(1,1);
					glVertex3f((float)(i+1+15), -(float)(j+1+12), 0.0f);
					glTexCoord2f(1,0);
					glVertex3f((float)(i+1+15), -(float)(j+12), 0.0f);
		
					glEnd();
				}
			}
		}

		glScalef(10.0f, 10.0f, 10.0f);
		glTranslatef(1.0f, -0.75f, 2.5f);	
	}



	glutSwapBuffers();

	return;
};

void OpenGLKeyboardUpFunction(unsigned char key, int x, int y)
{
	keyboard[key] = false;

	return;
};

void OpenGLKeyboardFunction(unsigned char key, int x, int y)
{
	keyboard[key] = true;

	return;
};

void OpenGLSpecialKeyboardFunction(int key, int x, int y)
{
	special_keyboard[key] = true;

	return;
};	

void OpenGLSpecialKeyboardUpFunction(int key, int x, int y)
{
	special_keyboard[key] = false;

	return;
};

void OpenGLMouseFunction(int button, int state, int x, int y)
{
	mouse->button = button;
	mouse->state = state;
	mouse->x = x;
	mouse->y = y;

	return;
};

void OpenGLPassiveMotionFunction(int x, int y)
{
	mouse->x = x;
	mouse->y = y;

	return;
};

// GLUT in Linux does support joystick detection but not input.
// GLUT in Windows supports both
void OpenGLJoystickFunction(unsigned int button, int x, int y, int z)
{
	joystick_axis->x = x;
	joystick_axis->y = y;
	joystick_axis->z = z;

	// Bitwise AND
	joystick_button[0] = button & 0x0001;
	joystick_button[1] = button & 0x0002;
	joystick_button[2] = button & 0x0004;
	joystick_button[3] = button & 0x0008;
	joystick_button[4] = button & 0x0010;
	joystick_button[5] = button & 0x0020;
	joystick_button[6] = button & 0x0040;
	joystick_button[7] = button & 0x0080;
	joystick_button[8] = button & 0x0100;
	joystick_button[9] = button & 0x0200;
	joystick_button[10] = button & 0x0400;
	joystick_button[11] = button & 0x0800;

	return;
};


void my_randomize()
{
	int stime = 0;
	long ltime = 0;
	ltime = time(NULL);
	stime = (unsigned)ltime/2;
	srand(stime);
};

int main(int argc, char **argv)
{
	my_randomize();

	camera_pos = new _Point();
	camera_rot = new _Point();

	mouse = new _Mouse();
	joystick_axis = new _Joystick();

	glutInit(&argc, argv);

	glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);

	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

	glutCreateWindow("Tetra");

	glutDisplayFunc(OpenGLDisplayFunction);
	glutIdleFunc(OpenGLIdleFunction);
	glutKeyboardFunc(OpenGLKeyboardFunction);
	glutKeyboardUpFunc(OpenGLKeyboardUpFunction);
	glutSpecialFunc(OpenGLSpecialKeyboardFunction);
	glutSpecialUpFunc(OpenGLSpecialKeyboardUpFunction);
	glutMouseFunc(OpenGLMouseFunction);
	glutPassiveMotionFunc(OpenGLPassiveMotionFunction);
	glutJoystickFunc(OpenGLJoystickFunction, 50);

	glutFullScreen();
	glutSetCursor(GLUT_CURSOR_NONE);

	OpenGLSetupFunction(WINDOW_WIDTH, WINDOW_HEIGHT);

   	glutMainLoop();


	delete camera_pos;
	delete camera_rot;

	delete mouse;
	delete joystick_axis;

	return 0;
}
