// Zapper.cpp

// This game is for Math Day 2015, to replace that ArcadeRogue game I was going to do.

// This is designed to be 2-player, and will eventually use two XboxControllers.  It should be able to run on the same computer as 'Arena' still.

/*
Some notes for future use:
- Joysticks using /dev/input/js0 are slow, use 'xboxdrv' instead.  For two controllers, use --wid 0 and --wid 1 when setting up two seperate instances of xboxdrv.
	Or -D --next-controller, or even in the config file specifying next-controller = true.  Remember to 'sudo rmmod xpad' beforehand!!!
- V-Sync on Linux is built in with the Nvidia drivers.  If you go to Nvidia Settings, and turn off V-Sync, the FPS will skyrocket.  I recommend keeping it on, so you stay at 60 FPS.
- The last textures I had used were really messing up.  Haven't checked it here 100%.  Be careful, something about a formatting issue?
- There is a way to do dual-screens, PIP really, involving drawing the first scene with all of the normal setup stuff, NO glutSwapBuffer(), glClear(DEPTH_BUFFER) again and redo
	the settings with now glViewport() smaller and gluPerspective() changed.  Draw it all over again.  Finally you glutSwapBuffer() when you are done with both.
- For sounds, I used: system("play -q -v 0.99 Laser.mp3 &");  You need to: sudo apt-get install libsox-fmt-mp3 for this to work.  This is using the 'sox' tools. 

*** Before you get started, make sure you have mono-channel sounds for each game!
sox OriginalSound.mp3 MonoCh1Sound.mp3 remix 1 0
sox OriginalSound.mp3 MonoCh2Sound.mp3 remix 0 1
Then you can play them and have them go to only one speaker at a time!
play MonoCh1Sound.mp3
play MonoCh2Sound.mp3
Easy :)

*** For the Xbox controllers, one of them is the Harmonix Music controller.
To find it's id, you need to use 'lsusb'
Then do something like:
sudo xboxdrv -s --device-by-id "1bad:028e" --type xbox360 -c XboxDrvConfig1.txt
The other one is better:
sudo xboxdrv -s -c XboxDrvConfig2.txt
It already has the --next-controller built into it


*/

/*
This game is intended to run at 60 FPS, this is almost always done through V-Sync, but just incase...

Also, I'm stealing the human models for this particular project.  If you want to change them, no problems.

In order to run this on Linux, you must include -lglut and -lGLU when compiling.
g++ -o Main.o Main.cpp -lglut -lGLU -lGL
./Main.o
Also make sure you have all of the glut and/or freeglut packages downloaded, GLU, maybe OpenGL Mesa Dev packages??

In order to run this on Windows, use Dev-C++ (Code::Blocks also works?).  Start a Multimedia Project with glut, not an empty project like normal.
To get that project, you need to go to Tools->Packages and download all glut and/or freeglut packages.
Remember that the Project Options->Linker has to have stuff like -lwinmm -lglut -lglut32 -lopengl32  (Something with GLU) etc....
*/





#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

#include <GL/freeglut.h>
#include <GL/gl.h>
#include <GL/glu.h>

#define WINDOW_WIDTH 640
#define WINDOW_HEIGHT 480

int mod_key; // for  GLUT_ACTIVE_SHIFT, GLUT_ACTIVE_CTRL, and GLUT_ACTIVE_ALT
bool keyboard[256], special_keyboard[256];
bool joystick_enabled = false;
int joystick_button[32];
GLuint tex[15];
int frames_per_second = 0, frames_per_second_counter = 0, frames_per_second_timer = 0;

int action_button[7]; // specific buttons on or off for movement, shooting, and jumping (not looking!)

class _Point {
public:
	_Point()
	{
		x = y = z = 0.0f;
	}

	float x, y, z;
	
	void Set(float my_x, float my_y, float my_z)
	{
		x = my_x;
		y = my_y;
		z = my_z;
	
		return;
	}
};

_Point *camera_pos, *camera_rot;

class _Mouse {
public:
	_Mouse()
	{
		x = y = 0;
	
		button = 0;
		state = 0;
	}

	int x, y;

	int button, state;

} *mouse;

class _Joystick {
public:
	_Joystick()
	{
		x = y = z = 0;
	}

	int x, y, z;

} *joystick_axis;

const int MAX_BULLETS = 1000;
const int MAX_BARRIERS = 10;
const int MAX_ENEMIES = 50;
const int MAX_POWERUPS = 3;
const int MAX_STARS = 100;

float player1_x, player1_y, player2_x, player2_y;
float player1_delay, player2_delay;
float player1_ammo, player2_ammo;
int player1_lives, player2_lives;
int player1_powerup, player2_powerup;
int player1_score, player2_score;
int player1_invinsible, player2_invinsible;

int bullet_type[MAX_BULLETS], bullet_owner[MAX_BULLETS];
float bullet_pos_x[MAX_BULLETS], bullet_pos_y[MAX_BULLETS];
float bullet_vel_x[MAX_BULLETS], bullet_vel_y[MAX_BULLETS];
float bullet_angle[MAX_BULLETS];

int barrier_type[MAX_BARRIERS];
float barrier_x[MAX_BARRIERS][3], barrier_y[MAX_BARRIERS][3];

int enemy_type[MAX_ENEMIES];
float enemy_x[MAX_ENEMIES], enemy_y[MAX_ENEMIES];
float enemy_timer[MAX_ENEMIES];

int powerup_type[MAX_POWERUPS];
float powerup_x[MAX_POWERUPS], powerup_y[MAX_POWERUPS];
float powerup_color[MAX_POWERUPS];

float star_red[MAX_STARS], star_green[MAX_STARS], star_blue[MAX_STARS];
float star_x[MAX_STARS], star_y[MAX_STARS];

float drag_speed = 0.002f;

int window = 0;
int screen = 0;
float animation_timer = 0.0f;
float animation_x[5], animation_y[5];
int player1_wait = 0, player2_wait = 0;

float total_distance_travelled = 0.0f;
float total_until_cease = 30.0f;
bool boss_initiated = false;


bool TriangleCollision(float px, float py, float tx1, float ty1, float tx2, float ty2, float tx3, float ty3)
{
	// using cross products
	float area_total = fabs((tx2-tx1) * (ty3-ty1) - (tx3-tx1) * (ty2-ty1)) / 2.0f;
	float area12 = fabs((tx1-px) * (ty2-py) - (tx2-px) * (ty1-py)) / 2.0f;
	float area23 = fabs((tx2-px) * (ty3-py) - (tx3-px) * (ty2-py)) / 2.0f;
	float area13 = fabs((tx1-px) * (ty3-py) - (tx3-px) * (ty1-py)) / 2.0f;

/*
	// using Heron's
	float side12 = sqrt(pow(tx1-tx2, 2.0f) + pow(ty1-ty2, 2.0f));
	float side23 = sqrt(pow(tx2-tx3, 2.0f) + pow(ty2-ty3, 2.0f));
	float side13 = sqrt(pow(tx1-tx3, 2.0f) + pow(ty1-ty3, 2.0f));
	float sidep1 = sqrt(pow(px-tx1, 2.0f) + pow(py-ty1, 2.0f));
	float sidep2 = sqrt(pow(px-ty2, 2.0f) + pow(py-ty2, 2.0f));
	float sidep3 = sqrt(pow(px-ty3, 2.0f) + pow(py-ty3, 2.0f));

	float area_total = 0.0f, area12 = 0.0f, area23 = 0.0f, area13 = 0.0f;

	float temp;

	temp = (side12 + side23 + side13) / 2.0f;
	
	area_total = sqrt(temp * (temp - side12) * (temp - side23) * (temp - side13));
	
	temp = (side12 + sidep1 + sidep2) / 2.0f;

	area12 = sqrt(temp * (temp - side12) * (temp - sidep1) * (temp - sidep2));
	
	temp = (side23 + sidep2 + sidep3) / 2.0f;

	area23 = sqrt(temp * (temp - side23) * (temp - sidep2) * (temp - sidep3));

	temp = (side13 + sidep1 + sidep3) / 2.0f;

	area13 = sqrt(temp * (temp - side13) * (temp - sidep1) * (temp - sidep3));
*/

	if (area12 + area23 + area13 <= area_total + 0.001f) return true;

	return false;
};


// Any picture in the .bmp format, 24 bit, should be good to go now.
bool LoadBitmap(const char *filename, GLuint &tex)
{
	FILE *bitmap;

	unsigned long int width, height;
	
	unsigned char *bits, *final;
	unsigned char header[54], temp;

	bitmap = fopen(filename, "rb");
	if (!bitmap) return false;

	fread(&header, 54, 1, bitmap);

	// If it's not a Bitmap, exit!
	if (256 * header[1] + header[0] != 19778)
	{
		fclose(bitmap);

		return false;
	}

	width = 256 * header[19] + header[18];
	height = 256 * header[23] + header[22];

	// Once the size is found, malloc() that much to 'bits' and read.
	bits = (unsigned char *) malloc(width*height*3);

	fread(bits, width*height*3, 1, bitmap);

	fclose(bitmap);

	// Flip the BGR pixels to RGB.
	for (int i=0; i<width*height*3; i+=3)
	{
		temp = bits[i];
		bits[i] = bits[i+2];
		bits[i+2] = temp;
	}

	final = (unsigned char *) malloc(width*height*4);

	unsigned long int count = 0;

	// Put in Alpha values.
	for (int i=0; i<width*height*3; i+=3)
	{
		final[count] = bits[i];
		count++;
		final[count] = bits[i+1];
		count++;
		final[count] = bits[i+2];
		count++;
		
		if (bits[i] == 0 && bits[i+1] == 0 && bits[i+2] == 0)
		{
			final[count] = 0;
			count++;
		}
		else
		{
			final[count] = 255;
			count++;
		}
	}
	
	// Remember each malloc() needs a free().
	free(bits);

	glGenTextures(1, &tex);
	glBindTexture(GL_TEXTURE_2D, tex);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR); 
	
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, final);
	
	// Remember each malloc() needs a free().
	free(final);

	return true;
};

// Translated Center tx,ty,tz
// Rotation Angle rx,ry,rz
// Point ax,ay,az
void RotatePoint(float tx, float ty, float tz,
	float rx, float ry, float rz,
	float &ax, float &ay, float &az)
{
	float nx, ny, nz;

	// First, rotate along x-axis
	ny = ay;
	nz = az;
	ay = (ny - ty) * cos(rx) + (nz - tz) * sin(rx) + ty;
	az = (nz - tz) * cos(rx) - (ny - ty) * sin(rx) + tz;

	// Second, rotate along y-axis
	nx = ax;
	nz = az;
	ax = (nx - tx) * cos(ry) - (nz - tz) * sin(ry) + tx;
	az = (nz - tz) * cos(ry) + (nx - tx) * sin(ry) + tz;

	// Third, rotate along z-axis
	nx = ax;
	ny = ay;
	ax = (nx - tx) * cos(rz) - (ny - ty) * sin(rz) + tx;
	ay = (ny - ty) * cos(rz) + (nx - tx) * sin(rz) + ty;

	return;
};

// All you need to setup.
void SetupAll(int w0, int h0, int w1, int h1)
{
	glViewport(w0, h0, w1, h1);
	//glMatrixMode(GL_PROJECTION);
	//glLoadIdentity();
	//gluPerspective(45.0f, (float)(w1-w0)/(float)(h1-h0), 0.1f, 1000.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity(); 
	//glEnable(GL_TEXTURE_2D);  
	glShadeModel(GL_SMOOTH);
	glClearColor(0.05f, 0.05f, 0.05f, 0.5f);
	glClearDepth(1.0f);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);					
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

	glEnable(GL_NORMALIZE); // now I don't need to make glNormal3f() into unit.
	
	glAlphaFunc(GL_GREATER, 0.9f);									
	glEnable(GL_ALPHA_TEST);

	// lighting    
//	GLfloat ambient[] = { 0.7f, 0.7f, 0.7f, 1.0f };  
//	GLfloat diffuse[] = { 0.7f, 0.7f, 0.7f, 0.7f }; 
//	GLfloat light_pos[] = { 10.0f, 10.0f, 10.0f, 1.0f };
//	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);                          
//	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse); 
//	glLightfv(GL_LIGHT1, GL_POSITION, light_pos);
//	glEnable(GL_LIGHT1);         
//	glEnable(GL_LIGHTING);

	// more stuff for lighting                                  
	glFrontFace(GL_CCW);
	glEnable(GL_NORMALIZE);     
	//glCullFace(GL_FRONT);                   

	// allows colors to be still lit up      
	glEnable(GL_COLOR_MATERIAL);

	// lighting    
	GLfloat ambient[] = { 0.3f, 0.3f, 0.3f, 1.0f };  
	GLfloat diffuse[] = { 0.7f, 0.7f, 0.7f, 0.7f }; 
	GLfloat light_pos[] = { 0.0f, 1.0f, 0.0f, 1.0f };
	glLightfv(GL_LIGHT1, GL_AMBIENT, ambient);                          
	glLightfv(GL_LIGHT1, GL_DIFFUSE, diffuse); 
	glLightfv(GL_LIGHT1, GL_POSITION, light_pos);
	glEnable(GL_LIGHT1);  

	//glLineWidth(4); // how thick all lines (and glutStrokeCharacter()) is

	player1_score = 0;
	player2_score = 0;
	player1_lives = 0;
	player2_lives = 0;

	int t;

	for (int i=0; i<MAX_STARS; i++)
	{
		t = rand() % 4 + 1;

		if (t == 1) { star_red[i] = 1.0f; star_green[i] = 0.0f; star_blue[i] = 0.0f; }
		if (t == 2) { star_red[i] = 1.0f; star_green[i] = 1.0f; star_blue[i] = 0.0f; }
		if (t == 3) { star_red[i] = 0.0f; star_green[i] = 0.0f; star_blue[i] = 1.0f; }
		if (t == 4) { star_red[i] = 1.0f; star_green[i] = 1.0f; star_blue[i] = 1.0f; }

		star_x[i] = -1.0f + 2.0f * (float)(rand() % 10000) / 10000.0f;
		star_y[i] = -1.0f + 2.0f * (float)(rand() % 10000) / 10000.0f;
	} 
	
	return;
};

void MenuLoop()
{
	// Menu loop here

	frames_per_second_counter++;

	if (frames_per_second_timer != time(0))
	{
		frames_per_second = frames_per_second_counter;
		frames_per_second_counter = 0;
		frames_per_second_timer = time(0);

		screen++;

		if (screen >= 100) screen -= 100;
	}

	if (keyboard[27]) exit(1);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	
	if (screen % 20 < 10)
	{
		// so to keep them all looking the same
		animation_timer = 0.0f;

		for (int i=0; i<5; i++)
		{
			animation_x[i] = -0.75f + 0.375f * (float)i;
			animation_y[i] = 0.0f;
		}

		for (int i=0; i<MAX_BULLETS; i++)
		{
			bullet_type[i] = 0;
		}


		glEnable(GL_TEXTURE_2D);
	
		glEnable(GL_LIGHTING);
	
		glEnable(GL_BLEND);
		glEnable(GL_ALPHA_TEST);
		glEnable(GL_DEPTH_TEST);

		for (int i=0; i<MAX_STARS; i++)
		{
			glBegin(GL_POINTS);
	
			glColor3f(star_red[i], star_green[i], star_blue[i]);
	
			glVertex3f(star_x[i], star_y[i], -1.0f);
		
			glEnd();
		}

		player1_x += 0.01f;
		player2_x += 0.01f;

		if (player1_x > 1.25f) 
		{
			player1_x = -1.75f + 0.5f * (float)(rand() % 100) / 100.0f;
			player1_y = 1.0f - 2.0f * (float)(rand() % 100) / 100.0f;
		}
		if (player2_x > 1.25f) 
		{
			player2_x = -1.75f + 0.5f * (float)(rand() % 100) / 100.0f;
			player2_y = 1.0f - 2.0f * (float)(rand() % 100) / 100.0f;
		}
	
		// player1
		glBegin(GL_TRIANGLES);
			
		glColor3f(1.0f,0.0f,0.0f);
			
		glVertex3f(-0.05f + player1_x, 0.03f + player1_y, -1.0f);
		glVertex3f(-0.03f + player1_x, player1_y, -1.0f);
		glVertex3f(player1_x, 0.02f + player1_y, -1.0f);
	
		glVertex3f(-0.05f + player1_x, -0.03f + player1_y, -1.0f);
		glVertex3f(-0.03f + player1_x, player1_y, -1.0f);
		glVertex3f(player1_x, -0.02f + player1_y, -1.0f);
	
		glColor3f(0.5f,0.5f,0.5f);
	
		glVertex3f(-0.04f + player1_x, 0.02f + player1_y, -1.0f);
		glVertex3f(-0.04f + player1_x, -0.02f + player1_y, -1.0f);
		glVertex3f(0.02f + player1_x, player1_y, -1.0f);
	
		glEnd();
	
		// player2
		glBegin(GL_TRIANGLES);
			
		glColor3f(0.0f,1.0f,1.0f);
			
		glVertex3f(-0.05f + player2_x, 0.03f + player2_y, -1.0f);
		glVertex3f(-0.03f + player2_x, player2_y, -1.0f);
		glVertex3f(player2_x, 0.02f + player2_y, -1.0f);
	
		glVertex3f(-0.05f + player2_x, -0.03f + player2_y, -1.0f);
		glVertex3f(-0.03f + player2_x, player2_y, -1.0f);
		glVertex3f(player2_x, -0.02f + player2_y, -1.0f);
	
		glColor3f(0.5f,0.5f,0.5f);
	
		glVertex3f(-0.04f + player2_x, 0.02f + player2_y, -1.0f);
		glVertex3f(-0.04f + player2_x, -0.02f + player2_y, -1.0f);
		glVertex3f(0.02f + player2_x, player2_y, -1.0f);
	
		glEnd();
	
		glDisable(GL_TEXTURE_2D);
		
		glDisable(GL_LIGHTING);
	
		glDisable(GL_BLEND);
		glDisable(GL_ALPHA_TEST);
		glDisable(GL_DEPTH_TEST);
	
		glColor3f(0.5f + 0.5f * (float)(rand() % 100) / 100.0f,
			0.5f + 0.5f * (float)(rand() % 100) / 100.0f,
			0.5f + 0.5f * (float)(rand() % 100) / 100.0f);

		glLineWidth(4);
		
		glPushMatrix();
		glTranslatef(-0.3f, 0.2f, -0.95f);
		glScalef(0.001f, 0.001f, 0.001f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'Z');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '!');
		glPopMatrix();

		glColor3f(1,1,1);
	
		glLineWidth(2);
	
		glPushMatrix();
		glTranslatef(-0.5f, -0.4f, -0.95f);
		glScalef(0.0005f, 0.0005f, 0.0005f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();

		glColor3f(1,1,1);
	
		glLineWidth(2);
	
		glPushMatrix();
		glTranslatef(-0.65f, 0.85f, -0.95f);
		glScalef(0.0005f, 0.0005f, 0.0005f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '1');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_score % 100000) - (player1_score % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_score % 10000) - (player1_score % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_score % 1000) - (player1_score % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_score % 100) - (player1_score % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((player1_score % 10) + 48));
		glPopMatrix();
	
		glPushMatrix();
		glTranslatef(-0.45f, 0.65f, -0.95f);
		glScalef(0.0005f, 0.0005f, 0.0005f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'l');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '2');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'v');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_score % 100000) - (player2_score % 10000)) / 10000 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_score % 10000) - (player2_score % 1000)) / 1000 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_score % 1000) - (player2_score % 100)) / 100 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_score % 100) - (player2_score % 10)) / 10 + 48));
		glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((player2_score % 10) + 48));
		glPopMatrix();
	}
	else if (screen % 20 >= 10)
	{
		glEnable(GL_TEXTURE_2D);
	
		glEnable(GL_LIGHTING);
	
		glEnable(GL_BLEND);
		glEnable(GL_ALPHA_TEST);
		glEnable(GL_DEPTH_TEST);

		// stars
		for (int i=0; i<MAX_STARS; i++)
		{
			glBegin(GL_POINTS);
	
			glColor3f(star_red[i], star_green[i], star_blue[i]);
	
			glVertex3f(star_x[i], star_y[i], -1.0f);
		
			glEnd();
		}


		// circular
		animation_x[0] += 0.001f * (cos(animation_timer * 6.28f) + cos(animation_timer * 3.14f/2.0f));
		animation_y[0] += 0.001f * (sin(animation_timer * 6.28f) + sin(animation_timer * 3.14f/2.0f));

		glBegin(GL_TRIANGLES);

		glColor3f(0.5f,0,0);

		glVertex3f(animation_x[0] + 0.03f, animation_y[0], -1.0f);
		glVertex3f(animation_x[0] + 0.01f, animation_y[0] - 0.02f, -1.0f);
		glVertex3f(animation_x[0] + 0.01f, animation_y[0] + 0.02f, -1.0f);
				
		glVertex3f(animation_x[0] - 0.03f, animation_y[0], -1.0f);
		glVertex3f(animation_x[0] - 0.01f, animation_y[0] - 0.02f, -1.0f);
		glVertex3f(animation_x[0] - 0.01f, animation_y[0] + 0.02f, -1.0f);

		glColor3f(0.5f,0.5f,0.5f);

		glVertex3f(animation_x[0], animation_y[0] + 0.03f, -1.0f);
		glVertex3f(animation_x[0] - 0.02f, animation_y[0] - 0.01f, -1.0f);
		glVertex3f(animation_x[0] + 0.02f, animation_y[0] - 0.01f, -1.0f);

		glEnd();


		// shaker
		animation_x[1] += 0.002f * (((float)(rand() % 200) / 100.0f) - 1.0f);
		animation_y[1] += 0.002f * (((float)(rand() % 200) / 100.0f) - 1.0f);

		glBegin(GL_TRIANGLES);
			
		glColor3f(0,0.5f,0);

		glVertex3f(animation_x[1], animation_y[1], -1.0f);
		glVertex3f(animation_x[1] - 0.02f, animation_y[1] + 0.01f, -1.0f);
		glVertex3f(animation_x[1], animation_y[1] + 0.02f, -1.0f);

		glVertex3f(animation_x[1], animation_y[1], -1.0f);
		glVertex3f(animation_x[1] + 0.02f, animation_y[1] + 0.01f, -1.0f);
		glVertex3f(animation_x[1], animation_y[1] + 0.02f, -1.0f);

		glColor3f(0.5f,0.5f,0.5f);

		glVertex3f(animation_x[1], animation_y[1] + 0.01f, -1.0f);
		glVertex3f(animation_x[1] - 0.02f, animation_y[1] - 0.02f, -1.0f);
		glVertex3f(animation_x[1] + 0.02f, animation_y[1] - 0.02f, -1.0f);

		glEnd();

		
		// oscillator
		animation_y[2] += 0.015f * (sin(2.0f * animation_timer * 6.28f) + cos(animation_timer * 6.28f));

		glBegin(GL_TRIANGLES);
			
		glColor3f(0,0,1.0f);

		glVertex3f(animation_x[2], animation_y[2] + 0.03f, -1.0f);
		glVertex3f(animation_x[2] - 0.02f, animation_y[2] + 0.01f, -1.0f);
		glVertex3f(animation_x[2] + 0.02f, animation_y[2] + 0.01f, -1.0f);
				
		glVertex3f(animation_x[2], animation_y[2] - 0.03f, -1.0f);
		glVertex3f(animation_x[2] - 0.02f, animation_y[2] - 0.01f, -1.0f);
		glVertex3f(animation_x[2] + 0.02f, animation_y[2] - 0.01f, -1.0f);

		glColor3f(0.5f,0.5f,0.5f);

		glVertex3f(animation_x[2], animation_y[2] + 0.02f, -1.0f);
		glVertex3f(animation_x[2] - 0.01f, animation_y[2] - 0.01f, -1.0f);
		glVertex3f(animation_x[2] + 0.01f, animation_y[2] - 0.01f, -1.0f);

		glEnd();


		// speeder
		//animation_x[3] -= 0.01f;
		animation_y[3] = 0.02f * sin(2.0f * (float)animation_timer * 6.28f);		

		glBegin(GL_TRIANGLES);

		glColor3f(0.0f,0.5f,0.5f);

		glVertex3f(animation_x[3] + 0.03f, animation_y[3] + 0.01f, -1.0f);
		glVertex3f(animation_x[3] - 0.02f, animation_y[3], -1.0f);
		glVertex3f(animation_x[3] - 0.02f, animation_y[3] + 0.02f, -1.0f);
				
		glVertex3f(animation_x[3] + 0.03f, animation_y[3] - 0.01f, -1.0f);
		glVertex3f(animation_x[3] - 0.02f, animation_y[3], -1.0f);
		glVertex3f(animation_x[3] - 0.02f, animation_y[3] - 0.02f, -1.0f);

		glColor3f(0.5f,0.5f,0.5f);

		glVertex3f(animation_x[3] - 0.03f, animation_y[3], -1.0f);
		glVertex3f(animation_x[3] + 0.01f, animation_y[3] - 0.01f, -1.0f);
		glVertex3f(animation_x[3] + 0.01f, animation_y[3] + 0.01f, -1.0f);

		glEnd();


		// shooter
		glBegin(GL_TRIANGLES);

		glColor3f(0.5f,0.5f,0.5f);

		glVertex3f(animation_x[4], animation_y[4] - 0.01f, -1.0f);
		glVertex3f(animation_x[4] + 0.02f, animation_y[4] + 0.02f, -1.0f);
		glVertex3f(animation_x[4] - 0.02f, animation_y[4] + 0.02f, -1.0f);

		glVertex3f(animation_x[4], animation_y[4] + 0.01f, -1.0f);
		glVertex3f(animation_x[4] + 0.02f, animation_y[4] - 0.02f, -1.0f);
		glVertex3f(animation_x[4] - 0.02f, animation_y[4] - 0.02f, -1.0f);

		glColor3f(0.5f,0.0f,0.5f);

		glVertex3f(animation_x[4], animation_y[4] + 0.01f, -1.0f);
		glVertex3f(animation_x[4] + 0.01f, animation_y[4] - 0.01f, -1.0f);
		glVertex3f(animation_x[4] - 0.01f, animation_y[4] - 0.01f, -1.0f);

		glEnd();

		if (animation_timer <= 0.0f)
		{
			for (int j=0; j<MAX_BULLETS; j++)
			{
				if (bullet_type[j] == 0)
				{
					bullet_type[j] = 1; // enemy type

					bullet_owner[j] = 0;
		
					bullet_pos_x[j] = animation_x[4];
					bullet_pos_y[j] = animation_y[4];
			
					bullet_vel_x[j] = -0.00025f;
					bullet_vel_y[j] = 0.00025f;
			
					j = MAX_BULLETS + 1;
				}
			}

			for (int j=0; j<MAX_BULLETS; j++)
			{
				if (bullet_type[j] == 0)
				{
					bullet_type[j] = 1; // enemy type

					bullet_owner[j] = 0;
		
					bullet_pos_x[j] = animation_x[4];
					bullet_pos_y[j] = animation_y[4];
			
					bullet_vel_x[j] = -0.00025f;
					bullet_vel_y[j] = -0.00025f;
			
					j = MAX_BULLETS + 1;
				}
			}

			for (int j=0; j<MAX_BULLETS; j++)
			{
				if (bullet_type[j] == 0)
				{
					bullet_type[j] = 1; // enemy type

					bullet_owner[j] = 0;
		
					bullet_pos_x[j] = animation_x[4];
					bullet_pos_y[j] = animation_y[4];
			
					bullet_vel_x[j] = 0.00025f;
					bullet_vel_y[j] = -0.00025f;
			
					j = MAX_BULLETS + 1;
				}
			}
					
			for (int j=0; j<MAX_BULLETS; j++)
			{
				if (bullet_type[j] == 0)
				{
					bullet_type[j] = 1; // enemy type

					bullet_owner[j] = 0;
		
					bullet_pos_x[j] = animation_x[4];
					bullet_pos_y[j] = animation_y[4];
			
					bullet_vel_x[j] = 0.00025f;
					bullet_vel_y[j] = 0.00025f;
			
					j = MAX_BULLETS + 1;
				}
			}
		}

		// bullets
		for (int i=0; i<MAX_BULLETS; i++)
		{
			if (bullet_type[i] > 0)
			{
				if (bullet_type[i] == 1) glColor3f(1.0f,1.0f,0); // enemy bullet
				else if (bullet_type[i] == 2) glColor3f(1.0f,1.0f,1.0f); // regular bullet
				else if (bullet_type[i] == 3) glColor3f(1.0f,0.0f,0.0f); // spready bullet
				else if (bullet_type[i] == 4) glColor3f(0.0f,1.0f,1.0f); // speedy bullet
				
				glBegin(GL_TRIANGLES);
			
				glVertex3f(bullet_pos_x[i], bullet_pos_y[i], -1.0f);
				glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]), 
					bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]), -1.0f);
				glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+3.14f/6.0f), 
					bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+3.14f/6.0f), -1.0f);
	
				glVertex3f(bullet_pos_x[i], bullet_pos_y[i], -1.0f);
				glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+2.0f*3.14f/3.0f), 
					bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+2.0f*3.14f/3.0f), -1.0f);
				glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+2.0f*3.14f/3.0f+3.14f/6.0f), 
					bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+2.0f*3.14f/3.0f+3.14f/6.0f), -1.0f);
	
				glVertex3f(bullet_pos_x[i], bullet_pos_y[i], -1.0f);
				glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+4.0f*3.14f/3.0f), 
					bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+4.0f*3.14f/3.0f), -1.0f);
				glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+4.0f*3.14f/3.0f+3.14f/6.0f), 
					bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+4.0f*3.14f/3.0f+3.14f/6.0f), -1.0f);
		
				glEnd();
	
				bullet_pos_x[i] += bullet_vel_x[i];
				bullet_pos_y[i] += bullet_vel_y[i];
	
				if (bullet_type[i] == 1) bullet_angle[i] += 0.2f;
				else bullet_angle[i] += 0.5f;
			}
		}


		animation_timer += 0.01f;

		glDisable(GL_TEXTURE_2D);
		
		glDisable(GL_LIGHTING);
	
		glDisable(GL_BLEND);
		glDisable(GL_ALPHA_TEST);
		glDisable(GL_DEPTH_TEST);

		glColor3f(0.5f + 0.5f * (float)(rand() % 100) / 100.0f,
			0.5f + 0.5f * (float)(rand() % 100) / 100.0f,
			0.5f + 0.5f * (float)(rand() % 100) / 100.0f);

		glLineWidth(4);
		
		glPushMatrix();
		glTranslatef(-0.3f, 0.6f, -0.95f);
		glScalef(0.001f, 0.001f, 0.001f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'Z');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '!');
		glPopMatrix();
	
		glColor3f(1,1,1);

		glLineWidth(2);

		glPushMatrix();
		glTranslatef(-0.5f, -0.8f, -0.95f);
		glScalef(0.0005f, 0.0005f, 0.0005f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'y');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();

		glColor3f(1,1,1);

		glPushMatrix();
		glTranslatef(-0.075f + -0.75f, -0.2f, -0.95f);
		glScalef(0.0004f, 0.0004f, 0.0004f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'p');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'i');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.075f + -0.75f + 0.375f, -0.2f, -0.95f);
		glScalef(0.0004f, 0.0004f, 0.0004f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'k');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.075f + -0.75f + 2.0f * 0.375f, -0.2f, -0.95f);
		glScalef(0.0004f, 0.0004f, 0.0004f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'm');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'c');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'k');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.075f + -0.75f + 3.0f * 0.375f, -0.2f, -0.95f);
		glScalef(0.0004f, 0.0004f, 0.0004f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'f');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glPopMatrix();

		glPushMatrix();
		glTranslatef(-0.075f + -0.75f + 4.0f * 0.375f, -0.2f, -0.95f);
		glScalef(0.0004f, 0.0004f, 0.0004f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'e');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glPopMatrix();
	
	}
	
	if (!keyboard['f']) player1_wait = 0;
	if (!keyboard['h']) player2_wait = 0;

	if ((keyboard['f'] && player1_wait == 0) || (keyboard['h'] && player2_wait == 0))
	{
		window = 1;

		player1_wait = 1;
		player2_wait = 1;

		total_distance_travelled = 0.0f;
		total_until_cease = 30.0f;
		boss_initiated = false;

		drag_speed = 0.002f;

		player1_x = -0.5f;
		player1_y = 0.1f;
		player2_x = -0.5f;
		player2_y = -0.1f;
		
		player1_delay = 0.0f;
		player2_delay = 0.0f;
		player1_ammo = 0.0f;
		player2_ammo = 0.0f;

		if (keyboard['f']) player1_lives = 3;
		if (keyboard['h']) player2_lives = 3;

		player1_powerup = 0;
		player2_powerup = 0;

		player1_score = 0;
		player2_score = 0;

		player1_invinsible = 120;
		player2_invinsible = 120;

		for (int i=0; i<MAX_BULLETS; i++)
		{
			bullet_type[i] = 0;
		}
	
		for (int i=0; i<MAX_BARRIERS; i++)
		{
			barrier_type[i] = 0;
		}
	
		for (int i=0; i<MAX_ENEMIES; i++)
		{
			enemy_type[i] = 0;
		}
	
		for (int i=0; i<MAX_POWERUPS; i++)
		{
			powerup_type[i] = 0;
		}
	}

	glutSwapBuffers();

	return;
};
	
void MainLoop()
{
	// Main loop here

	frames_per_second_counter++;

	if (frames_per_second_timer != time(0))
	{
		frames_per_second = frames_per_second_counter;
		frames_per_second_counter = 0;
		frames_per_second_timer = time(0);

		// constant points for staying alive
		//if (player1_lives > 0) player1_score += 1;
		//if (player2_lives > 0) player2_score += 1;

		// gets faster and faster!
		drag_speed *= 1.01f + 0.005f * (float)((int)((player1_score+player2_score) / 1000));
	}
	
	total_distance_travelled += drag_speed;

	if (total_distance_travelled > total_until_cease && boss_initiated == false)
	{
		boss_initiated = true;

		drag_speed *= 2.0f;

		for (int i=0; i<MAX_ENEMIES; i++)	
		{
			enemy_type[i] = 0;
		}

		for (int i=0; i<MAX_BARRIERS; i++)
		{
			barrier_type[i] = 0;
		}

		enemy_type[0] = 6; // boss	

		enemy_x[0] = 1.0f + 0.9f;
		enemy_y[0] = -0.55f;
		
		enemy_timer[0] = 0.0f;
	}	
	else if (total_distance_travelled < total_until_cease + 1.1f && boss_initiated == true)
	{
		if (player1_x > -0.5f) player1_x -= 2.0f * drag_speed;
		if (player2_x > -0.5f) player2_x -= 2.0f * drag_speed;

		for (int i=0; i<(int)sqrt((float)(MAX_BULLETS/3)); i++)
		{
			for (int j=0; j<(int)sqrt((float)(MAX_BULLETS/3)); j++)
			{
				bullet_type[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = 1; // like a shield
	
				bullet_pos_x[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = enemy_x[0] - 0.8f + (float)i/sqrt((float)(MAX_BULLETS/3));
				bullet_pos_y[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = 0.95f - 2.05f * (float)j/sqrt((float)(MAX_BULLETS/3));
	
				bullet_vel_x[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = 0.0f;
				bullet_vel_y[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = 0.0f;
			}
		}	
	}		

	if (total_distance_travelled > total_until_cease + 1.1f)
	{
		if (drag_speed > 0.0f)
		{
			drag_speed = 0.0f;
	
			for (int i=0; i<(int)sqrt((float)(MAX_BULLETS/3)); i++)
			{
				for (int j=0; j<(int)sqrt((float)(MAX_BULLETS/3)); j++)
				{
					bullet_type[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = 1; // like a shield
	
					bullet_pos_x[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = (float)i/sqrt((float)(MAX_BULLETS/3));
					bullet_pos_y[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = 0.95f - 2.05f * (float)j/sqrt((float)(MAX_BULLETS/3));
	
					bullet_vel_x[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = 0.0f;
					bullet_vel_y[i*(int)sqrt((float)(MAX_BULLETS/3))+j] = 0.0f;
				}
			}
		}
	}

	if (keyboard[27]) exit(1);

	if (player1_lives <= 0 && player2_lives <= 0)
	{
		window = 0;

		for (int i=0; i<MAX_BULLETS; i++)
		{
			bullet_type[i] = 0;
		}

		for (int i=0; i<MAX_ENEMIES; i++)
		{
			enemy_type[i] = 0;
			enemy_x[i] = 0.0f;
			enemy_y[i] = 0.0f;
		}
	}

	if (!keyboard['f'] && player1_lives <= 0) player1_wait = 0;
	if (!keyboard['h'] && player2_lives <= 0) player2_wait = 0;

	// Re-enter the game
	if (player1_lives <= 0 && keyboard['f'] && player1_wait == 0)
	{
		player1_wait = 1;

		player1_x = -0.5f;
		player1_y = 0.1f;
		
		player1_delay = 0.0f;
		player1_ammo = 0.0f;

		player1_lives = 3;

		player1_powerup = 0;

		player1_score = 0;

		player1_invinsible = 120;
	}
	if (player2_lives <= 0 && keyboard['h'] && player2_wait == 0)
	{
		player2_wait = 1;

		player2_x = -0.5f;
		player2_y = -0.1f;
		
		player2_delay = 0.0f;
		player2_ammo = 0.0f;
	
		player2_lives = 3;

		player2_powerup = 0;

		player2_score = 0;
	
		player2_invinsible = 120;
	}

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	// Draw here
	
	glEnable(GL_TEXTURE_2D);
	
	glEnable(GL_LIGHTING);

	glEnable(GL_BLEND);
	glEnable(GL_ALPHA_TEST);
	glEnable(GL_DEPTH_TEST);

	// stars
	for (int i=0; i<MAX_STARS; i++)
	{
		glBegin(GL_POINTS);

		glColor3f(star_red[i], star_green[i], star_blue[i]);

		glVertex3f(star_x[i], star_y[i], -1.0f);
	
		glEnd();

		star_x[i] -= drag_speed;

		if (star_x[i] < -1.0f)
		{
			star_x[i] = 1.0f;
			star_y[i] = -1.0f + 2.0f * (float)(rand() % 10000) / 10000.0f;
		}
	}

	// bullets
	for (int i=0; i<MAX_BULLETS; i++)
	{
		if (bullet_type[i] > 0)
		{
			if (bullet_type[i] == 1) glColor3f(1.0f,1.0f,0); // enemy bullet
			else if (bullet_type[i] == 2) glColor3f(1.0f,1.0f,1.0f); // regular bullet
			else if (bullet_type[i] == 3) glColor3f(1.0f,0.0f,0.0f); // spready bullet
			else if (bullet_type[i] == 4) glColor3f(0.0f,1.0f,1.0f); // speedy bullet
			
			glBegin(GL_TRIANGLES);
		
			glVertex3f(bullet_pos_x[i], bullet_pos_y[i], -1.0f);
			glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]), 
				bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]), -1.0f);
			glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+3.14f/6.0f), 
				bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+3.14f/6.0f), -1.0f);

			glVertex3f(bullet_pos_x[i], bullet_pos_y[i], -1.0f);
			glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+2.0f*3.14f/3.0f), 
				bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+2.0f*3.14f/3.0f), -1.0f);
			glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+2.0f*3.14f/3.0f+3.14f/6.0f), 
				bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+2.0f*3.14f/3.0f+3.14f/6.0f), -1.0f);

			glVertex3f(bullet_pos_x[i], bullet_pos_y[i], -1.0f);
			glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+4.0f*3.14f/3.0f), 
				bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+4.0f*3.14f/3.0f), -1.0f);
			glVertex3f(bullet_pos_x[i] + 0.02f * cos(bullet_angle[i]+4.0f*3.14f/3.0f+3.14f/6.0f), 
				bullet_pos_y[i] + 0.02f * sin(bullet_angle[i]+4.0f*3.14f/3.0f+3.14f/6.0f), -1.0f);
	
			glEnd();

			bullet_pos_x[i] += bullet_vel_x[i];
			bullet_pos_y[i] += bullet_vel_y[i];

			bullet_pos_x[i] -= drag_speed;

			if (bullet_type[i] == 1) bullet_angle[i] += 0.2f;
			else bullet_angle[i] += 0.5f;

			for (int j=0; j<MAX_BARRIERS; j++)
			{
				if (barrier_type[j] > 0 && (barrier_x[j][0] >= -1.0f || barrier_x[j][1] >= -1.0f || barrier_x[j][2] >= -1.0f))
				{
					if (TriangleCollision(bullet_pos_x[i], bullet_pos_y[i], barrier_x[j][0], barrier_y[j][0],
						barrier_x[j][1], barrier_y[j][1], barrier_x[j][2], barrier_y[j][2]))
					{
						bullet_type[i] = 0;
					}
				}
			}
	
			if (bullet_pos_y[i] > 1.0f) bullet_type[i] = 0;
			if (bullet_pos_y[i] < -1.0f) bullet_type[i] = 0;

			if (bullet_pos_x[i] > 1.0f) bullet_type[i] = 0;
			if (bullet_pos_x[i] < -1.0f) bullet_type[i] = 0;

			// your bullets destroy enemy bullets
			for (int j=0; j<MAX_BULLETS; j++)
			{
				if (bullet_type[i] > 1 && bullet_type[j] == 1 && pow(bullet_pos_x[i] - bullet_pos_x[j], 2.0f) + pow(bullet_pos_y[i] - bullet_pos_y[j], 2.0f) <= 0.005f)
				{
					bullet_type[i] = 0;
					bullet_type[j] = 0;
				}
			}

			for (int j=0; j<MAX_ENEMIES; j++)
			{
				if (bullet_type[i] > 1 && enemy_type[j] > 0 && pow(bullet_pos_x[i] - enemy_x[j], 2.0f) + pow(bullet_pos_y[i] - enemy_y[j], 2.0f) <= 0.005f)
				{
					if (enemy_type[j] == 6) // boss
					{
						system("play -q -v 0.99 Bomb2.mp3 &");

						if (player1_lives > 0) player1_score += 1000;
						if (player2_lives > 0) player2_score += 1000;
							
						total_distance_travelled = 0.0f;
						total_until_cease = 30.0f + 3.0f * (float)((int)((player1_score+player2_score) / 1000));
						boss_initiated = false;
		
						drag_speed = 0.002f;
					
						player1_delay = 0.0f;
						player2_delay = 0.0f;
					}
					else
					{
						system("play -q -v 0.99 Blop.mp3 &");
					}

					enemy_type[j] = 0;

					bullet_type[i] = 0;

					if (bullet_owner[i] == 1) 
					{
						player1_score += 5;
					}
					if (bullet_owner[i] == 2) 
					{
						player2_score += 5;
					}
				}
			}
		}
	}
	
	// barriers
	for (int i=0; i<MAX_BARRIERS; i++)
	{
		// creation
		if (barrier_type[i] == 0 && total_distance_travelled < total_until_cease - 10.0f)
		{
			barrier_type[i] = rand() % 5 + 1;

			barrier_x[i][0] = 3.0f + (float)(rand() % 3000) / 1000.0f;
			barrier_x[i][1] = barrier_x[i][0] + 0.2f + (float)(rand() % 2000) / 1000.0f;
			barrier_x[i][2] = barrier_x[i][0] + (barrier_x[i][1] - barrier_x[i][0]) * (float)(rand() % 1000) / 1000.0f;

			if (rand() % 2 == 0)
			{
				barrier_y[i][0] = 1.0f;
				barrier_y[i][1] = 1.0f;
				barrier_y[i][2] = 1.0f - (float)(rand() % 1000) / 1250.0f;// * (float)(rand() % 100) / 100.0f;
			}
			else 
			{
				barrier_y[i][0] = -1.0f;
				barrier_y[i][1] = -1.0f;
				barrier_y[i][2] = -1.0f + (float)(rand() % 1000) / 1250.0f;// * (float)(rand() % 100) / 100.0f;
			}
		}

		if (barrier_type[i] > 0)
		{
			if (barrier_type[i] == 1) glColor3f(0.5f,0.5f,0.5f);
			else if (barrier_type[i] == 2) glColor3f(0.5f,0.35f,0.35f);
			else if (barrier_type[i] == 3) glColor3f(0.35f,0.5f,0.35f);
			else if (barrier_type[i] == 4) glColor3f(0.35f,0.35f,0.5f);
			else if (barrier_type[i] == 5) glColor3f(0.35f,0.35f,0.35f);

			glBegin(GL_TRIANGLES);

			glVertex3f(barrier_x[i][0], barrier_y[i][0], -1.0f);
			glVertex3f(barrier_x[i][1], barrier_y[i][1], -1.0f);
			glVertex3f(barrier_x[i][2], barrier_y[i][2], -1.0f);

			glEnd();

			barrier_x[i][0] -= drag_speed;
			barrier_x[i][1] -= drag_speed;
			barrier_x[i][2] -= drag_speed;

			if (barrier_x[i][0] < -1.0f && barrier_x[i][1] < -1.0f && barrier_x[i][2] < -1.0f)
			{
				barrier_type[i] = 0;
			}
		}
	}

	bool temp_test;
	float temp_x, temp_y;

	// enemies
	for (int i=0; i<MAX_ENEMIES; i++)
	{
		// creation
		if (enemy_type[i] == 0 && total_distance_travelled < total_until_cease - 5.0f && i < 5 + 5 * ((int)((player1_score+player2_score) / 1000)))
		{
			enemy_type[i] = rand() % 5 + 1;

			enemy_x[i] = 2.0f + (float)(rand() % 1000) / 1000.0f;
			enemy_y[i] = ((float)(rand() % 2000) / 1000.0f) - 1.0f;
			
			enemy_timer[i] = (float)(rand() % 500) / 100.0f;

			temp_test = false;
			
			for (int j=0; j<MAX_BARRIERS; j++)
			{
				if (barrier_type[j] > 0 && (barrier_x[j][0] >= -1.0f || barrier_x[j][1] >= -1.0f || barrier_x[j][2] >= -1.0f))
				{
					if (TriangleCollision(enemy_x[i], enemy_y[i], barrier_x[j][0], barrier_y[j][0],
						barrier_x[j][1], barrier_y[j][1], barrier_x[j][2], barrier_y[j][2]))
					{
						temp_test = true;
					}
				}
			}

			if (temp_test == false)
			{
				// good!
			}
			else
			{
				enemy_type[i] = 0; // still not alive
			}
		}

		// behavior
		if (enemy_type[i] > 0)
		{
			enemy_timer[i] += 0.01f;

			if (enemy_type[i] == 1) // circular
			{
				glBegin(GL_TRIANGLES);

				glColor3f(0.5f,0,0);

				glVertex3f(enemy_x[i] + 0.03f, enemy_y[i], -1.0f);
				glVertex3f(enemy_x[i] + 0.01f, enemy_y[i] - 0.02f, -1.0f);
				glVertex3f(enemy_x[i] + 0.01f, enemy_y[i] + 0.02f, -1.0f);
				
				glVertex3f(enemy_x[i] - 0.03f, enemy_y[i], -1.0f);
				glVertex3f(enemy_x[i] - 0.01f, enemy_y[i] - 0.02f, -1.0f);
				glVertex3f(enemy_x[i] - 0.01f, enemy_y[i] + 0.02f, -1.0f);

				glColor3f(0.5f,0.5f,0.5f);

				glVertex3f(enemy_x[i], enemy_y[i] + 0.03f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] - 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.02f, enemy_y[i] - 0.01f, -1.0f);

				glEnd();
			}
			else if (enemy_type[i] == 2) // shaker
			{
				glBegin(GL_TRIANGLES);
			
				glColor3f(0,0.5f,0);

				glVertex3f(enemy_x[i], enemy_y[i], -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] + 0.01f, -1.0f);
				glVertex3f(enemy_x[i], enemy_y[i] + 0.02f, -1.0f);

				glVertex3f(enemy_x[i], enemy_y[i], -1.0f);
				glVertex3f(enemy_x[i] + 0.02f, enemy_y[i] + 0.01f, -1.0f);
				glVertex3f(enemy_x[i], enemy_y[i] + 0.02f, -1.0f);

				glColor3f(0.5f,0.5f,0.5f);

				glVertex3f(enemy_x[i], enemy_y[i] + 0.01f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] - 0.02f, -1.0f);
				glVertex3f(enemy_x[i] + 0.02f, enemy_y[i] - 0.02f, -1.0f);

				glEnd();
			}
			else if (enemy_type[i] == 3) // oscillator
			{
				glBegin(GL_TRIANGLES);
			
				glColor3f(0,0,1.0f);

				glVertex3f(enemy_x[i], enemy_y[i] + 0.03f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] + 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.02f, enemy_y[i] + 0.01f, -1.0f);
				
				glVertex3f(enemy_x[i], enemy_y[i] - 0.03f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] - 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.02f, enemy_y[i] - 0.01f, -1.0f);

				glColor3f(0.5f,0.5f,0.5f);

				glVertex3f(enemy_x[i], enemy_y[i] + 0.02f, -1.0f);
				glVertex3f(enemy_x[i] - 0.01f, enemy_y[i] - 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.01f, enemy_y[i] - 0.01f, -1.0f);

				glEnd();
			}
			else if (enemy_type[i] == 4) // speeder
			{
				glBegin(GL_TRIANGLES);

				glColor3f(0.0f,0.5f,0.5f);

				glVertex3f(enemy_x[i] + 0.03f, enemy_y[i] + 0.01f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i], -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] + 0.02f, -1.0f);
				
				glVertex3f(enemy_x[i] + 0.03f, enemy_y[i] - 0.01f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i], -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] - 0.02f, -1.0f);

				glColor3f(0.5f,0.5f,0.5f);

				glVertex3f(enemy_x[i] - 0.03f, enemy_y[i], -1.0f);
				glVertex3f(enemy_x[i] + 0.01f, enemy_y[i] - 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.01f, enemy_y[i] + 0.01f, -1.0f);

				glEnd();
			}
			else if (enemy_type[i] == 5) // shooter
			{
				glBegin(GL_TRIANGLES);

				glColor3f(0.5f,0.5f,0.5f);

				glVertex3f(enemy_x[i], enemy_y[i] - 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.02f, enemy_y[i] + 0.02f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] + 0.02f, -1.0f);

				glVertex3f(enemy_x[i], enemy_y[i] + 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.02f, enemy_y[i] - 0.02f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] - 0.02f, -1.0f);

				glColor3f(0.5f,0.0f,0.5f);

				glVertex3f(enemy_x[i], enemy_y[i] + 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.01f, enemy_y[i] - 0.01f, -1.0f);
				glVertex3f(enemy_x[i] - 0.01f, enemy_y[i] - 0.01f, -1.0f);

				glEnd();
			}
			else if (enemy_type[i] == 6) // boss / mega-oscillator
			{
				glBegin(GL_TRIANGLES);
			
				glColor3f(1.0f,1.0f,1.0f);

				glVertex3f(enemy_x[i], enemy_y[i] + 0.1f, -1.0f);
				glVertex3f(enemy_x[i] - 0.04f, enemy_y[i] + 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.04f, enemy_y[i] + 0.01f, -1.0f);
				
				glVertex3f(enemy_x[i], enemy_y[i] - 0.1f, -1.0f);
				glVertex3f(enemy_x[i] - 0.04f, enemy_y[i] - 0.01f, -1.0f);
				glVertex3f(enemy_x[i] + 0.04f, enemy_y[i] - 0.01f, -1.0f);

				glColor3f(0.5f + 0.5f * cos(enemy_timer[i] * enemy_timer[i] * 6.28f),0,0);

				glVertex3f(enemy_x[i], enemy_y[i] + 0.03f, -1.0f);
				glVertex3f(enemy_x[i] - 0.02f, enemy_y[i] - 0.02f, -1.0f);
				glVertex3f(enemy_x[i] + 0.02f, enemy_y[i] - 0.02f, -1.0f);

				glEnd();
			}
	
			temp_x = 0.0f;
			temp_y = 0.0f;

			if (enemy_type[i] == 1)
			{
				temp_x = 0.005f * (cos(enemy_timer[i] * 6.28f) + cos(enemy_timer[i] * 3.14f/2.0f));
				temp_y = 0.005f * (sin(enemy_timer[i] * 6.28f) + sin(enemy_timer[i] * 3.14f/2.0f));
			}
			else if (enemy_type[i] == 2)
			{
				temp_x += 0.02f * (((float)(rand() % 200) / 100.0f) - 1.0f);
				temp_y += 0.02f * (((float)(rand() % 200) / 100.0f) - 1.0f);
			}
			else if (enemy_type[i] == 3)
			{
				temp_y = 0.03f * (sin(2.0f * enemy_timer[i] * 6.28f) + cos(enemy_timer[i] * 6.28f));
			}
			else if (enemy_type[i] == 4)
			{
				temp_x -= 0.01f;
				temp_y = 0.015f * sin(2.0f * enemy_timer[i] * 6.28f);
			}
			else if (enemy_type[i] == 5)
			{
				temp_x = 0.0f;
				temp_y = 0.0f;

				if (enemy_timer[i] > 2.0f && enemy_x[i] <= 1.0f)
				{
					enemy_timer[i] = 0.0f;

					for (int j=0; j<MAX_BULLETS; j++)
					{
						if (bullet_type[j] == 0)
						{
							bullet_type[j] = 1; // enemy type

							bullet_owner[j] = 0;
		
							bullet_pos_x[j] = enemy_x[i];
							bullet_pos_y[j] = enemy_y[i];
			
							bullet_vel_x[j] = -0.001f;
							bullet_vel_y[j] = 0.001f;
			
							j = MAX_BULLETS + 1;
						}
					}

					for (int j=0; j<MAX_BULLETS; j++)
					{
						if (bullet_type[j] == 0)
						{
							bullet_type[j] = 1; // enemy type

							bullet_owner[j] = 0;
		
							bullet_pos_x[j] = enemy_x[i];
							bullet_pos_y[j] = enemy_y[i];
			
							bullet_vel_x[j] = -0.001f;
							bullet_vel_y[j] = -0.001f;
			
							j = MAX_BULLETS + 1;
						}
					}

					for (int j=0; j<MAX_BULLETS; j++)
					{
						if (bullet_type[j] == 0)
						{
							bullet_type[j] = 1; // enemy type

							bullet_owner[j] = 0;
		
							bullet_pos_x[j] = enemy_x[i];
							bullet_pos_y[j] = enemy_y[i];
			
							bullet_vel_x[j] = 0.001f;
							bullet_vel_y[j] = -0.001f;
			
							j = MAX_BULLETS + 1;
						}
					}
					
					for (int j=0; j<MAX_BULLETS; j++)
					{
						if (bullet_type[j] == 0)
						{
							bullet_type[j] = 1; // enemy type

							bullet_owner[j] = 0;
		
							bullet_pos_x[j] = enemy_x[i];
							bullet_pos_y[j] = enemy_y[i];
			
							bullet_vel_x[j] = 0.001f;
							bullet_vel_y[j] = 0.001f;
			
							j = MAX_BULLETS + 1;
						}
					}
				}
			}
			else if (enemy_type[i] == 6) // boss
			{
				temp_y = 0.04f * sin(enemy_timer[i] * 6.28f);

				if (rand() % (49 - 7 * ((int)((player1_score+player2_score) / 1000))>0?
					49 - 5 * ((int)((player1_score+player2_score) / 1000)):1) == 0)
				{
					system("play -q -v 0.99 GunSilencer.mp3 &");

					for (int j=0; j<MAX_BULLETS; j++)
					{
						if (bullet_type[j] == 0)
						{
							bullet_type[j] = 1; // enemy type

							bullet_owner[j] = 0;
		
							bullet_pos_x[j] = enemy_x[i];
							bullet_pos_y[j] = enemy_y[i];
			
							bullet_vel_x[j] = -0.03f;
							bullet_vel_y[j] = 0.03f - 0.06f * (float)(rand() % 100) / 100.0f;
			
							j = MAX_BULLETS + 1;
						}
					}
				}
			}

			temp_test = false;
			
			for (int j=0; j<MAX_BARRIERS; j++)
			{
				if (barrier_type[j] > 0 && (barrier_x[j][0] >= -1.0f || barrier_x[j][1] >= -1.0f || barrier_x[j][2] >= -1.0f))
				{
					if (TriangleCollision(enemy_x[i]+temp_x, enemy_y[i]+temp_y, barrier_x[j][0], barrier_y[j][0],
						barrier_x[j][1], barrier_y[j][1], barrier_x[j][2], barrier_y[j][2]))
					{
						temp_test = true;
					}
				}
			}

			if (temp_test == false)
			{
				enemy_x[i] += temp_x;
				enemy_y[i] += temp_y;
			}
			else
			{
				if (enemy_type[i] == 4) enemy_type[i] = 0; // special case! :D
			}

			if (enemy_y[i] > 1.0f) enemy_y[i] = 1.0f;
			if (enemy_y[i] < -1.0f) enemy_y[i] = -1.0f;

			enemy_x[i] -= drag_speed;

			if (enemy_x[i] < -1.0f)
			{
				enemy_type[i] = 0;
			}
		}
	}

	// powerups
	for (int i=0; i<MAX_POWERUPS; i++)
	{
		// creation
		if (powerup_type[i] == 0 && total_distance_travelled < total_until_cease - 5.0f)
		{
			if (rand() % 100 < 15)
			{
				powerup_type[i] = 1; // lives
			}
			else
			{
				powerup_type[i] = rand() % 2 + 2; // ammo
			}

			powerup_x[i] = 2.0f + (float)(rand() % 1000) / 1000.0f;
			powerup_y[i] = ((float)(rand() % 2000) / 1000.0f) - 1.0f;

			temp_test = false;
			
			for (int j=0; j<MAX_BARRIERS; j++)
			{
				if (barrier_type[j] > 0 && (barrier_x[j][0] >= -1.0f || barrier_x[j][1] >= -1.0f || barrier_x[j][2] >= -1.0f))
				{
					if (TriangleCollision(powerup_x[i], powerup_y[i], barrier_x[j][0], barrier_y[j][0],
						barrier_x[j][1], barrier_y[j][1], barrier_x[j][2], barrier_y[j][2]))
					{
						temp_test = true;
					}
				}
			}

			if (temp_test == false)
			{
				// good!
			}
			else
			{
				powerup_type[i] = 0; // still not alive
			}
		}

		if (powerup_type[i] > 0)
		{
			if (powerup_type[i] == 1) // life
			{
				glBegin(GL_QUADS);
	
				glColor3f(1,1,1);
				//glColor3f(0.75f + 0.25f * sin(powerup_color[i]*6.28f),
				//	0.75f + 0.25f * sin(powerup_color[i]*6.28f),
				//	0.75f + 0.25f * sin(powerup_color[i]*6.28f));
				
				glVertex3f(powerup_x[i]-0.03f, powerup_y[i]-0.03f, -1.0f);
				glVertex3f(powerup_x[i]-0.03f, powerup_y[i]+0.03f, -1.0f);
				glVertex3f(powerup_x[i]+0.03f, powerup_y[i]+0.03f, -1.0f);
				glVertex3f(powerup_x[i]+0.03f, powerup_y[i]-0.03f, -1.0f);

				//glColor3f(0,1,0);
				glColor3f(0.0f,0.75f + 0.25f * sin(powerup_color[i]*3.14f),0.0f);
		
				glVertex3f(powerup_x[i]-0.01f, powerup_y[i]-0.02f, -1.0f);
				glVertex3f(powerup_x[i]-0.01f, powerup_y[i]+0.02f, -1.0f);
				glVertex3f(powerup_x[i]+0.01f, powerup_y[i]+0.02f, -1.0f);
				glVertex3f(powerup_x[i]+0.01f, powerup_y[i]-0.02f, -1.0f);

				glVertex3f(powerup_x[i]-0.02f, powerup_y[i]-0.01f, -1.0f);
				glVertex3f(powerup_x[i]-0.02f, powerup_y[i]+0.01f, -1.0f);
				glVertex3f(powerup_x[i]+0.02f, powerup_y[i]+0.01f, -1.0f);
				glVertex3f(powerup_x[i]+0.02f, powerup_y[i]-0.01f, -1.0f);

				glEnd();
			}
			else if (powerup_type[i] == 2) // spreader
			{
				glBegin(GL_QUADS);
	
				glColor3f(1,1,1);
				//glColor3f(0.75f + 0.25f * sin(powerup_color[i]*6.28f),
				//	0.75f + 0.25f * sin(powerup_color[i]*6.28f),
				//	0.75f + 0.25f * sin(powerup_color[i]*6.28f));
				
				glVertex3f(powerup_x[i]-0.03f, powerup_y[i]-0.03f, -1.0f);
				glVertex3f(powerup_x[i]-0.03f, powerup_y[i]+0.03f, -1.0f);
				glVertex3f(powerup_x[i]+0.03f, powerup_y[i]+0.03f, -1.0f);
				glVertex3f(powerup_x[i]+0.03f, powerup_y[i]-0.03f, -1.0f);

				//glColor3f(1,0,0);
				glColor3f(0.75f + 0.25f * sin(powerup_color[i]*3.14f),0.0f,0.0f);
		
				glVertex3f(powerup_x[i]-0.01f, powerup_y[i], -1.0f);
				glVertex3f(powerup_x[i]-0.01f, powerup_y[i]+0.02f, -1.0f);
				glVertex3f(powerup_x[i]+0.01f, powerup_y[i]+0.02f, -1.0f);
				glVertex3f(powerup_x[i]+0.01f, powerup_y[i], -1.0f);
				
				glVertex3f(powerup_x[i]-0.02f, powerup_y[i]-0.02f, -1.0f);
				glVertex3f(powerup_x[i]-0.02f, powerup_y[i], -1.0f);
				glVertex3f(powerup_x[i]-0.01f, powerup_y[i], -1.0f);
				glVertex3f(powerup_x[i]-0.01f, powerup_y[i]-0.02f, -1.0f);

				glVertex3f(powerup_x[i]+0.01f, powerup_y[i]-0.02f, -1.0f);
				glVertex3f(powerup_x[i]+0.01f, powerup_y[i], -1.0f);
				glVertex3f(powerup_x[i]+0.02f, powerup_y[i], -1.0f);
				glVertex3f(powerup_x[i]+0.02f, powerup_y[i]-0.02f, -1.0f);

				glEnd();
			}
			else if (powerup_type[i] == 3) // speedy
			{
				glBegin(GL_QUADS);
	
				glColor3f(1,1,1);
				//glColor3f(0.75f + 0.25f * sin(powerup_color[i]*6.28f),
				//	0.75f + 0.25f * sin(powerup_color[i]*6.28f),
				//	0.75f + 0.25f * sin(powerup_color[i]*6.28f));
				
				glVertex3f(powerup_x[i]-0.03f, powerup_y[i]-0.03f, -1.0f);
				glVertex3f(powerup_x[i]-0.03f, powerup_y[i]+0.03f, -1.0f);
				glVertex3f(powerup_x[i]+0.03f, powerup_y[i]+0.03f, -1.0f);
				glVertex3f(powerup_x[i]+0.03f, powerup_y[i]-0.03f, -1.0f);

				//glColor3f(0,1,1);
				glColor3f(0.0f,0.75f + 0.25f * sin(powerup_color[i]*3.14f),0.75f + 0.25f * sin(powerup_color[i]*3.14f));
				
				glVertex3f(powerup_x[i]-0.02f, powerup_y[i]-0.01f, -1.0f);
				glVertex3f(powerup_x[i]-0.02f, powerup_y[i]+0.01f, -1.0f);
				glVertex3f(powerup_x[i]+0.02f, powerup_y[i]+0.01f, -1.0f);
				glVertex3f(powerup_x[i]+0.02f, powerup_y[i]-0.01f, -1.0f);


				glEnd();
			}

			powerup_color[i] += 0.1f;
	
			powerup_x[i] -= drag_speed;

			if (powerup_x[i] < -1.0f)
			{
				powerup_type[i] = 0;
			}
		}
	}
		
	// player1
	if (player1_lives > 0)
	{
		if (keyboard['w'])
		{
			player1_y += 0.01f;

			if (player1_y > 0.95f) player1_y = 0.95f;
		}
		if (keyboard['s'])
		{
			player1_y -= 0.01f;

			if (player1_y < -0.95f) player1_y = -0.95f;
		}
		if (keyboard['a'])
		{
			player1_x -= 0.01f;

			if (player1_x < -0.95f) player1_x = -0.95f;
		}
		if (keyboard['d'])
		{
			player1_x += 0.01f;

			if (player1_x > 0.95f) player1_x = 0.95f;
		}
		
		player1_delay -= 0.001f;
		if (player1_delay < 0.0f) player1_delay = 0.0f;

		//player1_ammo += 0.002f;
		//if (player1_ammo > 1.0f) player1_ammo = 1.0f;
		if (player1_ammo <= 0.0f) player1_powerup = 0;

		if (player1_invinsible > 0) player1_invinsible--;

		if (keyboard['f'] && player1_delay <= 0.0f)
		{
			if (player1_powerup == 0 || player1_ammo <= 0.0f)
			{
				system("play -q -v 0.99 BulletWhizzing.mp3 &");

				player1_delay = 0.03f;

				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 2;

						bullet_owner[i] = 1;
		
						bullet_pos_x[i] = player1_x;
						bullet_pos_y[i] = player1_y;
		
						bullet_vel_x[i] = 0.02f + drag_speed;
						bullet_vel_y[i] = 0.0f;
		
						i = MAX_BULLETS + 1;
					}
				}
			}	
			else if (player1_powerup == 2)
			{
				system("play -q -v 0.99 44Magnum.mp3 &");

				player1_delay = 0.02f;

				player1_ammo -= 0.1f / 2.0f;

				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 3;

						bullet_owner[i] = 1;
	
						bullet_pos_x[i] = player1_x;
						bullet_pos_y[i] = player1_y;
		
						bullet_vel_x[i] = 0.015f * 0.707f + drag_speed;
						bullet_vel_y[i] = -0.005f * 0.707f;
		
						i = MAX_BULLETS + 1;
					}
				}
		
				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 3;

						bullet_owner[i] = 1;
	
						bullet_pos_x[i] = player1_x;
						bullet_pos_y[i] = player1_y;
		
						bullet_vel_x[i] = 0.015f + drag_speed;
						bullet_vel_y[i] = 0.0f;
		
						i = MAX_BULLETS + 1;
					}
				}
	
				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 3;

						bullet_owner[i] = 1;
		
						bullet_pos_x[i] = player1_x;
						bullet_pos_y[i] = player1_y;
		
						bullet_vel_x[i] = 0.015f * 0.707f + drag_speed;
						bullet_vel_y[i] = 0.005f * 0.707f;
		
						i = MAX_BULLETS + 1;		
					}
				}
			}
			else if (player1_powerup == 3)
			{
				system("play -q -v 0.99 M4A1Single.mp3 &");

				player1_delay = 0.0067f;

				player1_ammo -= 0.033f / 2.0f;

				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 4;

						bullet_owner[i] = 1;
		
						bullet_pos_x[i] = player1_x;
						bullet_pos_y[i] = player1_y;
		
						bullet_vel_x[i] = 0.02f + drag_speed;
						bullet_vel_y[i] = 0.01f * (((float)(rand() % 200) / 100.0f) - 1.0f);
		
						i = MAX_BULLETS + 1;
					}
				}
			}
		}

		glBegin(GL_TRIANGLES);
		
		glColor3f(1.0f-pow(sin((float)player1_invinsible/60.0f * 62.8f),2.0f),0.0f,0.0f);
		
		glVertex3f(-0.05f + player1_x, 0.03f + player1_y, -1.0f);
		glVertex3f(-0.03f + player1_x, player1_y, -1.0f);
		glVertex3f(player1_x, 0.02f + player1_y, -1.0f);

		glVertex3f(-0.05f + player1_x, -0.03f + player1_y, -1.0f);
		glVertex3f(-0.03f + player1_x, player1_y, -1.0f);
		glVertex3f(player1_x, -0.02f + player1_y, -1.0f);

		glColor3f(0.5f-0.5f*pow(sin((float)player1_invinsible/60.0f * 62.8f),2.0f),
			0.5f-0.5f*pow(sin((float)player1_invinsible/60.0f * 62.8f),2.0f),
			0.5f-0.5f*pow(sin((float)player1_invinsible/60.0f * 62.8f),2.0f));

		glVertex3f(-0.04f + player1_x, 0.02f + player1_y, -1.0f);
		glVertex3f(-0.04f + player1_x, -0.02f + player1_y, -1.0f);
		glVertex3f(0.02f + player1_x, player1_y, -1.0f);

		glEnd();
	
		if (player1_powerup == 2)
		{
			glLineWidth(5);

			glBegin(GL_LINES);
	
			glColor3f(1,1,1);

			glVertex3f(-0.0375f + player1_x, player1_y, -1.0f);
			glVertex3f(0.0f + player1_x, player1_y, -1.0f);

			glEnd();

			glBegin(GL_LINES);

			glColor3f(1,0,0);

			glVertex3f(-0.0375f + player1_x, player1_y, -1.0f);
			glVertex3f(-0.0375f + player1_x + 0.0375f * player1_ammo, player1_y, -1.0f);

			glEnd();
		}
		else if (player1_powerup == 3)
		{
			glLineWidth(5);

			glBegin(GL_LINES);

			glColor3f(1,1,1);

			glVertex3f(-0.0375f + player1_x, player1_y, -1.0f);
			glVertex3f(0.0f + player1_x, player1_y, -1.0f);
	
			glEnd();

			glBegin(GL_LINES);

			glColor3f(0,1,1);

			glVertex3f(-0.0375f + player1_x, player1_y, -1.0f);
			glVertex3f(-0.0375f + player1_x + 0.0375f * player1_ammo, player1_y, -1.0f);

			glEnd();
		}

		for (int i=0; i<MAX_BARRIERS; i++)
		{
			if (barrier_type[i] > 0 && player1_invinsible <= 0 && (barrier_x[i][0] >= -1.0f || barrier_x[i][1] >= -1.0f || barrier_x[i][2] >= -1.0f))
			{
				if (TriangleCollision(player1_x, player1_y, barrier_x[i][0], barrier_y[i][0],
					barrier_x[i][1], barrier_y[i][1], barrier_x[i][2], barrier_y[i][2]))
				{
					system("play -q -v 0.99 MetroidDoor.mp3 &");

					player1_lives -= 1;

					player1_x = -0.95f;
					player1_y = 0.0f;

					player1_powerup = 0;

					player1_invinsible = 120;
				}
			}
		}

		for (int i=0; i<MAX_BULLETS; i++)
		{
			// only enemy bullets
			if (bullet_type[i] == 1 && player1_invinsible <= 0 && pow(player1_x - bullet_pos_x[i], 2.0f) + pow(player1_y - bullet_pos_y[i], 2.0f) <= 0.005f)
			{
				system("play -q -v 0.99 MetroidDoor.mp3 &");

				bullet_type[i] = 0;

				player1_lives -= 1;

				player1_x = -0.95f;
				player1_y = 0.0f;

				player1_powerup = 0;

				player1_invinsible = 120;
			}
		}

		for (int i=0; i<MAX_ENEMIES; i++)
		{
			if (enemy_type[i] > 0 && player1_invinsible <= 0 && pow(player1_x - enemy_x[i], 2.0f) + pow(player1_y - enemy_y[i], 2.0f) <= 0.005f)
			{
				system("play -q -v 0.99 MetroidDoor.mp3 &");

				enemy_type[i] = 0;

				player1_lives -= 1;

				player1_x = -0.95f;
				player1_y = 0.0f;

				player1_powerup = 0;

				player1_invinsible = 120;
			}
		}	

		for (int i=0; i<MAX_POWERUPS; i++)
		{
			if (powerup_type[i] > 0 && pow(player1_x - powerup_x[i], 2.0f) + pow(player1_y - powerup_y[i], 2.0f) <= 0.005f)
			{
				system("play -q -v 0.99 PowerUpRay.mp3 &");

				if (powerup_type[i] == 1) // extra life
				{
					player1_lives += 1;
				}
				else
				{
					player1_powerup = powerup_type[i];

					player1_ammo = 1.0f;
				}

				powerup_type[i] = 0;
			}
		}
	}
	
	// player2
	if (player2_lives > 0)
	{
		if (keyboard['i'])
		{
			player2_y += 0.01f;

			if (player2_y > 0.95f) player2_y = 0.95f;
		}
		if (keyboard['k'])
		{
			player2_y -= 0.01f;
			
			if (player2_y < -0.95f) player2_y = -0.95f;
		}
		if (keyboard['j'])
		{
			player2_x -= 0.01f;

			if (player2_x < -0.95f) player2_x = -0.95f;
		}
		if (keyboard['l'])
		{
			player2_x += 0.01f;

			if (player2_x > 0.95f) player2_x = 0.95f;
		}

		player2_delay -= 0.001f;
		if (player2_delay < 0.0f) player2_delay = 0.0f;

		//player2_ammo += 0.002f;
		//if (player2_ammo > 1.0f) player2_ammo = 1.0f;
		if (player2_ammo <= 0.0f) player2_powerup = 0;

		if (player2_invinsible > 0) player2_invinsible--;
		
		if (keyboard['h'] && player2_delay <= 0.0f)
		{
			if (player2_powerup == 0 || player2_ammo <= 0.0f)
			{
				system("play -q -v 0.99 BulletWhizzing.mp3 &");
			
				player2_delay = 0.03f;

				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 2;

						bullet_owner[i] = 2;
		
						bullet_pos_x[i] = player2_x;
						bullet_pos_y[i] = player2_y;
		
						bullet_vel_x[i] = 0.02f + drag_speed;
						bullet_vel_y[i] = 0.0f;
		
						i = MAX_BULLETS + 1;
					}
				}
			}
			else if (player2_powerup == 2)
			{	
				system("play -q -v 0.99 44Magnum.mp3 &");

				player2_delay = 0.02f;

				player2_ammo -= 0.1f / 2.0f;

				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 3;

						bullet_owner[i] = 2;
	
						bullet_pos_x[i] = player2_x;
						bullet_pos_y[i] = player2_y;
		
						bullet_vel_x[i] = 0.015f * 0.707f + drag_speed;
						bullet_vel_y[i] = -0.005f * 0.707f;
	
						i = MAX_BULLETS + 1;
					}
				}
		
				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 3;

						bullet_owner[i] = 2;
		
						bullet_pos_x[i] = player2_x;
						bullet_pos_y[i] = player2_y;
		
						bullet_vel_x[i] = 0.015f + drag_speed;
						bullet_vel_y[i] = 0.0f;
		
						i = MAX_BULLETS + 1;
					}
				}
	
				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 3;

						bullet_owner[i] = 2;
		
						bullet_pos_x[i] = player2_x;
						bullet_pos_y[i] = player2_y;
		
						bullet_vel_x[i] = 0.015f * 0.707f + drag_speed;
						bullet_vel_y[i] = 0.005f * 0.707f;
	
						i = MAX_BULLETS + 1;		
					}
				}
			}
			else if (player2_powerup == 3)
			{
				system("play -q -v 0.99 M4A1Single.mp3 &");

				player2_delay = 0.0067f;

				player2_ammo -= 0.033f / 2.0f;

				for (int i=0; i<MAX_BULLETS; i++)
				{
					if (bullet_type[i] == 0)
					{
						bullet_type[i] = 4;

						bullet_owner[i] = 1;
		
						bullet_pos_x[i] = player2_x;
						bullet_pos_y[i] = player2_y;
		
						bullet_vel_x[i] = 0.02f + drag_speed;
						bullet_vel_y[i] = 0.01f * (((float)(rand() % 200) / 100.0f) - 1.0f);
		
						i = MAX_BULLETS + 1;
					}
				}
			}			
		}

		glBegin(GL_TRIANGLES);
		
		glColor3f(0.0f,1.0f-pow(sin((float)player2_invinsible/60.0f * 62.8f),2.0f),
			1.0f-pow(sin((float)player2_invinsible/60.0f * 62.8f),2.0f));
		
		glVertex3f(-0.05f + player2_x, 0.03f + player2_y, -1.0f);
		glVertex3f(-0.03f + player2_x, player2_y, -1.0f);
		glVertex3f(player2_x, 0.02f + player2_y, -1.0f);

		glVertex3f(-0.05f + player2_x, -0.03f + player2_y, -1.0f);
		glVertex3f(-0.03f + player2_x, player2_y, -1.0f);
		glVertex3f(player2_x, -0.02f + player2_y, -1.0f);

		glColor3f(0.5f-0.5f*pow(sin((float)player2_invinsible/60.0f * 62.8f),2.0f),
			0.5f-0.5f*pow(sin((float)player2_invinsible/60.0f * 62.8f),2.0f),
			0.5f-0.5f*pow(sin((float)player2_invinsible/60.0f * 62.8f),2.0f));

		glVertex3f(-0.04f + player2_x, 0.02f + player2_y, -1.0f);
		glVertex3f(-0.04f + player2_x, -0.02f + player2_y, -1.0f);
		glVertex3f(0.02f + player2_x, player2_y, -1.0f);

		glEnd();
	
		if (player2_powerup == 2)
		{
			glLineWidth(5);

			glBegin(GL_LINES);

			glColor3f(1,1,1);

			glVertex3f(-0.0375f + player2_x, player2_y, -1.0f);
			glVertex3f(0.0f + player2_x, player2_y, -1.0f);
	
			glEnd();

			glBegin(GL_LINES);

			glColor3f(1,0,0);

			glVertex3f(-0.0375f + player2_x, player2_y, -1.0f);
			glVertex3f(-0.0375f + player2_x + 0.0375f * player2_ammo, player2_y, -1.0f);

			glEnd();
		}
		else if (player2_powerup == 3)
		{
			glLineWidth(5);

			glBegin(GL_LINES);

			glColor3f(1,1,1);

			glVertex3f(-0.0375f + player2_x, player2_y, -1.0f);
			glVertex3f(0.0f + player2_x, player2_y, -1.0f);

			glEnd();

			glBegin(GL_LINES);

			glColor3f(0,1,1);

			glVertex3f(-0.0375f + player2_x, player2_y, -1.0f);
			glVertex3f(-0.0375f + player2_x + 0.0375f * player2_ammo, player2_y, -1.0f);

			glEnd();
		}

		for (int i=0; i<MAX_BARRIERS; i++)
		{
			if (barrier_type[i] > 0 && player2_invinsible <= 0 && (barrier_x[i][0] >= -1.0f || barrier_x[i][1] >= -1.0f || barrier_x[i][2] >= -1.0f))
			{
				if (TriangleCollision(player2_x, player2_y, barrier_x[i][0], barrier_y[i][0],
					barrier_x[i][1], barrier_y[i][1], barrier_x[i][2], barrier_y[i][2]))
				{
					system("play -q -v 0.99 MetroidDoor.mp3 &");

					player2_lives -= 1;

					player2_x = -0.95f;
					player2_y = 0.0f;

					player2_powerup = 0;

					player2_invinsible = 120;
				}
			}
		}	

		for (int i=0; i<MAX_BULLETS; i++)
		{
			// only enemy bullets
			if (bullet_type[i] == 1 && player2_invinsible <= 0 && pow(player2_x - bullet_pos_x[i], 2.0f) + pow(player2_y - bullet_pos_y[i], 2.0f) <= 0.005f)
			{
				system("play -q -v 0.99 MetroidDoor.mp3 &");

				bullet_type[i] = 0;

				player2_lives -= 1;

				player2_x = -0.95f;
				player2_y = 0.0f;

				player2_powerup = 0;

				player2_invinsible = 120;
			}
		}

		for (int i=0; i<MAX_ENEMIES; i++)
		{
			if (enemy_type[i] > 0 && player2_invinsible <= 0 && pow(player2_x - enemy_x[i], 2.0f) + pow(player2_y - enemy_y[i], 2.0f) <= 0.005f)
			{
				system("play -q -v 0.99 MetroidDoor.mp3 &");

				enemy_type[i] = 0;

				player2_lives -= 1;

				player2_x = -0.95f;
				player2_y = 0.0f;

				player2_powerup = 0;

				player2_invinsible = 120;
			}
		}	

		for (int i=0; i<MAX_POWERUPS; i++)
		{
			if (powerup_type[i] > 0 && pow(player2_x - powerup_x[i], 2.0f) + pow(player2_y - powerup_y[i], 2.0f) <= 0.005f)
			{
				system("play -q -v 0.99 PowerUpRay.mp3 &");

				if (powerup_type[i] == 1) // extra life
				{
					player2_lives += 1;
				}
				else
				{
					player2_powerup = powerup_type[i];

					player2_ammo = 1.0f;
				}

				powerup_type[i] = 0;
			}
		}
	}


	glDisable(GL_TEXTURE_2D);
	
	glDisable(GL_LIGHTING);

	glDisable(GL_BLEND);
	glDisable(GL_ALPHA_TEST);
	glDisable(GL_DEPTH_TEST);

	glColor3f(1,1,1);

	glLineWidth(2);

	if (player1_lives <= 0)
	{
		glPushMatrix();
		glTranslatef(-0.3f, 0.90f, -0.95f);
		glScalef(0.0005f, 0.0005f, 0.0005f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '1');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();
	}
	if (player2_lives <= 0)
	{
		glPushMatrix();
		glTranslatef(-0.3f, -0.95f, -0.95f);
		glScalef(0.0005f, 0.0005f, 0.0005f);
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, '2');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 's');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'h');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'B');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'u');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'n');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'o');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'a');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 'r');
		glutStrokeCharacter(GLUT_STROKE_ROMAN, 't');
		glPopMatrix();
	}

	glLineWidth(3);
	
	glPushMatrix();
	glTranslatef(-0.95f, 0.90f, -0.95f);
	glScalef(0.0005f, 0.0005f, 0.0005f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '1');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_lives % 100) - (player1_lives % 10)) / 10 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((player1_lives % 10) + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '/');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '1');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
	if (player1_ammo > 0.0f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	if (player1_ammo > 0.25f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	if (player1_ammo > 0.5f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	if (player1_ammo > 0.75f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	if (player1_ammo >= 1.0f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '|');
	glPopMatrix();
	
	glPushMatrix();
	glTranslatef(-0.95f, -0.95f, -0.95f);
	glScalef(0.0005f, 0.0005f, 0.0005f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'L');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '2');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_lives % 100) - (player2_lives % 10)) / 10 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((player2_lives % 10) + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '/');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'A');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '2');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
	if (player2_ammo > 0.0f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	if (player2_ammo > 0.25f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	if (player2_ammo > 0.5f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	if (player2_ammo > 0.75f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	if (player2_ammo >= 1.0f) glutStrokeCharacter(GLUT_STROKE_ROMAN, '='); else glutStrokeCharacter(GLUT_STROKE_ROMAN, ' ');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '|');
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.70f, 0.90f, -0.95f);
	glScalef(0.0005f, 0.0005f, 0.0005f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '1');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_score % 100000) - (player1_score % 10000)) / 10000 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_score % 10000) - (player1_score % 1000)) / 1000 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_score % 1000) - (player1_score % 100)) / 100 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player1_score % 100) - (player1_score % 10)) / 10 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((player1_score % 10) + 48));
	glPopMatrix();

	glPushMatrix();
	glTranslatef(0.70f, -0.95f, -0.95f);
	glScalef(0.0005f, 0.0005f, 0.0005f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '2');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, ':');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_score % 100000) - (player2_score % 10000)) / 10000 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_score % 10000) - (player2_score % 1000)) / 1000 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_score % 1000) - (player2_score % 100)) / 100 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((player2_score % 100) - (player2_score % 10)) / 10 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((player2_score % 10) + 48));
	glPopMatrix();

/*
	glLineWidth(1);

	glColor3f(1,1,1);
	glPushMatrix();
	glTranslatef(-0.95f, 0.95f, -0.95f);
	glScalef(0.0003f, 0.0003f, 0.0003f);
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'F');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'P');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, 'S');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, '=');
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((frames_per_second % 10000) - (frames_per_second % 1000)) / 1000 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((frames_per_second % 1000) - (frames_per_second % 100)) / 100 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)(((frames_per_second % 100) - (frames_per_second % 10)) / 10 + 48));
	glutStrokeCharacter(GLUT_STROKE_ROMAN, (char)((frames_per_second % 10) + 48));
	glPopMatrix();
*/
	
	glutSwapBuffers();

	return;
};

void OpenGLSetupFunction()
{
	glutWarpPointer(WINDOW_WIDTH/2, WINDOW_HEIGHT/2);

	for (int i=0; i<256; i++) 
	{
		keyboard[i] = false;
		special_keyboard[i] = false;
	}

	for (int i=0; i<32; i++) joystick_button[i] = 0;
	joystick_axis->x = 0;
	joystick_axis->y = 0;
	joystick_axis->z = 0;

/*
	// If there is a joystick...
	if (glutDeviceGet(GLUT_HAS_JOYSTICK)) 
	{
		printf("Joystick Detected!\n");

		joystick_enabled = true;
	}
*/	


	// INITIALIZE HERE!!!

	SetupAll(0,0,WINDOW_WIDTH,WINDOW_HEIGHT);

	window = 0; // menu

	return;
};

void OpenGLDisplayFunction()
{
	return;
};

void OpenGLIdleFunction()
{
	if (window == 0)
	{
		MenuLoop();
	}
	else if (window == 1)
	{
		MainLoop();
	}

	return;	
};

void OpenGLKeyboardUpFunction(unsigned char key, int x, int y)
{
	keyboard[key] = false;

	mod_key = 0;

	return;
};

void OpenGLKeyboardFunction(unsigned char key, int x, int y)
{
	keyboard[key] = true;

	mod_key = glutGetModifiers(); 

	return;
};

void OpenGLSpecialKeyboardFunction(int key, int x, int y)
{
	special_keyboard[key] = true;

	return;
};	

void OpenGLSpecialKeyboardUpFunction(int key, int x, int y)
{
	special_keyboard[key] = false;

	return;
};

// GLUT in Linux does support joystick detection but not input.
// GLUT in Windows supports both
void OpenGLJoystickFunction(unsigned int button, int x, int y, int z)
{
	joystick_axis->x = x;
	joystick_axis->y = y;
	joystick_axis->z = z;

	// Bitwise AND
	joystick_button[0] = button & 0x0001;
	joystick_button[1] = button & 0x0002;
	joystick_button[2] = button & 0x0004;
	joystick_button[3] = button & 0x0008;
	joystick_button[4] = button & 0x0010;
	joystick_button[5] = button & 0x0020;
	joystick_button[6] = button & 0x0040;
	joystick_button[7] = button & 0x0080;
	joystick_button[8] = button & 0x0100;
	joystick_button[9] = button & 0x0200;
	joystick_button[10] = button & 0x0400;
	joystick_button[11] = button & 0x0800;

	return;
};

void OpenGLMouseFunction(int button, int state, int x, int y)
{
	mouse->button = button;
	mouse->state = state;
	mouse->x = x;
	mouse->y = y;

	if (mouse->button == 0 && mouse->state == GLUT_DOWN) action_button[0] = true;
	if (mouse->button == 0 && mouse->state == GLUT_UP) action_button[0] = false;

	if (mouse->button == 1 && mouse->state == GLUT_DOWN) action_button[1] = true;
	if (mouse->button == 1 && mouse->state == GLUT_UP) action_button[1] = false;

	if (mouse->button == 2 && mouse->state == GLUT_DOWN) action_button[2] = true;
	if (mouse->button == 2 && mouse->state == GLUT_UP) action_button[2] = false;

	if (mouse->button == 3 && mouse->state == GLUT_DOWN) action_button[3] += 2;
	if (mouse->button == 3 && mouse->state == GLUT_UP) action_button[3] -= 1;

	if (mouse->button == 4 && mouse->state == GLUT_DOWN) action_button[4] += 2;
	if (mouse->button == 4 && mouse->state == GLUT_UP) action_button[4] -= 1;

	if (mouse->button == 5 && mouse->state == GLUT_DOWN) action_button[5] += 2;
	if (mouse->button == 5 && mouse->state == GLUT_UP) action_button[5] -= 1;

	if (mouse->button == 6 && mouse->state == GLUT_DOWN) action_button[6] += 2;
	if (mouse->button == 6 && mouse->state == GLUT_UP) action_button[6] -= 1;

	for (int i=3; i<7; i++)
	{
		if (action_button[i] > 4) action_button[i] = 4;
		else if (action_button[i] < 0) action_button[i] = 0;
	}
	 
	return;
};

void OpenGLMotionFunction(int x, int y)
{
	mouse->x = x;
	mouse->y = y;
	 
	return;
};

void OpenGLPassiveMotionFunction(int x, int y)
{
	mouse->x = x;
	mouse->y = y;

	return;
};

void my_randomize()
{
	int stime = 0;
	long ltime = 0;
	ltime = time(NULL);
	stime = (unsigned)ltime/2;
	srand(stime);
};

int main(int argc, char **argv)
{
	my_randomize();

	camera_pos = new _Point();
	camera_rot = new _Point();

	joystick_axis = new _Joystick();
	mouse = new _Mouse();



	glutInit(&argc, argv);

	glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);

	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

	glutCreateWindow("Zapper");
	glutFullScreen();
	glutSetCursor(GLUT_CURSOR_NONE); 

	glutDisplayFunc(OpenGLDisplayFunction);
	glutIdleFunc(OpenGLIdleFunction);
	glutKeyboardFunc(OpenGLKeyboardFunction);
	glutKeyboardUpFunc(OpenGLKeyboardUpFunction);
	glutSpecialFunc(OpenGLSpecialKeyboardFunction);
	glutSpecialUpFunc(OpenGLSpecialKeyboardUpFunction);
	glutJoystickFunc(OpenGLJoystickFunction, 50);
	glutMouseFunc(OpenGLMouseFunction);
	glutMotionFunc(OpenGLMotionFunction);
	glutPassiveMotionFunc(OpenGLPassiveMotionFunction);

	OpenGLSetupFunction();


   	glutMainLoop();


	delete camera_pos;
	delete camera_rot;

	delete joystick_axis;
	delete mouse;


	// THESE DELETE'S DONT HAPPEN!!!  Figure out why later....

	return 0;
}


